# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Cortex - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""
Cortex - your AI study companion, as a native desktop app.

Runs in its own window (like Lumina) using the Microsoft Edge WebView2 runtime,
which gives it a *secure context*, so the microphone, voice tutor and speech work,
and your data (notes, decks, progress) persists in a local profile beside this file.

One-time setup:
    pip install pywebview
Launch:
    double-click  Cortex.bat
    or run:       pythonw cortex_app.py     (use 'python' to see errors)

Note (Windows): rendering uses the Edge WebView2 runtime, preinstalled on Windows 11
and most updated Windows 10 systems. If the window looks broken, install the free
"WebView2 Runtime" from Microsoft and relaunch.
"""

import os
import sys
import threading
import http.server
import socketserver

try:
    import webview  # pywebview
except ImportError:
    sys.stderr.write(
        "\n[Cortex] pywebview is not installed.\n"
        "Run this once:\n    pip install pywebview\n"
        "then launch Cortex again.\n\n"
    )
    sys.exit(1)

FROZEN = getattr(sys, "frozen", False)
BASE_DIR = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
if FROZEN:
    APP_HOME = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "Cortex")
else:
    APP_HOME = BASE_DIR
# A fixed port keeps the origin stable so IndexedDB/localStorage persist between launches.
PORT = 8766
STORAGE = os.path.join(APP_HOME, ".cortex-store")


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)

    def end_headers(self):
        # Never cache, so edits to the app files always show on the next open.
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        super().end_headers()

    def log_message(self, *args):
        pass  # stay quiet


def serve():
    socketserver.ThreadingTCPServer.allow_reuse_address = True
    with socketserver.ThreadingTCPServer(("127.0.0.1", PORT), Handler) as httpd:
        httpd.serve_forever()


def main():
    os.makedirs(STORAGE, exist_ok=True)
    threading.Thread(target=serve, daemon=True).start()
    webview.create_window(
        "Cortex · AI Study Companion",
        f"http://127.0.0.1:{PORT}/index.html",
        width=1280,
        height=860,
        min_size=(390, 600),
    )
    # private_mode=False + a fixed storage_path => your study data is saved between sessions.
    webview.start(private_mode=False, storage_path=STORAGE)


if __name__ == "__main__":
    main()
