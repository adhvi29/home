/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * Cortex - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ===========================================================
   app.js, UI, routing, and glue for Cortex.
   Ties together db / srs / nlp / gamify into a single-page app.
   =========================================================== */
(function () {
  const { db, srs, nlp, game } = window.Cortex;

  // ---------- tiny helpers ----------
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const view = $("#view");
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const fmtDate = (ts) => new Date(ts).toLocaleDateString(undefined, { month: "short", day: "numeric" });
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  const plural = (n, w) => `${n} ${w}${n === 1 ? "" : "s"}`;

  const DECK_COLORS = ["#6d5efc", "#00b894", "#ff6a88", "#0ea5e9", "#f59e0b", "#a855f7", "#ec4899", "#14b8a6"];
  const THEMES = [
    { id: "aurora", name: "Aurora", c1: "#6d5efc", c2: "#00d4ff", price: 0 },
    { id: "sunset", name: "Sunset", c1: "#ff6a88", c2: "#ffb347", price: 150 },
    { id: "forest", name: "Forest", c1: "#00b894", c2: "#7bed9f", price: 150 },
    { id: "rose", name: "Rose Quartz", c1: "#ec4899", c2: "#a78bfa", price: 200 },
    { id: "ember", name: "Ember", c1: "#f7971e", c2: "#ff4e50", price: 200 },
    { id: "ocean", name: "Ocean", c1: "#2193b0", c2: "#6dd5ed", price: 250 },
    { id: "neon", name: "Neon Mint", c1: "#00f5a0", c2: "#00d9f5", price: 300 },
    { id: "candy", name: "Candy", c1: "#fc466b", c2: "#3f5efb", price: 350 },
  ];

  const app = {
    view: "dashboard", currentDeck: null, studySession: null, quiz: null,
    pendingQuiz: null, chat: [], chatContext: "all", _focusInt: null,
    focus: { minutes: 25, remaining: 25 * 60, total: 25 * 60, running: false },
    _assistantCards: null, _assistantQuiz: null, lastTopic: null, _lastMap: null,
  };

  // ---------- data access ----------
  const getDecks = () => db.getAll("decks");
  const getCards = (deckId) => db.getAllByIndex("cards", "deckId", deckId);
  const getAllCards = () => db.getAll("cards");
  const getNotes = () => db.getAll("notes");
  const getFiles = () => db.getAll("files");

  // file object-URL cache
  const urlCache = new Map();
  function fileURL(rec) {
    if (!rec) return "";
    if (urlCache.has(rec.id)) return urlCache.get(rec.id);
    const u = URL.createObjectURL(rec.blob);
    urlCache.set(rec.id, u);
    return u;
  }
  async function saveFile(file) {
    const kind = file.type.startsWith("image/") ? "photo" : "document";
    let text = "";
    if (kind === "document") { try { text = await window.Cortex.reader.readFileText(file); } catch (e) { console.warn("[reader]", e); } }
    const rec = { id: uid(), name: file.name, type: file.type, size: file.size, kind, text, blob: file, createdAt: Date.now() };
    await db.put("files", rec);
    return rec;
  }

  // ---------- reward feedback ----------
  function applyEvents(ev, opts = {}) {
    if (!ev) return;
    updateChrome();
    pulseXp();
    const celebrate = ev.levelUps?.length || ev.badges?.length || opts.confetti;
    if (celebrate) confetti(ev.levelUps?.length ? 1.4 : 1);
    (ev.levelUps || []).forEach((l) =>
      toast({ icon: "⭐", title: `Level ${l}!`, text: "Keep the momentum going." })
    );
    (ev.badges || []).forEach((b) =>
      toast({ icon: b.emoji, title: `Badge: ${b.name}`, text: `+${b.coins} coins · ${b.desc}` })
    );
    if (ev.perfect) toast({ icon: "🌟", title: "Perfect score!", text: "Flawless quiz, bonus XP." });
    if (!ev.levelUps?.length && !ev.badges?.length && ev.message && !opts.silent)
      toast({ icon: "✅", title: ev.message, text: `+${ev.xp} XP` });
  }
  function pulseXp() {
    $("#topXp")?.parentElement?.animate(
      [{ transform: "scale(1)" }, { transform: "scale(1.16)" }, { transform: "scale(1)" }],
      { duration: 420, easing: "ease-out" }
    );
  }

  // ---------- chrome (sidebar + topbar) ----------
  function updateChrome() {
    const s = game.state;
    const li = game.levelInfo(s.xp);
    $("#sideLevelNum").textContent = "Lv " + li.level;
    $("#sideXp").textContent = `${li.into} / ${li.span} XP`;
    $("#sideRing").style.setProperty("--p", li.progress);
    $("#sideCoins").textContent = s.coins;
    $("#topStreak").textContent = s.streak;
    $("#topXp").textContent = s.xp;
    $("#topCoins").textContent = s.coins;
    const mc = $("#mTopCoins"); if (mc) mc.textContent = s.coins;
  }

  function applyTheme() {
    const root = document.documentElement;
    root.dataset.theme = game.state.mode || "dark";
    const t = THEMES.find((x) => x.id === game.state.activeTheme) || THEMES[0];
    root.style.setProperty("--accent-1", t.c1);
    root.style.setProperty("--accent-2", t.c2);
  }

  // ---------- toasts ----------
  function toast({ icon = "✨", title, text }) {
    const el = document.createElement("div");
    el.className = "toast";
    el.innerHTML = `<div class="t-ico">${icon}</div><div class="t-body"><strong>${esc(title)}</strong>${text ? `<span>${esc(text)}</span>` : ""}</div>`;
    $("#toasts").appendChild(el);
    setTimeout(() => { el.classList.add("out"); setTimeout(() => el.remove(), 300); }, 3200);
  }

  // ---------- confetti ----------
  function confetti(power = 1) {
    const c = $("#confetti"), ctx = c.getContext("2d");
    c.width = innerWidth; c.height = innerHeight;
    const cs = getComputedStyle(document.documentElement);
    const colors = [cs.getPropertyValue("--accent-1"), cs.getPropertyValue("--accent-2"), "#ffd166", "#fb7185", "#34d399"];
    const N = Math.round(130 * power);
    const P = Array.from({ length: N }, () => ({
      x: Math.random() * c.width, y: -20 - Math.random() * c.height * 0.3,
      r: 4 + Math.random() * 6, vx: -2 + Math.random() * 4, vy: 2 + Math.random() * 5,
      rot: Math.random() * 6, vr: -0.2 + Math.random() * 0.4,
      color: colors[(Math.random() * colors.length) | 0],
    }));
    let frame = 0;
    cancelAnimationFrame(app._confettiRAF);
    const tick = () => {
      ctx.clearRect(0, 0, c.width, c.height);
      frame++;
      P.forEach((p) => {
        p.vy += 0.07; p.x += p.vx; p.y += p.vy; p.rot += p.vr;
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
        ctx.globalAlpha = Math.max(0, 1 - frame / 170);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.r / 2, -p.r / 2, p.r, p.r * 1.6);
        ctx.restore();
      });
      if (frame < 170) app._confettiRAF = requestAnimationFrame(tick);
      else ctx.clearRect(0, 0, c.width, c.height);
    };
    tick();
  }

  // ---------- mind map (SVG) ----------
  const MAP_PALETTE = ["#6d5efc", "#00b894", "#ff6a88", "#0ea5e9", "#f59e0b", "#a855f7", "#ec4899", "#14b8a6"];
  function mindmapSVG(data, { w = 700, h = 440 } = {}) {
    const cx = w / 2, cy = h / 2;
    const branches = data.branches || [];
    const n = Math.max(branches.length, 1);
    const R = Math.min(w, h) * 0.36;
    const cs = getComputedStyle(document.documentElement);
    const a1 = (cs.getPropertyValue("--accent-1") || "#6d5efc").trim();
    const a2 = (cs.getPropertyValue("--accent-2") || "#00d4ff").trim();
    let edges = "", nodes = "";
    branches.forEach((b, i) => {
      const ang = (-90 + i * (360 / n)) * Math.PI / 180;
      const bx = cx + Math.cos(ang) * R, by = cy + Math.sin(ang) * (R * 0.82);
      const col = MAP_PALETTE[i % MAP_PALETTE.length];
      edges += `<path d="M ${cx} ${cy} Q ${(cx + bx) / 2} ${cy} ${bx} ${by}" stroke="${col}" stroke-width="2.5" fill="none" opacity="0.55"/>`;
      const raw = b.label || "";
      const label = raw.length > 24 ? raw.slice(0, 22) + "…" : raw;
      const pw = Math.max(58, label.length * 7.6 + 22);
      nodes += `<g transform="translate(${bx},${by})">
        <rect x="${-pw / 2}" y="-15" width="${pw}" height="30" rx="15" fill="${col}26" stroke="${col}" stroke-width="1.5"/>
        <text x="0" y="4.5" text-anchor="middle" font-size="13" font-weight="600" fill="${cs.getPropertyValue("--text").trim()}">${esc(label)}</text></g>`;
    });
    const cw = Math.max(96, (data.center || "").length * 9.5 + 30);
    const center = `<g transform="translate(${cx},${cy})">
      <rect x="${-cw / 2}" y="-23" width="${cw}" height="46" rx="14" fill="url(#mmg)"/>
      <text x="0" y="6" text-anchor="middle" font-size="16" font-weight="800" fill="#fff">${esc(data.center || "Topic")}</text></g>`;
    return `<svg class="mindmap" viewBox="0 0 ${w} ${h}" width="100%" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Mind map of ${esc(data.center || "")}">
      <defs><linearGradient id="mmg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a1}"/><stop offset="1" stop-color="${a2}"/></linearGradient></defs>
      ${edges}${nodes}${center}</svg>`;
  }

  // ---------- modal ----------
  function openModal(html, opts = {}) {
    const root = $("#modal");
    root.innerHTML = `<div class="modal-scrim"></div><div class="modal ${opts.lg ? "lg" : ""}">${html}</div>`;
    root.classList.add("open"); root.setAttribute("aria-hidden", "false");
    const close = () => closeModal();
    if (!opts.persistent) $(".modal-scrim", root).addEventListener("click", close);
    return $(".modal", root);
  }
  function closeModal() {
    const root = $("#modal");
    root.classList.remove("open"); root.setAttribute("aria-hidden", "true"); root.innerHTML = "";
  }
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeModal(); });

  function confirmDialog(title, body, okLabel = "Confirm", danger = false) {
    return new Promise((res) => {
      const m = openModal(`
        <div class="modal-head"><h3>${esc(title)}</h3></div>
        <p style="color:var(--text-dim);margin:0 0 20px;line-height:1.55">${body}</p>
        <div class="modal-foot">
          <button class="btn ghost" data-x>Cancel</button>
          <button class="btn ${danger ? "danger" : ""}" data-ok>${esc(okLabel)}</button>
        </div>`);
      $("[data-x]", m).onclick = () => { closeModal(); res(false); };
      $("[data-ok]", m).onclick = () => { closeModal(); res(true); };
    });
  }

  // ===========================================================
  //  ROUTER
  // ===========================================================
  const TITLES = {
    dashboard: ["Dashboard", "Welcome back, let's learn something."],
    decks: ["Flashcards", "Your decks and spaced-repetition reviews."],
    deckDetail: ["Deck", ""],
    study: ["Review", "Rate how well you knew each card."],
    quiz: ["Quiz", "Test yourself and earn bonus XP."],
    assistant: ["Study Assistant", "Your offline AI, summaries, quizzes & flashcards from your notes."],
    tutor: ["Live Tutor", "Voice session + shared whiteboard, work problems through together."],
    notes: ["Notes", "Capture ideas and attach photos or documents."],
    library: ["Library", "Every photo and document you've added."],
    achievements: ["Achievements", "Badges, levels and your study stats."],
    store: ["Rewards Shop", "Spend coins on themes and manage your data."],
  };

  function setView(name) {
    stopFocus();
    if (name !== "tutor") stopTutor();
    app.view = name;
    $$(".nav-item").forEach((b) => b.classList.toggle("active", b.dataset.view === name));
    const [t, sub] = TITLES[name] || ["Cortex", ""];
    $("#pageTitle").textContent = t;
    $("#pageSub").textContent = sub;
    closeSidebar();
    view.scrollTop = 0; $(".main").scrollTop = 0;
    (RENDER[name] || RENDER.dashboard)();
    updateChrome();
  }

  // ===========================================================
  //  VIEWS
  // ===========================================================
  const RENDER = {};

  // ---------- Dashboard ----------
  RENDER.dashboard = async () => {
    const s = game.state;
    const li = game.levelInfo(s.xp);
    const cards = await getAllCards();
    const due = cards.filter((c) => srs.isDue(c)).length;
    const mastered = cards.filter((c) => srs.mastery(c) >= 80).length;
    const goalPct = clamp(Math.round((s.todayReviews / Math.max(1, s.dailyGoal)) * 100), 0, 100);
    const hour = new Date().getHours();
    const greet = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
    const recent = game.BADGES.filter((b) => s.badges.includes(b.id)).slice(-4);

    view.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:18px">
        <div class="card hero">
          <h2>${greet} 👋</h2>
          <p>${due ? `You have <b>${plural(due, "card")}</b> due for review. A few minutes now beats an hour of cramming later.` : "You're all caught up on reviews. Add new material or generate a quiz to keep learning."}</p>
          <div class="btn-row">
            <button class="btn" data-go="review">${due ? "Start review" : "Browse decks"}
              <svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
            <button class="btn ghost" data-view="assistant">Ask the assistant</button>
          </div>
        </div>

        <div class="grid cols-4">
          <div class="card ring-wrap">
            <div class="ring-stack"><div class="ring" style="--p:${li.progress}"></div>
              <div class="ring-inner"><div class="lvl">${li.level}</div><div class="lbl">Level</div></div></div>
            <div><div class="value" style="font-size:18px">${li.into}/${li.span}</div>
              <div class="label" style="margin-top:2px">${li.toNext} XP to next</div></div>
          </div>
          ${statCard("Day streak", s.streak, "🔥", s.streak ? "Best: " + s.bestStreak : "Study today to start one")}
          ${statCard("Due today", due, "📆", due ? "Ready to review" : "Nothing due, nice!")}
          ${statCard("Cards mastered", mastered, "🧠", plural(cards.length, "card") + " total")}
        </div>

        <div class="grid cols-2">
          <div class="card" style="padding:20px">
            <div class="section-head"><h2>Daily goal</h2><span class="sub">${s.todayReviews} / ${s.dailyGoal} reviews</span></div>
            <div class="goal-row"><div class="bar"><span style="width:${goalPct}%"></span></div><b>${goalPct}%</b></div>
            <p style="color:var(--text-dim);font-size:13px;margin:14px 0 0">${goalPct >= 100 ? "🎉 Goal smashed for today!" : "Keep going, consistency compounds."}</p>
          </div>
          ${focusCard()}
        </div>

        <div>
          <div class="section-head"><h2>Quick actions</h2></div>
          <div class="quick-actions">
            ${qa("decks", "📇", "New flashcards", "Build a deck")}
            ${qa("quiz", "🧩", "Generate quiz", "Test yourself")}
            ${qa("library", "📎", "Add material", "Photos & docs")}
            ${qa("notes", "✍️", "Write a note", "Capture ideas")}
          </div>
        </div>

        <div>
          <div class="section-head"><h2>Recent achievements</h2><span class="sub" data-view="achievements" style="cursor:pointer">View all →</span></div>
          ${recent.length ? `<div class="grid cols-4">${recent.map(badgeCard).join("")}</div>`
            : `<div class="card empty"><div style="font-size:38px">🏅</div><h3>No badges yet</h3><p>Review cards, take quizzes and build streaks to unlock achievements.</p></div>`}
        </div>
      </div>`;

    $("[data-go='review']").onclick = async () => {
      const decks = await getDecks();
      if (!decks.length) return setView("decks");
      const allCards = await getAllCards();
      const target = decks.find((d) => allCards.some((c) => c.deckId === d.id && srs.isDue(c))) || decks[0];
      openDeck(target.id);
    };
    wireFocus();
  };

  const statCard = (label, value, icon, sub) => `
    <div class="card stat-card">
      <div class="label">${icon} ${label}</div>
      <div class="value">${value}</div>
      <div class="label" style="font-weight:500;color:var(--text-faint)">${sub}</div>
    </div>`;
  const qa = (viewName, icon, title, sub) => `
    <button class="qa" data-view="${viewName}"><div class="qa-ico">${icon}</div>
      <div><strong>${title}</strong><br><span>${sub}</span></div></button>`;

  // ---------- Focus timer (Pomodoro) ----------
  function focusCard() {
    const f = app.focus;
    const p = Math.round(((f.total - f.remaining) / f.total) * 100);
    return `
      <div class="card" style="padding:20px">
        <div class="section-head"><h2>Focus timer</h2><span class="sub">Pomodoro · earn XP</span></div>
        <div style="display:flex;align-items:center;gap:20px">
          <div class="ring-stack"><div class="ring" id="focusRing" style="--p:${p}"></div>
            <div class="ring-inner"><div class="lvl" id="focusTime" style="font-size:20px">${mmss(f.remaining)}</div></div></div>
          <div style="flex:1">
            <div style="display:flex;gap:6px;margin-bottom:12px">
              ${[25, 50, 15, 5].map((m) => `<button class="chip" data-fmin="${m}" ${f.minutes === m ? 'style="border-color:var(--accent-1);color:var(--text)"' : ""}>${m}m</button>`).join("")}
            </div>
            <div style="display:flex;gap:8px">
              <button class="btn sm" id="focusToggle">${f.running ? "Pause" : "Start"}</button>
              <button class="btn ghost sm" id="focusReset">Reset</button>
            </div>
          </div>
        </div>
      </div>`;
  }
  const mmss = (s) => `${String((s / 60) | 0).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
  function wireFocus() {
    const toggle = $("#focusToggle"); if (!toggle) return;
    toggle.onclick = () => (app.focus.running ? pauseFocus() : startFocus());
    $("#focusReset").onclick = () => { pauseFocus(); app.focus.remaining = app.focus.total; refreshFocus(); };
    $$("[data-fmin]").forEach((b) => (b.onclick = () => {
      pauseFocus(); app.focus.minutes = +b.dataset.fmin; app.focus.total = app.focus.minutes * 60;
      app.focus.remaining = app.focus.total; if (app.view === "dashboard") RENDER.dashboard();
    }));
  }
  function refreshFocus() {
    const t = $("#focusTime"), r = $("#focusRing");
    if (t) t.textContent = mmss(app.focus.remaining);
    if (r) r.style.setProperty("--p", Math.round(((app.focus.total - app.focus.remaining) / app.focus.total) * 100));
  }
  function startFocus() {
    if (app.focus.running) return;
    app.focus.running = true;
    const tg = $("#focusToggle"); if (tg) tg.textContent = "Pause";
    app._focusInt = setInterval(() => {
      app.focus.remaining--;
      if (app.focus.remaining <= 0) return completeFocus();
      refreshFocus();
    }, 1000);
  }
  function pauseFocus() {
    app.focus.running = false; clearInterval(app._focusInt);
    const tg = $("#focusToggle"); if (tg) tg.textContent = "Start";
  }
  function stopFocus() { app.focus.running = false; clearInterval(app._focusInt); }
  function completeFocus() {
    const mins = app.focus.minutes;
    pauseFocus(); app.focus.remaining = app.focus.total;
    const ev = game.onFocusComplete(mins);
    applyEvents(ev, { confetti: true });
    toast({ icon: "🍅", title: "Focus session complete!", text: `Great ${mins} minutes of deep work.` });
    if (app.view === "dashboard") RENDER.dashboard();
  }

  // ---------- Decks ----------
  RENDER.decks = async () => {
    const decks = await getDecks();
    const cards = await getAllCards();
    view.innerHTML = `
      <div class="section-head">
        <span class="sub">${plural(decks.length, "deck")} · ${plural(cards.length, "card")}</span>
        <button class="btn" id="newDeck"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" stroke-linecap="round"/></svg>New deck</button>
      </div>
      ${decks.length ? `<div class="grid cols-3">${decks.map((d) => deckCard(d, cards)).join("")}</div>`
        : `<div class="card empty"><svg viewBox="0 0 24 24"><rect x="3" y="5" width="14" height="14" rx="2"/><path d="M7 5V3.5A1.5 1.5 0 0 1 8.5 2H19a2 2 0 0 1 2 2v11.5A1.5 1.5 0 0 1 19.5 17H18"/></svg>
          <h3>No decks yet</h3><p>Create your first deck, then add cards by hand or let the Assistant build them from your notes.</p>
          <button class="btn" id="newDeck2"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" stroke-linecap="round"/></svg>Create a deck</button></div>`}`;
    $("#newDeck") && ($("#newDeck").onclick = newDeckDialog);
    $("#newDeck2") && ($("#newDeck2").onclick = newDeckDialog);
    $$(".deck-card").forEach((el) => (el.onclick = () => openDeck(el.dataset.id)));
  };

  function deckCard(d, cards) {
    const mine = cards.filter((c) => c.deckId === d.id);
    const due = mine.filter((c) => srs.isDue(c)).length;
    const avg = mine.length ? Math.round(mine.reduce((a, c) => a + srs.mastery(c), 0) / mine.length) : 0;
    return `
      <div class="card deck-card" data-id="${d.id}">
        <div class="deck-top">
          <div class="deck-ico" style="background:linear-gradient(135deg,${d.color},${shade(d.color, -25)})">${esc(d.name[0]?.toUpperCase() || "?")}</div>
          <span class="deck-due ${due ? "" : "none"}">${due ? due + " due" : "✓ done"}</span>
        </div>
        <div><h3>${esc(d.name)}</h3>
          <div class="deck-meta"><span><b>${mine.length}</b> cards</span><span><b>${avg}%</b> mastery</span></div></div>
        <div class="bar" style="height:7px"><span style="width:${avg}%"></span></div>
      </div>`;
  }

  function newDeckDialog() {
    const m = openModal(`
      <div class="modal-head"><h3>New deck</h3></div>
      <div class="field"><label>Deck name</label><input class="input" id="dName" placeholder="e.g. Biology · Cell Structure" maxlength="60"></div>
      <div class="field"><label>Colour</label><div id="swatches" style="display:flex;gap:8px;flex-wrap:wrap">
        ${DECK_COLORS.map((c, i) => `<button data-c="${c}" class="swatch-pick" style="width:34px;height:34px;border-radius:10px;border:2px solid ${i === 0 ? "var(--text)" : "transparent"};background:${c};cursor:pointer"></button>`).join("")}
      </div></div>
      <div class="modal-foot"><button class="btn ghost" data-x>Cancel</button><button class="btn" data-ok>Create</button></div>`);
    let color = DECK_COLORS[0];
    $$(".swatch-pick", m).forEach((b) => (b.onclick = () => { color = b.dataset.c; $$(".swatch-pick", m).forEach((x) => (x.style.borderColor = "transparent")); b.style.borderColor = "var(--text)"; }));
    $("[data-x]", m).onclick = closeModal;
    const name = $("#dName", m); name.focus();
    $("[data-ok]", m).onclick = async () => {
      const v = name.value.trim(); if (!v) return name.focus();
      const deck = { id: uid(), name: v, color, createdAt: Date.now() };
      await db.put("decks", deck); closeModal(); openDeck(deck.id);
    };
    name.addEventListener("keydown", (e) => e.key === "Enter" && $("[data-ok]", m).click());
  }

  // ---------- Deck detail ----------
  async function openDeck(id) {
    app.currentDeck = id; setView("deckDetail");
  }
  RENDER.deckDetail = async () => {
    const deck = (await getDecks()).find((d) => d.id === app.currentDeck);
    if (!deck) return setView("decks");
    $("#pageTitle").textContent = deck.name;
    const cards = await getCards(deck.id);
    const due = cards.filter((c) => srs.isDue(c)).length;
    $("#pageSub").textContent = `${plural(cards.length, "card")} · ${due} due for review`;

    view.innerHTML = `
      <div class="section-head">
        <button class="btn ghost sm" id="backDecks"><svg viewBox="0 0 24 24"><path d="M15 6l-6 6 6 6" stroke-linecap="round" stroke-linejoin="round"/></svg>All decks</button>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn ghost sm" id="genCards">✨ Generate cards</button>
          <button class="btn ghost sm" id="addCard"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" stroke-linecap="round"/></svg>Add card</button>
          <button class="btn sm" id="study" ${cards.length ? "" : "disabled"}>Study ${due ? `(${due})` : "all"}</button>
          <button class="icon-btn" id="delDeck" title="Delete deck"><svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2M6 7l1 13a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-13" stroke-linecap="round"/></svg></button>
        </div>
      </div>
      ${cards.length ? `<div class="grid cols-2">${cards.map(cardRow).join("")}</div>`
        : `<div class="card empty"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M8 9h8M8 13h5" stroke-linecap="round"/></svg>
          <h3>This deck is empty</h3><p>Add cards manually, or paste your notes and let Cortex generate flashcards automatically.</p></div>`}`;

    $("#backDecks").onclick = () => setView("decks");
    $("#addCard").onclick = () => cardDialog(deck.id);
    $("#genCards").onclick = () => generateCardsDialog(deck.id);
    $("#study").onclick = () => startStudy(deck.id);
    $("#delDeck").onclick = async () => {
      if (await confirmDialog("Delete deck?", `“${esc(deck.name)}” and its ${plural(cards.length, "card")} will be permanently removed.`, "Delete", true)) {
        for (const c of cards) await db.del("cards", c.id);
        await db.del("decks", deck.id); setView("decks");
      }
    };
    $$("[data-edit]").forEach((b) => (b.onclick = () => cardDialog(deck.id, cards.find((c) => c.id === b.dataset.edit))));
    $$("[data-delc]").forEach((b) => (b.onclick = async () => { await db.del("cards", b.dataset.delc); RENDER.deckDetail(); }));
  };

  function cardRow(c) {
    const m = srs.mastery(c);
    const img = c.imageId ? `<span class="chip">🖼️ image</span>` : "";
    return `
      <div class="card" style="padding:16px;display:flex;flex-direction:column;gap:10px">
        <div style="display:flex;justify-content:space-between;gap:10px">
          <div style="flex:1;min-width:0">
            <div style="font-weight:650;font-size:14.5px">${esc(c.front)}</div>
            <div style="color:var(--text-dim);font-size:13px;margin-top:4px">${esc(c.back)}</div>
          </div>
          <div style="display:flex;gap:4px;flex:none">
            <button class="icon-btn" style="width:32px;height:32px" data-edit="${c.id}"><svg viewBox="0 0 24 24"><path d="M4 20h4L18.5 9.5a2.1 2.1 0 0 0-3-3L5 17v3Z"/></svg></button>
            <button class="icon-btn" style="width:32px;height:32px" data-delc="${c.id}"><svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13" stroke-linecap="round"/></svg></button>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:8px">${img}
          <div class="bar" style="height:6px;flex:1"><span style="width:${m}%"></span></div>
          <span style="font-size:11px;color:var(--text-faint)">${m}%</span></div>
      </div>`;
  }

  function cardDialog(deckId, card) {
    const editing = !!card;
    const m = openModal(`
      <div class="modal-head"><h3>${editing ? "Edit card" : "New card"}</h3></div>
      <div class="field"><label>Front (question / prompt)</label><textarea class="input" id="cFront" placeholder="What is the powerhouse of the cell?">${esc(card?.front || "")}</textarea></div>
      <div class="field"><label>Back (answer)</label><textarea class="input" id="cBack" placeholder="The mitochondria">${esc(card?.back || "")}</textarea></div>
      <div class="field"><label>Image (optional)</label>
        <div id="imgArea"></div>
        <button class="btn ghost sm" id="cImg" style="margin-top:6px">🖼️ ${card?.imageId ? "Change image" : "Attach image"}</button></div>
      <div class="modal-foot"><button class="btn ghost" data-x>Cancel</button><button class="btn" data-ok>${editing ? "Save" : "Add card"}</button></div>`);
    let imageId = card?.imageId || null;
    const drawImg = async () => {
      const area = $("#imgArea", m);
      if (!imageId) { area.innerHTML = ""; return; }
      const f = await db.get("files", imageId);
      area.innerHTML = f ? `<img src="${fileURL(f)}" style="max-height:120px;border-radius:10px">` : "";
    };
    drawImg();
    $("#cImg", m).onclick = () => pickFiles("image/*", false, async (files) => {
      if (files[0]) { const rec = await saveFile(files[0]); imageId = rec.id; applyEvents(game.onFileAdded(1), { silent: true }); drawImg(); }
    });
    $("[data-x]", m).onclick = closeModal;
    $("#cFront", m).focus();
    $("[data-ok]", m).onclick = async () => {
      const front = $("#cFront", m).value.trim(), back = $("#cBack", m).value.trim();
      if (!front || !back) return toast({ icon: "⚠️", title: "Both sides needed", text: "Fill in front and back." });
      if (editing) { await db.put("cards", { ...card, front, back, imageId }); }
      else { await db.put("cards", { id: uid(), deckId, front, back, imageId, srs: srs.fresh(), createdAt: Date.now() }); applyEvents(game.onCardCreated(1), { silent: true }); }
      closeModal(); RENDER.deckDetail();
    };
  }

  function generateCardsDialog(deckId) {
    const m = openModal(`
      <div class="modal-head"><h3>✨ Generate flashcards</h3></div>
      <p style="color:var(--text-dim);margin:0 0 14px;font-size:13.5px">Paste notes or text. Cortex finds definitions and key terms and turns them into cards automatically.</p>
      <div class="field"><textarea class="input" id="genText" style="min-height:170px" placeholder="Paste a paragraph, lecture notes, a textbook section…"></textarea></div>
      <div class="modal-foot"><button class="btn ghost" data-x>Cancel</button><button class="btn" data-ok>Generate</button></div>`);
    $("[data-x]", m).onclick = closeModal;
    $("#genText", m).focus();
    $("[data-ok]", m).onclick = async () => {
      const text = $("#genText", m).value.trim();
      if (text.length < 40) return toast({ icon: "⚠️", title: "Need more text", text: "Paste at least a few sentences." });
      const made = nlp.makeFlashcards(text, 15);
      if (!made.length) return toast({ icon: "🤔", title: "Couldn't find cards", text: "Try text with clear definitions." });
      for (const c of made) await db.put("cards", { id: uid(), deckId, front: c.front, back: c.back, imageId: null, srs: srs.fresh(), createdAt: Date.now() });
      applyEvents(game.onCardCreated(made.length));
      closeModal(); toast({ icon: "✨", title: `Generated ${made.length} cards`, text: "Review them anytime." }); RENDER.deckDetail();
    };
  }

  // ---------- Study session ----------
  async function startStudy(deckId) {
    const cards = await getCards(deckId);
    if (!cards.length) return;
    const due = cards.filter((c) => srs.isDue(c));
    const pool = due.length ? due : cards;
    app.studySession = { deckId, queue: pool.map((c) => c.id), idx: 0, total: pool.length, reviewed: 0, correct: 0, byId: Object.fromEntries(cards.map((c) => [c.id, c])), done: false };
    setView("study");
  }
  RENDER.study = () => {
    const ss = app.studySession;
    if (!ss) return setView("decks");
    if (ss.idx >= ss.queue.length) return studyDone();

    const card = ss.byId[ss.queue[ss.idx]];
    const imgHtml = card.imageId ? `<img data-img="${card.imageId}" alt="">` : "";
    view.innerHTML = `
      <div class="study-wrap">
        <div class="study-progress">
          <button class="icon-btn" id="exitStudy"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18" stroke-linecap="round"/></svg></button>
          <div class="bar"><span style="width:${Math.round((ss.idx / ss.queue.length) * 100)}%"></span></div>
          <span>${ss.idx + 1} / ${ss.queue.length}</span>
        </div>
        <div class="flashcard" id="flash">
          <div class="flashcard-inner">
            <div class="face front"><span class="face-tag">Question</span><div class="face-txt">${esc(card.front)}</div>${imgHtml}<span class="hint">Tap to flip</span></div>
            <div class="face back"><span class="face-tag">Answer</span><div class="face-txt">${esc(card.back)}</div></div>
          </div>
        </div>
        <div id="rateRow" style="display:none">
          <div class="rate-row">
            ${rateBtn("again", "Again", card)}${rateBtn("hard", "Hard", card)}${rateBtn("good", "Good", card)}${rateBtn("easy", "Easy", card)}
          </div>
        </div>
      </div>`;

    if (card.imageId) db.get("files", card.imageId).then((f) => { const el = $('[data-img]'); if (el && f) el.src = fileURL(f); });
    const flash = $("#flash");
    flash.onclick = () => { flash.classList.add("flipped"); $("#rateRow").style.display = "block"; };
    $("#exitStudy").onclick = () => setView("deckDetail");
    $$(".rate-btn").forEach((b) => (b.onclick = () => grade(b.dataset.q)));
  };
  const rateBtn = (q, label, card) => `
    <button class="rate-btn" data-q="${q}"><span>${label}</span><small>${srs.previewInterval(card.srs, q)}</small></button>`;

  async function grade(q) {
    const ss = app.studySession;
    const card = ss.byId[ss.queue[ss.idx]];
    card.srs = srs.review(card.srs, q);
    await db.put("cards", card);
    ss.reviewed++;
    if (q !== "again") ss.correct++;
    else ss.queue.push(card.id); // repeat lapsed cards later this session
    applyEvents(game.onReview(q), { silent: true });
    ss.idx++;
    RENDER.study();
  }
  function studyDone() {
    const ss = app.studySession;
    if (!ss.done) { ss.done = true; applyEvents(game.onSessionComplete(ss.total), { confetti: true }); }
    const acc = ss.reviewed ? Math.round((ss.correct / ss.reviewed) * 100) : 0;
    view.innerHTML = `
      <div class="study-wrap"><div class="card session-done">
        <div class="big">🎉</div>
        <h2 style="margin:0">Session complete!</h2>
        <p style="color:var(--text-dim);margin:0">You reviewed ${plural(ss.total, "card")} with ${acc}% recall.</p>
        <div class="grid cols-2" style="width:100%;margin-top:8px">
          ${statCard("Reviewed", ss.total, "📚", "this session")}
          ${statCard("Recall", acc + "%", "🎯", "first-try correct")}
        </div>
        <div style="display:flex;gap:10px;margin-top:16px">
          <button class="btn ghost" id="againStudy">Study again</button>
          <button class="btn" id="backDeck">Back to deck</button>
        </div>
      </div></div>`;
    $("#againStudy").onclick = () => startStudy(ss.deckId);
    $("#backDeck").onclick = () => setView("deckDetail");
  }

  // ---------- Quiz ----------
  RENDER.quiz = async () => {
    if (app.pendingQuiz) { app.quiz = { questions: app.pendingQuiz, idx: 0, correct: 0, done: false }; app.pendingQuiz = null; }
    if (app.quiz) return app.quiz.idx >= app.quiz.questions.length ? quizResult() : quizStage();
    quizSetup();
  };

  async function quizSetup() {
    const decks = await getDecks();
    const notes = await getNotes();
    const docs = (await getFiles()).filter((f) => f.kind === "document" && f.text && f.text.trim());
    view.innerHTML = `
      <div class="quiz-stage">
        <div class="card" style="padding:24px">
          <div class="section-head"><h2>Create a quiz</h2></div>
          <div class="field"><label>Quiz from a deck</label>
            <div style="display:flex;gap:8px">
              <select class="input" id="qDeck"><option value="">Choose a deck…</option>${decks.map((d) => `<option value="${d.id}">${esc(d.name)}</option>`).join("")}</select>
              <button class="btn" id="qFromDeck">Start</button></div></div>
          <div class="field"><label>Quiz from a note</label>
            <div style="display:flex;gap:8px">
              <select class="input" id="qNote"><option value="">Choose a note…</option>${notes.map((n) => `<option value="${n.id}">${esc(n.title || "Untitled")}</option>`).join("")}</select>
              <button class="btn ghost" id="qFromNote">Start</button></div></div>
          ${docs.length ? `<div class="field"><label>Quiz from a document</label>
            <div style="display:flex;gap:8px">
              <select class="input" id="qDoc"><option value="">Choose a document…</option>${docs.map((f) => `<option value="${f.id}">${esc(f.name)}</option>`).join("")}</select>
              <button class="btn ghost" id="qFromDoc">Start</button></div></div>` : ""}
          <div class="field"><label>Or paste text</label>
            <textarea class="input" id="qText" placeholder="Paste notes or a passage to be quizzed on…"></textarea></div>
          <button class="btn block" id="qFromText">Generate quiz from text</button>
        </div>
      </div>`;

    $("#qFromDeck").onclick = async () => {
      const id = $("#qDeck").value; if (!id) return toast({ icon: "⚠️", title: "Pick a deck" });
      const cards = await getCards(id);
      if (cards.length < 1) return toast({ icon: "🤔", title: "Deck is empty" });
      startQuiz(quizFromCards(cards));
    };
    $("#qFromNote").onclick = async () => {
      const id = $("#qNote").value; if (!id) return toast({ icon: "⚠️", title: "Pick a note" });
      const n = (await getNotes()).find((x) => x.id === id);
      quizFromText(`${n.title}. ${n.body}`);
    };
    if ($("#qFromDoc")) $("#qFromDoc").onclick = async () => {
      const id = $("#qDoc").value; if (!id) return toast({ icon: "⚠️", title: "Pick a document" });
      const f = await db.get("files", id);
      quizFromText(f.text || "");
    };
    $("#qFromText").onclick = () => quizFromText($("#qText").value.trim());
  }

  function quizFromText(text) {
    if (!text || text.length < 40) return toast({ icon: "⚠️", title: "Need more text", text: "Paste a few sentences first." });
    const qs = nlp.generateQuestions(text, 8);
    if (!qs.length) return toast({ icon: "🤔", title: "Couldn't generate questions", text: "Try richer text with key terms." });
    startQuiz(qs);
  }
  function quizFromCards(cards) {
    const backs = cards.map((c) => c.back);
    return cards.slice(0, 12).map((c) => {
      if (cards.length >= 4) {
        const opts = nlp.generateQuestions ? null : null; // (placeholder, distractors below)
        const distract = backs.filter((b) => b !== c.back).sort(() => Math.random() - 0.5).slice(0, 3);
        return { type: "mcq", question: c.front, answer: c.back, options: [c.back, ...distract].sort(() => Math.random() - 0.5) };
      }
      return { type: "cloze", question: c.front, answer: c.back };
    });
  }
  function startQuiz(questions) {
    app.quiz = { questions, idx: 0, correct: 0, done: false };
    setView("quiz");
  }

  function quizStage() {
    const q = app.quiz, cur = q.questions[q.idx];
    const opts = cur.type === "mcq"
      ? cur.options.map((o, i) => `<button class="opt" data-opt="${esc(o)}"><span class="key">${"ABCD"[i]}</span>${esc(o)}</button>`).join("")
      : `<input class="input cloze-input" id="clozeIn" placeholder="Type your answer…" autocomplete="off">
         <button class="btn block" id="clozeCheck" style="margin-top:12px">Check answer</button>`;
    view.innerHTML = `
      <div class="quiz-stage">
        <div class="study-progress">
          <button class="icon-btn" id="exitQuiz"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18" stroke-linecap="round"/></svg></button>
          <div class="bar"><span style="width:${Math.round((q.idx / q.questions.length) * 100)}%"></span></div>
          <span>${q.idx + 1} / ${q.questions.length}</span>
        </div>
        <div class="card qcard">
          <div class="qnum">Question ${q.idx + 1}${cur.type === "mcq" ? " · choose one" : " · fill the blank"}</div>
          <div class="qtext">${esc(cur.question)}</div>
          <div id="opts">${opts}</div>
        </div>
        <div id="nextWrap" style="display:none;text-align:right"><button class="btn" id="nextQ">${q.idx + 1 < q.questions.length ? "Next question" : "See results"} →</button></div>
      </div>`;
    $("#exitQuiz").onclick = async () => { if (await confirmDialog("End quiz?", "Your progress in this quiz will be lost.", "End")) { app.quiz = null; setView("quiz"); } };

    if (cur.type === "mcq") {
      $$(".opt").forEach((b) => (b.onclick = () => answerMcq(b, cur)));
    } else {
      const inp = $("#clozeIn"); inp.focus();
      const check = () => answerCloze(inp.value, cur);
      $("#clozeCheck").onclick = check;
      inp.addEventListener("keydown", (e) => e.key === "Enter" && check());
    }
    $("#nextQ") && ($("#nextQ").onclick = nextQuestion);
  }
  function answerMcq(btn, cur) {
    const picked = btn.dataset.opt;
    const right = picked === cur.answer;
    if (right) app.quiz.correct++;
    $$(".opt").forEach((b) => {
      b.disabled = true;
      if (b.dataset.opt === cur.answer) b.classList.add("correct");
      else if (b === btn) b.classList.add("wrong");
    });
    revealNext();
  }
  function answerCloze(val, cur) {
    const norm = (s) => s.toLowerCase().replace(/[^a-z0-9 ]/g, "").trim();
    const right = norm(val) && (norm(val) === norm(cur.answer) || norm(cur.answer).startsWith(norm(val)) && norm(val).length >= 3);
    if (right) app.quiz.correct++;
    const opts = $("#opts");
    opts.innerHTML = `<div class="opt ${right ? "correct" : "wrong"}" disabled><span class="key">${right ? "✓" : "✕"}</span>You: ${esc(val || "")}</div>
      ${right ? "" : `<div class="opt correct" disabled><span class="key">✓</span>Answer: ${esc(cur.answer)}</div>`}`;
    revealNext();
  }
  function revealNext() { $("#nextWrap").style.display = "block"; }
  function nextQuestion() {
    app.quiz.idx++;
    app.quiz.idx >= app.quiz.questions.length ? quizResult() : quizStage();
  }
  function quizResult() {
    const q = app.quiz;
    const total = q.questions.length, pct = total ? Math.round((q.correct / total) * 100) : 0;
    if (!q.done) { q.done = true; applyEvents(game.onQuizComplete({ total, correct: q.correct }), { confetti: pct >= 60 }); }
    const msg = pct === 100 ? "Perfect! Flawless run. 🌟" : pct >= 80 ? "Excellent work!" : pct >= 60 ? "Solid, keep practising." : "Keep at it, review and retry.";
    view.innerHTML = `
      <div class="quiz-stage"><div class="card quiz-result">
        <div class="score-ring" style="--p:${pct}"></div>
        <div style="font-size:34px;font-weight:800;margin-top:-96px">${pct}%</div>
        <h2 style="margin:62px 0 0">${q.correct} / ${total} correct</h2>
        <p style="color:var(--text-dim);margin:6px 0 16px">${msg}</p>
        <div style="display:flex;gap:10px">
          <button class="btn ghost" id="newQuiz">New quiz</button>
          <button class="btn" id="retryQuiz">Try again</button>
        </div>
      </div></div>`;
    $("#newQuiz").onclick = () => { app.quiz = null; setView("quiz"); };
    $("#retryQuiz").onclick = () => startQuiz(q.questions.map((x) => ({ ...x })));
  }

  // ---------- Assistant ----------
  const STARTER_CHIPS = ["Teach me about black holes", "Summarize my notes", "Quiz me", "What should I study?"];

  RENDER.assistant = async () => {
    const [notes, files] = await Promise.all([getNotes(), getFiles()]);
    const docs = files.filter((f) => f.text && f.text.trim());
    if (!app.chat.length) app.chat.push(await welcomeMsg());
    view.innerHTML = `
      <div class="assistant">
        <div class="assistant-head">
          <div class="ai-id">
            <div class="ai-orb"></div>
            <div class="ai-meta"><strong>Cortex AI</strong><span class="ai-status"><i></i> Online · runs offline</span></div>
          </div>
          <div class="ai-tools">
            <select class="input" id="ctxSel" title="Knowledge source">
              <option value="all" ${app.chatContext === "all" ? "selected" : ""}>🧠 All sources (${notes.length + docs.length})</option>
              ${notes.length ? `<optgroup label="Notes">${notes.map((n) => `<option value="${n.id}" ${app.chatContext === n.id ? "selected" : ""}>📝 ${esc(n.title || "Untitled")}</option>`).join("")}</optgroup>` : ""}
              ${docs.length ? `<optgroup label="Documents">${docs.map((f) => `<option value="${f.id}" ${app.chatContext === f.id ? "selected" : ""}>📄 ${esc(f.name)}</option>`).join("")}</optgroup>` : ""}
            </select>
            <button class="icon-btn" id="clearChat" title="Clear conversation"><svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13" stroke-linecap="round"/></svg></button>
          </div>
        </div>
        <div class="chat" id="chat">${app.chat.map(renderMsg).join("")}</div>
        <div class="assistant-foot">
          <div class="suggest-row">${STARTER_CHIPS.map((s) => `<button class="suggest" data-chip="${esc(s)}">${esc(s)}</button>`).join("")}</div>
          <div class="composer">
            <textarea class="input" id="chatIn" placeholder="Ask me anything about your notes…" rows="1"></textarea>
            <button class="btn" id="chatSend" aria-label="Send"><svg viewBox="0 0 24 24"><path d="M4 12 20 4l-6 16-3-7-7-1Z" stroke-linejoin="round"/></svg></button>
          </div>
        </div>
      </div>`;
    $("#ctxSel").onchange = (e) => (app.chatContext = e.target.value);
    $("#clearChat").onclick = async () => { app.chat = [await welcomeMsg()]; app.lastTopic = null; RENDER.assistant(); };
    const ta = $("#chatIn");
    const send = () => { const v = ta.value.trim(); if (v) { ta.value = ""; ta.style.height = "auto"; handleChat(v); } };
    $("#chatSend").onclick = send;
    ta.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } });
    ta.addEventListener("input", () => { ta.style.height = "auto"; ta.style.height = Math.min(140, ta.scrollHeight) + "px"; });
    $("#chat").addEventListener("click", onChatClick);
    scrollChat();
  };
  function onChatClick(e) {
    const chip = e.target.closest("[data-chip]");
    if (chip) return handleChat(chip.dataset.chip);
    const act = e.target.closest("[data-act]");
    if (act) doAct(act.dataset.act);
  }
  function doAct(act) {
    if (act === "start-quiz" && app._assistantQuiz) { app.pendingQuiz = app._assistantQuiz; setView("quiz"); }
    else if (act === "save-cards") saveAssistantCards();
    else if (act === "open-decks") setView("decks");
    else if (act === "open-notes") setView("notes");
    else if (act === "expand-map" && app._lastMap) {
      const m = openModal(`<div class="modal-head"><h3>🧠 ${esc(app._lastMap.center)}</h3><button class="icon-btn" data-x><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18" stroke-linecap="round"/></svg></button></div><div class="mindmap-lg">${mindmapSVG(app._lastMap, { w: 900, h: 580 })}</div>`, { lg: true });
      $("[data-x]", m).onclick = closeModal;
    }
  }
  async function welcomeMsg() {
    const [notes, cards] = await Promise.all([getNotes(), getAllCards()]);
    const has = notes.length || cards.length;
    const intro = has
      ? `Hi! I'm <strong>Cortex AI</strong> 🧠 I've read your <strong>${notes.length} note${notes.length === 1 ? "" : "s"}</strong>${cards.length ? ` and <strong>${cards.length} card${cards.length === 1 ? "" : "s"}</strong>` : ""}. Ask me anything, about your notes, or anything else (I'll check my knowledge base and the web too).`
      : `Hi! I'm <strong>Cortex AI</strong> 🧠 Ask me anything, I answer from your notes, a built-in knowledge base, and the web. Add notes anytime and I'll summarize, quiz you and teach from them.`;
    return { role: "bot", html: `<div>${intro}</div>` };
  }
  function renderMsg(m) {
    if (m.role === "user") return `<div class="msg user">${esc(m.text)}</div>`;
    return `<div class="msg bot">${m.html || ""}</div>`;
  }
  function scrollChat() {
    const c = $("#chat"); if (!c) return;
    c.scrollTop = c.scrollHeight;
    requestAnimationFrame(() => { c.scrollTop = c.scrollHeight; });
    setTimeout(() => { c.scrollTop = c.scrollHeight; }, 60);
  }
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  function showTyping() { const c = $("#chat"); if (!c || $("#typing")) return; c.insertAdjacentHTML("beforeend", `<div class="msg bot typing" id="typing"><span></span><span></span><span></span></div>`); scrollChat(); }
  function removeTyping() { $("#typing")?.remove(); }
  const richToHtml = (text) => esc(text).replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>").replace(/\n/g, "<br>");

  // word-by-word typewriter that understands **bold**
  async function typeRich(el, text) {
    if (!text) return;
    if (text.length > 300) { el.innerHTML = richToHtml(text); scrollChat(); return; }
    for (let i = 0, segs = text.split("**"); i < segs.length; i++) {
      const target = i % 2 === 1 ? el.appendChild(document.createElement("strong")) : el;
      for (const w of (segs[i].match(/\S+\s*|\s+/g) || [])) {
        target.appendChild(document.createTextNode(w));
        scrollChat();
        if (!/^\s+$/.test(w)) await wait(12 + Math.random() * 22);
      }
    }
  }

  // render a structured reply { text, bullets, html, actions, chips, meta } with a streaming feel
  async function streamBot(reply) {
    const entry = { role: "bot", html: "" };
    app.chat.push(entry);
    const c = $("#chat");
    if (!c) { entry.html = staticReply(reply); return; }
    const bubble = document.createElement("div");
    bubble.className = "msg bot";
    c.appendChild(bubble);
    const body = document.createElement("div");
    bubble.appendChild(body);
    await typeRich(body, reply.text || "");
    if (reply.bullets?.length) {
      const ul = document.createElement("ul");
      reply.bullets.forEach((b, i) => { const li = document.createElement("li"); li.style.animationDelay = i * 55 + "ms"; li.innerHTML = richToHtml(b); ul.appendChild(li); });
      bubble.appendChild(ul); scrollChat();
    }
    if (reply.steps?.length) {
      const ol = document.createElement("ol"); ol.className = "steps";
      reply.steps.forEach((s, i) => { const li = document.createElement("li"); li.style.animationDelay = i * 70 + "ms"; li.innerHTML = richToHtml(s); ol.appendChild(li); });
      bubble.appendChild(ol); scrollChat();
    }
    if (reply.html) { const d = document.createElement("div"); d.innerHTML = reply.html; bubble.appendChild(d); scrollChat(); }
    if (reply.meta) { const d = document.createElement("div"); d.className = "msg-meta"; d.textContent = reply.meta; bubble.appendChild(d); }
    if (reply.actions?.length) {
      const w = document.createElement("div"); w.className = "msg-actions";
      w.innerHTML = reply.actions.map((a) => `<button class="btn sm" data-act="${a.act}">${esc(a.label)}</button>`).join("");
      bubble.appendChild(w); scrollChat();
    }
    if (reply.chips?.length) {
      const w = document.createElement("div"); w.className = "suggest-row followups";
      w.innerHTML = reply.chips.map((ch) => `<button class="suggest" data-chip="${esc(ch)}">${esc(ch)}</button>`).join("");
      bubble.appendChild(w); scrollChat();
    }
    entry.html = bubble.innerHTML;
    scrollChat();
  }
  function staticReply(reply) {
    let h = `<div>${richToHtml(reply.text || "")}</div>`;
    if (reply.bullets?.length) h += `<ul>${reply.bullets.map((b) => `<li>${richToHtml(b)}</li>`).join("")}</ul>`;
    if (reply.steps?.length) h += `<ol class="steps">${reply.steps.map((s) => `<li>${richToHtml(s)}</li>`).join("")}</ol>`;
    if (reply.html) h += `<div>${reply.html}</div>`;
    if (reply.meta) h += `<div class="msg-meta">${esc(reply.meta)}</div>`;
    if (reply.actions?.length) h += `<div class="msg-actions">${reply.actions.map((a) => `<button class="btn sm" data-act="${a.act}">${esc(a.label)}</button>`).join("")}</div>`;
    if (reply.chips?.length) h += `<div class="suggest-row followups">${reply.chips.map((ch) => `<button class="suggest" data-chip="${esc(ch)}">${esc(ch)}</button>`).join("")}</div>`;
    return h;
  }

  async function contextText() {
    const [notes, files] = await Promise.all([getNotes(), getFiles()]);
    if (app.chatContext !== "all") {
      const n = notes.find((x) => x.id === app.chatContext);
      if (n) return `${n.title}. ${n.body}`;
      const f = files.find((x) => x.id === app.chatContext);
      return f && f.text ? `${f.name}. ${f.text}` : "";
    }
    const parts = notes.map((n) => `${n.title}. ${n.body}`)
      .concat(files.filter((f) => f.text && f.text.trim()).map((f) => `${f.name}. ${f.text}`));
    let txt = parts.join("\n\n");
    if (!txt.trim()) { const cards = await getAllCards(); txt = cards.map((c) => `${c.front} ${c.back}`).join(". "); }
    return txt;
  }
  const pick = (arr) => arr[(Math.random() * arr.length) | 0];
  const clean = (s) => s.replace(/^(the|a|an)\s+/i, "").replace(/[?.!,"'“”]+$/g, "").trim();
  function extractTopic(text, re) { const m = text.match(re); return m ? clean(m[1]) : null; }
  function topicSentences(ctx, topic) {
    const re = new RegExp("\\b" + topic.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\b", "i");
    return nlp.sentences(ctx).filter((s) => re.test(s)).join(" ");
  }
  const lastNoun = (text) => (nlp.content(text).sort((a, b) => b.length - a.length)[0] || null);

  async function handleChat(text) {
    app.chat.push({ role: "user", text });
    const c = $("#chat");
    if (c) { c.insertAdjacentHTML("beforeend", renderMsg({ role: "user", text })); scrollChat(); }
    showTyping();
    let reply;
    try { reply = await buildReply(text); }
    catch (e) { console.warn(e); reply = { text: "Hmm, I hit a snag working that out. Mind rephrasing?" }; }
    await wait(260 + Math.min(520, (reply.text || "").length * 3));
    removeTyping();
    await streamBot(reply);
  }

  async function buildReply(raw) {
    let text = raw.trim();
    let t = text.toLowerCase();
    const KB = window.Cortex.knowledge;

    // conversational follow-up → reuse the last topic
    if (app.lastTopic && /^(tell me more|more|go on|continue|explain (more|further)|another( one)?|elaborate|and\??)$/.test(t)) {
      text = "Explain " + app.lastTopic; t = text.toLowerCase();
    }

    //, small talk / personality, 
    if (/^(hi+|hey+|hello+|yo|sup|hiya|howdy|greetings|good (morning|afternoon|evening))\b/.test(t))
      return { text: pick(["Hey! 👋 What are we studying today? Ask me anything, or tap a shortcut below.", "Hi there! 🧠 I can summarize, quiz you, or answer questions, from your notes or my own knowledge."]), chips: STARTER_CHIPS };
    if (/\b(who are you|what are you|your name|are you (an ?ai|chatgpt|gpt|real))\b/.test(t))
      return { text: "I'm **Cortex AI**, your personal study companion. I run entirely on your device (no internet, no API keys): I read your notes & documents, and I have a built-in knowledge base spanning science, maths, history, and more.", chips: STARTER_CHIPS };
    if (t.length < 28 && /\b(thank|thanks|thx|cheers|nice|great|awesome|cool|perfect|love (it|you)|good (job|bot))\b/.test(t))
      return { text: pick(["Anytime! 😊", "You got it, happy studying!", "🙌 Keep that streak alive!", "Glad to help!"]) };
    if (/\b(joke|funny|make me laugh|pun)\b/.test(t))
      return { text: pick(["Why did the student eat his homework? Because the teacher said it was a piece of cake! 🍰", "I'd tell you a chemistry joke, but I know I wouldn't get a reaction. ⚗️", "Parallel lines have so much in common… it's a shame they'll never meet. 📐"]), chips: ["Quiz me", "Summarize my notes"] };
    if (/\b(motivat|inspire|encourage|i('m| am) (tired|stressed|stuck)|give up|too hard|can'?t do)\b/.test(t))
      return { text: pick(["You've got this 💪 Small, steady sessions beat last-minute cramming every time. Want a quick quiz to build momentum?", "Every expert was once a beginner. Let's take one small step, shall I summarize where you are?"]), chips: ["Quiz me", "What should I study?"] };
    if (/\b(help|what can you (do|help)|how do you work|capabilities|commands?|options?|what should i ask)\b/.test(t))
      return helpReply();

    //, equation solver (linear & quadratic, e.g. "3x+6=12" or "x^2-5x+6=0"), 
    if (KB && KB.solveEquation && /=/.test(text) && /x/i.test(text)) {
      const eq = KB.solveEquation(text);
      if (eq) return { text: "Let's solve for **x**:", steps: eq.steps, meta: eq.type === "quadratic" ? "🧮 Quadratic equation" : "🧮 Equation solved", chips: ["Quiz me", "What should I study?"] };
    }
    //, calculus: symbolic derivative, 
    if (KB && KB.differentiate && /\b(differentiate|derivative|d\s*\/\s*dx)\b/i.test(text)) {
      const d = KB.differentiate(text);
      if (d) return { text: `Derivative of **${d.input}**:`, steps: [`d/dx ( ${d.input} ) = **${d.derivative}**`], meta: "🧮 Symbolic differentiation", chips: [`Differentiate ${d.derivative}`, "What should I study?"] };
      return { text: "I can differentiate polynomials and standard functions, sin, cos, tan, eˣ, ln, √. Try **differentiate x^3 + 2x**." };
    }
    //, calculus: definite integral (numeric), 
    if (KB && KB.integrateDefinite && /\b(integrate|integral|∫)\b/i.test(text)) {
      const r = KB.integrateDefinite(text);
      if (r) return { text: `∫ **${r.fn}** dx from **${r.a}** to **${r.b}** ≈ **${r.result}**`, meta: "🧮 Definite integral · Simpson's rule", chips: ["What should I study?"] };
      return { text: "Give me a definite integral like **integrate x^2 from 0 to 3** and I'll compute it." };
    }
    //, calculator (no notes needed; "step" requests fall through to the worked solution below), 
    if (KB && KB.looksLikeMath(text) && !/\bstep|working/i.test(t)) {
      const r = KB.evalMath(text);
      if (r !== null) return { text: `**${r}**`, meta: "🧮 Calculated", chips: ["Quiz me", "What should I study?"] };
    }

    //, meta / progress, 
    if (/\bhow many\b.*\b(note|card|deck|flashcard)/.test(t) || /\bmy (notes|cards|decks|stats|progress)\b/.test(t)) {
      const [notes, decks, cards] = await Promise.all([getNotes(), getDecks(), getAllCards()]);
      const due = cards.filter((c) => srs.isDue(c)).length;
      return { text: "Here's where you stand:", bullets: [
        `**${notes.length}** note${notes.length === 1 ? "" : "s"}`,
        `**${decks.length}** deck${decks.length === 1 ? "" : "s"} · **${cards.length}** card${cards.length === 1 ? "" : "s"}`,
        `**${due}** card${due === 1 ? "" : "s"} due now`,
        `Level **${game.levelInfo(game.state.xp).level}** · 🔥 **${game.state.streak}**-day streak`,
      ], chips: ["What should I study?", "Summarize my notes"] };
    }
    if (/\b(what (should|do) i (study|review|learn|do)|recommend|what'?s due|where (should|do) i start|weak(est)?)\b/.test(t))
      return await recommendReply();
    if (/\b(study plan|^plan\b|make.*\bplan\b|schedule|how (should|do) i (prepare|study)|prepare for|revision plan)\b/.test(t))
      return await planReply();

    const ctx = (await contextText()).trim();
    const need = () => ({ text: "I work from your notes & documents, and I don't see any yet. Add a note in **Notes** or upload a file in **Library**, then ask me again. (I can still answer general-knowledge and maths questions!)", actions: [{ label: "📝 Go to Notes", act: "open-notes" }] });

    //, step-by-step explanations & worked solutions, 
    if (/\bstep[ -]?by[ -]?step\b|\bsteps? (?:to|for|of|in|on)\b|walk me through|break (?:it|this|that) down|how (?:do|to|does)\b.*\b(?:work|solve|calculate|find|happen)\b/.test(t)) {
      if (KB && KB.looksLikeMath(text)) {
        const r = KB.evalSteps(text);
        if (r && r.steps.length) return { text: "Let's work through it step by step:", steps: r.steps.concat([`**Answer: ${r.result}**`]), meta: "🧮 Worked solution", chips: ["Quiz me", "What should I study?"] };
      }
      let topic = clean(text
        .replace(/^(can you |could you |please )?(explain|describe|teach me|show me|tell me about|give me|walk me through|break down|outline|list)\s+/i, "")
        .replace(/\b(step[ -]?by[ -]?step|steps?)\b/ig, " ")
        .replace(/\bhow (?:do|does|to) (?:i |you |we |a )?/ig, " ")
        .replace(/^\s*(?:of|for|to|in|on|about)\s+/i, "")
        .replace(/\b(work|works|happen|happens|done|solved?|calculated?)\b\s*$/i, "")
        .replace(/\s+/g, " ").trim());
      if (!topic || /^(my\s+)?notes?$|^this$|^it$|^them$/i.test(topic) || topic.length < 2) topic = app.lastTopic;
      const proc = KB && topic && KB.steps(topic);
      if (proc) { app.lastTopic = proc.title; return { text: `**${proc.title}**, step by step:`, steps: proc.steps, meta: "🌐 Built-in knowledge", chips: [`Quiz me on ${proc.title}`, `Mind map of ${proc.title}`] }; }
      if (topic) {
        const base = (ctx && nlp.define(topic, ctx)) || (KB && KB.lookup(topic) && KB.lookup(topic).d);
        if (base) { app.lastTopic = topic; const parts = nlp.sentences(base); return { text: `Here's **${topic}** broken down:`, steps: parts.length > 1 ? parts : [base], chips: [`Quiz me on ${topic}`, `Mind map of ${topic}`] }; }
      }
    }

    //, mind map / diagram, 
    if (/\b(mind ?map|concept map|diagram|map (?:of|out)|draw|visuali[sz]e)\b/.test(t)) {
      let topic = extractTopic(text, /(?:mind ?map (?:of|for|on)|concept map (?:of|for)|diagram (?:of|for)|map (?:of|out)|draw|visuali[sz]e)\s+(.+)/i);
      if (topic && /^(my\s+)?notes?$|^this$|^it$|^them$|^everything$/i.test(topic)) topic = null;
      if (!topic) topic = app.lastTopic;
      let src = ctx;
      if (topic && KB) { const kb = KB.lookup(topic); if (kb) src = [ctx, kb.t + ". " + kb.d].filter(Boolean).join(". "); }
      const data = nlp.mindmap(src || "", topic);
      if (!data.branches.length) return { text: topic ? `I don't have enough material to map **${topic}**. Add notes on it, or try a topic I know.` : "Tell me what to map, e.g. \"mind map of photosynthesis\", or add some notes first.", chips: ["Key terms", "Summarize my notes"] };
      if (topic) app.lastTopic = topic;
      app._lastMap = data;
      return { text: `Here's a mind map of **${data.center}**:`, html: mindmapSVG(data), actions: [{ label: "⤢ Expand", act: "expand-map" }], chips: [`Quiz me on ${data.center}`, `Explain ${data.center}`, `Steps for ${data.center}`] };
    }

    if (/\b(summar\w*|tl;?dr|overview|gist|recap|key points?)\b/.test(t)) {
      if (!ctx) return need();
      return { text: "Here's the **gist**:", bullets: nlp.summarize(ctx, 5), chips: ["Quiz me", "Make flashcards", "Key terms"] };
    }
    if (/\b(quiz\w*|test me|test myself|practice questions?|exam me)\b/.test(t)) {
      if (!ctx) return need();
      const topic = extractTopic(text, /(?:quiz me on|test me on|questions? on|quiz on|practice|about)\s+(.+)/i);
      const qs = nlp.generateQuestions((topic && topicSentences(ctx, topic)) || ctx, 6);
      if (!qs.length) return { text: "I couldn't find enough material to build questions yet, add more detailed notes." };
      app._assistantQuiz = qs; if (topic) app.lastTopic = topic;
      return { text: `I built a **${qs.length}-question quiz**${topic ? ` on **${topic}**` : ""}, multiple-choice, fill-the-blank and true/false. Ready?`, actions: [{ label: "▶ Start quiz", act: "start-quiz" }], chips: ["Make flashcards", "Summarize my notes"] };
    }
    if (/\b(flash ?card\w*|make cards|study cards|create cards)\b/.test(t)) {
      if (!ctx) return need();
      const topic = extractTopic(text, /(?:cards? on|flashcards? on|cards? about|about)\s+(.+)/i);
      const cards = nlp.makeFlashcards((topic && topicSentences(ctx, topic)) || ctx, 12);
      if (!cards.length) return { text: "I couldn't extract clear flashcards. Notes with definitions (\"X is Y\") work best." };
      app._assistantCards = cards; if (topic) app.lastTopic = topic;
      return { text: `I made **${cards.length} flashcards**${topic ? ` on **${topic}**` : ""}. A few:`, bullets: cards.slice(0, 4).map((c) => `**${c.front}** → ${c.back}`), actions: [{ label: "💾 Save to a deck", act: "save-cards" }], chips: ["Quiz me", "Summarize my notes"] };
    }
    if (/\b(key ?terms?|important (terms|words|concepts)|main (ideas|concepts|points)|topics?|concepts?|vocab\w*|glossary)\b/.test(t)) {
      if (!ctx) return need();
      const terms = nlp.keyTerms(ctx, 14);
      if (!terms.length) return { text: "I couldn't pick out clear key terms from this." };
      return { text: "The most important terms, tap one to dig in:", html: `<div class="term-cloud">${terms.map((x) => `<button class="chip" data-chip="Explain ${esc(x)}">${esc(x)}</button>`).join("")}</div>`, chips: ["Summarize my notes", "Quiz me"] };
    }
    if (/\b(facts?|key dates?|important dates?|numbers?|figures?|statistics?|stats|data points?)\b/.test(t)) {
      if (!ctx) return need();
      const facts = nlp.extractFacts(ctx, 7);
      if (!facts.length) return { text: "I couldn't spot specific facts, dates or figures in your notes." };
      return { text: "Key facts & figures I found:", bullets: facts, chips: ["Quiz me", "Summarize my notes"] };
    }
    if (/\b(outline|structure|organi[sz]e|break (it|this) down|study guide|mind ?map)\b/.test(t)) {
      if (!ctx) return need();
      const groups = nlp.outline(ctx);
      if (!groups.length) return { text: "There isn't quite enough structure to outline yet, add more notes." };
      return { text: "Here's a study outline:", bullets: groups.map((g) => `**${g.term}**, ${g.points.join(" ")}`), chips: ["Make flashcards", "Quiz me"] };
    }

    const cmp = text.match(/\b(?:compare|difference between|contrast)\s+(.+?)\s+(?:and|vs\.?|versus|with)\s+(.+)/i);
    if (cmp) {
      const A = clean(cmp[1]), B = clean(cmp[2]); app.lastTopic = A;
      const ia = (ctx && nlp.define(A, ctx)) || kbInfo(KB, A), ib = (ctx && nlp.define(B, ctx)) || kbInfo(KB, B);
      if (ia || ib) return { text: `Comparing **${A}** and **${B}**:`, bullets: [`**${A}:** ${ia || "not found"}`, `**${B}:** ${ib || "not found"}`], chips: [`Quiz me on ${A}`, `Explain ${B}`] };
    }
    const rel = text.match(/\b(?:related to|connected to|connections? (?:to|with)|associated with|linked to)\s+(.+)/i);
    if (rel && ctx) {
      const term = clean(rel[1]); app.lastTopic = term;
      const r = nlp.related(term, ctx);
      if (r.length) return { text: `Concepts related to **${term}**, tap to explore:`, html: `<div class="term-cloud">${r.map((x) => `<button class="chip" data-chip="Explain ${esc(x)}">${esc(x)}</button>`).join("")}</div>`, chips: [`Quiz me on ${term}`] };
    }

    //"teach me about X", a mini-lesson from notes → knowledge base → the web, 
    const teachM = text.match(/^(?:teach me|tutor me|help me (?:understand|learn)|i want to learn|lesson on|explain to me)\b(?:\s+(?:about|on))?\s*(.*)/i);
    if (teachM) {
      const topic = clean(teachM[1]) || app.lastTopic;
      if (!topic) return { text: "Of course, what would you like me to teach you? 📚", chips: ["Teach me photosynthesis", "Teach me World War II", "Teach me algebra"] };
      app.lastTopic = topic;
      let info = ctx && nlp.define(topic, ctx) && nlp.answer(topic, ctx).score >= 0.05 ? nlp.define(topic, ctx) : null;
      let src = info ? "📝 From your notes" : null, link = "";
      if (!info) { const kb = KB && KB.lookup(topic); if (kb) { info = kb.d; src = `📚 Built-in knowledge · ${kb.c}`; } }
      if (!info) { const o = await tryOnline(topic); if (o) { info = o.extract; src = `🌐 Wikipedia · ${o.title}`; link = `<a href="${esc(o.url)}" target="_blank" rel="noopener">Read more on Wikipedia →</a>`; app.lastTopic = o.title; } }
      if (!info) return { text: `I couldn't find anything on **${esc(topic)}** in your notes, my knowledge, or the web (are you online?). Try rephrasing.`, chips: ["Summarize my notes"] };
      const pts = nlp.sentences(info).slice(0, 5);
      return { text: `Let's learn about **${app.lastTopic}** 📚`, steps: pts.length ? pts : [info], meta: src, html: link, chips: [`Quiz me on ${app.lastTopic}`, `Mind map of ${app.lastTopic}`, "Tell me more"] };
    }

    //, definition / explanation: your notes → knowledge base → (later) the web, 
    const defM = text.match(/^(?:define|explain|what(?:'s| is| are| was| were)|who(?:'s| is| are| was| were)|meaning of|tell me about|describe|elaborate on)\s+(.+)/i);
    const askedTerm = defM ? clean(defM[1]) : null;
    if (defM) {
      app.lastTopic = askedTerm;
      const d = ctx ? nlp.define(askedTerm, ctx) : null;
      if (d && nlp.answer(askedTerm, ctx).score >= 0.05) return { text: `Here's what your notes say about **${esc(askedTerm)}**:`, bullets: [d], meta: "📝 From your notes", chips: [`Quiz me on ${askedTerm}`, `Mind map of ${askedTerm}`, "Tell me more"] };
      const kb = KB && KB.lookup(askedTerm);
      if (kb) return { text: `**${kb.t}**, ${kb.d}`, meta: `📚 Built-in knowledge · ${kb.c}`, chips: [`Quiz me on ${kb.t}`, `Mind map of ${kb.t}`, "Tell me more"] };
      // else fall through to web/general search below
    }

    //, free-form Q&A: your notes → built-in knowledge → Wikipedia, 
    const fromNotes = ctx ? nlp.answer(text, ctx) : { sentence: null };
    if (fromNotes.sentence && fromNotes.score >= 0.1) {
      app.lastTopic = lastNoun(text) || app.lastTopic;
      const bullets = [fromNotes.sentence]; if (fromNotes.support) bullets.push(fromNotes.support);
      return { text: "Here's what your notes say:", bullets, meta: "📝 From your notes", chips: ["Tell me more", "Quiz me", "Summarize my notes"] };
    }
    const kbAns = KB && KB.answer(text);
    if (kbAns) {
      app.lastTopic = kbAns.term || app.lastTopic;
      return { text: kbAns.text, meta: kbAns.type === "fact" ? `📚 Built-in knowledge · ${kbAns.category}` : "🧮 Calculated", chips: kbAns.term ? [`Quiz me on ${kbAns.term}`, `Mind map of ${kbAns.term}`] : ["Summarize my notes"] };
    }
    // the web, so I can answer even without your notes
    const o = await tryOnline(askedTerm || text);
    if (o) {
      app.lastTopic = o.title;
      const pts = nlp.sentences(o.extract).slice(0, 3);
      return { text: `**${o.title}**`, bullets: pts.length ? pts : [o.extract], meta: "🌐 From Wikipedia", html: `<a href="${esc(o.url)}" target="_blank" rel="noopener">Read more on Wikipedia →</a>`, chips: [`Quiz me on ${o.title}`, `Mind map of ${o.title}`, "Tell me more"] };
    }
    if (fromNotes.sentence) {
      const bullets = [fromNotes.sentence]; if (fromNotes.support) bullets.push(fromNotes.support);
      return { text: "Here's the closest thing in your notes:", bullets, meta: "📝 From your notes", chips: ["Tell me more", "Summarize my notes"] };
    }
    return { text: (window.Cortex.online && window.Cortex.online.available()) ? "I couldn't find a clear answer to that. Try rephrasing or being more specific, I can search your notes, my knowledge base, and Wikipedia." : "I couldn't find that in your notes or my built-in knowledge, and I appear to be offline so I can't look it up online right now.", chips: ["Summarize my notes", "Key terms", "Help"] };
  }
  async function tryOnline(query) {
    const O = window.Cortex.online;
    if (!O || !query) return null;
    try { return await O.search(query); } catch (e) { return null; }
  }

  const kbInfo = (KB, term) => { const e = KB && KB.lookup(term); return e ? e.d : null; };

  function helpReply() {
    return { text: "I'm **Cortex AI**, I can teach, test and answer almost anything. I can:", bullets: [
      "❓ **Answer anything**, from your notes, my built-in knowledge, or **Wikipedia**",
      "🧑‍🏫 **Teach me [about X]**, a guided mini-lesson on any topic",
      "📋 **Summarize**, TextRank pulls out the key points",
      "🧩 **Quiz me [on X]**, auto MCQ, fill-the-blank & true/false",
      "📇 **Make flashcards [on X]**, saved to a deck in one tap",
      "🔑 **Key terms · facts · outline**, see what matters",
      "🗺️ **Mind map [of X]**, visualize how ideas connect",
      "🪜 **Step by step**, break problems & processes into steps",
      "🧮 **Advanced maths**, trig, logs, factorials, **solve equations** (incl. quadratics), **derivatives** & **integrals**, e.g. \"differentiate x^3+2x\", \"integrate x^2 from 0 to 3\", \"solve x^2-5x+6=0\", \"sin(30°)\", \"log(1000)\", \"8!\"",
      "🎯 **What should I study?**, advice from your own progress",
    ], chips: ["Mind map of photosynthesis", "Explain mitosis step by step", "Quiz me"] };
  }
  async function recommendReply() {
    const [decks, cards] = await Promise.all([getDecks(), getAllCards()]);
    if (!cards.length) return { text: "You don't have any flashcards yet. Create a deck, or ask me to **make flashcards** from your notes, then I'll tell you exactly what to review.", actions: [{ label: "📇 Go to Flashcards", act: "open-decks" }] };
    const due = cards.filter((c) => srs.isDue(c));
    const byDeck = {}; cards.forEach((c) => (byDeck[c.deckId] = byDeck[c.deckId] || []).push(c));
    let weakest = null;
    for (const d of decks) { const cs = byDeck[d.id] || []; if (!cs.length) continue; const m = cs.reduce((a, c) => a + srs.mastery(c), 0) / cs.length; if (!weakest || m < weakest.m) weakest = { d, m }; }
    const bullets = [];
    if (due.length) bullets.push(`You have **${due.length}** card${due.length === 1 ? "" : "s"} due right now, clear those first.`);
    else bullets.push("Nothing's due right now, great time to learn something new or take a quiz.");
    if (weakest) bullets.push(`Your weakest deck is **${weakest.d.name}** (${Math.round(weakest.m)}% mastery), give it some love.`);
    bullets.push(`Hit your daily goal of **${game.state.dailyGoal}** reviews to protect your 🔥 **${game.state.streak}**-day streak.`);
    return { text: "Here's my recommendation:", bullets, actions: [{ label: "📇 Open Flashcards", act: "open-decks" }], chips: ["Quiz me", "Summarize my notes"] };
  }
  async function planReply() {
    const [ctx, cards] = await Promise.all([contextText(), getAllCards()]);
    const terms = ctx.trim() ? nlp.keyTerms(ctx, 6) : [];
    const bullets = [
      "**Now:** clear any due cards, then read your notes through once.",
      terms.length ? `**Focus topics:** ${terms.slice(0, 5).join(", ")}.` : "**Add notes** and I'll pull out focus topics for you.",
      "**Daily:** 20 to 30 min of spaced-repetition review, little and often beats cramming.",
      "**Before the test:** take a full quiz, then re-study anything under 70% mastery.",
    ];
    return { text: "Here's a simple, effective study plan:", bullets, actions: cards.length ? [{ label: "📇 Start reviewing", act: "open-decks" }] : [], chips: ["Quiz me", "Make flashcards"] };
  }
  async function saveAssistantCards() {
    const cards = app._assistantCards; if (!cards) return;
    const decks = await getDecks();
    const m = openModal(`
      <div class="modal-head"><h3>Save ${cards.length} flashcards</h3></div>
      <div class="field"><label>Add to deck</label>
        <select class="input" id="saveDeck"><option value="__new">➕ New deck…</option>${decks.map((d) => `<option value="${d.id}">${esc(d.name)}</option>`).join("")}</select></div>
      <div class="field" id="newNameField"><label>New deck name</label><input class="input" id="newDeckName" value="Assistant Cards"></div>
      <div class="modal-foot"><button class="btn ghost" data-x>Cancel</button><button class="btn" data-ok>Save</button></div>`);
    const sel = $("#saveDeck", m);
    sel.onchange = () => ($("#newNameField", m).style.display = sel.value === "__new" ? "flex" : "none");
    $("[data-x]", m).onclick = closeModal;
    $("[data-ok]", m).onclick = async () => {
      let deckId = sel.value;
      if (deckId === "__new") { const name = $("#newDeckName", m).value.trim() || "Assistant Cards"; const d = { id: uid(), name, color: DECK_COLORS[(Math.random() * DECK_COLORS.length) | 0], createdAt: Date.now() }; await db.put("decks", d); deckId = d.id; }
      for (const c of cards) await db.put("cards", { id: uid(), deckId, front: c.front, back: c.back, imageId: null, srs: srs.fresh(), createdAt: Date.now() });
      applyEvents(game.onCardCreated(cards.length));
      closeModal(); toast({ icon: "💾", title: `Saved ${cards.length} cards`, text: "Find them in Flashcards." });
    };
  }

  // ===========================================================
  //  LIVE TUTOR, voice session + shared whiteboard workspace
  // ===========================================================
  const BOARD_COLORS = ["#1f2937", "#6d5efc", "#ef4444", "#10b981", "#f59e0b", "#ec4899"];
  const MATH_SYMS = ["²", "³", "½", "π", "√", "×", "÷", "±", "≤", "≥", "≠", "∞", "∑", "∫", "θ", "°", "→", "( )", "/"];
  const tutor = {
    active: false, seconds: 0, timer: null, micOn: false, speakerOn: true,
    rec: null, speaking: false, supportsSTT: !!(window.SpeechRecognition || window.webkitSpeechRecognition),
    tool: "pen", color: "#1f2937", size: 3, drawing: false, stroke: null,
    strokes: [], redo: [], texts: [], transcript: [], activeText: null,
    ctx: null, canvas: null, dpr: 1, _ro: null,
  };
  const fmtClock = (s) => `${String((s / 60) | 0).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
  const hexA = (hex, a) => { const n = parseInt(hex.slice(1), 16); return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`; };
  const pressure = (e) => (e.pointerType === "pen" ? (e.pressure > 0 ? e.pressure : 0.5) : 0.5);
  const stripForSpeech = (s) => s.replace(/\*\*/g, "").replace(/[#*_`>]/g, "").replace(/[\u{1F000}-\u{1FAFF}←-➿⬀-⯿☀-⛿]/gu, " ").replace(/\s+/g, " ").trim();

  RENDER.tutor = () => { if (!tutor.active) renderTutorLobby(); else renderTutorCall(); };

  function renderTutorLobby() {
    view.innerHTML = `
      <div class="tutor-lobby">
        <div class="card lobby-card">
          <div class="ai-orb xl"></div>
          <h2>Live Tutor Session</h2>
          <p>Talk through problems out loud with your Cortex tutor and work them out together on a shared whiteboard, ideal for maths. Write with a <strong>stylus</strong> or mouse, type equations with your <strong>keyboard</strong>, and the tutor answers by voice.</p>
          <div class="lobby-feats">
            <span class="chip">🎙️ ${tutor.supportsSTT ? "Talk to your tutor" : "Type to your tutor"}</span>
            <span class="chip">🔊 Spoken answers</span>
            <span class="chip">✍️ Pen + keyboard board</span>
            <span class="chip">🧮 Maths symbols</span>
          </div>
          <button class="btn lg" id="startCall"><svg viewBox="0 0 24 24"><path d="M6.6 10.8a15 15 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.24 11 11 0 0 0 3.4.55 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1 11 11 0 0 0 .55 3.4 1 1 0 0 1-.24 1Z"/></svg> Start session</button>
          <p class="lobby-note">${tutor.supportsSTT ? "🎙️ Voice works best in <strong>Chrome or Edge</strong>, allow the mic when prompted. You can also <strong>type</strong> to the tutor anytime, and it answers aloud." : "Live voice input isn't available in this browser, but you can <strong>type</strong> to the tutor and it answers aloud."}</p>
        </div>
      </div>`;
    $("#startCall").onclick = startCall;
  }

  function startCall() {
    tutor.active = true; tutor.seconds = 0; tutor.transcript = [];
    renderTutorCall();
    addTranscript("bot", { text: "Hi! I'm your Cortex tutor 👋 What are we working on today? Talk to me, or write it on the board and tap ✋." });
    speak("Hi! I'm your Cortex tutor. What are we working on today?");
    if (tutor.supportsSTT) startMic();
  }

  function renderTutorCall() {
    view.innerHTML = `
      <div class="tutor">
        <div class="board-wrap card">
          <div class="board-toolbar">
            <div class="tool-group">
              <button class="tool ${tutor.tool === "pen" ? "on" : ""}" data-tool="pen" title="Pen">✏️</button>
              <button class="tool ${tutor.tool === "highlighter" ? "on" : ""}" data-tool="highlighter" title="Highlighter">🖍️</button>
              <button class="tool ${tutor.tool === "eraser" ? "on" : ""}" data-tool="eraser" title="Eraser">🧽</button>
              <button class="tool ${tutor.tool === "text" ? "on" : ""}" data-tool="text" title="Text box (keyboard)">🔤</button>
            </div>
            <div class="tool-group swatches">${BOARD_COLORS.map((c) => `<button class="swatch ${tutor.color === c ? "on" : ""}" data-color="${c}" style="background:${c}"></button>`).join("")}</div>
            <div class="tool-group"><input type="range" id="sizeRange" min="1" max="22" value="${tutor.size}" title="Brush size"></div>
            <div class="tool-group math-palette">${MATH_SYMS.map((s) => `<button class="msym" data-sym="${esc(s)}" tabindex="-1">${esc(s)}</button>`).join("")}</div>
            <div class="tool-group right">
              <button class="tool readbtn" id="readBtn" title="Read my handwriting → text">Aa→</button>
              <button class="tool" id="undoBtn" title="Undo">↶</button>
              <button class="tool" id="clearBtn" title="Clear board">🗑️</button>
              <button class="tool" id="saveBtn" title="Save as image">⬇️</button>
            </div>
          </div>
          <div class="board-stage" id="boardStage">
            <canvas id="board"></canvas>
            <div class="text-layer" id="textLayer"></div>
          </div>
        </div>
        <aside class="call-panel card">
          <div class="tutor-tile">
            <div class="ai-orb big" id="tutorOrb"></div>
            <div class="tile-name">Cortex Tutor</div>
            <div class="call-timer"><span class="rec-dot"></span><span id="callTimer">${fmtClock(tutor.seconds)}</span></div>
          </div>
          <div class="transcript" id="transcript"></div>
          <div class="live-caption" id="liveCaption"></div>
          <div class="tutor-composer">
            <input class="input" id="tutorInput" placeholder="Type to your tutor…" autocomplete="off">
            <button class="btn sm" id="tutorSend" aria-label="Send"><svg viewBox="0 0 24 24"><path d="M4 12 20 4l-6 16-3-7-7-1Z" stroke-linejoin="round"/></svg></button>
          </div>
          <div class="call-controls">
            <button class="cc ${tutor.micOn ? "on" : ""}" id="micBtn" title="Microphone" ${tutor.supportsSTT ? "" : "disabled"}>🎙️</button>
            <button class="cc ${tutor.speakerOn ? "on" : ""}" id="spkBtn" title="Tutor voice">🔊</button>
            <button class="cc" id="askBtn" title="Ask about my work">✋</button>
            <button class="cc end" id="endBtn" title="End session"><svg viewBox="0 0 24 24"><path d="M6.6 10.8a15 15 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.24 11 11 0 0 0 3.4.55 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1 11 11 0 0 0 .55 3.4 1 1 0 0 1-.24 1Z" transform="rotate(135 12 12)"/></svg></button>
          </div>
        </aside>
      </div>`;
    initBoard(); wireBoardToolbar(); wireCallControls(); renderTranscript();
    if (!tutor.timer) tutor.timer = setInterval(() => { tutor.seconds++; const t = $("#callTimer"); if (t) t.textContent = fmtClock(tutor.seconds); }, 1000);
    $("#transcript").addEventListener("click", (e) => {
      const chip = e.target.closest("[data-chip]"); if (chip) return onStudentSpeech(chip.dataset.chip);
      const act = e.target.closest("[data-act]"); if (act) doAct(act.dataset.act);
    });
    if (tutor.micOn && tutor.supportsSTT) startMic();
  }

  // ---- whiteboard ----
  function initBoard() {
    const stage = $("#boardStage"), canvas = $("#board");
    tutor.canvas = canvas;
    const resize = () => {
      const r = stage.getBoundingClientRect();
      tutor.dpr = window.devicePixelRatio || 1;
      canvas.width = Math.round(r.width * tutor.dpr); canvas.height = Math.round(r.height * tutor.dpr);
      canvas.style.width = r.width + "px"; canvas.style.height = r.height + "px";
      tutor.ctx = canvas.getContext("2d"); tutor.ctx.scale(tutor.dpr, tutor.dpr);
      redrawBoard();
    };
    resize();
    tutor._ro && tutor._ro.disconnect();
    tutor._ro = new ResizeObserver(resize); tutor._ro.observe(stage);
    canvas.style.cursor = tutor.tool === "text" ? "text" : "crosshair";
    canvas.onpointerdown = boardDown; canvas.onpointermove = boardMove;
    canvas.onpointerup = boardUp; canvas.onpointercancel = boardUp;
    $("#textLayer").innerHTML = ""; tutor.texts.forEach(addTextBoxEl);
  }
  function boardDown(e) {
    if (tutor.tool === "text") { placeTextBox(e.offsetX, e.offsetY); return; }
    tutor.drawing = true;
    tutor.stroke = { tool: tutor.tool, color: tutor.color, size: tutor.size, points: [{ x: e.offsetX, y: e.offsetY, p: pressure(e) }] };
    try { tutor.canvas.setPointerCapture(e.pointerId); } catch (x) {}
  }
  function boardMove(e) {
    if (!tutor.drawing) return;
    const pts = tutor.stroke.points;
    const pt = { x: e.offsetX, y: e.offsetY, p: pressure(e) };
    pts.push(pt);
    drawSegment(tutor.stroke, pts[pts.length - 2], pt);
  }
  function boardUp() {
    if (!tutor.drawing) return;
    tutor.drawing = false;
    if (tutor.stroke && tutor.stroke.points.length) { if (tutor.stroke.points.length === 1) drawSegment(tutor.stroke, tutor.stroke.points[0], tutor.stroke.points[0]); tutor.strokes.push(tutor.stroke); tutor.redo = []; }
    tutor.stroke = null;
  }
  function strokeStyleFor(ctx, s, pr) {
    if (s.tool === "eraser") { ctx.globalCompositeOperation = "destination-out"; ctx.strokeStyle = "rgba(0,0,0,1)"; ctx.lineWidth = s.size * 2.4; }
    else if (s.tool === "highlighter") { ctx.globalCompositeOperation = "source-over"; ctx.strokeStyle = hexA(s.color, 0.3); ctx.lineWidth = s.size * 3.2; }
    else { ctx.globalCompositeOperation = "source-over"; ctx.strokeStyle = s.color; ctx.lineWidth = Math.max(0.6, s.size * (0.5 + pr)); }
    ctx.lineCap = "round"; ctx.lineJoin = "round";
  }
  function drawSegment(s, a, b) {
    const ctx = tutor.ctx; if (!ctx) return;
    strokeStyleFor(ctx, s, (a.p + b.p) / 2);
    ctx.beginPath();
    if (a === b) { ctx.arc(a.x, a.y, ctx.lineWidth / 2, 0, 7); ctx.fillStyle = ctx.strokeStyle; ctx.fill(); }
    else { ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
    ctx.globalCompositeOperation = "source-over";
  }
  function drawStroke(s) { const p = s.points; if (p.length === 1) return drawSegment(s, p[0], p[0]); for (let i = 1; i < p.length; i++) drawSegment(s, p[i - 1], p[i]); }
  function redrawBoard() { const c = tutor.canvas, ctx = tutor.ctx; if (!ctx) return; ctx.clearRect(0, 0, c.width, c.height); tutor.strokes.forEach(drawStroke); }

  function placeTextBox(x, y) { const item = { x, y, text: "", color: tutor.color }; tutor.texts.push(item); addTextBoxEl(item); }
  function addTextBoxEl(item) {
    const el = document.createElement("div"); el.className = "text-box"; el.style.left = item.x + "px"; el.style.top = item.y + "px"; el.style.color = item.color || tutor.color;
    el.innerHTML = `<div class="tb-grip" title="Drag">⠿</div><div class="tb-edit" contenteditable="true" spellcheck="false"></div><button class="tb-del" title="Delete">✕</button>`;
    const edit = el.querySelector(".tb-edit"); edit.textContent = item.text || "";
    edit.addEventListener("input", () => (item.text = edit.textContent));
    edit.addEventListener("focus", () => (tutor.activeText = edit));
    el.querySelector(".tb-del").onclick = () => { tutor.texts = tutor.texts.filter((t) => t !== item); el.remove(); };
    const grip = el.querySelector(".tb-grip");
    grip.onpointerdown = (e) => {
      e.preventDefault();
      const stage = $("#boardStage").getBoundingClientRect();
      const offX = e.clientX - (stage.left + item.x), offY = e.clientY - (stage.top + item.y);
      const mv = (ev) => { item.x = Math.max(0, ev.clientX - stage.left - offX); item.y = Math.max(0, ev.clientY - stage.top - offY); el.style.left = item.x + "px"; el.style.top = item.y + "px"; };
      const up = () => { window.removeEventListener("pointermove", mv); window.removeEventListener("pointerup", up); };
      window.addEventListener("pointermove", mv); window.addEventListener("pointerup", up);
    };
    $("#textLayer").appendChild(el);
    setTimeout(() => edit.focus(), 0);
  }
  function insertSym(sym) {
    const map = { "( )": "()" };
    const s = map[sym] || sym;
    const ae = document.activeElement;
    const edit = (ae && ae.classList && ae.classList.contains("tb-edit")) ? ae : tutor.activeText;
    if (!edit) return toast({ icon: "🔤", title: "Pick a text box first", text: "Add a text box (🔤) and tap inside it." });
    tutor.activeText = edit;
    edit.focus();
    const sel = window.getSelection();
    if (sel && sel.rangeCount && edit.contains(sel.anchorNode)) {
      const range = sel.getRangeAt(0); range.deleteContents();
      const node = document.createTextNode(s); range.insertNode(node);
      range.setStartAfter(node); range.collapse(true); sel.removeAllRanges(); sel.addRange(range);
    } else {
      edit.textContent += s;
      const range = document.createRange(); range.selectNodeContents(edit); range.collapse(false);
      const sel2 = window.getSelection(); sel2.removeAllRanges(); sel2.addRange(range);
    }
    edit.dispatchEvent(new Event("input", { bubbles: true }));
  }
  function wireBoardToolbar() {
    $$("[data-tool]").forEach((b) => (b.onclick = () => { tutor.tool = b.dataset.tool; $$("[data-tool]").forEach((x) => x.classList.toggle("on", x === b)); if (tutor.canvas) tutor.canvas.style.cursor = tutor.tool === "text" ? "text" : "crosshair"; }));
    $$("[data-color]").forEach((b) => (b.onclick = () => { tutor.color = b.dataset.color; $$("[data-color]").forEach((x) => x.classList.toggle("on", x === b)); }));
    $("#sizeRange").oninput = (e) => (tutor.size = +e.target.value);
    $$("[data-sym]").forEach((b) => (b.onmousedown = (e) => { e.preventDefault(); insertSym(b.dataset.sym); }));
    $("#undoBtn").onclick = () => { if (tutor.strokes.length) { tutor.redo.push(tutor.strokes.pop()); redrawBoard(); } };
    $("#clearBtn").onclick = async () => { if (await confirmDialog("Clear the board?", "This erases all drawings and text boxes.", "Clear", true)) { tutor.strokes = []; tutor.texts = []; $("#textLayer").innerHTML = ""; redrawBoard(); } };
    $("#saveBtn").onclick = savePNG;
    $("#readBtn").onclick = recognizeHandwriting;
  }
  function recognizeHandwriting() {
    const HW = window.Cortex.handwriting;
    const ink = tutor.strokes.filter((s) => s.tool !== "eraser");
    if (!ink.length) return toast({ icon: "✍️", title: "Write something first", text: "Use the pen to write digits or an equation, then tap Aa→." });
    const text = HW.recognizeStrokes(tutor.strokes);
    openHwModal(text);
  }
  function openHwModal(text) {
    const m = openModal(`
      <div class="modal-head"><h3>✍️ Handwriting → text</h3><button class="icon-btn" data-x><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18" stroke-linecap="round"/></svg></button></div>
      <p style="color:var(--text-dim);margin:0 0 10px;font-size:13px">I read your board as (edit if needed):</p>
      <input class="input" id="hwText" value="${esc(text)}" style="font-size:20px;text-align:center;letter-spacing:.04em">
      <p class="msg-meta" style="margin-top:10px">Not quite right? Tap <strong>Teach me</strong> and show me the character, I learn from your handwriting.</p>
      <div class="modal-foot">
        <button class="btn ghost" id="hwTeach">🧠 Teach me</button>
        <button class="btn ghost" id="hwInsert">Insert on board</button>
        <button class="btn" id="hwAsk">Ask tutor</button>
      </div>`);
    $("[data-x]", m).onclick = closeModal;
    $("#hwInsert", m).onclick = () => {
      const v = $("#hwText", m).value.trim();
      if (v) { const item = { x: 40, y: 40, text: v, color: tutor.color }; tutor.texts.push(item); addTextBoxEl(item); }
      closeModal();
    };
    $("#hwAsk", m).onclick = () => { const v = $("#hwText", m).value.trim(); closeModal(); if (v) onStudentSpeech(v); };
    $("#hwTeach", m).onclick = () => { closeModal(); openTeachModal(); };
  }
  function openTeachModal() {
    const m = openModal(`
      <div class="modal-head"><h3>🧠 Teach me your handwriting</h3><button class="icon-btn" data-x><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18" stroke-linecap="round"/></svg></button></div>
      <p style="color:var(--text-dim);margin:0 0 12px;font-size:13px">Draw <strong>one</strong> character, type what it is, and save. Every sample makes me smarter${window.Cortex.handwriting.learned ? ` (you've taught me ${window.Cortex.handwriting.learned} so far)` : ""}.</p>
      <canvas id="teachCanvas" class="teach-canvas"></canvas>
      <div style="display:flex;gap:8px;align-items:center;margin-top:12px">
        <input class="input" id="teachLabel" maxlength="3" placeholder="e.g. 7" style="max-width:96px;font-size:20px;text-align:center">
        <button class="btn ghost sm" id="teachClear">Clear</button>
        <button class="btn sm" id="teachSave" style="margin-left:auto">Save sample</button>
      </div>`);
    $("[data-x]", m).onclick = closeModal;
    const cv = $("#teachCanvas", m); setupMiniDraw(cv);
    $("#teachClear", m).onclick = () => cv._reset();
    $("#teachSave", m).onclick = () => {
      const label = $("#teachLabel", m).value.trim();
      if (!label) return toast({ icon: "⚠️", title: "Type the character first" });
      if (!cv._strokes.length) return toast({ icon: "✍️", title: "Draw it first" });
      if (window.Cortex.handwriting.train(cv._strokes, label)) { toast({ icon: "🧠", title: `Learned “${label}”`, text: "I'll recognise it better now." }); cv._reset(); $("#teachLabel", m).value = ""; $("#teachLabel", m).focus(); }
    };
  }
  function setupMiniDraw(cv) {
    const dpr = window.devicePixelRatio || 1, W = 300, H = 180;
    cv.width = W * dpr; cv.height = H * dpr; cv.style.height = H + "px";
    const ctx = cv.getContext("2d"); ctx.scale(dpr, dpr);
    ctx.strokeStyle = "#1f2937"; ctx.lineWidth = 4; ctx.lineCap = "round"; ctx.lineJoin = "round";
    cv._strokes = []; let cur = null, drawing = false;
    cv._reset = () => { cv._strokes = []; ctx.clearRect(0, 0, cv.width, cv.height); };
    cv.onpointerdown = (e) => { drawing = true; try { cv.setPointerCapture(e.pointerId); } catch (x) {} cur = { tool: "pen", points: [{ x: e.offsetX, y: e.offsetY }] }; };
    cv.onpointermove = (e) => { if (!drawing) return; const pts = cur.points, p = { x: e.offsetX, y: e.offsetY }; ctx.beginPath(); ctx.moveTo(pts[pts.length - 1].x, pts[pts.length - 1].y); ctx.lineTo(p.x, p.y); ctx.stroke(); pts.push(p); };
    cv.onpointerup = () => { if (drawing && cur && cur.points.length) cv._strokes.push(cur); cur = null; drawing = false; };
    cv.onpointerleave = cv.onpointerup;
  }
  function savePNG() {
    const c = tutor.canvas; const tmp = document.createElement("canvas"); tmp.width = c.width; tmp.height = c.height;
    const x = tmp.getContext("2d"); x.fillStyle = "#ffffff"; x.fillRect(0, 0, tmp.width, tmp.height); x.drawImage(c, 0, 0);
    x.scale(tutor.dpr, tutor.dpr); x.textBaseline = "top"; x.font = "18px " + getComputedStyle(document.body).fontFamily;
    tutor.texts.forEach((it) => { x.fillStyle = it.color || "#1f2937"; (it.text || "").split("\n").forEach((ln, i) => x.fillText(ln, it.x + 8, it.y + 6 + i * 22)); });
    const a = document.createElement("a"); a.href = tmp.toDataURL("image/png"); a.download = "cortex-whiteboard.png"; a.click();
    toast({ icon: "⬇️", title: "Whiteboard saved" });
  }

  // ---- transcript + voice ----
  function addTranscript(role, payload) {
    tutor.transcript.push({ role, payload });
    const wrap = $("#transcript"); if (!wrap) return;
    const div = document.createElement("div"); div.className = "t-msg " + role;
    div.innerHTML = role === "user" ? esc(payload) : staticReply(payload);
    wrap.appendChild(div); wrap.scrollTop = wrap.scrollHeight;
  }
  function renderTranscript() {
    const wrap = $("#transcript"); if (!wrap) return;
    wrap.innerHTML = tutor.transcript.map((m) => `<div class="t-msg ${m.role}">${m.role === "user" ? esc(m.payload) : staticReply(m.payload)}</div>`).join("");
    wrap.scrollTop = wrap.scrollHeight;
  }
  async function onStudentSpeech(text) {
    if (!text || !text.trim()) return;
    addTranscript("user", text.trim());
    let reply; try { reply = await buildReply(text.trim()); } catch (e) { reply = { text: "Sorry, I didn't catch that, could you say it another way?" }; }
    addTranscript("bot", reply);
    if (tutor.speakerOn) speak(replyToSpeech(reply));
  }
  function replyToSpeech(reply) {
    let s = reply.text || "";
    if (reply.bullets?.length) s += ". " + reply.bullets.join(". ");
    if (reply.steps?.length) s += ". " + reply.steps.join(". ");
    return s;
  }
  function askAboutWork() {
    const work = tutor.texts.map((t) => t.text).filter((s) => s && s.trim()).join("  ").trim();
    if (!work) return toast({ icon: "✍️", title: "Type your working first", text: "Use the 🔤 tool to type an equation, then tap ✋." });
    onStudentSpeech(work);
  }
  function orbSpeaking(on) { const o = $("#tutorOrb"); if (o) o.classList.toggle("speaking", on); }
  function speak(text) {
    if (!tutor.speakerOn || !window.speechSynthesis) return;
    const clean = stripForSpeech(text); if (!clean) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(clean); u.rate = 1.03; u.pitch = 1;
    tutor.speaking = true; orbSpeaking(true);
    if (tutor.micOn && tutor.rec) { try { tutor.rec.stop(); } catch (e) {} }
    u.onend = () => { tutor.speaking = false; orbSpeaking(false); if (tutor.micOn && tutor.rec) { try { tutor.rec.start(); } catch (e) {} } };
    window.speechSynthesis.speak(u);
  }
  function setCaption(t) { const c = $("#liveCaption"); if (c) c.textContent = t || ""; }
  async function startMic() {
    if (!tutor.supportsSTT) { tutor.micOn = false; updateMicBtn(); setCaption("Voice isn't supported here, type to the tutor below. (Chrome or Edge work best.)"); return; }
    if (!window.isSecureContext || !navigator.mediaDevices) { setCaption("Mic is blocked on file:// pages, open via http://localhost:4317. You can type below."); return; }
    // Explicitly ask for mic permission first, the most reliable way to trigger the prompt.
    setCaption("Requesting microphone…");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((t) => t.stop());
    } catch (err) {
      tutor.micOn = false; updateMicBtn();
      const msg = err && (err.name === "NotFoundError" || err.name === "DevicesNotFoundError")
        ? "No microphone found, plug one in, or type to the tutor below."
        : "Microphone blocked. Click the 🔒 / camera icon in the address bar, allow the mic, then tap 🎙️ again, or just type below.";
      setCaption(msg); toast({ icon: "🎙️", title: "Microphone blocked", text: msg });
      return;
    }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    try { if (tutor.rec) { tutor.rec.onend = null; tutor.rec.stop(); } } catch (e) {}
    const r = new SR(); tutor.rec = r; tutor._micFatal = false;
    r.continuous = true; r.interimResults = true; r.lang = "en-US";
    r.onstart = () => { tutor.micOn = true; updateMicBtn(); setCaption("🎙️ Listening, just talk."); };
    r.onresult = (e) => {
      let interim = "", final = "";
      for (let i = e.resultIndex; i < e.results.length; i++) { const t = e.results[i][0].transcript; if (e.results[i].isFinal) final += t; else interim += t; }
      setCaption(interim || (tutor.micOn ? "🎙️ Listening, just talk." : ""));
      if (final.trim() && !tutor.speaking) { setCaption("🎙️ Listening, just talk."); onStudentSpeech(final); }
    };
    r.onend = () => { if (tutor.micOn && !tutor.speaking && !tutor._micFatal) { try { r.start(); } catch (e) {} } };
    r.onerror = (e) => {
      if (e.error === "no-speech" || e.error === "aborted") return; // transient, ignore
      const msgs = {
        "not-allowed": "Mic permission denied, allow it in the address bar, then tap 🎙️.",
        "service-not-allowed": "Mic is blocked for this site, allow it and retry.",
        "network": "Live transcription needs internet and a Chrome/Edge browser (it may not work inside the desktop-app window). You can type below.",
        "audio-capture": "No microphone detected, type to the tutor below.",
      };
      if (msgs[e.error]) { tutor._micFatal = true; tutor.micOn = false; updateMicBtn(); setCaption(msgs[e.error]); toast({ icon: "🎙️", title: "Microphone", text: msgs[e.error] }); }
    };
    try { r.start(); } catch (e) { setCaption("Couldn't start the mic, tap 🎙️ again, or type below."); }
  }
  function stopMicOnly() { tutor.micOn = false; try { tutor.rec && tutor.rec.stop(); } catch (e) {} updateMicBtn(); }
  function toggleMic() { tutor.micOn ? stopMicOnly() : startMic(); }
  function updateMicBtn() { const b = $("#micBtn"); if (b) b.classList.toggle("on", tutor.micOn); }
  function wireCallControls() {
    $("#micBtn").onclick = toggleMic;
    $("#spkBtn").onclick = () => { tutor.speakerOn = !tutor.speakerOn; if (!tutor.speakerOn && window.speechSynthesis) window.speechSynthesis.cancel(); $("#spkBtn").classList.toggle("on", tutor.speakerOn); };
    $("#askBtn").onclick = askAboutWork;
    $("#endBtn").onclick = endCall;
    const ti = $("#tutorInput");
    if (ti) {
      const tsend = () => { const v = ti.value.trim(); if (v) { ti.value = ""; onStudentSpeech(v); } };
      $("#tutorSend").onclick = tsend;
      ti.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); tsend(); } });
    }
  }
  function endCall() { stopTutor(); tutor.active = false; tutor.micOn = false; RENDER.tutor(); }
  function stopTutor() {
    try { tutor.rec && tutor.rec.stop(); } catch (e) {}
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    clearInterval(tutor.timer); tutor.timer = null;
    tutor._ro && tutor._ro.disconnect(); tutor.speaking = false;
  }

  // ---------- Notes ----------
  RENDER.notes = async () => {
    const notes = (await getNotes()).sort((a, b) => b.updatedAt - a.updatedAt);
    view.innerHTML = `
      <div class="section-head"><span class="sub">${plural(notes.length, "note")}</span>
        <button class="btn" id="newNote"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" stroke-linecap="round"/></svg>New note</button></div>
      ${notes.length ? `<div class="grid cols-3">${notes.map(noteCard).join("")}</div>`
        : `<div class="card empty"><svg viewBox="0 0 24 24"><path d="M5 3h9l5 5v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z"/><path d="M14 3v5h5M8 13h8M8 17h5" stroke-linecap="round"/></svg>
          <h3>No notes yet</h3><p>Write study notes and attach photos or documents. The Assistant can summarize and quiz you on them.</p>
          <button class="btn" id="newNote2">Write your first note</button></div>`}`;
    $("#newNote") && ($("#newNote").onclick = () => noteDialog());
    $("#newNote2") && ($("#newNote2").onclick = () => noteDialog());
    $$(".note-card").forEach((el) => (el.onclick = async () => noteDialog((await getNotes()).find((n) => n.id === el.dataset.id))));
  };
  function noteCard(n) {
    return `<div class="card note-card" data-id="${n.id}">
      <h3>${esc(n.title || "Untitled")}</h3>
      <p>${esc(n.body || "No content yet…")}</p>
      <div class="note-foot"><span>${fmtDate(n.updatedAt)}</span>${n.fileIds?.length ? `<span>📎 ${n.fileIds.length}</span>` : ""}</div>
    </div>`;
  }
  async function noteDialog(note) {
    const editing = !!note;
    let fileIds = [...(note?.fileIds || [])];
    const m = openModal(`
      <div class="modal-head"><h3>${editing ? "Edit note" : "New note"}</h3>${editing ? `<button class="icon-btn" id="delNote"><svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13" stroke-linecap="round"/></svg></button>` : ""}</div>
      <div class="field"><label>Title</label><input class="input" id="nTitle" placeholder="Note title" value="${esc(note?.title || "")}"></div>
      <div class="field"><label>Content</label><textarea class="input" id="nBody" style="min-height:180px" placeholder="Write your notes here…">${esc(note?.body || "")}</textarea></div>
      <div class="field"><label>Attachments</label><div class="attach-row" id="attaches"></div>
        <div style="display:flex;gap:8px;margin-top:8px">
          <button class="btn ghost sm" id="addPhoto">🖼️ Photo</button>
          <button class="btn ghost sm" id="addDoc">📄 Document</button></div></div>
      <div class="modal-foot"><button class="btn ghost" data-x>Cancel</button><button class="btn" data-ok>${editing ? "Save" : "Create"}</button></div>`, { lg: true });

    const drawAttaches = async () => {
      const wrap = $("#attaches", m);
      if (!fileIds.length) { wrap.innerHTML = `<span style="color:var(--text-faint);font-size:13px">No attachments</span>`; return; }
      const files = await Promise.all(fileIds.map((id) => db.get("files", id)));
      wrap.innerHTML = files.filter(Boolean).map((f) => `
        <span class="attach">${f.kind === "photo" ? `<img src="${fileURL(f)}">` : `<svg viewBox="0 0 24 24"><path d="M6 2h8l4 4v16H6V2Z"/><path d="M14 2v4h4" stroke-linejoin="round"/></svg>`}
          <span style="max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(f.name)}</span>
          <button data-rm="${f.id}">✕</button></span>`).join("");
      $$("[data-rm]", wrap).forEach((b) => (b.onclick = () => { fileIds = fileIds.filter((x) => x !== b.dataset.rm); drawAttaches(); }));
    };
    drawAttaches();
    const attach = (accept) => pickFiles(accept, true, async (files) => {
      for (const file of files) { const rec = await saveFile(file); fileIds.push(rec.id); }
      applyEvents(game.onFileAdded(files.length), { silent: true });
      drawAttaches();
    });
    $("#addPhoto", m).onclick = () => attach("image/*");
    $("#addDoc", m).onclick = () => attach(".txt,.md,.csv,.pdf,.doc,.docx,application/*,text/*");
    $("[data-x]", m).onclick = closeModal;
    $("#nTitle", m).focus();
    if (editing) $("#delNote", m).onclick = async () => {
      if (await confirmDialog("Delete note?", "This note will be permanently removed.", "Delete", true)) { await db.del("notes", note.id); closeModal(); RENDER.notes(); }
    };
    $("[data-ok]", m).onclick = async () => {
      const title = $("#nTitle", m).value.trim(), body = $("#nBody", m).value.trim();
      if (!title && !body) return toast({ icon: "⚠️", title: "Note is empty" });
      const now = Date.now();
      if (editing) await db.put("notes", { ...note, title, body, fileIds, updatedAt: now });
      else { await db.put("notes", { id: uid(), title, body, fileIds, createdAt: now, updatedAt: now }); applyEvents(game.onNoteCreated()); }
      closeModal(); RENDER.notes();
    };
  }

  // ---------- Library ----------
  let libFilter = "all";
  RENDER.library = async () => {
    const files = (await getFiles()).sort((a, b) => b.createdAt - a.createdAt);
    const shown = files.filter((f) => libFilter === "all" || f.kind === libFilter);
    view.innerHTML = `
      <div class="dropzone" id="drop">
        <svg viewBox="0 0 24 24"><path d="M12 16V4m0 0L8 8m4-4 4 4" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 16v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" stroke-linecap="round"/></svg>
        <strong>Drop photos or documents here</strong><br><span style="font-size:13px">or click to browse · stored privately on this device</span>
      </div>
      <div class="section-head" style="margin-top:22px">
        <div style="display:flex;gap:8px">
          ${["all", "photo", "document"].map((k) => `<button class="chip" data-filter="${k}" ${libFilter === k ? 'style="border-color:var(--accent-1);color:var(--text)"' : ""}>${k === "all" ? "All" : k === "photo" ? "🖼️ Photos" : "📄 Documents"}</button>`).join("")}
        </div>
        <span class="sub">${plural(shown.length, "item")}</span>
      </div>
      ${shown.length ? `<div class="lib-grid">${shown.map(libItem).join("")}</div>`
        : `<div class="card empty"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9.5" r="1.5"/><path d="m4 17 4.5-4.5a2 2 0 0 1 2.8 0L20 21" stroke-linecap="round"/></svg>
          <h3>Nothing here yet</h3><p>Upload textbook photos, lecture slides, PDFs or notes. Text files can be turned into quizzes.</p></div>`}`;

    const drop = $("#drop");
    drop.onclick = () => pickFiles("image/*,.txt,.md,.csv,.pdf,.doc,.docx,application/*,text/*", true, addLibFiles);
    ["dragover", "dragenter"].forEach((e) => drop.addEventListener(e, (ev) => { ev.preventDefault(); drop.classList.add("drag"); }));
    ["dragleave", "drop"].forEach((e) => drop.addEventListener(e, () => drop.classList.remove("drag")));
    drop.addEventListener("drop", (ev) => { ev.preventDefault(); addLibFiles([...ev.dataTransfer.files]); });
    $$("[data-filter]").forEach((b) => (b.onclick = () => { libFilter = b.dataset.filter; RENDER.library(); }));
    $$("[data-open]").forEach((b) => (b.onclick = () => openFile(b.dataset.open)));
    $$("[data-dl]").forEach((b) => (b.onclick = (e) => { e.stopPropagation(); downloadFile(b.dataset.dl); }));
    $$("[data-delf]").forEach((b) => (b.onclick = async (e) => { e.stopPropagation(); await deleteFile(b.dataset.delf); RENDER.library(); }));
  };
  function libItem(f) {
    const thumb = f.kind === "photo"
      ? `<img src="${fileURL(f)}" loading="lazy">`
      : `<div class="doc-ico"><svg viewBox="0 0 24 24"><path d="M6 2h8l4 4v16H6V2Z"/><path d="M14 2v4h4" stroke-linejoin="round"/></svg><span>${esc((f.name.split(".").pop() || "doc").slice(0, 5))}</span></div>`;
    return `<div class="lib-item">
      <div class="lib-thumb" data-open="${f.id}">${thumb}</div>
      <div class="lib-info"><span class="name" title="${esc(f.name)}">${esc(f.name)}</span>
        <span style="display:flex;gap:2px">
          <button class="icon-btn" style="width:28px;height:28px" data-dl="${f.id}" title="Download"><svg viewBox="0 0 24 24"><path d="M12 4v12m0 0 4-4m-4 4-4-4M5 20h14" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
          <button class="icon-btn" style="width:28px;height:28px" data-delf="${f.id}" title="Delete"><svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13" stroke-linecap="round"/></svg></button>
        </span></div></div>`;
  }
  async function addLibFiles(files) {
    if (!files?.length) return;
    let n = 0;
    for (const file of files) { await saveFile(file); n++; }
    applyEvents(game.onFileAdded(n));
    toast({ icon: "📎", title: `Added ${plural(n, "file")}`, text: "Saved to your library." });
    RENDER.library();
  }
  async function openFile(id) {
    const f = await db.get("files", id); if (!f) return;
    if (f.kind === "photo") {
      openModal(`<div class="img-viewer"><div class="modal-head"><h3>${esc(f.name)}</h3><button class="icon-btn" data-x>✕</button></div><img src="${fileURL(f)}"></div>`, { lg: true });
      $("#modal [data-x]").onclick = closeModal;
      return;
    }
    if (f.text && f.text.trim()) {
      const ext = (f.name.split(".").pop() || "").toLowerCase();
      const note = /pdf|docx|rtf/.test(ext) ? `<div class="msg-meta" style="margin-bottom:10px">📄 Text auto-extracted from ${esc(ext.toUpperCase())} · ${f.text.length.toLocaleString()} characters</div>` : "";
      const m = openModal(`<div class="modal-head"><h3>${esc(f.name)}</h3><button class="icon-btn" data-x>✕</button></div>
        ${note}<pre style="white-space:pre-wrap;font-size:13px;line-height:1.6;color:var(--text-dim);max-height:56vh;overflow:auto;margin:0 0 16px">${esc(f.text.slice(0, 12000))}</pre>
        <div class="modal-foot"><button class="btn ghost" data-dl>Download</button><button class="btn" data-quiz>Quiz me on this</button></div>`, { lg: true });
      $("[data-x]", m).onclick = closeModal;
      $("[data-dl]", m).onclick = () => downloadFile(id);
      $("[data-quiz]", m).onclick = () => { closeModal(); quizFromText(f.text); };
      return;
    }
    const m = openModal(`<div class="modal-head"><h3>${esc(f.name)}</h3><button class="icon-btn" data-x>✕</button></div>
      <div class="empty" style="padding:30px"><div style="font-size:34px">📄</div><h3>No text preview</h3><p>I couldn't extract readable text from this file${/\.pdf$/i.test(f.name) ? ", it may be a scanned/image-only PDF" : ""}. You can still download it.</p></div>
      <div class="modal-foot"><button class="btn" data-dl>Download</button></div>`, { lg: true });
    $("[data-x]", m).onclick = closeModal;
    $("[data-dl]", m).onclick = () => downloadFile(id);
  }
  async function downloadFile(id) {
    const f = await db.get("files", id); if (!f) return;
    const a = document.createElement("a"); a.href = fileURL(f); a.download = f.name; a.click();
  }
  async function deleteFile(id) {
    // detach from any notes first
    const notes = await getNotes();
    for (const n of notes) if (n.fileIds?.includes(id)) await db.put("notes", { ...n, fileIds: n.fileIds.filter((x) => x !== id) });
    if (urlCache.has(id)) { URL.revokeObjectURL(urlCache.get(id)); urlCache.delete(id); }
    await db.del("files", id);
  }

  // ---------- Achievements ----------
  RENDER.achievements = () => {
    const s = game.state, li = game.levelInfo(s.xp);
    view.innerHTML = `
      <div class="stat-strip">
        ${statCard("Level", li.level, "⭐", `${li.toNext} XP to next`)}
        ${statCard("Total XP", s.xp, "✨", "lifetime")}
        ${statCard("Reviews", s.stats.reviews, "📚", "cards studied")}
        ${statCard("Best streak", s.bestStreak, "🔥", `current: ${s.streak}`)}
      </div>
      <div class="card" style="padding:22px;margin-bottom:24px">
        <div class="section-head"><h2>Level ${li.level}</h2><span class="sub">${li.into} / ${li.span} XP</span></div>
        <div class="goal-row"><div class="bar"><span style="width:${li.progress}%"></span></div><b>${li.progress}%</b></div>
      </div>
      <div class="section-head"><h2>Badges</h2><span class="sub">${s.badges.length} / ${game.BADGES.length} unlocked</span></div>
      <div class="badges-grid">${game.BADGES.map((b) => badgeCard(b)).join("")}</div>`;
  };
  function badgeCard(b) {
    const s = game.state;
    const unlocked = s.badges.includes(b.id);
    const val = Math.min(b.value(s), b.target(s)), tgt = b.target(s);
    const pct = Math.round((val / tgt) * 100);
    return `<div class="badge ${unlocked ? "unlocked" : "locked"}">
      <div class="emoji">${b.emoji}</div><h4>${b.name}</h4><p>${b.desc}</p>
      ${unlocked ? `<div class="chip" style="margin-top:10px">+${b.coins} 🪙</div>`
        : `<div class="bar progress-mini" style="margin-top:10px"><span style="width:${pct}%"></span></div>
           <p style="margin-top:6px;font-size:10.5px">${val} / ${tgt}</p>`}</div>`;
  }

  // ---------- Store ----------
  RENDER.store = () => {
    const s = game.state;
    view.innerHTML = `
      <div class="card" style="padding:18px 22px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between">
        <div><div class="label" style="color:var(--text-dim);font-size:13px;font-weight:600">Your balance</div>
          <div style="font-size:28px;font-weight:800;display:flex;align-items:center;gap:8px">🪙 ${s.coins}</div></div>
        <span class="sub" style="max-width:240px;text-align:right">Earn coins by reviewing, quizzing and unlocking badges.</span>
      </div>

      <div class="section-head"><h2>Appearance</h2></div>
      <div class="card toggle-row" style="margin-bottom:12px">
        <div><strong>Dark mode</strong><div style="font-size:12.5px;color:var(--text-dim)">Switch between light and dark</div></div>
        <button class="switch ${s.mode === "dark" ? "on" : ""}" id="darkToggle"></button>
      </div>

      <div class="section-head" style="margin-top:22px"><h2>Themes</h2><span class="sub">${s.unlockedThemes.length} / ${THEMES.length} unlocked</span></div>
      <div class="grid cols-4">${THEMES.map(themeCard).join("")}</div>

      <div class="section-head" style="margin-top:28px"><h2>Goals & data</h2></div>
      <div class="card" style="padding:20px">
        <div class="field"><label>Daily review goal</label>
          <div style="display:flex;gap:8px;align-items:center"><input class="input" id="goalInput" type="number" min="5" max="200" value="${s.dailyGoal}" style="max-width:120px"><span style="color:var(--text-dim);font-size:13px">reviews per day</span></div></div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:8px">
          <button class="btn ghost sm" id="exportBtn">⬇️ Export backup</button>
          <button class="btn ghost sm" id="importBtn">⬆️ Import backup</button>
          <button class="btn danger sm" id="resetBtn">Reset all progress</button>
        </div>
      </div>`;

    $("#darkToggle").onclick = () => { game.setMode(s.mode === "dark" ? "light" : "dark"); applyTheme(); RENDER.store(); };
    $$("[data-theme-apply]").forEach((b) => (b.onclick = () => { game.setTheme(b.dataset.themeApply); applyTheme(); RENDER.store(); }));
    $$("[data-theme-buy]").forEach((b) => (b.onclick = () => buyTheme(b.dataset.themeBuy)));
    $("#goalInput").onchange = (e) => { game.setDailyGoal(+e.target.value); toast({ icon: "🎯", title: "Goal updated" }); };
    $("#exportBtn").onclick = exportData;
    $("#importBtn").onclick = importData;
    $("#resetBtn").onclick = resetData;
  };
  function themeCard(t) {
    const s = game.state;
    const owned = s.unlockedThemes.includes(t.id);
    const active = s.activeTheme === t.id;
    return `<div class="theme-card ${active ? "active" : ""}">
      <div class="swatch" style="background:linear-gradient(135deg,${t.c1},${t.c2})"></div>
      <div class="t-row"><h4>${t.name}</h4>${owned ? "" : `<span class="price"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/></svg>${t.price}</span>`}</div>
      <div style="margin-top:12px">${owned
        ? (active ? `<button class="btn block sm" disabled>✓ Active</button>` : `<button class="btn ghost block sm" data-theme-apply="${t.id}">Apply</button>`)
        : `<button class="btn block sm" data-theme-buy="${t.id}" ${s.coins < t.price ? "disabled" : ""}>${s.coins < t.price ? "Need more coins" : "Unlock"}</button>`}</div>
    </div>`;
  }
  async function buyTheme(id) {
    const t = THEMES.find((x) => x.id === id);
    if (!game.spendCoins(t.price)) return toast({ icon: "🪙", title: "Not enough coins" });
    game.unlockTheme(id); game.setTheme(id); applyTheme();
    confetti(1); toast({ icon: "🎨", title: `Unlocked ${t.name}!`, text: "Theme applied." });
    RENDER.store();
  }

  // ---------- Data export/import/reset ----------
  async function exportData() {
    const data = await db.export();
    const blob = new Blob([JSON.stringify(data)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = `cortex-backup-${new Date().toISOString().slice(0, 10)}.json`; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    toast({ icon: "⬇️", title: "Backup exported" });
  }
  function importData() {
    pickFiles("application/json,.json", false, async (files) => {
      if (!files[0]) return;
      if (!(await confirmDialog("Import backup?", "This replaces all current data with the backup's contents.", "Import"))) return;
      try {
        const data = JSON.parse(await files[0].text());
        await db.import(data);
        await game.load(); applyTheme(); updateChrome();
        toast({ icon: "✅", title: "Backup restored" }); setView("dashboard");
      } catch (e) { toast({ icon: "⚠️", title: "Import failed", text: "That file isn't a valid backup." }); }
    });
  }
  async function resetData() {
    if (!(await confirmDialog("Reset everything?", "All decks, cards, notes, files and progress will be permanently deleted. This cannot be undone.", "Reset all", true))) return;
    urlCache.forEach((u) => URL.revokeObjectURL(u)); urlCache.clear();
    await db.wipe(); await game.load(); applyTheme(); updateChrome();
    toast({ icon: "🧹", title: "Fresh start", text: "Everything has been reset." }); setView("dashboard");
  }

  // ---------- file picker ----------
  function pickFiles(accept, multiple, cb) {
    const inp = document.createElement("input");
    inp.type = "file"; inp.accept = accept; inp.multiple = !!multiple;
    inp.onchange = () => cb([...inp.files]);
    inp.click();
  }

  // ---------- small color util ----------
  function shade(hex, pct) {
    const n = parseInt(hex.slice(1), 16);
    let r = (n >> 16) + Math.round(2.55 * pct), g = ((n >> 8) & 255) + Math.round(2.55 * pct), b = (n & 255) + Math.round(2.55 * pct);
    r = clamp(r, 0, 255); g = clamp(g, 0, 255); b = clamp(b, 0, 255);
    return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  }

  // ===========================================================
  //  BOOT
  // ===========================================================
  function wireGlobal() {
    document.addEventListener("click", (e) => {
      const nav = e.target.closest("[data-view]");
      if (nav) setView(nav.dataset.view);
    });
    $("#mobileMenuBtn").onclick = openSidebar;
    $("#scrim").onclick = closeSidebar;
    window.addEventListener("resize", () => { if (innerWidth > 860) closeSidebar(); });
  }
  function openSidebar() { $("#sidebar").classList.add("open"); $("#scrim").classList.add("show"); }
  function closeSidebar() { $("#sidebar").classList.remove("open"); $("#scrim").classList.remove("show"); }

  async function init() {
    await db.open();
    await game.load();
    applyTheme();
    wireGlobal();
    window.Cortex.handwriting && window.Cortex.handwriting.init();
    updateChrome();
    setView("dashboard");
  }
  document.addEventListener("DOMContentLoaded", init);
})();
