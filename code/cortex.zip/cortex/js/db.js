/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * Cortex - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ===========================================================
   db.js, tiny Promise wrapper around IndexedDB.
   Stores photos/documents as Blobs (large capacity, offline).
   =========================================================== */
(function () {
  const NAME = "cortex-db";
  const VERSION = 1;
  const STORES = {
    kv: { keyPath: "key" },
    decks: { keyPath: "id" },
    cards: { keyPath: "id", indexes: [["deckId", "deckId"]] },
    notes: { keyPath: "id" },
    files: { keyPath: "id" },
  };

  let _db = null;

  function open() {
    if (_db) return Promise.resolve(_db);
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(NAME, VERSION);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        for (const [name, cfg] of Object.entries(STORES)) {
          if (!db.objectStoreNames.contains(name)) {
            const store = db.createObjectStore(name, { keyPath: cfg.keyPath });
            (cfg.indexes || []).forEach(([idx, path]) => store.createIndex(idx, path));
          }
        }
      };
      req.onsuccess = () => { _db = req.result; resolve(_db); };
      req.onerror = () => reject(req.error);
    });
  }

  function tx(store, mode, fn) {
    return open().then(
      (db) =>
        new Promise((resolve, reject) => {
          const t = db.transaction(store, mode);
          const s = t.objectStore(store);
          let result;
          Promise.resolve(fn(s)).then((r) => (result = r));
          t.oncomplete = () => resolve(result);
          t.onerror = () => reject(t.error);
          t.onabort = () => reject(t.error);
        })
    );
  }

  const reqProm = (r) =>
    new Promise((res, rej) => {
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });

  const DB = {
    open,
    get: (store, key) => tx(store, "readonly", (s) => reqProm(s.get(key))),
    getAll: (store) => tx(store, "readonly", (s) => reqProm(s.getAll())),
    getAllByIndex: (store, index, value) =>
      tx(store, "readonly", (s) => reqProm(s.index(index).getAll(value))),
    put: (store, value) => tx(store, "readwrite", (s) => reqProm(s.put(value))),
    bulkPut: (store, values) =>
      tx(store, "readwrite", (s) => Promise.all(values.map((v) => reqProm(s.put(v))))),
    del: (store, key) => tx(store, "readwrite", (s) => reqProm(s.delete(key))),
    clear: (store) => tx(store, "readwrite", (s) => reqProm(s.clear())),

    // key/value convenience for app + game state
    kvGet: (key, fallback) =>
      DB.get("kv", key).then((row) => (row === undefined ? fallback : row.value)),
    kvSet: (key, value) => DB.put("kv", { key, value }),

    // export everything to a plain object (files become base64 for portability)
    async export() {
      const [kv, decks, cards, notes, files] = await Promise.all([
        DB.getAll("kv"), DB.getAll("decks"), DB.getAll("cards"),
        DB.getAll("notes"), DB.getAll("files"),
      ]);
      const filesEnc = await Promise.all(
        files.map(async (f) => ({ ...f, blob: await blobToB64(f.blob) }))
      );
      return { v: VERSION, exportedAt: Date.now(), kv, decks, cards, notes, files: filesEnc };
    },

    async import(data) {
      if (!data || !Array.isArray(data.decks)) throw new Error("Invalid backup file");
      await Promise.all(Object.keys(STORES).map((s) => DB.clear(s)));
      const files = await Promise.all(
        (data.files || []).map(async (f) => ({ ...f, blob: await b64ToBlob(f.blob, f.type) }))
      );
      await Promise.all([
        DB.bulkPut("kv", data.kv || []),
        DB.bulkPut("decks", data.decks || []),
        DB.bulkPut("cards", data.cards || []),
        DB.bulkPut("notes", data.notes || []),
        DB.bulkPut("files", files),
      ]);
    },

    async wipe() {
      await Promise.all(Object.keys(STORES).map((s) => DB.clear(s)));
    },
  };

  function blobToB64(blob) {
    return new Promise((res) => {
      const r = new FileReader();
      r.onload = () => res(r.result);
      r.readAsDataURL(blob);
    });
  }
  async function b64ToBlob(dataUrl, type) {
    const r = await fetch(dataUrl);
    const b = await r.blob();
    return type ? b.slice(0, b.size, type) : b;
  }

  window.Cortex = window.Cortex || {};
  window.Cortex.db = DB;
})();
