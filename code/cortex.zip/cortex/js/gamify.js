/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * Cortex - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ===========================================================
   gamify.js, the reward system: XP, levels, coins, streaks,
   badges. Stateful: loads from IndexedDB, mutates, persists,
   and returns "events" so the UI can pop toasts & confetti.
   =========================================================== */
(function () {
  const DB = window.Cortex.db;

  const DEFAULT = {
    xp: 0, coins: 0, level: 1,
    streak: 0, bestStreak: 0, lastStudyDate: null,
    badges: [],
    stats: { reviews: 0, cardsCreated: 0, quizzes: 0, perfectQuizzes: 0,
             notes: 0, files: 0, focusMinutes: 0, studyDays: 0, correctAnswers: 0 },
    unlockedThemes: ["aurora"], activeTheme: "aurora", mode: "dark",
    dailyGoal: 20, todayReviews: 0, todayDate: null,
    studiedNight: false, studiedEarly: false,
  };

  // ---- level curve ----
  const step = (lvl) => 100 + (lvl - 1) * 45;          // XP needed for that level
  function totalFor(level) { let t = 0; for (let k = 1; k < level; k++) t += step(k); return t; }
  function levelInfo(xp) {
    let level = 1;
    while (xp >= totalFor(level + 1) && level < 999) level++;
    const base = totalFor(level), span = step(level);
    const into = xp - base;
    return { level, into, span, toNext: span - into, progress: Math.round((into / span) * 100) };
  }

  // ---- badges ----
  const BADGES = [
    { id: "first-card", emoji: "🎯", name: "First Steps", desc: "Review your first card", coins: 20, target: (s) => 1, value: (s) => s.stats.reviews },
    { id: "ten-cards", emoji: "⚡", name: "Warming Up", desc: "Review 10 cards", coins: 30, target: () => 10, value: (s) => s.stats.reviews },
    { id: "centurion", emoji: "💯", name: "Centurion", desc: "Review 100 cards", coins: 100, target: () => 100, value: (s) => s.stats.reviews },
    { id: "streak3", emoji: "🔥", name: "On a Roll", desc: "Reach a 3-day streak", coins: 40, target: () => 3, value: (s) => s.bestStreak },
    { id: "streak7", emoji: "🗓️", name: "Weeklong", desc: "Reach a 7-day streak", coins: 80, target: () => 7, value: (s) => s.bestStreak },
    { id: "streak30", emoji: "🏆", name: "Unstoppable", desc: "Reach a 30-day streak", coins: 300, target: () => 30, value: (s) => s.bestStreak },
    { id: "quizzer", emoji: "🧩", name: "Quiz Taker", desc: "Finish a quiz", coins: 25, target: () => 1, value: (s) => s.stats.quizzes },
    { id: "flawless", emoji: "🌟", name: "Flawless", desc: "Score 100% on a quiz", coins: 60, target: () => 1, value: (s) => s.stats.perfectQuizzes },
    { id: "scholar", emoji: "📚", name: "Scholar", desc: "Create 25 cards", coins: 50, target: () => 25, value: (s) => s.stats.cardsCreated },
    { id: "notetaker", emoji: "📝", name: "Note Taker", desc: "Write 5 notes", coins: 40, target: () => 5, value: (s) => s.stats.notes },
    { id: "collector", emoji: "🖼️", name: "Collector", desc: "Add 5 photos or docs", coins: 40, target: () => 5, value: (s) => s.stats.files },
    { id: "deepwork", emoji: "🍅", name: "Deep Work", desc: "Finish a focus session", coins: 35, target: () => 1, value: (s) => (s.stats.focusMinutes >= 1 ? 1 : 0) },
    { id: "level5", emoji: "🥈", name: "Rising Star", desc: "Reach level 5", coins: 75, target: () => 5, value: (s) => s.level },
    { id: "level10", emoji: "🥇", name: "Mastermind", desc: "Reach level 10", coins: 150, target: () => 10, value: (s) => s.level },
    { id: "nightowl", emoji: "🦉", name: "Night Owl", desc: "Study after midnight", coins: 30, target: () => 1, value: (s) => (s.studiedNight ? 1 : 0) },
    { id: "earlybird", emoji: "🌅", name: "Early Bird", desc: "Study before 8am", coins: 30, target: () => 1, value: (s) => (s.studiedEarly ? 1 : 0) },
  ];

  let state = null;

  async function load() {
    const saved = await DB.kvGet("game", null);
    state = Object.assign({}, DEFAULT, saved || {});
    state.stats = Object.assign({}, DEFAULT.stats, state.stats || {});
    state.level = levelInfo(state.xp).level;
    rollDay();
    return state;
  }
  const save = () => DB.kvSet("game", state);

  // ---- date helpers ----
  const today = () => new Date().toLocaleDateString("en-CA"); // YYYY-MM-DD, local
  function yesterday() { const d = new Date(); d.setDate(d.getDate() - 1); return d.toLocaleDateString("en-CA"); }

  function rollDay() {
    const t = today();
    if (state.todayDate !== t) { state.todayDate = t; state.todayReviews = 0; }
  }

  // Called on any study action; advances/breaks the streak.
  function touchStreak() {
    rollDay();
    const t = today();
    if (state.lastStudyDate === t) return; // already counted today
    state.streak = state.lastStudyDate === yesterday() ? state.streak + 1 : 1;
    state.lastStudyDate = t;
    state.bestStreak = Math.max(state.bestStreak, state.streak);
    state.stats.studyDays += 1;
  }

  // Core award. Returns the events for the UI.
  function award(xp, evt = {}) {
    const before = levelInfo(state.xp).level;
    state.xp += xp;
    const coins = Math.max(0, Math.ceil(xp / 4)) + (evt.bonusCoins || 0);
    state.coins += coins;
    const after = levelInfo(state.xp);
    state.level = after.level;

    const levelUps = [];
    for (let l = before + 1; l <= after.level; l++) {
      levelUps.push(l);
      state.coins += l * 10; // level-up coin bonus
    }

    const newBadges = checkBadges();
    return { xp, coins: coins + levelUps.reduce((a, l) => a + l * 10, 0), levelUps, badges: newBadges, ...evt.extra };
  }

  function checkBadges() {
    const unlocked = [];
    for (const b of BADGES) {
      if (state.badges.includes(b.id)) continue;
      if (b.value(state) >= b.target(state)) {
        state.badges.push(b.id);
        state.coins += b.coins;
        unlocked.push(b);
      }
    }
    return unlocked;
  }

  function markTime() {
    const h = new Date().getHours();
    if (h >= 0 && h < 5) state.studiedNight = true;
    if (h >= 5 && h < 8) state.studiedEarly = true;
  }

  // ---- public actions (each persists and returns events) ----
  function finish(events) { save(); return events; }

  const actions = {
    onReview(grade) {
      touchStreak(); markTime();
      state.stats.reviews += 1; state.todayReviews += 1;
      const base = grade === "easy" ? 7 : grade === "good" ? 5 : grade === "hard" ? 4 : 2;
      return finish(award(base));
    },
    onSessionComplete(count) {
      return finish(award(10, { extra: { message: `Session complete · ${count} cards` } }));
    },
    onCardCreated(n = 1) { state.stats.cardsCreated += n; return finish(award(2 * n)); },
    onQuizComplete({ total, correct }) {
      touchStreak(); markTime();
      state.stats.quizzes += 1;
      state.stats.correctAnswers += correct;
      const perfect = total > 0 && correct === total;
      if (perfect) state.stats.perfectQuizzes += 1;
      const xp = correct * 4 + 10 + (perfect ? 25 : 0);
      return finish(award(xp, { bonusCoins: perfect ? 25 : 0, extra: { perfect } }));
    },
    onNoteCreated() { state.stats.notes += 1; return finish(award(5)); },
    onFileAdded(n = 1) { state.stats.files += n; return finish(award(3 * n)); },
    onFocusComplete(minutes) {
      touchStreak(); markTime();
      state.stats.focusMinutes += minutes;
      return finish(award(Math.max(10, Math.round(minutes * 0.8)), { extra: { message: `${minutes}-min focus done` } }));
    },
    spendCoins(amount) {
      if (state.coins < amount) return false;
      state.coins -= amount; save(); return true;
    },
    setDailyGoal(g) { state.dailyGoal = Math.max(5, Math.min(200, g | 0)); save(); },
    setTheme(id) { state.activeTheme = id; save(); },
    unlockTheme(id) { if (!state.unlockedThemes.includes(id)) state.unlockedThemes.push(id); save(); },
    setMode(m) { state.mode = m; save(); },
  };

  window.Cortex = window.Cortex || {};
  window.Cortex.game = {
    load, save, levelInfo, BADGES,
    get state() { return state; },
    ...actions,
  };
})();
