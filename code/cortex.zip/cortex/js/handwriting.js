/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * Cortex - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ===========================================================
   handwriting.js, from-scratch offline handwriting recognition.
   No libraries, no API, no training data files.

   How it works:
     1. Each character drawing is rendered to a small canvas,
        auto-cropped to its ink, scaled into a 14×14 grid, and
        turned into a normalized "ink-density" feature vector.
     2. Recognition is k-Nearest-Neighbours against templates.
     3. Built-in templates are generated at load by rendering
        0-9 and common maths symbols in several system fonts.
     4. The user can TEACH it their own handwriting, those
        samples are stored and weighted higher, so it adapts.
     5. A multi-character drawing is segmented left-to-right by
        horizontal gaps, then each piece is classified.
   =========================================================== */
(function () {
  const GRID = 14;
  const CHARS = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "+", "-", "=", "x", "(", ")", "/", "."];
  const FONTS = ["Arial", "Georgia", "'Times New Roman'", "Verdana", "'Courier New'", "'Trebuchet MS'"];
  let templates = [];     // built-in {label, feat}
  let userTemplates = []; // learned {label, feat, user:true}

  const tmp = (w, h) => { const c = document.createElement("canvas"); c.width = Math.max(8, w | 0); c.height = Math.max(8, h | 0); return c; };

  // ---- feature: auto-crop ink, fit to square, downsample to GRID×GRID, L2-normalize ----
  function featureFromCanvas(canvas) {
    const ctx = canvas.getContext("2d"), W = canvas.width, H = canvas.height;
    const data = ctx.getImageData(0, 0, W, H).data;
    let minX = W, minY = H, maxX = -1, maxY = -1;
    const ink = new Float32Array(W * H);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const a = data[(y * W + x) * 4 + 3];
      if (a > 20) { ink[y * W + x] = a / 255; if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y; }
    }
    if (maxX < 0) return null;
    const bw = maxX - minX + 1, bh = maxY - minY + 1, side = Math.max(bw, bh);
    const offX = minX - (side - bw) / 2, offY = minY - (side - bh) / 2, cell = side / GRID;
    const feat = new Float32Array(GRID * GRID);
    for (let gy = 0; gy < GRID; gy++) for (let gx = 0; gx < GRID; gx++) {
      let sum = 0, cnt = 0;
      const x0 = Math.floor(offX + gx * cell), x1 = Math.ceil(offX + (gx + 1) * cell);
      const y0 = Math.floor(offY + gy * cell), y1 = Math.ceil(offY + (gy + 1) * cell);
      for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) { cnt++; if (x >= 0 && x < W && y >= 0 && y < H) sum += ink[y * W + x]; }
      feat[gy * GRID + gx] = cnt ? sum / cnt : 0;
    }
    let norm = 0; for (const v of feat) norm += v * v; norm = Math.sqrt(norm) || 1;
    for (let i = 0; i < feat.length; i++) feat[i] /= norm;
    return feat;
  }

  function featFromStrokes(strokes) {
    let minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
    strokes.forEach((s) => s.points.forEach((p) => { if (p.x < minX) minX = p.x; if (p.x > maxX) maxX = p.x; if (p.y < minY) minY = p.y; if (p.y > maxY) maxY = p.y; }));
    if (maxX < minX) return null;
    const pad = 14, w = maxX - minX + pad * 2, h = maxY - minY + pad * 2;
    const c = tmp(w, h), ctx = c.getContext("2d");
    ctx.strokeStyle = "#000"; ctx.fillStyle = "#000"; ctx.lineCap = "round"; ctx.lineJoin = "round";
    ctx.lineWidth = Math.max(6, Math.min(w, h) * 0.11);
    strokes.forEach((s) => {
      const p = s.points;
      if (p.length === 1) { ctx.beginPath(); ctx.arc(p[0].x - minX + pad, p[0].y - minY + pad, ctx.lineWidth / 2, 0, 7); ctx.fill(); return; }
      ctx.beginPath(); ctx.moveTo(p[0].x - minX + pad, p[0].y - minY + pad);
      for (let i = 1; i < p.length; i++) ctx.lineTo(p[i].x - minX + pad, p[i].y - minY + pad);
      ctx.stroke();
    });
    return featureFromCanvas(c);
  }

  function featFromText(ch, font) {
    const S = 110, c = tmp(S, S), ctx = c.getContext("2d");
    ctx.fillStyle = "#000"; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.font = `bold 74px ${font}`;
    ctx.fillText(ch, S / 2, S / 2 + 4);
    return featureFromCanvas(c);
  }

  // idealized "how people draw it" stroke templates for shapes fonts handle poorly
  const seg = (...pts) => ({ tool: "pen", points: pts.map(([x, y]) => ({ x, y })) });
  const dot = (x, y) => ({ tool: "pen", points: [{ x, y }] });
  const STROKE_TEMPLATES = {
    "1": [[seg([50, 12], [50, 92])], [seg([38, 26], [50, 12], [50, 92])]],
    "-": [[seg([16, 52], [84, 52])]],
    "=": [[seg([18, 42], [82, 42]), seg([18, 62], [82, 62])]],
    "+": [[seg([16, 52], [84, 52]), seg([50, 18], [50, 86])]],
    "/": [[seg([78, 12], [22, 88])]],
    "x": [[seg([26, 28], [74, 84]), seg([74, 28], [26, 84])]],
    "7": [[seg([20, 16], [82, 16]), seg([82, 16], [44, 92])]],
    ".": [[dot(50, 84)]],
    "(": [[seg([66, 14], [38, 50], [66, 88])]],
    ")": [[seg([38, 14], [66, 50], [38, 88])]],
  };
  function buildStrokeBuiltins() {
    for (const label in STROKE_TEMPLATES) for (const sample of STROKE_TEMPLATES[label]) { const f = featFromStrokes(sample); if (f) { templates.push({ label, feat: f }); templates.push({ label, feat: f }); } }
  }
  function buildBuiltins() {
    templates = [];
    for (const ch of CHARS) for (const f of FONTS) { const ft = featFromText(ch, f); if (ft) templates.push({ label: ch, feat: ft }); }
    buildStrokeBuiltins();
  }

  const dist = (a, b) => { let s = 0; for (let i = 0; i < a.length; i++) { const d = a[i] - b[i]; s += d * d; } return s; };

  function classify(feat) {
    if (!feat) return { label: "?", conf: 0 };
    const all = templates.concat(userTemplates);
    const scored = all.map((t) => ({ label: t.label, d: dist(feat, t.feat), user: t.user })).sort((a, b) => a.d - b.d);
    const k = scored.slice(0, 5);
    const votes = {};
    k.forEach((t) => { votes[t.label] = (votes[t.label] || 0) + (1 / (1 + t.d)) * (t.user ? 1.7 : 1); });
    let best = "?", bv = -1; for (const l in votes) if (votes[l] > bv) { bv = votes[l]; best = l; }
    return { label: best, conf: k.length ? 1 / (1 + k[0].d) : 0 };
  }

  // group strokes into characters by horizontal gaps (left-to-right writing)
  function segment(strokes) {
    const items = strokes.map((s) => { let a = 1e9, b = -1e9; s.points.forEach((p) => { if (p.x < a) a = p.x; if (p.x > b) b = p.x; }); return { s, minX: a, maxX: b }; }).filter((it) => it.maxX >= it.minX);
    if (!items.length) return [];
    items.sort((p, q) => p.minX - q.minX);
    let minY = 1e9, maxY = -1e9;
    strokes.forEach((s) => s.points.forEach((p) => { if (p.y < minY) minY = p.y; if (p.y > maxY) maxY = p.y; }));
    const gap = Math.max(14, (maxY - minY) * 0.25);
    const groups = []; let cur = [items[0]], curMax = items[0].maxX;
    for (let i = 1; i < items.length; i++) {
      const it = items[i];
      if (it.minX <= curMax + gap) { cur.push(it); curMax = Math.max(curMax, it.maxX); }
      else { groups.push(cur); cur = [it]; curMax = it.maxX; }
    }
    groups.push(cur);
    return groups.map((g) => g.map((x) => x.s));
  }

  function recognizeStrokes(strokes) {
    const ink = (strokes || []).filter((s) => s.tool !== "eraser" && s.points && s.points.length);
    if (!ink.length) return "";
    return segment(ink).map((g) => { const r = classify(featFromStrokes(g)); return r.label === "?" ? "" : r.label; }).join("");
  }

  function train(strokes, label) {
    const ink = (strokes || []).filter((s) => s.tool !== "eraser" && s.points && s.points.length);
    const f = featFromStrokes(ink);
    if (!f || !label) return false;
    userTemplates.push({ label: String(label), feat: f, user: true });
    save(); return true;
  }
  function save() { try { localStorage.setItem("cortex-hw", JSON.stringify(userTemplates.map((t) => ({ label: t.label, feat: Array.from(t.feat) })))); } catch (e) {} }
  function load() { try { const raw = localStorage.getItem("cortex-hw"); if (raw) userTemplates = JSON.parse(raw).map((t) => ({ label: t.label, feat: Float32Array.from(t.feat), user: true })); } catch (e) {} }

  function init() { if (!templates.length) buildBuiltins(); load(); }

  window.Cortex = window.Cortex || {};
  window.Cortex.handwriting = { init, recognizeStrokes, train, classify, featFromStrokes, get learned() { return userTemplates.length; } };
})();
