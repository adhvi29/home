/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * Cortex - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ===========================================================
   knowledge.js, a built-in, offline knowledge base + math
   engine so Cortex AI is knowledgeable on its own, even before
   you add any notes. ~100 core study concepts across subjects,
   plus a from-scratch calculator (tokenizer + shunting-yard).
   =========================================================== */
(function () {
  // t: term · a: aliases · c: category · d: explanation
  const KB = [
    //, Biology, 
    { t: "Cell", a: ["cells"], c: "Biology", d: "The cell is the basic structural and functional unit of all living things. Cells can be prokaryotic (no nucleus) or eukaryotic (with a nucleus)." },
    { t: "Mitochondria", a: ["mitochondrion"], c: "Biology", d: "Mitochondria are organelles that produce most of a cell's energy (ATP) through respiration, often called the 'powerhouse of the cell'." },
    { t: "Photosynthesis", a: [], c: "Biology", d: "Photosynthesis is the process by which plants convert sunlight, water and carbon dioxide into glucose and oxygen, using chlorophyll in the chloroplasts." },
    { t: "Cellular respiration", a: ["respiration"], c: "Biology", d: "Cellular respiration breaks down glucose with oxygen to release energy (ATP), producing carbon dioxide and water as by-products." },
    { t: "DNA", a: ["deoxyribonucleic acid"], c: "Biology", d: "DNA is the molecule that carries genetic instructions in living organisms. It has a double-helix structure made of nucleotide bases A, T, C and G." },
    { t: "RNA", a: ["ribonucleic acid"], c: "Biology", d: "RNA is a single-stranded nucleic acid that helps convert the genetic information in DNA into proteins." },
    { t: "Osmosis", a: [], c: "Biology", d: "Osmosis is the movement of water molecules across a semipermeable membrane from a region of low solute concentration to high solute concentration." },
    { t: "Diffusion", a: [], c: "Biology", d: "Diffusion is the net movement of particles from an area of higher concentration to an area of lower concentration." },
    { t: "Enzyme", a: ["enzymes"], c: "Biology", d: "Enzymes are biological catalysts (usually proteins) that speed up chemical reactions in living organisms without being used up." },
    { t: "Evolution", a: [], c: "Biology", d: "Evolution is the change in the heritable characteristics of populations over successive generations, driven largely by natural selection." },
    { t: "Natural selection", a: ["survival of the fittest"], c: "Biology", d: "Natural selection is the process where organisms better adapted to their environment tend to survive and produce more offspring." },
    { t: "Mitosis", a: [], c: "Biology", d: "Mitosis is cell division that produces two genetically identical daughter cells, used for growth and repair." },
    { t: "Meiosis", a: [], c: "Biology", d: "Meiosis is cell division that produces four genetically different sex cells (gametes), each with half the number of chromosomes." },
    { t: "Chlorophyll", a: [], c: "Biology", d: "Chlorophyll is the green pigment in plants that absorbs light energy for photosynthesis." },
    { t: "Ecosystem", a: [], c: "Biology", d: "An ecosystem is a community of living organisms interacting with each other and their physical environment." },
    { t: "Gene", a: ["genes"], c: "Biology", d: "A gene is a section of DNA that codes for a particular protein or trait." },
    { t: "Protein", a: ["proteins"], c: "Biology", d: "Proteins are large molecules made of amino acids that perform most functions in cells, from structure to catalysis." },
    { t: "Bacteria", a: ["bacterium"], c: "Biology", d: "Bacteria are single-celled prokaryotic microorganisms; some are helpful, others cause disease." },
    { t: "Virus", a: ["viruses"], c: "Biology", d: "A virus is a tiny infectious agent that can only replicate inside the living cells of a host." },

    //, Chemistry, 
    { t: "Atom", a: ["atoms"], c: "Chemistry", d: "An atom is the smallest unit of an element, made of a nucleus (protons and neutrons) surrounded by electrons." },
    { t: "Molecule", a: ["molecules"], c: "Chemistry", d: "A molecule is two or more atoms chemically bonded together." },
    { t: "Element", a: ["elements"], c: "Chemistry", d: "An element is a pure substance made of only one type of atom; there are over 110 known elements." },
    { t: "Compound", a: ["compounds"], c: "Chemistry", d: "A compound is a substance formed when two or more different elements are chemically bonded, like water (H₂O)." },
    { t: "Periodic table", a: [], c: "Chemistry", d: "The periodic table arranges the chemical elements by atomic number, grouping those with similar properties into columns." },
    { t: "Acid", a: ["acids"], c: "Chemistry", d: "An acid is a substance that releases hydrogen ions (H⁺) in solution and has a pH below 7." },
    { t: "Base", a: ["alkali", "bases"], c: "Chemistry", d: "A base (alkali) accepts hydrogen ions or releases hydroxide ions (OH⁻) and has a pH above 7." },
    { t: "pH", a: ["ph scale"], c: "Chemistry", d: "pH measures how acidic or basic a solution is, on a scale of 0 (very acidic) to 14 (very basic), with 7 being neutral." },
    { t: "Ion", a: ["ions"], c: "Chemistry", d: "An ion is an atom or molecule with a net electric charge from losing or gaining electrons." },
    { t: "Covalent bond", a: [], c: "Chemistry", d: "A covalent bond forms when two atoms share electrons." },
    { t: "Ionic bond", a: [], c: "Chemistry", d: "An ionic bond forms when one atom transfers electrons to another, creating oppositely charged ions that attract." },
    { t: "Catalyst", a: ["catalysts"], c: "Chemistry", d: "A catalyst speeds up a chemical reaction without being consumed by it." },
    { t: "Isotope", a: ["isotopes"], c: "Chemistry", d: "Isotopes are atoms of the same element with the same number of protons but different numbers of neutrons." },

    //, Physics, 
    { t: "Gravity", a: ["gravitation"], c: "Physics", d: "Gravity is the force of attraction between any two masses; on Earth it gives weight to objects and pulls them toward the centre at about 9.8 m/s²." },
    { t: "Newton's first law", a: ["law of inertia", "first law of motion"], c: "Physics", d: "An object stays at rest or moves at constant velocity unless acted on by an unbalanced force (inertia)." },
    { t: "Newton's second law", a: ["second law of motion", "f=ma"], c: "Physics", d: "The force on an object equals its mass times its acceleration (F = ma)." },
    { t: "Newton's third law", a: ["third law of motion"], c: "Physics", d: "For every action there is an equal and opposite reaction." },
    { t: "Energy", a: [], c: "Physics", d: "Energy is the capacity to do work. It cannot be created or destroyed, only transformed (conservation of energy)." },
    { t: "Kinetic energy", a: [], c: "Physics", d: "Kinetic energy is the energy of motion, given by KE = ½mv²." },
    { t: "Potential energy", a: [], c: "Physics", d: "Potential energy is stored energy due to an object's position or state, e.g. gravitational PE = mgh." },
    { t: "Force", a: ["forces"], c: "Physics", d: "A force is a push or pull that can change an object's motion, measured in newtons (N)." },
    { t: "Velocity", a: [], c: "Physics", d: "Velocity is the speed of an object in a given direction (a vector quantity)." },
    { t: "Acceleration", a: [], c: "Physics", d: "Acceleration is the rate of change of velocity over time." },
    { t: "Momentum", a: [], c: "Physics", d: "Momentum is mass times velocity (p = mv); total momentum is conserved in collisions." },
    { t: "Friction", a: [], c: "Physics", d: "Friction is a force that opposes the relative motion of surfaces in contact." },
    { t: "Ohm's law", a: ["ohms law"], c: "Physics", d: "Ohm's law states that voltage equals current times resistance (V = IR)." },
    { t: "Photon", a: [], c: "Physics", d: "A photon is a particle of light, a quantum of electromagnetic energy." },

    //, Mathematics, 
    { t: "Prime number", a: ["primes"], c: "Maths", d: "A prime number is a whole number greater than 1 with exactly two factors: 1 and itself (e.g. 2, 3, 5, 7, 11)." },
    { t: "Pi", a: ["π"], c: "Maths", d: "Pi (π ≈ 3.14159) is the ratio of a circle's circumference to its diameter." },
    { t: "Pythagorean theorem", a: ["pythagoras"], c: "Maths", d: "In a right-angled triangle, the square of the hypotenuse equals the sum of the squares of the other two sides: a² + b² = c²." },
    { t: "Derivative", a: ["differentiation"], c: "Maths", d: "A derivative measures the instantaneous rate of change of a function, the slope of its graph at a point." },
    { t: "Integral", a: ["integration"], c: "Maths", d: "An integral measures the area under a curve; it is the reverse operation of differentiation." },
    { t: "Function", a: [], c: "Maths", d: "A function is a relation that assigns exactly one output to each input." },
    { t: "Percentage", a: ["percent"], c: "Maths", d: "A percentage is a number expressed as a fraction of 100 (e.g. 25% = 25/100 = 0.25)." },
    { t: "Mean", a: ["average"], c: "Maths", d: "The mean is the sum of values divided by how many values there are." },
    { t: "Median", a: [], c: "Maths", d: "The median is the middle value when numbers are arranged in order." },
    { t: "Mode", a: [], c: "Maths", d: "The mode is the value that appears most often in a data set." },
    { t: "Probability", a: [], c: "Maths", d: "Probability measures how likely an event is, from 0 (impossible) to 1 (certain)." },
    { t: "Fibonacci sequence", a: ["fibonacci"], c: "Maths", d: "The Fibonacci sequence is 0, 1, 1, 2, 3, 5, 8, 13… where each number is the sum of the two before it." },

    //, Computer Science, 
    { t: "Algorithm", a: ["algorithms"], c: "Computer Science", d: "An algorithm is a step-by-step set of instructions for solving a problem or completing a task." },
    { t: "Variable", a: ["variables"], c: "Computer Science", d: "A variable is a named container that stores a value which can change as a program runs." },
    { t: "Loop", a: ["loops", "iteration"], c: "Computer Science", d: "A loop repeats a block of code multiple times, e.g. for and while loops." },
    { t: "Binary", a: ["binary number"], c: "Computer Science", d: "Binary is a base-2 number system using only 0s and 1s, the language of computers." },
    { t: "Boolean", a: ["booleans"], c: "Computer Science", d: "A boolean is a data type with only two values: true or false." },
    { t: "Recursion", a: ["recursive"], c: "Computer Science", d: "Recursion is when a function calls itself to solve smaller instances of a problem." },
    { t: "Big O notation", a: ["big o", "time complexity"], c: "Computer Science", d: "Big O notation describes how an algorithm's running time or memory grows as the input size increases." },
    { t: "Array", a: ["arrays"], c: "Computer Science", d: "An array is an ordered collection of elements stored under one variable, accessed by index." },

    //, History, 
    { t: "World War I", a: ["wwi", "ww1", "first world war", "world war 1", "great war"], c: "History", d: "World War I (1914 to 1918) was a global war centred in Europe between the Allied Powers and the Central Powers, triggered by the assassination of Archduke Franz Ferdinand." },
    { t: "World War II", a: ["wwii", "ww2", "second world war", "world war 2"], c: "History", d: "World War II (1939 to 1945) was a global conflict between the Allies (US, USSR, UK and others) and the Axis (Germany, Italy, Japan). It ended after Germany's surrender and the atomic bombings of Japan." },
    { t: "Renaissance", a: [], c: "History", d: "The Renaissance (14th, 17th century) was a European cultural movement reviving art, science and learning, beginning in Italy." },
    { t: "Industrial Revolution", a: [], c: "History", d: "The Industrial Revolution (c.1760 to 1840) was the shift to machine manufacturing, factories and steam power, beginning in Britain." },
    { t: "Cold War", a: [], c: "History", d: "The Cold War (1947 to 1991) was a period of political tension and rivalry between the United States and the Soviet Union, without direct large-scale fighting." },
    { t: "French Revolution", a: [], c: "History", d: "The French Revolution (1789 to 1799) overthrew the monarchy in France and spread ideals of liberty, equality and fraternity." },

    //, Geography / Earth, 
    { t: "Equator", a: [], c: "Geography", d: "The equator is the imaginary line around the middle of the Earth, at 0° latitude, dividing it into the Northern and Southern Hemispheres." },
    { t: "Latitude", a: [], c: "Geography", d: "Latitude measures how far north or south a place is from the equator, in degrees." },
    { t: "Longitude", a: [], c: "Geography", d: "Longitude measures how far east or west a place is from the Prime Meridian, in degrees." },
    { t: "Tectonic plates", a: ["plate tectonics"], c: "Geography", d: "Tectonic plates are large slabs of Earth's crust that move slowly, causing earthquakes, volcanoes and mountain formation." },
    { t: "Climate", a: [], c: "Geography", d: "Climate is the average weather pattern of a region over a long period (usually 30+ years)." },

    //, Astronomy, 
    { t: "Solar System", a: [], c: "Astronomy", d: "The Solar System is the Sun and everything bound to it by gravity: eight planets, their moons, dwarf planets, asteroids and comets." },
    { t: "Black hole", a: ["black holes"], c: "Astronomy", d: "A black hole is a region of space where gravity is so strong that nothing, not even light, can escape." },
    { t: "Galaxy", a: ["galaxies"], c: "Astronomy", d: "A galaxy is a huge system of stars, gas, dust and dark matter bound together by gravity; ours is the Milky Way." },
    { t: "Big Bang", a: ["big bang theory"], c: "Astronomy", d: "The Big Bang is the leading theory that the universe began about 13.8 billion years ago from an extremely hot, dense state and has been expanding ever since." },

    //, Economics, 
    { t: "Supply and demand", a: ["supply", "demand"], c: "Economics", d: "Supply and demand describes how the price of a good is set by the relationship between how much is available and how much people want it." },
    { t: "Inflation", a: [], c: "Economics", d: "Inflation is the general rise in prices over time, which reduces the purchasing power of money." },
    { t: "GDP", a: ["gross domestic product"], c: "Economics", d: "GDP (Gross Domestic Product) is the total value of all goods and services produced in a country in a given period." },

    //, Language / Literature, 
    { t: "Metaphor", a: [], c: "English", d: "A metaphor describes something by saying it is something else, e.g. 'time is a thief'." },
    { t: "Simile", a: [], c: "English", d: "A simile compares two things using 'like' or 'as', e.g. 'as brave as a lion'." },
    { t: "Noun", a: [], c: "English", d: "A noun is a word that names a person, place, thing or idea." },
    { t: "Verb", a: [], c: "English", d: "A verb is a word that expresses an action, occurrence or state of being." },
    { t: "Adjective", a: [], c: "English", d: "An adjective is a word that describes or modifies a noun." },
    { t: "Alliteration", a: [], c: "English", d: "Alliteration is the repetition of the same initial consonant sound in nearby words, e.g. 'Peter Piper picked'." },
    { t: "Personification", a: [], c: "English", d: "Personification gives human qualities to non-human things, e.g. 'the wind whispered'." },
    { t: "Hyperbole", a: [], c: "English", d: "Hyperbole is deliberate exaggeration for effect, e.g. 'I've told you a million times'." },
    { t: "Onomatopoeia", a: [], c: "English", d: "Onomatopoeia is a word that imitates a sound, like 'buzz', 'bang' or 'sizzle'." },
    { t: "Synonym", a: [], c: "English", d: "A synonym is a word with the same or similar meaning as another, e.g. 'big' and 'large'." },
    { t: "Antonym", a: [], c: "English", d: "An antonym is a word with the opposite meaning of another, e.g. 'hot' and 'cold'." },
    { t: "Adverb", a: [], c: "English", d: "An adverb describes a verb, adjective or another adverb, often ending in -ly (e.g. 'quickly')." },
    { t: "Pronoun", a: [], c: "English", d: "A pronoun replaces a noun, like 'he', 'she', 'it' or 'they'." },
    { t: "Protagonist", a: [], c: "English", d: "The protagonist is the main character of a story, often the hero." },

    //, more Biology, 
    { t: "Nucleus", a: [], c: "Biology", d: "The nucleus is the control centre of a eukaryotic cell, containing the cell's DNA." },
    { t: "Ribosome", a: ["ribosomes"], c: "Biology", d: "Ribosomes are tiny structures where proteins are made by joining amino acids together." },
    { t: "Chloroplast", a: ["chloroplasts"], c: "Biology", d: "Chloroplasts are organelles in plant cells where photosynthesis takes place; they contain chlorophyll." },
    { t: "Cell membrane", a: [], c: "Biology", d: "The cell membrane is a thin barrier that controls what enters and leaves the cell." },
    { t: "Homeostasis", a: [], c: "Biology", d: "Homeostasis is the maintenance of a stable internal environment in the body (e.g. temperature, blood sugar)." },
    { t: "Food chain", a: [], c: "Biology", d: "A food chain shows how energy passes from one organism to the next: producer → consumer → predator." },
    { t: "Neuron", a: ["neurone", "nerve cell"], c: "Biology", d: "A neuron is a nerve cell that transmits electrical signals around the body." },
    { t: "Hormone", a: ["hormones"], c: "Biology", d: "Hormones are chemical messengers released into the blood to regulate body processes." },
    { t: "Vaccine", a: ["vaccination", "immunisation"], c: "Biology", d: "A vaccine trains the immune system to recognise a pathogen, giving protection without causing the disease." },
    { t: "Digestion", a: [], c: "Biology", d: "Digestion is the breakdown of food into small molecules the body can absorb and use." },

    //, more Chemistry, 
    { t: "States of matter", a: ["solid liquid gas"], c: "Chemistry", d: "The three common states of matter are solid (fixed shape), liquid (flows, fixed volume) and gas (fills its container)." },
    { t: "Mixture", a: ["mixtures"], c: "Chemistry", d: "A mixture contains two or more substances that are not chemically bonded and can be separated physically." },
    { t: "Chemical reaction", a: ["reaction"], c: "Chemistry", d: "A chemical reaction rearranges atoms to turn reactants into new products." },
    { t: "Electron", a: ["electrons"], c: "Chemistry", d: "An electron is a negatively charged particle that orbits the nucleus of an atom." },
    { t: "Proton", a: ["protons"], c: "Chemistry", d: "A proton is a positively charged particle in the nucleus of an atom; its count is the atomic number." },
    { t: "Neutron", a: ["neutrons"], c: "Chemistry", d: "A neutron is a neutral (uncharged) particle in the nucleus of an atom." },
    { t: "Solvent", a: [], c: "Chemistry", d: "A solvent is the substance (usually a liquid) that dissolves a solute to form a solution." },
    { t: "Exothermic", a: ["exothermic reaction"], c: "Chemistry", d: "An exothermic reaction releases energy, usually as heat (e.g. combustion)." },
    { t: "Endothermic", a: ["endothermic reaction"], c: "Chemistry", d: "An endothermic reaction absorbs energy from its surroundings, often cooling them." },

    //, more Physics, 
    { t: "Wave", a: ["waves"], c: "Physics", d: "A wave transfers energy from place to place without transferring matter, e.g. light, sound or water waves." },
    { t: "Frequency", a: [], c: "Physics", d: "Frequency is the number of wave cycles per second, measured in hertz (Hz)." },
    { t: "Wavelength", a: [], c: "Physics", d: "Wavelength is the distance between two corresponding points on a wave, e.g. crest to crest." },
    { t: "Voltage", a: ["potential difference"], c: "Physics", d: "Voltage is the energy given to charge in a circuit, measured in volts (V)." },
    { t: "Current", a: ["electric current"], c: "Physics", d: "Electric current is the rate of flow of electric charge, measured in amperes (A)." },
    { t: "Resistance", a: [], c: "Physics", d: "Resistance opposes the flow of current in a circuit, measured in ohms (Ω)." },
    { t: "Density", a: [], c: "Physics", d: "Density is mass per unit volume (density = mass ÷ volume)." },
    { t: "Pressure", a: [], c: "Physics", d: "Pressure is force per unit area (pressure = force ÷ area), measured in pascals (Pa)." },
    { t: "Nuclear fusion", a: ["fusion"], c: "Physics", d: "Nuclear fusion joins light nuclei into a heavier one, releasing huge energy, it powers the Sun." },
    { t: "Nuclear fission", a: ["fission"], c: "Physics", d: "Nuclear fission splits a heavy nucleus into smaller ones, releasing energy, used in power stations." },
    { t: "Speed of light", a: [], c: "Physics", d: "The speed of light in a vacuum is about 299,792,458 metres per second, the universe's speed limit." },

    //, more Maths, 
    { t: "Quadratic equation", a: ["quadratic"], c: "Maths", d: "A quadratic equation has the form ax² + bx + c = 0 and can be solved with the quadratic formula." },
    { t: "Slope", a: ["gradient"], c: "Maths", d: "Slope (gradient) measures the steepness of a line: rise divided by run." },
    { t: "Area", a: [], c: "Maths", d: "Area is the amount of space inside a 2D shape, measured in square units." },
    { t: "Volume", a: [], c: "Maths", d: "Volume is the amount of space a 3D object occupies, measured in cubic units." },
    { t: "Ratio", a: [], c: "Maths", d: "A ratio compares two quantities, e.g. 2:3 means 2 parts to 3 parts." },
    { t: "Logarithm", a: ["log"], c: "Maths", d: "A logarithm is the power to which a base must be raised to get a number; log₁₀(100) = 2." },
    { t: "Standard deviation", a: [], c: "Maths", d: "Standard deviation measures how spread out a set of values is around the mean." },

    //, more History, 
    { t: "American Revolution", a: ["us revolution"], c: "History", d: "The American Revolution (1775 to 1783) was the war in which the Thirteen Colonies won independence from Britain." },
    { t: "Roman Empire", a: ["ancient rome"], c: "History", d: "The Roman Empire was a vast Mediterranean civilisation (27 BC, 476 AD) known for law, engineering and military power." },
    { t: "Ancient Egypt", a: ["egyptians"], c: "History", d: "Ancient Egypt was a civilisation along the Nile famous for pharaohs, pyramids and hieroglyphics." },
    { t: "Great Depression", a: [], c: "History", d: "The Great Depression (1929 to 1939) was a severe worldwide economic downturn that began with a US stock market crash." },

    //, more Geography / Astronomy / Economics, 
    { t: "Water cycle", a: ["hydrological cycle"], c: "Geography", d: "The water cycle is the continuous movement of water through evaporation, condensation, precipitation and collection." },
    { t: "Volcano", a: ["volcanoes"], c: "Geography", d: "A volcano is an opening in Earth's crust through which molten rock (lava), ash and gases erupt." },
    { t: "Erosion", a: [], c: "Geography", d: "Erosion is the wearing away and movement of rock and soil by wind, water or ice." },
    { t: "Planet", a: ["planets"], c: "Astronomy", d: "A planet is a large body that orbits a star, is round due to its gravity, and has cleared its orbit." },
    { t: "Eclipse", a: ["solar eclipse", "lunar eclipse"], c: "Astronomy", d: "An eclipse happens when one celestial body moves into the shadow of another, e.g. the Moon blocking the Sun." },
    { t: "Orbit", a: [], c: "Astronomy", d: "An orbit is the curved path one object takes around another due to gravity, like Earth around the Sun." },
    { t: "Recession", a: [], c: "Economics", d: "A recession is a significant, widespread decline in economic activity lasting months, usually two quarters of falling GDP." },

    //, more Computer Science, 
    { t: "Database", a: ["databases"], c: "Computer Science", d: "A database is an organised collection of data that can be easily stored, searched and updated." },
    { t: "Compiler", a: [], c: "Computer Science", d: "A compiler translates source code written by a programmer into machine code a computer can run." },
    { t: "CPU", a: ["processor", "central processing unit"], c: "Computer Science", d: "The CPU is the 'brain' of a computer that carries out instructions and calculations." },
    { t: "Encryption", a: [], c: "Computer Science", d: "Encryption scrambles data so only someone with the key can read it, keeping information secure." },
  ];

  //, step-by-step processes & procedures, 
  const STEPS = [
    { t: "Photosynthesis", a: ["photosynthesis process"], steps: [
      "Light is absorbed by chlorophyll in the chloroplasts of leaf cells.",
      "Water is taken up by the roots and carried to the leaves.",
      "Carbon dioxide enters the leaf through tiny pores called stomata.",
      "Light energy splits water and powers reactions that combine CO₂ into glucose.",
      "Glucose is used for energy/growth, and oxygen is released as a by-product." ] },
    { t: "Cellular respiration", a: ["respiration process"], steps: [
      "Glucose and oxygen are delivered to the cells by the blood.",
      "Glycolysis splits glucose into pyruvate in the cytoplasm, releasing a little energy.",
      "The pyruvate enters the mitochondria and goes through the Krebs cycle.",
      "The electron transport chain uses oxygen to release most of the energy as ATP.",
      "Carbon dioxide and water are produced as waste and removed from the body." ] },
    { t: "The water cycle", a: ["water cycle"], steps: [
      "Evaporation: the Sun heats water in oceans and lakes, turning it into vapour.",
      "Condensation: the vapour rises, cools, and forms clouds.",
      "Precipitation: water falls back to Earth as rain, snow or hail.",
      "Collection: water gathers in rivers, lakes and oceans, and the cycle repeats." ] },
    { t: "Mitosis", a: ["cell division"], steps: [
      "Interphase: the cell grows and copies its DNA.",
      "Prophase: chromosomes condense and become visible.",
      "Metaphase: chromosomes line up along the middle of the cell.",
      "Anaphase: identical chromosome copies are pulled to opposite ends.",
      "Telophase & cytokinesis: the cell splits into two identical daughter cells." ] },
    { t: "The scientific method", a: ["scientific method"], steps: [
      "Ask a question based on an observation.",
      "Do background research and form a hypothesis (a testable prediction).",
      "Design and run a fair experiment to test it.",
      "Collect and analyse the data.",
      "Draw a conclusion and share results, then repeat to confirm." ] },
    { t: "Writing an essay", a: ["essay", "essay writing"], steps: [
      "Understand the question and decide your main argument (thesis).",
      "Brainstorm ideas and gather evidence.",
      "Plan an outline: introduction, body paragraphs, conclusion.",
      "Write each body paragraph with one point, evidence and explanation.",
      "Write the intro and conclusion, then proofread and edit." ] },
    { t: "Order of operations", a: ["bodmas", "pemdas", "bidmas"], steps: [
      "Brackets first, solve anything inside ( ).",
      "Indices / Orders next, powers and roots.",
      "Division and Multiplication, left to right.",
      "Addition and Subtraction, left to right." ] },
    { t: "Long division", a: ["how to divide"], steps: [
      "Divide: how many times does the divisor go into the first digit(s)?",
      "Multiply that answer by the divisor.",
      "Subtract to find the remainder.",
      "Bring down the next digit and repeat until finished." ] },
  ];

  function steps(query) {
    const q = norm(query);
    const qt = new Set(tok(query));
    let best = null, score = 0;
    for (const p of STEPS) {
      const names = [p.t, ...(p.a || [])];
      let s = 0;
      for (const n of names) { if (new RegExp("\\b" + reEsc(n.toLowerCase()) + "\\b").test(q)) s += 5; }
      for (const n of names) for (const w of tok(n)) if (qt.has(w)) s += 1.5;
      if (s > score) { score = s; best = p; }
    }
    return score >= 3 ? { title: best.t, steps: best.steps } : null;
  }

  // index by token for fast-ish matching
  const MINISTOP = new Set("the and are was for with what whats why how does did you your this that from have has had been will can not when where who which".split(" "));
  const norm = (s) => s.toLowerCase().replace(/[^a-z0-9 ]/g, " ");
  const tok = (s) => norm(s).split(/\s+/).filter((w) => w.length > 2 && !MINISTOP.has(w));
  const reEsc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  function lookup(query) {
    const q = norm(query);
    const qt = new Set(tok(query));
    let best = null, bestScore = 0;
    for (const e of KB) {
      const names = [e.t, ...(e.a || [])];
      let score = 0;
      // strong: an alias/term appears as a whole word/phrase in the query
      for (const n of names) { const nl = n.toLowerCase(); if (new RegExp("\\b" + reEsc(nl) + "\\b").test(q)) score += 4 + nl.length / 10; }
      // token overlap with name + definition
      const dt = tok(e.t + " " + (e.a || []).join(" ") + " " + e.d);
      let overlap = 0; for (const w of dt) if (qt.has(w)) overlap++;
      score += overlap * 0.6;
      // bonus if a name token matches
      for (const n of names) for (const w of tok(n)) if (qt.has(w)) score += 1.2;
      if (score > bestScore) { bestScore = score; best = e; }
    }
    return bestScore >= 3 ? best : null;
  }

  // ---------- from-scratch calculator ----------
  function preprocess(q) {
    let s = " " + q.toLowerCase() + " ";
    s = s.replace(/what\s+is|whats|calculate|compute|evaluate|solve|equals?|the\s+|please|step[ -]?by[ -]?step|steps?|show me|work(?:ed)?(?: it)?(?: out)?|\?/g, " ");
    s = s.replace(/(\d+(?:\.\d+)?)\s*%\s*of\s*(\d+(?:\.\d+)?)/g, "($1/100*$2)");
    s = s.replace(/(\d+(?:\.\d+)?)\s*%/g, "($1/100)");
    s = s.replace(/(\d+(?:\.\d+)?)\s*squared\b/g, "($1^2)");
    s = s.replace(/(\d+(?:\.\d+)?)\s*cubed\b/g, "($1^3)");
    s = s.replace(/\bplus\b/g, "+").replace(/\bminus\b/g, "-")
      .replace(/\b(times|multiplied by)\b/g, "*").replace(/\b(divided by|over)\b/g, "/")
      .replace(/\b(to the power of|power of|raised to)\b/g, "^");
    s = s.replace(/(square root of|sqrt of)\s*/g, "sqrt ");
    return s.trim();
  }
  const FNAMES = "sqrt|cbrt|sin|cos|tan|asin|acos|atan|sinh|cosh|tanh|log10|log2|log|ln|exp|abs|sign|floor|ceil|round|ncr|npr|gcd|lcm|fact|pow|root|min|max";
  const looksLikeMath = (q) => {
    const s = normMath(q);
    if (/=/.test(s)) return false;
    const hasNum = /\d|\bpi\b|\btau\b/.test(s);
    const hasOp = /[+\-*/^!°]/.test(s) || new RegExp("\\b(" + FNAMES + ")\\s*\\(").test(s);
    return hasNum && hasOp;
  };

  function tokenizeMath(s) {
    const out = []; const re = /\s*(\d+\.?\d*|\.\d+|[-+*/^()]|sqrt|abs|round)\s*/g; let m, last = 0;
    while ((m = re.exec(s))) { if (m.index !== last) return null; last = re.lastIndex; out.push(m[1]); }
    return last === s.length ? out : null;
  }
  const MPREC = { "+": 1, "-": 1, "*": 2, "/": 2, "^": 3 };
  const MFUNCS = new Set(["sqrt", "abs", "round"]);
  const MSYM = { "+": "+", "-": "−", "*": "×", "/": "÷", "^": "^" };
  const round = (n) => Math.round(n * 1e10) / 1e10;

  // shunting-yard → Reverse Polish Notation
  function toRPN(query) {
    const tokens = tokenizeMath(preprocess(query).replace(/\bx\b/g, "*"));
    if (!tokens) return null;
    const output = [], ops = [];
    let prev = null;
    for (const t of tokens) {
      if (/^[\d.]/.test(t)) output.push(parseFloat(t));
      else if (MFUNCS.has(t)) ops.push(t);
      else if (t in MPREC) {
        let op = t;
        if (op === "-" && (prev === null || prev in MPREC || prev === "(")) op = "u-";
        while (ops.length) { const top = ops[ops.length - 1]; if (top === "(") break; const tp = top === "u-" ? 4 : (MFUNCS.has(top) ? 5 : MPREC[top]); const cp = op === "u-" ? 4 : MPREC[op]; if (tp > cp || (tp === cp && op !== "^" && op !== "u-")) output.push(ops.pop()); else break; }
        ops.push(op);
      } else if (t === "(") ops.push(t);
      else if (t === ")") { while (ops.length && ops[ops.length - 1] !== "(") output.push(ops.pop()); if (!ops.length) return null; ops.pop(); if (ops.length && MFUNCS.has(ops[ops.length - 1])) output.push(ops.pop()); }
      prev = t;
    }
    while (ops.length) { const o = ops.pop(); if (o === "(") return null; output.push(o); }
    return output;
  }

  // evaluate RPN; if `steps` array is passed, record each operation
  function evalRPN(rpn, steps) {
    const st = [];
    for (const tk of rpn) {
      if (typeof tk === "number") st.push(tk);
      else if (tk === "u-") { if (!st.length) return null; const a = st.pop(); st.push(-a); }
      else if (MFUNCS.has(tk)) { if (!st.length) return null; const a = st.pop(); const r = tk === "sqrt" ? Math.sqrt(a) : tk === "abs" ? Math.abs(a) : Math.round(a); if (steps) steps.push(`${tk}(${round(a)}) = **${round(r)}**`); st.push(r); }
      else { if (st.length < 2) return null; const b = st.pop(), a = st.pop(); const r = tk === "+" ? a + b : tk === "-" ? a - b : tk === "*" ? a * b : tk === "/" ? a / b : Math.pow(a, b); if (steps) steps.push(`${round(a)} ${MSYM[tk]} ${round(b)} = **${round(r)}**`); st.push(r); }
    }
    return st.length === 1 && isFinite(st[0]) ? round(st[0]) : null;
  }

  function evalMath(query) { return evaluate(query); }
  function evalSteps(query) {
    const rpn = toRPN(query); if (!rpn) return null;
    const steps = []; const result = evalRPN(rpn, steps);
    return result === null ? null : { result, steps };
  }

  // ===========================================================
  //  Advanced engine: expression parser → AST → scientific eval,
  //  symbolic differentiation, and numeric integration.
  // ===========================================================
  const CONSTS = { pi: Math.PI, e: Math.E, tau: 2 * Math.PI, phi: (1 + Math.sqrt(5)) / 2, __deg: Math.PI / 180 };
  function factorial(n) { if (n < 0 || n !== Math.floor(n) || n > 170) return NaN; let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; }
  function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { const t = b; b = a % b; a = t; } return a; }
  function lcm(a, b) { return Math.abs(a * b) / (gcd(a, b) || 1); }
  const FN1 = { sin: Math.sin, cos: Math.cos, tan: Math.tan, asin: Math.asin, acos: Math.acos, atan: Math.atan, sinh: Math.sinh, cosh: Math.cosh, tanh: Math.tanh, ln: Math.log, log: Math.log10, log10: Math.log10, log2: Math.log2, exp: Math.exp, sqrt: Math.sqrt, cbrt: Math.cbrt, abs: Math.abs, sign: Math.sign, floor: Math.floor, ceil: Math.ceil, round: Math.round, fact: factorial };
  const FN2 = { ncr: (n, r) => factorial(n) / (factorial(r) * factorial(n - r)), npr: (n, r) => factorial(n) / factorial(n - r), gcd, lcm, pow: Math.pow, root: (x, n) => Math.sign(x) * Math.pow(Math.abs(x), 1 / n), logb: (x, b) => Math.log(x) / Math.log(b), max: Math.max, min: Math.min };

  function normMath(s) {
    return String(s).toLowerCase()
      .replace(/[×·∙]/g, "*").replace(/÷/g, "/").replace(/−/g, "-").replace(/√/g, "sqrt").replace(/π/g, "pi").replace(/²/g, "^2").replace(/³/g, "^3")
      .replace(/(\d+(?:\.\d+)?)\s*%\s*of\s*(\d+(?:\.\d+)?)/g, "($1/100*$2)").replace(/(\d+(?:\.\d+)?)\s*%/g, "($1/100)")
      .replace(/(\d+(?:\.\d+)?)\s*squared\b/g, "($1^2)").replace(/(\d+(?:\.\d+)?)\s*cubed\b/g, "($1^3)")
      .replace(/(\d+(?:\.\d+)?)\s*factorial\b/g, "($1)!").replace(/\bfactorial of\s*(\d+(?:\.\d+)?)/g, "($1)!")
      .replace(/\bdegrees?\b|\bdeg\b/g, "°")
      .replace(/\bplus\b/g, "+").replace(/\bminus\b/g, "-").replace(/\b(times|multiplied by)\b/g, "*").replace(/\b(divided by|over)\b/g, "/").replace(/\b(to the power of|power of|raised to)\b/g, "^").replace(/\bsquare root of\b/g, "sqrt")
      .replace(/\b(what is|whats|calculate|compute|evaluate|the value of|value of|work out|answer to|equals?|please)\b/g, " ")
      .replace(/[?]/g, " ").trim();
  }
  function lexM(s) {
    const t = []; let i = 0; s = s.replace(/\s+/g, "");
    while (i < s.length) {
      const c = s[i];
      if (/[0-9.]/.test(c)) { let j = i + 1; while (j < s.length && /[0-9.]/.test(s[j])) j++; t.push({ t: "num", v: parseFloat(s.slice(i, j)) }); i = j; }
      else if (/[a-z]/.test(c)) { let j = i + 1; while (j < s.length && /[a-z0-9]/.test(s[j])) j++; t.push({ t: "name", v: s.slice(i, j) }); i = j; }
      else if ("+-*/^".includes(c)) { t.push({ t: "op", v: c }); i++; }
      else if (c === "(") { t.push({ t: "(" }); i++; }
      else if (c === ")") { t.push({ t: ")" }); i++; }
      else if (c === ",") { t.push({ t: "," }); i++; }
      else if (c === "!") { t.push({ t: "!" }); i++; }
      else if (c === "°") { t.push({ t: "deg" }); i++; }
      else return null;
    }
    return t;
  }
  function parseM(tokens) {
    let p = 0; const peek = () => tokens[p], eat = () => tokens[p++];
    function expr() { let n = term(); while (peek() && peek().t === "op" && (peek().v === "+" || peek().v === "-")) { const op = eat().v; n = { op, a: n, b: term() }; } return n; }
    function term() {
      let n = unary();
      while (peek()) { const k = peek();
        if (k.t === "op" && (k.v === "*" || k.v === "/")) { const op = eat().v; n = { op, a: n, b: unary() }; }
        else if (k.t === "num" || k.t === "(" || k.t === "name") n = { op: "*", a: n, b: unary() };
        else break;
      } return n;
    }
    function unary() { if (peek() && peek().t === "op" && peek().v === "-") { eat(); return { neg: unary() }; } if (peek() && peek().t === "op" && peek().v === "+") { eat(); return unary(); } return pow(); }
    function pow() { const b = postfix(); if (peek() && peek().t === "op" && peek().v === "^") { eat(); return { op: "^", a: b, b: unary() }; } return b; }
    function postfix() { let n = primary(); while (peek() && (peek().t === "!" || peek().t === "deg")) { const k = eat(); n = k.t === "!" ? { fact: n } : { op: "*", a: n, b: { c: "__deg" } }; } return n; }
    function primary() {
      const k = eat(); if (!k) throw "eof";
      if (k.t === "num") return { n: k.v };
      if (k.t === "(") { const e = expr(); if (!peek() || peek().t !== ")") throw "paren"; eat(); return e; }
      if (k.t === "name") {
        if (peek() && peek().t === "(") { eat(); const args = []; if (peek() && peek().t !== ")") { args.push(expr()); while (peek() && peek().t === ",") { eat(); args.push(expr()); } } if (!peek() || peek().t !== ")") throw "paren"; eat(); return { f: k.v, args }; }
        if (k.v === "x") return { v: "x" };
        if (CONSTS[k.v] !== undefined) return { c: k.v };
        throw "name";
      }
      throw "tok";
    }
    const a = expr(); if (p < tokens.length) throw "trail"; return a;
  }
  function parseMath(s) { try { const tk = lexM(normMath(s)); if (!tk || !tk.length) return null; return parseM(tk); } catch (e) { return null; } }

  function ev(a, sc) {
    if (!a) return NaN;
    if ("n" in a) return a.n;
    if ("v" in a) return sc && sc[a.v] !== undefined ? sc[a.v] : NaN;
    if ("c" in a) return CONSTS[a.c];
    if ("neg" in a) return -ev(a.neg, sc);
    if ("fact" in a) return factorial(ev(a.fact, sc));
    if ("f" in a) { const args = a.args.map((x) => ev(x, sc)); if (FN1[a.f] && args.length === 1) return FN1[a.f](args[0]); if (FN2[a.f]) return FN2[a.f](...args); return NaN; }
    const x = ev(a.a, sc), y = ev(a.b, sc);
    return a.op === "+" ? x + y : a.op === "-" ? x - y : a.op === "*" ? x * y : a.op === "/" ? x / y : a.op === "^" ? Math.pow(x, y) : NaN;
  }
  function evaluate(query) { const a = parseMath(query); if (!a) return null; const r = ev(a, {}); return isFinite(r) ? round(r) : null; }

  const hasVar = (a) => !a ? false : "v" in a ? true : "neg" in a ? hasVar(a.neg) : "fact" in a ? hasVar(a.fact) : "f" in a ? a.args.some(hasVar) : "op" in a ? hasVar(a.a) || hasVar(a.b) : false;
  function diff(a) {
    if (!a) return null;
    if ("n" in a || "c" in a) return { n: 0 };
    if ("v" in a) return { n: 1 };
    if ("neg" in a) { const d = diff(a.neg); return d ? { neg: d } : null; }
    if ("fact" in a) return null;
    if ("f" in a) return diffFn(a);
    const u = a.a, v = a.b, du = diff(u), dv = diff(v); if (!du || !dv) return null;
    if (a.op === "+" || a.op === "-") return { op: a.op, a: du, b: dv };
    if (a.op === "*") return { op: "+", a: { op: "*", a: du, b: v }, b: { op: "*", a: u, b: dv } };
    if (a.op === "/") return { op: "/", a: { op: "-", a: { op: "*", a: du, b: v }, b: { op: "*", a: u, b: dv } }, b: { op: "^", a: v, b: { n: 2 } } };
    if (a.op === "^") {
      if (!hasVar(v)) { const n = ev(v, {}); return { op: "*", a: { op: "*", a: { n }, b: { op: "^", a: u, b: { n: n - 1 } } }, b: du }; }
      if (!hasVar(u)) return { op: "*", a: { op: "*", a: a, b: { f: "ln", args: [u] } }, b: dv };
      return null;
    }
    return null;
  }
  function diffFn(a) {
    const u = a.args[0], du = diff(u); if (!du) return null;
    const chain = (d) => ({ op: "*", a: d, b: du });
    const sq = (z) => ({ op: "^", a: z, b: { n: 2 } });
    switch (a.f) {
      case "sin": return chain({ f: "cos", args: [u] });
      case "cos": return chain({ neg: { f: "sin", args: [u] } });
      case "tan": return chain({ op: "/", a: { n: 1 }, b: sq({ f: "cos", args: [u] }) });
      case "exp": return chain({ f: "exp", args: [u] });
      case "ln": return { op: "/", a: du, b: u };
      case "log": case "log10": return { op: "/", a: du, b: { op: "*", a: u, b: { f: "ln", args: [{ n: 10 }] } } };
      case "sqrt": return { op: "/", a: du, b: { op: "*", a: { n: 2 }, b: { f: "sqrt", args: [u] } } };
      case "asin": return { op: "/", a: du, b: { f: "sqrt", args: [{ op: "-", a: { n: 1 }, b: sq(u) }] } };
      case "acos": return { neg: { op: "/", a: du, b: { f: "sqrt", args: [{ op: "-", a: { n: 1 }, b: sq(u) }] } } };
      case "atan": return { op: "/", a: du, b: { op: "+", a: { n: 1 }, b: sq(u) } };
      default: return null;
    }
  }
  function simp(a) {
    if (!a || "n" in a || "v" in a || "c" in a) return a;
    if ("neg" in a) { const c = simp(a.neg); return "n" in c ? { n: -c.n } : { neg: c }; }
    if ("fact" in a) return { fact: simp(a.fact) };
    if ("f" in a) return { f: a.f, args: a.args.map(simp) };
    const x = simp(a.a), y = simp(a.b), op = a.op, nm = (z) => "n" in z;
    if (nm(x) && nm(y)) { const r = op === "+" ? x.n + y.n : op === "-" ? x.n - y.n : op === "*" ? x.n * y.n : op === "/" ? x.n / y.n : Math.pow(x.n, y.n); return { n: round(r) }; }
    if (op === "+") { if (nm(x) && x.n === 0) return y; if (nm(y) && y.n === 0) return x; }
    if (op === "-") { if (nm(y) && y.n === 0) return x; if (nm(x) && x.n === 0) return simp({ neg: y }); }
    if (op === "*") { if ((nm(x) && x.n === 0) || (nm(y) && y.n === 0)) return { n: 0 }; if (nm(x) && x.n === 1) return y; if (nm(y) && y.n === 1) return x; }
    if (op === "/") { if (nm(x) && x.n === 0) return { n: 0 }; if (nm(y) && y.n === 1) return x; }
    if (op === "^") { if (nm(y) && y.n === 1) return x; if (nm(y) && y.n === 0) return { n: 1 }; }
    return { op, a: x, b: y };
  }
  const PREC = { "+": 1, "-": 1, "*": 2, "/": 2, "^": 3 };
  const CNAME = { pi: "π", e: "e", tau: "τ", phi: "φ", __deg: "(π/180)" };
  const fmtNum = (v) => (Number.isInteger(v) ? String(v) : String(round(v)));
  function astStr(a, pp, right) {
    pp = pp || 0; let s, myP = 99;
    if (!a) return "";
    if ("n" in a) s = fmtNum(a.n);
    else if ("v" in a) s = "x";
    else if ("c" in a) s = CNAME[a.c] || a.c;
    else if ("neg" in a) { myP = 2; s = "−" + astStr(a.neg, 3, false); }
    else if ("fact" in a) s = astStr(a.fact, 4, false) + "!";
    else if ("f" in a) s = a.f + "(" + a.args.map((z) => astStr(z, 0, false)).join(", ") + ")";
    else {
      myP = PREC[a.op];
      const l = astStr(a.a, myP, false), r = astStr(a.b, myP, true);
      if (a.op === "*" && "n" in a.a && !("n" in a.b) && (("v" in a.b) || (a.b.op === "^" && "v" in a.b.a))) s = (a.a.n === 1 ? "" : a.a.n === -1 ? "−" : fmtNum(a.a.n)) + r;
      else if (a.op === "^") s = l + "^" + r;
      else s = l + " " + (a.op === "*" ? "·" : a.op === "-" ? "−" : a.op === "/" ? "/" : "+") + " " + r;
    }
    if (myP < pp || (myP === pp && right && pp >= 1 && pp <= 3)) s = "(" + s + ")";
    return s;
  }
  function differentiate(query) {
    let s = String(query).replace(/^.*?(?:differentiate|derivative of|derivative|d\s*\/\s*dx of|d\s*\/\s*dx)\s*/i, "").replace(/\s*with respect to\s*x\s*$/i, "").replace(/[?]/g, "").trim();
    const ast = parseMath(s); if (!ast) return null;
    let d = diff(ast); if (!d) return null;
    d = simp(simp(simp(d)));
    return { input: astStr(ast, 0, false), derivative: astStr(d, 0, false) };
  }
  function integrateDefinite(query) {
    const m = String(query).match(/(?:integrate|integral of|integral|∫)\s*(.+?)\s*(?:dx\s*)?(?:from|,)\s*(.+?)\s*(?:to|,)\s*(.+?)\s*$/i);
    if (!m) return null;
    const ast = parseMath(m[1].replace(/\bdx\b/i, "")); if (!ast) return null;
    const a = evaluate(m[2]), b = evaluate(m[3]); if (a === null || b === null) return null;
    const f = (x) => ev(ast, { x });
    const n = 1000, h = (b - a) / n; let sum = f(a) + f(b);
    for (let i = 1; i < n; i++) sum += (i % 2 ? 4 : 2) * f(a + i * h);
    const res = (h / 3) * sum;
    return isFinite(res) ? { fn: astStr(ast, 0, false), a: round(a), b: round(b), result: round(res) } : null;
  }

  // ---- equation solver (linear & quadratic in x), from scratch ----
  // Samples f(x) = LHS − RHS at x = 0,1,−1,2. Any degree-≤2 polynomial in x is
  // then determined by f(0)=c, a=(f1+f-1)/2−c, b=(f1−f-1)/2 (with a consistency check).
  function solveEquation(str0) {
    let q = String(str0).toLowerCase().replace(/step by step/g, "").replace(/^solve(?: for x)?:?/g, "").replace(/[?]/g, "").trim();
    if ((q.match(/=/g) || []).length !== 1 || !/x/.test(q)) return null;
    const [L, R] = q.split("=");
    const aL = parseMath(L), aR = parseMath(R); if (!aL || !aR) return null;
    const g = (x) => ev(aL, { x }) - ev(aR, { x });
    const f0 = g(0), f1 = g(1), fm1 = g(-1), f2 = g(2);
    if (![f0, f1, fm1, f2].every(isFinite)) return null;
    const c = f0, a = (f1 + fm1) / 2 - c, b = (f1 - fm1) / 2;
    if (Math.abs((4 * a + 2 * b + c) - f2) > 1e-6 * (1 + Math.abs(f2))) return null; // not linear/quadratic in x
    const near = (z) => Math.abs(z) < 1e-9;
    const disp = String(str0).replace(/\s+/g, " ").trim();
    const sgn = (n) => (n >= 0 ? "+ " + round(n) : "− " + round(-n));
    const coef = (n) => (n === 1 ? "" : n === -1 ? "−" : String(round(n)));
    if (near(a)) {
      if (near(b)) return null;
      const x = round(-c / b);
      const steps = [`Start: **${disp}**`, `Rearrange to **${coef(b)}x ${sgn(c)} = 0**`];
      if (Math.abs(b) === 1) steps.push(b === -1 ? `Multiply by −1: **x = ${x}**` : `So **x = ${x}**`);
      else { steps.push(`Move the number across: **${coef(b)}x = ${round(-c)}**`); steps.push(`Divide by ${round(b)}: **x = ${x}**`); }
      return { type: "linear", solution: x, steps };
    }
    const D = b * b - 4 * a * c;
    const steps = [`This is a quadratic: **${coef(a)}x² ${sgn(b)}x ${sgn(c)} = 0**`, `Quadratic formula: x = (−b ± √(b²−4ac)) ÷ 2a`, `Discriminant: D = (${round(b)})² − 4·${round(a)}·${round(c)} = **${round(D)}**`];
    if (D < -1e-9) { const re = round(-b / (2 * a)), im = round(Math.sqrt(-D) / (2 * a)); steps.push("D < 0 → two complex roots:"); steps.push(`**x = ${re} ± ${Math.abs(im)}i**`); return { type: "quadratic", complex: true, steps }; }
    if (near(D)) { const x = round(-b / (2 * a)); steps.push("D = 0 → one repeated root:"); steps.push(`**x = ${x}**`); return { type: "quadratic", solution: x, steps }; }
    const r1 = round((-b + Math.sqrt(D)) / (2 * a)), r2 = round((-b - Math.sqrt(D)) / (2 * a));
    steps.push(`x = (${round(-b)} ± √${round(D)}) ÷ ${round(2 * a)}`);
    steps.push(`**x = ${r1}**  or  **x = ${r2}**`);
    return { type: "quadratic", solutions: [r1, r2], steps };
  }

  // unified entry point used by the assistant
  function answer(query) {
    if (looksLikeMath(query)) { const r = evalMath(query); if (r !== null) return { type: "math", text: `**${r}**`, expr: query }; }
    const e = lookup(query);
    if (e) return { type: "fact", text: e.d, term: e.t, category: e.c };
    return null;
  }

  window.Cortex = window.Cortex || {};
  window.Cortex.knowledge = { lookup, answer, evalMath, evalSteps, looksLikeMath, steps, solveEquation, differentiate, integrateDefinite, evaluate, entries: KB, processes: STEPS };
})();
