/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * Cortex - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ===========================================================
   nlp.js, from-scratch text intelligence (no libraries, no API).
   This is the brain behind the Study Assistant & Quiz generator.

   Real algorithms, all hand-written:
     • light stemmer + stopword filtering
     • TF-IDF vector space over sentences
     • cosine-similarity retrieval  → free-form Q&A ("ask anything")
     • TextRank (PageRank on a sentence graph) → summarization
     • automatic question generation (definition / cloze / true-false)
     • fact, outline, related-term & comparison extraction
    It's heuristic, but it genuinely "reads" your notes.
   =========================================================== */
(function () {
  const STOP = new Set(("a about above after again against all am an and any are aren't as at be became become " +
    "because been before being below between both but by can cannot could did do does doing don't down during " +
    "each few for from further had has have having he her here hers him his how i if in into is it its itself " +
    "just let me more most my no nor not of off on once only or other our out over own same she should so some " +
    "such than that the their them then there these they this those through to too under until up very was we " +
    "were what when where which while who whom why will with would you your also which within upon many one two " +
    "three may might must shall each via etc however therefore thus often usually generally mainly include " +
    "including such using used use known called example examples like make makes made get got").split(/\s+/));

  const words = (t) => (String(t).toLowerCase().match(/[a-z0-9][a-z0-9'-]*/g) || []);
  const content = (t) => words(t).filter((w) => w.length > 2 && !STOP.has(w));
  const cap = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);
  const escapeReg = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  function sentences(text) {
    return (String(text || "").replace(/\s+/g, " ").match(/[^.!?]+[.!?]*/g) || [])
      .map((s) => s.trim()).filter((s) => s.length > 1);
  }

  // ---- light stemmer (conservative; only used for matching, never display) ----
  function stem(w) {
    w = w.toLowerCase();
    if (w.length <= 4) return w;
    if (/ies$/.test(w)) return w.slice(0, -3) + "y";
    if (/(ss|us|is)$/.test(w)) { /* keep base, fall through to verb endings */ }
    let s = w
      .replace(/(ational|ization|isation)$/, "ize")
      .replace(/(ing|edly|ed|ly|ment|ness|tion|sion|ities|ity|ous|ive|ize|ise|al|er|est|ful)$/, "");
    if (/[^s]s$/.test(s)) s = s.slice(0, -1); // plural -s but not -ss
    return s.length >= 3 ? s : w;
  }
  const tokens = (t) => content(t).map(stem);

  // ---- TF-IDF vector space over sentences ----
  function buildCorpus(sents) {
    const docs = sents.map((s) => {
      const tk = tokens(s), tf = Object.create(null);
      tk.forEach((w) => (tf[w] = (tf[w] || 0) + 1));
      return { tf };
    });
    const N = docs.length || 1;
    const df = Object.create(null);
    docs.forEach((d) => Object.keys(d.tf).forEach((t) => (df[t] = (df[t] || 0) + 1)));
    const idf = Object.create(null);
    for (const t in df) idf[t] = Math.log(1 + N / df[t]);
    docs.forEach((d) => (d.vec = tfidf(d.tf, idf, N)));
    return { docs, idf, N };
  }
  function tfidf(tf, idf, N) {
    const v = Object.create(null);
    for (const t in tf) v[t] = (1 + Math.log(tf[t])) * (idf[t] !== undefined ? idf[t] : Math.log(1 + N));
    return v;
  }
  function cosine(a, b) {
    let dot = 0, na = 0, nb = 0;
    for (const t in a) { na += a[t] * a[t]; if (b[t]) dot += a[t] * b[t]; }
    for (const t in b) nb += b[t] * b[t];
    return na && nb ? dot / Math.sqrt(na * nb) : 0;
  }

  // ---- TextRank summarization (PageRank over a sentence-similarity graph) ----
  function textrank(docs) {
    const N = docs.length;
    const sim = Array.from({ length: N }, () => new Float64Array(N));
    const out = new Float64Array(N);
    for (let i = 0; i < N; i++) {
      for (let j = i + 1; j < N; j++) {
        const s = cosine(docs[i].vec, docs[j].vec);
        sim[i][j] = sim[j][i] = s;
      }
    }
    for (let i = 0; i < N; i++) { let sum = 0; for (let j = 0; j < N; j++) sum += sim[i][j]; out[i] = sum || 1; }
    let score = new Float64Array(N).fill(1 / N);
    const d = 0.85;
    for (let it = 0; it < 30; it++) {
      const next = new Float64Array(N);
      for (let i = 0; i < N; i++) {
        let acc = 0;
        for (let j = 0; j < N; j++) if (i !== j && sim[j][i] > 0) acc += (sim[j][i] / out[j]) * score[j];
        next[i] = (1 - d) / N + d * acc;
      }
      score = next;
    }
    return score;
  }

  function summarize(text, n = 3) {
    const sents = sentences(text);
    if (sents.length <= n) return sents;
    const { docs } = buildCorpus(sents);
    let scores;
    try { scores = Array.from(textrank(docs)); } catch (_) { scores = sents.map(() => Math.random()); }
    return scores
      .map((sc, i) => ({ i, s: sents[i], sc: sc * (i === 0 ? 1.12 : 1) }))
      .sort((a, b) => b.sc - a.sc)
      .slice(0, n)
      .sort((a, b) => a.i - b.i)
      .map((x) => x.s);
  }

  // ---- key terms (aggregate TF-IDF + capitalized phrases) ----
  function keyTerms(text, limit = 12) {
    const sents = sentences(text);
    const { docs, idf, N } = buildCorpus(sents);
    const agg = Object.create(null);
    docs.forEach((d) => { for (const t in d.vec) agg[t] = (agg[t] || 0) + d.vec[t]; });
    // map stem -> a representative original word for display
    const display = Object.create(null);
    content(text).forEach((w) => { const s = stem(w); if (!display[s] || w.length < display[s].length) display[s] = w; });
    const ranked = Object.entries(agg).sort((a, b) => b[1] - a[1]).map(([s]) => display[s] || s);

    const phrases = (text.match(/\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3})\b/g) || []).map((p) => p.trim());
    const seen = new Set(), out = [];
    for (const p of [...phrases, ...ranked]) {
      const k = p.toLowerCase();
      if (seen.has(k) || STOP.has(k)) continue;
      seen.add(k); out.push(cap(p));
      if (out.length >= limit) break;
    }
    return out;
  }

  // ---- definitions ("X is/are/means/refers to Y") ----
  function definitions(text) {
    const out = [], seen = new Set();
    for (const s of sentences(text)) {
      const m = s.match(/^(.{2,60}?)\s+(?:is|are|was|were|means?|refers? to|is defined as|is called|describes?)\s+(.{4,}?)[.!?]?$/i);
      if (m) {
        const term = m[1].replace(/^(the|a|an)\s+/i, "").trim();
        const key = term.toLowerCase();
        if (!STOP.has(key) && term.split(/\s+/).length <= 5 && !seen.has(key)) { seen.add(key); out.push({ term, definition: s.trim() }); }
      }
    }
    return out;
  }

  // ---- free-form Q&A: retrieve the best-matching sentence(s) ----
  function questionType(q) {
    const t = q.toLowerCase();
    if (/\b(when|what year|which year|what date|how long)\b/.test(t)) return "when";
    if (/\bwho\b/.test(t)) return "who";
    if (/\b(how many|how much|what (?:number|percentage|fraction))\b/.test(t)) return "num";
    if (/\bwhy\b/.test(t)) return "why";
    if (/\bwhere\b/.test(t)) return "where";
    if (/\bhow\b/.test(t)) return "how";
    return "what";
  }
  function typeBoost(type, s) {
    const hasYear = /\b(1\d{3}|20\d{2})\b/.test(s);
    const hasDate = /\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\b/i.test(s) || /\b\d{1,2}(st|nd|rd|th)\b/.test(s);
    const hasNum = /\d/.test(s);
    const hasName = /[a-z]\s+[A-Z][a-z]+/.test(s); // capitalized word mid-sentence
    if (type === "when") return (hasYear ? 0.35 : 0) + (hasDate ? 0.2 : 0);
    if (type === "num") return hasNum ? 0.35 : 0;
    if (type === "who") return hasName ? 0.3 : 0;
    if (type === "why") return /\b(because|since|due to|so that|in order to|as a result|reason)\b/i.test(s) ? 0.35 : 0;
    if (type === "where") return /\b(in|at|on|near|across|within)\s+[A-Z]/.test(s) ? 0.25 : 0;
    return 0;
  }
  function answer(question, text) {
    const sents = sentences(text);
    if (!sents.length) return { sentence: null };
    const { docs, idf, N } = buildCorpus(sents);
    const qtf = Object.create(null);
    tokens(question).forEach((w) => (qtf[w] = (qtf[w] || 0) + 1));
    if (!Object.keys(qtf).length) return { sentence: null };
    const qvec = tfidf(qtf, idf, N);
    const type = questionType(question);
    // `cos` (raw cosine) decides whether there's a real match; the type boost only re-ranks.
    const scored = docs.map((d, i) => { const cos = cosine(qvec, d.vec); return { i, s: sents[i], cos, rank: cos + typeBoost(type, sents[i]) }; })
      .sort((a, b) => b.rank - a.rank);
    const best = scored[0];
    if (!best || best.cos < 0.06) return { sentence: null }; // need genuine word overlap, not just a type boost
    const second = scored.find((x) => x !== best && x.cos > 0.08 && x.cos > best.cos * 0.5);
    return { sentence: best.s, support: second ? second.s : null, score: best.cos };
  }

  // ---- question generation (definition / cloze / true-false MCQs) ----
  function generateQuestions(text, count = 8) {
    const sents = sentences(text).filter((s) => content(s).length >= 4 && s.length < 240);
    const terms = keyTerms(text, 22);
    const termsLc = terms.map((t) => t.toLowerCase());
    const defs = definitions(text);
    const pools = { def: [], cloze: [], tf: [] };
    const used = new Set();

    // definition MCQs
    for (const d of defs) {
      const answer = d.term;
      if (used.has(answer.toLowerCase())) continue;
      const distract = pickDistractors(answer, terms, 3);
      if (distract.length < 3) continue;
      const q = d.definition.replace(new RegExp(escapeReg(answer), "i"), "_____");
      pools.def.push({ type: "mcq", question: "Which term fits: “" + q + "”", answer, options: shuffle([answer, ...distract]) });
      used.add(answer.toLowerCase());
    }
    // cloze MCQs + true/false
    for (const s of shuffle(sents)) {
      const cw = content(s).filter((w) => termsLc.includes(stem(w)) || termsLc.includes(w) || w.length >= 6);
      if (!cw.length) continue;
      const target = cw.sort((a, b) => b.length - a.length)[0];
      const re = new RegExp("\\b" + escapeReg(target) + "\\b", "i");
      if (re.test(s) && !used.has(target)) {
        const distract = pickDistractors(target, terms, 3);
        if (distract.length === 3) {
          pools.cloze.push({ type: "mcq", question: s.replace(re, "_____"), answer: cap(target), options: shuffle([cap(target), ...distract.map(cap)]) });
          used.add(target);
        }
      }
      // true/false from a different salient term
      const tfTerm = cw.find((w) => w !== target);
      if (tfTerm && pools.tf.length < count) {
        if (Math.random() < 0.5) {
          pools.tf.push({ type: "mcq", question: `True or False, “${s}”`, answer: "True", options: ["True", "False"] });
        } else {
          const repl = pickDistractors(tfTerm, terms, 1)[0];
          if (repl && repl.toLowerCase() !== tfTerm) {
            const fs = s.replace(new RegExp("\\b" + escapeReg(tfTerm) + "\\b", "i"), repl.toLowerCase());
            pools.tf.push({ type: "mcq", question: `True or False, “${fs}”`, answer: "False", options: ["True", "False"] });
          }
        }
      }
    }
    // interleave the three types for variety
    const out = [];
    const order = [pools.def, pools.cloze, pools.tf];
    let added = true;
    while (out.length < count && added) {
      added = false;
      for (const p of order) { if (p.length) { out.push(p.shift()); added = true; if (out.length >= count) break; } }
    }
    return out;
  }

  function makeFlashcards(text, limit = 12) {
    const cards = [], seen = new Set();
    for (const d of definitions(text)) {
      const k = d.term.toLowerCase();
      if (seen.has(k)) continue; seen.add(k);
      cards.push({ front: "What is " + d.term + "?", back: d.definition });
      if (cards.length >= limit) return cards;
    }
    for (const s of sentences(text)) {
      const cw = content(s).filter((w) => w.length >= 6);
      if (!cw.length || s.length > 200) continue;
      const target = cw.sort((a, b) => b.length - a.length)[0];
      if (seen.has(target)) continue; seen.add(target);
      cards.push({ front: s.replace(new RegExp("\\b" + escapeReg(target) + "\\b", "i"), "_____"), back: target });
      if (cards.length >= limit) break;
    }
    return cards;
  }

  function define(term, text) {
    const t = term.toLowerCase().trim();
    if (!t) return null;
    const sents = sentences(text);
    for (const s of sents) if (new RegExp("\\b" + escapeReg(t) + "\\b\\s+(is|are|was|were|means?|refers? to|describes?)", "i").test(s)) return s;
    for (const s of sents) if (new RegExp("\\b" + escapeReg(t) + "\\b", "i").test(s)) return s;
    // fall back to fuzzy retrieval
    const a = answer(term, text);
    return a.sentence;
  }

  // ---- extra extractors ----
  function extractFacts(text, limit = 8) {
    const out = [];
    for (const s of sentences(text)) {
      if (/\b(1\d{3}|20\d{2})\b/.test(s) || /\b\d+(\.\d+)?%?\b/.test(s) ||
        /\b(first|largest|smallest|biggest|most|fastest|slowest|invented|discovered|founded|created|born|died|consists?|contains?|equals?)\b/i.test(s))
        out.push(s.trim());
      if (out.length >= limit) break;
    }
    return out;
  }
  function outline(text) {
    const terms = keyTerms(text, 6), sents = sentences(text);
    return terms.map((t) => ({
      term: t,
      points: sents.filter((s) => new RegExp("\\b" + escapeReg(t) + "\\b", "i").test(s)).slice(0, 2),
    })).filter((g) => g.points.length).slice(0, 5);
  }
  function related(term, text) {
    const sents = sentences(text).filter((s) => new RegExp("\\b" + escapeReg(term) + "\\b", "i").test(s));
    const f = Object.create(null);
    sents.forEach((s) => content(s).forEach((w) => { if (stem(w) !== stem(term.toLowerCase()) && w.length > 3) f[w] = (f[w] || 0) + 1; }));
    return Object.entries(f).sort((a, b) => b[1] - a[1]).slice(0, 8).map((x) => cap(x[0]));
  }
  function compare(a, b, text) {
    return { a: { term: a, info: define(a, text) }, b: { term: b, info: define(b, text) } };
  }

  // ---- helpers ----
  function pickDistractors(answer, pool, k = 3) {
    const a = answer.toLowerCase();
    const cand = [...new Set(pool)].filter((t) => t.toLowerCase() !== a && stem(t.toLowerCase()) !== stem(a));
    return shuffle(cand).slice(0, k);
  }
  function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [a[i], a[j]] = [a[j], a[i]]; }
    return a;
  }

  // Build a mind-map structure: { center, branches:[{label}] }
  function mindmap(text, topic) {
    if (topic) {
      const center = cap(topic);
      const ctoks = new Set(words(topic));
      const rel = related(topic, text).filter((r) => !ctoks.has(r.toLowerCase()));
      if (rel.length) return { center, branches: rel.slice(0, 7).map((r) => ({ label: r })) };
      const ss = sentences(text).filter((s) => new RegExp("\\b" + escapeReg(topic) + "\\b", "i").test(s));
      const ws = [...new Set(content(ss.join(" ")).filter((w) => w.length >= 5 && !ctoks.has(w) && stem(w) !== stem(topic.toLowerCase())))].slice(0, 7).map(cap);
      return { center, branches: ws.map((l) => ({ label: l })) };
    }
    const groups = outline(text);
    if (groups.length) {
      const center = keyTerms(text, 1)[0] || "Topic";
      return { center, branches: groups.filter((g) => g.term.toLowerCase() !== center.toLowerCase()).slice(0, 7).map((g) => ({ label: g.term })) };
    }
    const kt = keyTerms(text, 8);
    return { center: kt[0] || "Topic", branches: kt.slice(1, 8).map((l) => ({ label: l })) };
  }

  window.Cortex = window.Cortex || {};
  window.Cortex.nlp = {
    sentences, words, content, keyTerms, summarize, definitions, define,
    generateQuestions, makeFlashcards, answer, extractFacts, outline, related, compare, mindmap,
  };
})();
