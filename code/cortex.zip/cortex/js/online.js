/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * Cortex - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ===========================================================
   online.js, optional online knowledge via Wikipedia.
   Free, no API key, CORS-friendly. Used as a fallback so the
   assistant/tutor can answer things that aren't in your notes
   or the built-in knowledge base. Fails gracefully offline.
   =========================================================== */
(function () {
  const cache = new Map();

  function cleanQuery(q) {
    return String(q || "").toLowerCase()
      .replace(/^(can you |could you |please |hey |ok |okay )/g, "")
      .replace(/\b(tell me about|what is|what are|what's|whats|who is|who are|who was|who were|where is|when (was|did)|define|explain|describe|meaning of|info(rmation)? on|teach me about|teach me|search for|look up|google|on wikipedia|wikipedia|wiki)\b/g, " ")
      .replace(/[?!.]+$/g, "").replace(/\s+/g, " ").trim();
  }

  async function fetchJSON(url, ms = 7000) {
    const c = new AbortController();
    const t = setTimeout(() => c.abort(), ms);
    try {
      const r = await fetch(url, { signal: c.signal, headers: { accept: "application/json" } });
      clearTimeout(t);
      return r.ok ? await r.json() : null;
    } catch (e) { clearTimeout(t); return null; }
  }

  async function summary(title) {
    const j = await fetchJSON("https://en.wikipedia.org/api/rest_v1/page/summary/" + encodeURIComponent(title));
    if (!j || j.type === "disambiguation" || !j.extract) return null;
    return {
      title: j.title,
      extract: j.extract,
      url: (j.content_urls && j.content_urls.desktop && j.content_urls.desktop.page) || ("https://en.wikipedia.org/wiki/" + encodeURIComponent(title)),
      thumb: (j.thumbnail && j.thumbnail.source) || null,
    };
  }

  async function search(query) {
    if (typeof navigator !== "undefined" && navigator.onLine === false) return null;
    const q = cleanQuery(query) || String(query || "").trim();
    if (!q || q.length < 2) return null;
    if (cache.has(q)) return cache.get(q);
    // 1) try the exact title
    let res = await summary(q);
    // 2) otherwise search for the best-matching article, then summarise it
    if (!res) {
      const s = await fetchJSON("https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=" + encodeURIComponent(q) + "&srlimit=1&format=json&origin=*");
      const hit = s && s.query && s.query.search && s.query.search[0];
      if (hit) res = await summary(hit.title);
    }
    cache.set(q, res);
    return res;
  }

  window.Cortex = window.Cortex || {};
  window.Cortex.online = { search, summary, cleanQuery, available: () => (typeof navigator === "undefined" || navigator.onLine !== false) };
})();
