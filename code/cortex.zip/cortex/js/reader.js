/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * Cortex - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ===========================================================
   reader.js, extract readable text from uploaded files,
   entirely client-side & offline. No libraries.

     • txt / md / csv / json / code / html / rtf  → direct
     • .docx  → unzip (ZIP central directory) + parse document.xml
     • .pdf   → locate streams, FlateDecode via the browser's
                built-in DecompressionStream, pull Tj/TJ text ops

   PDFs are best-effort (text-based PDFs work; scanned/encrypted
   ones won't). DOCX is reliable. Everything runs in the browser.
   =========================================================== */
(function () {
  async function readFileText(file) {
    const name = (file.name || "").toLowerCase();
    const type = file.type || "";
    try {
      if (type.startsWith("image/")) return "";
      if (/\.html?$/.test(name) || type.includes("html")) return stripTags(await file.text());
      if (/\.rtf$/.test(name) || type.includes("rtf")) return stripRtf(await file.text());
      if (/\.docx$/.test(name) || type.includes("officedocument.wordprocessing")) return await readDocx(file);
      if (/\.pdf$/.test(name) || type === "application/pdf") return await readPdf(file);
      if (/\.(txt|md|markdown|csv|tsv|log|json|js|ts|py|java|c|cpp|cs|rb|go|rs|php|sql|css|yml|yaml|ini|xml)$/.test(name) ||
          type.startsWith("text/") || /json|javascript|xml/.test(type)) {
        let t = await file.text();
        if (/\.xml$/.test(name)) t = stripTags(t);
        return t;
      }
    } catch (e) { console.warn("[reader] failed to read", name, e); }
    return "";
  }

  // ---------- helpers ----------
  const decodeXml = (s) => s
    .replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"').replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, d) => String.fromCharCode(+d))
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCharCode(parseInt(h, 16)));
  const stripTags = (s) => decodeXml(s.replace(/<(script|style)[\s\S]*?<\/\1>/gi, " ").replace(/<[^>]+>/g, " ")).replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
  const stripRtf = (s) => s.replace(/\\par[d]?/g, "\n").replace(/\{\\[^}]*\}/g, "").replace(/\\[a-z]+-?\d* ?/gi, "").replace(/[{}]/g, "").trim();

  async function inflate(u8, format) {
    const ds = new DecompressionStream(format);
    const ab = await new Response(new Blob([u8]).stream().pipeThrough(ds)).arrayBuffer();
    return new Uint8Array(ab);
  }

  // ---------- DOCX (ZIP + XML) ----------
  const u16 = (d, o) => d[o] | (d[o + 1] << 8);
  const u32 = (d, o) => (d[o] | (d[o + 1] << 8) | (d[o + 2] << 16) | (d[o + 3] << 24)) >>> 0;

  async function unzipEntry(buf, target) {
    // find End Of Central Directory record
    let eocd = -1;
    for (let i = buf.length - 22; i >= 0 && i > buf.length - 22 - 65536; i--) { if (u32(buf, i) === 0x06054b50) { eocd = i; break; } }
    if (eocd < 0) return null;
    let p = u32(buf, eocd + 16);           // central directory offset
    const count = u16(buf, eocd + 10);
    for (let i = 0; i < count; i++) {
      if (u32(buf, p) !== 0x02014b50) break;
      const method = u16(buf, p + 10);
      const compSize = u32(buf, p + 20);
      const nameLen = u16(buf, p + 28);
      const extraLen = u16(buf, p + 30);
      const commentLen = u16(buf, p + 32);
      const lhOff = u32(buf, p + 42);
      const fname = new TextDecoder().decode(buf.subarray(p + 46, p + 46 + nameLen));
      if (fname === target) {
        const lhNameLen = u16(buf, lhOff + 26), lhExtra = u16(buf, lhOff + 28);
        const start = lhOff + 30 + lhNameLen + lhExtra;
        const comp = buf.subarray(start, start + compSize);
        if (method === 0) return comp;
        if (method === 8) return await inflate(comp, "deflate-raw");
        return null;
      }
      p += 46 + nameLen + extraLen + commentLen;
    }
    return null;
  }

  async function readDocx(file) {
    const buf = new Uint8Array(await file.arrayBuffer());
    const data = await unzipEntry(buf, "word/document.xml");
    if (!data) return "";
    const xml = new TextDecoder().decode(data);
    let out = "";
    for (const para of xml.split(/<\/w:p>/)) {
      const runs = [...para.matchAll(/<w:t[^>]*>([\s\S]*?)<\/w:t>/g)].map((m) => decodeXml(m[1]));
      const line = runs.join("");
      if (line.trim()) out += line + "\n";
    }
    return out.trim();
  }

  // ---------- PDF ----------
  async function readPdf(file) {
    const buf = new Uint8Array(await file.arrayBuffer());
    if (buf.length > 25_000_000) return "";
    const raw = new TextDecoder("latin1").decode(buf); // 1 char per byte → offsets match
    let text = "";
    const sre = /stream\r?\n/g;
    let m;
    while ((m = sre.exec(raw))) {
      const start = m.index + m[0].length;
      let end = raw.indexOf("endstream", start);
      if (end < 0) { continue; }
      while (end > start && (buf[end - 1] === 10 || buf[end - 1] === 13)) end--;
      const pre = raw.slice(Math.max(0, m.index - 350), m.index);
      let bytes = buf.subarray(start, end);
      if (/FlateDecode/.test(pre)) { try { bytes = await inflate(bytes, "deflate"); } catch (e) { sre.lastIndex = end + 9; continue; } }
      else if (/(DCTDecode|CCITTFax|JPXDecode|Image)/.test(pre)) { sre.lastIndex = end + 9; continue; }
      text += extractOps(new TextDecoder("latin1").decode(bytes)) + "\n";
      sre.lastIndex = end + 9;
    }
    return cleanup(text);
  }

  function extractOps(s) {
    let out = "";
    const re = /\(((?:\\.|[^\\()])*)\)\s*Tj|\[((?:[^\]\\]|\\.)*)\]\s*TJ|(Td|TD|T\*|')/g;
    let m;
    while ((m = re.exec(s))) {
      if (m[1] !== undefined) out += pdfStr(m[1]);
      else if (m[2] !== undefined) out += pdfArr(m[2]);
      else out += "\n";
    }
    return out;
  }
  function pdfArr(arr) {
    let out = ""; const re = /\(((?:\\.|[^\\()])*)\)|(-?\d+(?:\.\d+)?)/g; let m;
    while ((m = re.exec(arr))) {
      if (m[1] !== undefined) out += pdfStr(m[1]);
      else if (parseFloat(m[2]) < -120) out += " "; // wide kerning ≈ space
    }
    return out;
  }
  const pdfStr = (s) => s
    .replace(/\\(\d{1,3})/g, (_, o) => String.fromCharCode(parseInt(o, 8)))
    .replace(/\\n/g, "\n").replace(/\\r/g, "").replace(/\\t/g, " ").replace(/\\([()\\])/g, "$1");
  const cleanup = (t) => t.replace(/[ \t]+/g, " ").replace(/ ?\n ?/g, "\n").replace(/\n{3,}/g, "\n\n").trim();

  window.Cortex = window.Cortex || {};
  window.Cortex.reader = { readFileText };
})();
