/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * Cortex - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ===========================================================
   srs.js, spaced repetition, written from scratch.
   A variant of the SM-2 algorithm. Each card carries an
   "ease factor" that grows when you find it easy and shrinks
   when you struggle, so hard cards come back sooner. This is
   the adaptive "learning" core, no library, just the math.
   =========================================================== */
(function () {
  const DAY = 86400000;

  // A brand-new card: due immediately, neutral ease.
  function fresh() {
    return {
      ease: 2.5,      // ease factor (how fast intervals grow)
      interval: 0,    // days until next review
      reps: 0,        // consecutive successful reviews
      lapses: 0,      // times forgotten
      due: Date.now(),
      last: null,
    };
  }

  // Map the four study buttons to SM-2 quality scores (0 to 5).
  const QUALITY = { again: 1, hard: 3, good: 4, easy: 5 };

  /**
   * Grade a review and return the updated SRS state.
   * @param {object} srs  current state
   * @param {string} grade  'again' | 'hard' | 'good' | 'easy'
   */
  function review(srs, grade) {
    const q = QUALITY[grade] ?? 4;
    const s = { ...srs };
    s.last = Date.now();

    if (q < 3) {
      // Forgot it, reset the streak and show it again soon.
      s.reps = 0;
      s.lapses += 1;
      s.interval = 0; // re-show within the same session (~10 min handled by app)
    } else {
      s.reps += 1;
      if (s.reps === 1) s.interval = 1;
      else if (s.reps === 2) s.interval = 6;
      else s.interval = Math.round(s.interval * s.ease);

      // "hard" earns a shorter step even on success
      if (grade === "hard") s.interval = Math.max(1, Math.round(s.interval * 0.6));
      if (grade === "easy") s.interval = Math.round(s.interval * 1.3);
    }

    // Update ease factor (SM-2 formula), clamped to a sane floor.
    s.ease = Math.max(1.3, s.ease + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02)));
    s.ease = Math.round(s.ease * 100) / 100;

    s.due = Date.now() + s.interval * DAY;
    return s;
  }

  function isDue(card, now = Date.now()) {
    return (card.srs?.due ?? 0) <= now;
  }

  // Human-friendly "next review" label for a prospective grade.
  function previewInterval(srs, grade) {
    const s = review(srs, grade);
    if (s.interval === 0) return "<10m";
    if (s.interval === 1) return "1d";
    if (s.interval < 30) return s.interval + "d";
    if (s.interval < 365) return Math.round(s.interval / 30) + "mo";
    return (Math.round((s.interval / 365) * 10) / 10) + "y";
  }

  // A 0 to 100 "mastery" estimate for progress bars.
  function mastery(card) {
    const s = card.srs;
    if (!s || s.reps === 0) return 0;
    const byInterval = Math.min(1, Math.log10(s.interval + 1) / Math.log10(120));
    const byEase = (s.ease - 1.3) / (2.7 - 1.3);
    return Math.round(Math.min(100, (byInterval * 0.7 + byEase * 0.3) * 100));
  }

  window.Cortex = window.Cortex || {};
  window.Cortex.srs = { fresh, review, isDue, previewInterval, mastery, QUALITY };
})();
