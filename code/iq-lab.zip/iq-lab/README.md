> Copyright (c) 2026 Adhvik Mahesh. All rights reserved.  
> IQ Lab - https://github.com/adhvi29  
> You may view and run this code for personal and educational use only.  
> You may not copy it into other projects, redistribute, sell, or present  
> it as your own work without written permission from the author.  
> Removing or changing this notice is not permitted. See LICENSE.txt.

# IQ Lab

> **Note: Supabase code not included.** This download runs fully offline in your browser; the optional cloud sign-in and sync were removed.

A five-index cognitive battery with modelled item difficulty, age norms, honest error bars, and year-over-year tracking. Vanilla JS, no build step, no dependencies, no network. Open `index.html`.

## What makes it different from the usual "free IQ test"

| | Typical free test | IQ Lab |
|---|---|---|
| Items | Fixed list, same every time | Generated from a seed, matrices, series, figures, folds, spans and symbols are all constructed at runtime |
| Scoring | Count correct answers | Logistic IRT with an explicit guessing floor, plus a simulated bias correction |
| Guessing | Ignored | Modelled as `c = 1/options` |
| Age | Usually ignored | Deviation IQ against age-specific norms (10 to 80) |
| Composite | Average of subtests | g-weighted, rescaled for index intercorrelation, deflated for measurement error |
| Uncertainty | None, or fake precision | 90% band, measurement vs calibration error separated, reliable-change threshold on retest |
| Retesting | Same items → inflated | Fresh items every sitting |

## Layout

```
index.html              shell + the Improve and Method content
css/styles.css          design system, dark/light
js/rng.js               seeded PRNG (mulberry32) + option assembly
js/gen/shapes.js        SVG primitives shared by the figural subtests
js/gen/matrix.js        Raven-style progressive matrices
js/gen/series.js        number and letter series
js/gen/verbal.js        curated verbal bank (95 items)
js/gen/spatial.js       mental rotation + paper folding
js/gen/logic.js         syllogisms, conditionals, linear orderings
js/gen/weights.js       balance scales (Figure Weights)
js/gen/memory.js        adaptive span staircase
js/gen/speed.js         symbol search
js/scoring.js           IRT estimation, bias correction, age norms, composite
js/battery.js           form assembly
js/test.js              sitting runner
js/charts.js            hand-rolled SVG charts
js/store.js             localStorage history + export/import
js/app.js               router and views
tools/                  simulation + audit scripts (node, no deps)
```

## The five indices

| Index | What it measures | How it is scored |
|---|---|---|
| **Gf** Fluid Reasoning | Matrices, number series, deduction, balance scales | IRT, 34 items |
| **Gc** Verbal | Analogies, vocabulary, classification | IRT, 14 items |
| **Gv** Visual-Spatial | Rotation, paper folding | IRT, 10 items |
| **Gwm** Working Memory | Backward digit span, letter-number sequencing | Adaptive staircase → age-normed z |
| **Gs** Processing Speed | Symbol search, 90s | Correct − incorrect → age-normed z |

Composite weights approximate g-loadings: Gf 0.30, Gc 0.22, Gv 0.18, Gwm 0.17, Gs 0.13.

## Calibration

The model is verified by simulation, not asserted. Five scripts in `tools/` do this:

- `verify.js`, structural checks on every generator: valid answer index, distinct options, finite difficulties.
- `calibrate.js`, simulates test-takers at known ability and checks the scale centres and spreads correctly.
- `bias.js`, measures the estimator's bias curve per item count; its output is pasted into `BIAS_TABLES` in `scoring.js`.
- `solvable.js`, audits every generated number series: fits a catalogue of rules to the shown terms **plus the keyed answer**, and fails if none fits. Catches items where the rule changes mid-sequence.
- `weights-audit.js`, re-derives each balance-scale item from its rendered SVG, solves the premise system, and fails if the answer is ambiguous, non-unique, or disagrees with the key.

Current results:

```
Scale centring (person performing exactly at their age norm → should be 100)
  age 10  100.5      age 18  100.1      age 60  100.7
  age 12   99.1      age 25   99.9      age 75   99.9
  age 14  100.6      age 40   99.7
  age 15  100.7      age 16   99.8

Simulated population of 15-year-olds
  mean 101.3   SD 14.4            (target: 100, 15)
  16th=87  50th=101  84th=116  98th=131
  2.1% score 130+                  (true figure 2.3%)

Ability recovery on the real gf ladder
  bias < 0.1 logits across θ ∈ [-1, +2]; ±0.21 at the extremes
  measurement SE ≈ 5 IQ points on the full battery → 90% band ≈ ±8

Item solvability
  16,347 number series audited      0 unsolvable
   6,000 balance scales audited     0 ambiguous, 0 non-unique, 0 mis-keyed
```

Re-run all four after changing item difficulties or counts:

```bash
cd tools && node verify.js && node solvable.js && node weights-audit.js && node calibrate.js
```


## One-time local purge

`IQ.store.purgeLegacyData()` runs once on first load after this change and clears everything the app had previously written to this browser: `iqlab.*` keys, any leftover Supabase session, and the saved theme. It is gated on `iqlab.purged.v2`, so it fires exactly once and is inert afterwards, without that flag it would erase every new sitting on every reload.

Only code running in a given browser can clear that browser's storage, so this is the mechanism by which existing local data goes away. Once it has run everywhere you care about, the function and its call in `js/app.js` can be deleted.

## Honest limits

- **No standardisation sample.** The simulations prove the model is internally consistent. They cannot prove the difficulty scale is anchored correctly against real people. The absolute score may sit a few points off.
- **That offset is constant**, so tracking yourself over time is far more trustworthy than the absolute number. This is the app's actual purpose.
- **Processing Speed is the weakest calibration.** The task is modelled on a clinical subtest but is not that subtest.
- **Reasoning sections are untimed.** Time per item is recorded; take it the same way each sitting.
- **Verbal assumes a comfortable English reader.**
- **Extremes are unreliable.** Above ~135 or below ~65 there are too few items at the right difficulty.
- **Not a clinical instrument.** It diagnoses nothing.

## Data

Everything is in `localStorage` under `iqlab.v1`. With no account connected, nothing is uploaded and a cleared cache erases the record, export a JSON backup from the History page after each sitting. With an account connected, the cloud copy is the backup, and the export still works as a portable archive.
