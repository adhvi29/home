/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   IQ LAB · Router and views
   ============================================================ */
window.IQ = window.IQ || {};

(function (IQ) {
  'use strict';

  const views = {};
  let current = 'home';
  let lastResult = null;

  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $$(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  function go(name, opts) {
    if (current === 'test' && name !== 'test') IQ.test.abort();
    current = name;
    $$('.view').forEach(function (v) { v.hidden = v.dataset.view !== name; });
    $$('[data-nav]').forEach(function (b) { b.classList.toggle('active', b.dataset.nav === name); });
    $('#siteNav').hidden = (name === 'test');
    window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
    if (views[name]) views[name](opts || {});
  }

  /* ============================ HOME ============================ */

  views.home = function () {
    const el = $('[data-view="home"]');
    const p = IQ.store.profile();
    const attempts = IQ.store.attempts();
    const draft = IQ.store.loadDraft();
    const last = attempts[attempts.length - 1];
    const birth = IQ.store.validateBirth(p.birth);
    const age = birth.ok ? birth.age : null;
    const bounds = IQ.store.birthBounds();

    const formCards = Object.keys(IQ.battery.FORMS).map(function (k) {
      const f = IQ.battery.FORMS[k];
      return '<button class="form-card" data-form="' + f.id + '">' +
        '<span class="form-name">' + f.name + '</span>' +
        '<span class="form-time">' + f.minutes + '</span>' +
        '<span class="form-note">' + f.note + '</span>' +
        '</button>';
    }).join('');

    el.innerHTML =
      '<section class="hero">' +
      '  <p class="eyebrow">Cognitive assessment &amp; longitudinal tracking</p>' +
      '  <h1>Measure it properly. Then watch it over years, not days.</h1>' +
      '  <p class="hero-sub">Five indices, item difficulty modelled rather than counted, age-normed, and every figure generated fresh so a retest cannot be gamed by memory. The score comes with error bars, because a score without them is a guess wearing a suit.</p>' +
      '</section>' +

      (draft ? '<div class="resume-card">' +
        '<div><strong>You have an unfinished sitting.</strong><p>Started ' +
        new Date(draft.startedAt).toLocaleString() + ' &middot; ' + esc(draft.form) + ' form.</p></div>' +
        '<div class="resume-actions">' +
        '<button class="btn btn-primary" id="resumeBtn">Resume</button>' +
        '<button class="btn btn-ghost" id="discardBtn">Discard</button>' +
        '</div></div>' : '') +

      '<section class="card profile-card">' +
      '  <h2>Your details</h2>' +
      '  <p class="muted">Age is not optional here. An IQ score means "compared with people your own age", so without a date of birth there is nothing to compare against.</p>' +
      '  <div class="field-row">' +
      '    <label class="field"><span>Name <em>(optional)</em></span>' +
      '      <input type="text" id="pName" value="' + esc(p.name) + '" placeholder="For your own records" /></label>' +
      '    <label class="field"><span>Date of birth</span>' +
      '      <input type="date" id="pBirth" value="' + esc(p.birth) + '" min="' + bounds.min + '" max="' + bounds.max + '" /></label>' +
      '  </div>' +
      '  <p class="' + (birth.ok ? 'age-readout' : 'warn') + '" id="ageOut">' + esc(birth.message) + '</p>' +
      '</section>' +

      '<section class="card">' +
      '  <h2>Choose a form</h2>' +
      '  <div class="form-grid' + (age ? '' : ' disabled') + '" id="formGrid">' + formCards + '</div>' +
      (age ? '' : '<p class="warn">Set a valid date of birth above first.</p>') +
      '</section>' +

      (last ? '<section class="card last-card">' +
        '<h2>Where you stand</h2>' +
        '<div class="last-row">' +
        '  <div class="last-score"><span class="big">' + Math.round(last.score.fsiq) + '</span>' +
        '    <span class="sub">' + esc(last.score.classification) + ' &middot; ' + esc(last.score.percentile) + 'th percentile</span></div>' +
        '  <div class="last-meta">' +
        '    <p>' + new Date(last.date).toLocaleDateString() + ' &middot; ' + esc(last.formName || last.form) + '</p>' +
        '    <p class="muted">90% band ' + Math.round(last.score.ci[0]) + '&ndash;' + Math.round(last.score.ci[1]) + '</p>' +
        '    <button class="btn btn-ghost btn-sm" id="viewLast">See full breakdown</button>' +
        '  </div>' +
        '</div></section>' : '') +

      '<section class="card note-card">' +
      '  <h2>What this is and is not</h2>' +
      '  <p>This is a carefully built estimate, not a clinical assessment. A real IQ score comes from a test standardised on thousands of people; this one uses item difficulties and age curves that were reasoned out rather than measured on a sample. The absolute number could sit a few points high or low.</p>' +
      '  <p><strong>What that means in practice:</strong> treat the absolute score as approximate, and the <em>changes in your own score over time</em> as the real signal. The calibration offset is the same at every sitting, so it cancels out when you compare yourself with yourself. That is exactly the comparison you want.</p>' +
      '  <p><a href="#" data-nav-link="method">How the scoring works &rarr;</a></p>' +
      '</section>';

    const nameEl = $('#pName', el), birthEl = $('#pBirth', el);
    function saveProfile() {
      IQ.store.setProfile({ name: nameEl.value.trim(), birth: birthEl.value });
      const v = IQ.store.validateBirth(birthEl.value);
      const out = $('#ageOut', el);
      out.textContent = v.message;
      out.className = v.ok ? 'age-readout' : 'warn';
      $('#formGrid', el).classList.toggle('disabled', !v.ok);
    }
    nameEl.addEventListener('change', saveProfile);
    // `input` fires while a half-typed date still reads as year 0001, so the
    // message updates live; the full re-render waits for `change`.
    birthEl.addEventListener('input', saveProfile);
    birthEl.addEventListener('change', function () { saveProfile(); views.home(); });

    $$('.form-card', el).forEach(function (btn) {
      btn.addEventListener('click', function () {
        const v = IQ.store.validateBirth(IQ.store.profile().birth);
        if (!v.ok) {
          alert(v.message + '\n\nThe score cannot be computed without a usable age.');
          return;
        }
        beginTest(btn.dataset.form);
      });
    });

    const resume = $('#resumeBtn', el);
    if (resume) {
      resume.addEventListener('click', function () {
        go('test');
        IQ.test.start($('[data-view="test"]'), {
          seed: draft.seed, form: draft.form, startedAt: draft.startedAt, restore: draft
        }, onTestDone);
      });
      $('#discardBtn', el).addEventListener('click', function () {
        if (confirm('Discard the unfinished sitting?')) { IQ.store.clearDraft(); views.home(); }
      });
    }

    const vl = $('#viewLast', el);
    if (vl) vl.addEventListener('click', function () { go('result', { attempt: last }); });
  };

  function beginTest(form) {
    const seed = IQ.rng.newSeed();
    go('test');
    IQ.test.start($('[data-view="test"]'), { seed: seed, form: form }, onTestDone);
  }

  function onTestDone(payload) {
    const p = IQ.store.profile();
    const date = payload.finishedAt;
    const age = IQ.store.ageAt(p.birth, date);
    if (!age) {
      // Only reachable if the date of birth was edited mid-sitting
      alert('Your answers are saved, but the date of birth is no longer usable, so the score cannot be computed. Fix it in Settings and retake.');
      go('settings');
      return;
    }
    const score = IQ.scoring.score({
      gf: payload.responses.gf, gc: payload.responses.gc, gv: payload.responses.gv,
      spans: payload.spans, speed: payload.speed
    }, age);

    const minutes = (new Date(payload.finishedAt) - new Date(payload.startedAt)) / 60000;

    const rec = IQ.store.addAttempt({
      date: date, age: age, seed: payload.seed, form: payload.form, formName: payload.formName,
      score: score, spans: payload.spans, speed: payload.speed, log: payload.log,
      minutes: Math.round(minutes)
    });
    lastResult = rec;
    go('result', { attempt: rec });
  }

  /* ============================ RESULT ============================ */

  views.result = function (opts) {
    const el = $('[data-view="result"]');
    const attempts = IQ.store.attempts();
    const a = opts.attempt || lastResult || attempts[attempts.length - 1];
    if (!a) { el.innerHTML = '<p class="empty">No result to show.</p>'; return; }

    const s = a.score;
    const prev = attempts.filter(function (x) { return new Date(x.date) < new Date(a.date); }).pop();
    const cmp = prev ? IQ.scoring.compare(prev.score, s) : null;
    const isSecond = attempts.length === 2 && attempts[attempts.length - 1].id === a.id;

    /* per-section summary from the item log */
    const bySec = {};
    (a.log || []).forEach(function (l) {
      if (l.type === 'span' || l.type === 'speed') return;
      const k = l.sec;
      bySec[k] = bySec[k] || { n: 0, ok: 0, rt: 0, hardestOk: -99 };
      bySec[k].n++;
      if (l.correct) { bySec[k].ok++; if (l.b > bySec[k].hardestOk) bySec[k].hardestOk = l.b; }
      bySec[k].rt += l.rt || 0;
    });

    const secNames = {
      matrix: 'Pattern Matrices', series: 'Number Series', logic: 'Deductive Reasoning',
      verbal: 'Verbal Reasoning', spatial: 'Spatial Reasoning'
    };

    const secRows = Object.keys(bySec).map(function (k) {
      const d = bySec[k];
      return '<tr><td>' + esc(secNames[k] || k) + '</td>' +
        '<td>' + d.ok + ' / ' + d.n + '</td>' +
        '<td>' + (d.hardestOk > -99 ? d.hardestOk.toFixed(1) : '&mdash;') + '</td>' +
        '<td>' + Math.round(d.rt / Math.max(1, d.n) / 1000) + 's</td></tr>';
    }).join('');

    const idx = s.indices;
    const sortedIdx = IQ.scoring.INDEX_ORDER.slice().sort(function (x, y) { return idx[y].iq - idx[x].iq; });
    const strongest = IQ.scoring.INDEX_META[sortedIdx[0]];
    const weakest = IQ.scoring.INDEX_META[sortedIdx[sortedIdx.length - 1]];
    const spread = idx[sortedIdx[0]].iq - idx[sortedIdx[sortedIdx.length - 1]].iq;

    el.innerHTML =
      '<section class="result-head">' +
      '  <p class="eyebrow">' + new Date(a.date).toLocaleDateString(undefined, { dateStyle: 'long' }) +
      ' &middot; ' + esc(a.formName || a.form) + ' &middot; age ' + a.age.toFixed(1) +
      (a.minutes ? ' &middot; ' + a.minutes + ' min' : '') + '</p>' +
      '  <div class="score-hero">' +
      '    <div class="score-num">' + Math.round(s.fsiq) + '</div>' +
      '    <div class="score-side">' +
      '      <p class="score-class">' + esc(s.classification) + '</p>' +
      '      <p class="score-pct">' + esc(s.percentile) + 'th percentile for your age</p>' +
      '      <p class="score-ci">90% confidence band <strong>' + Math.round(s.ci[0]) + ' &ndash; ' + Math.round(s.ci[1]) + '</strong></p>' +
      '    </div>' +
      '  </div>' +
      '  <p class="score-caveat">The single number is the least informative part of this page. The band above is how much this test would bounce around if you sat it again tomorrow with the same underlying ability; the profile below is what actually tells you something.</p>' +
      '</section>' +

      '<section class="card"><h2>Where that sits</h2>' + IQ.charts.bell(s.fsiq, s.band90) +
      '<p class="muted">The shaded region is your confidence band, not a point. Roughly ' +
      esc(s.percentile) + '% of people your age would score below the midpoint.</p></section>' +

      (cmp ? '<section class="card change-card ' + (cmp.significant ? 'sig' : '') + '">' +
        '<h2>Change since ' + new Date(prev.date).toLocaleDateString() + '</h2>' +
        '<p class="change-num">' + (cmp.delta >= 0 ? '+' : '') + cmp.delta.toFixed(1) + ' points</p>' +
        '<p>' + (cmp.significant
          ? 'This is larger than measurement noise (the threshold for this pair of sittings is ' + cmp.threshold.toFixed(1) + ' points), so something real probably changed.'
          : 'This is <strong>within</strong> measurement noise. A change needs to exceed ' + cmp.threshold.toFixed(1) +
            ' points before it means anything on this pair of sittings. Treat it as "no detectable change".') + '</p>' +
        (isSecond ? '<p class="warn-inline">This is your second ever sitting. Expect roughly +5 to +8 points from familiarity with the format alone, that part is not real gain. Use this sitting, not your first, as your baseline.</p>' : '') +
        '</section>' : '') +

      '<section class="card"><h2>Index profile</h2>' +
      '<div class="profile-split">' +
      '  <div>' + IQ.charts.radar(idx, prev ? prev.score.indices : null) +
      (prev ? '<p class="muted center">Dashed outline: your previous sitting.</p>' : '') + '</div>' +
      '  <div class="idx-notes">' +
      IQ.scoring.INDEX_ORDER.map(function (k) {
        const m = IQ.scoring.INDEX_META[k], v = idx[k];
        return '<div class="idx-note" style="--idx:' + m.color + '"><div class="idx-head"><strong>' + m.name + '</strong><span>' + Math.round(v.iq) + '</span></div>' +
          '<p>' + m.blurb + '</p>' +
          '<p class="idx-raw">' + (v.total ? v.raw + ' of ' + v.total + ' items correct' :
            (k === 'gwm' ? 'span ' + v.raw + (v.detail ? ' &middot; ' + v.detail : '') :
             'net ' + v.raw + ' in ' + (a.speed && a.speed.seconds ? a.speed.seconds : 90) + 's' + (v.detail ? ' &middot; ' + v.detail : ''))) + '</p></div>';
      }).join('') +
      '  </div>' +
      '</div>' +
      IQ.charts.indexBars(idx) +
      '<p class="muted">Each dot is an index score, each bar its 90% band. Bands this wide are normal for a test this length, index scores are always noisier than the composite.</p>' +
      '</section>' +

      '<section class="card"><h2>Reading your profile</h2>' +
      '<p>Your strongest index is <strong>' + strongest.name + '</strong> and your weakest is <strong>' + weakest.name +
      '</strong>, a spread of ' + Math.round(spread) + ' points. ' +
      (spread < 12
        ? 'That is a flat profile, your abilities are fairly evenly developed, and the composite is a fair summary of you.'
        : spread < 25
          ? 'That is a normal amount of unevenness. Most people are noticeably better at some of these than others.'
          : 'That is a wide spread. When the spread is this large the composite starts to hide more than it reveals, the individual indices are the more useful numbers.') +
      '</p>' +
      '<p class="muted">One caution on the bands: an index gap only means something if the two bands barely overlap. Eyeball the chart above before concluding you are "a spatial person".</p>' +
      '</section>' +

      (secRows ? '<section class="card"><h2>Section detail</h2>' +
        '<table class="tbl"><thead><tr><th>Section</th><th>Correct</th><th>Hardest solved</th><th>Avg time</th></tr></thead>' +
        '<tbody>' + secRows + '</tbody></table>' +
        '<p class="muted">"Hardest solved" is the difficulty in logits of the toughest item you got right: 0 is about average for an adult, +2 is hard, &minus;2 is easy. It is a more robust signal than the raw total, because one careless slip on an easy item barely moves it.</p>' +
        '</section>' : '') +

      '<section class="card actions-card">' +
      '  <h2>What now</h2>' +
      '  <div class="btn-row">' +
      '    <button class="btn btn-primary" data-nav-link="improve">How to improve &rarr;</button>' +
      '    <button class="btn btn-ghost" data-nav-link="history">Track it over time</button>' +
      '    <button class="btn btn-ghost" data-nav-link="home">Back to start</button>' +
      '  </div>' +
      '  <p class="muted">Next benchmark: no sooner than six months from now, on the full battery, rested. Testing more often than that mostly measures your familiarity with the format.</p>' +
      '</section>';
  };

  /* ============================ HISTORY ============================ */

  views.history = function () {
    const el = $('[data-view="history"]');
    const attempts = IQ.store.attempts();

    if (!attempts.length) {
      el.innerHTML = '<section class="card"><h2>No results yet</h2>' +
        '<p class="muted">Sit the battery once and this becomes your baseline. The chart here is the whole point of the app, one score is a snapshot, a decade of scores is a trajectory.</p>' +
        '<button class="btn btn-primary" data-nav-link="home">Take the test</button></section>' + ioBlock();
      wireIo(el);
      return;
    }

    const first = attempts[0], last = attempts[attempts.length - 1];
    const years = (new Date(last.date) - new Date(first.date)) / (365.2425 * 24 * 3600 * 1000);

    const rows = attempts.slice().reverse().map(function (a) {
      const s = a.score;
      return '<tr>' +
        '<td>' + new Date(a.date).toLocaleDateString() + '</td>' +
        '<td>' + a.age.toFixed(1) + '</td>' +
        '<td>' + esc(a.formName || a.form) + '</td>' +
        '<td class="num"><strong>' + Math.round(s.fsiq) + '</strong></td>' +
        '<td class="num muted">' + Math.round(s.ci[0]) + '&ndash;' + Math.round(s.ci[1]) + '</td>' +
        IQ.scoring.INDEX_ORDER.map(function (k) {
          return '<td class="num">' + Math.round(s.indices[k].iq) + '</td>';
        }).join('') +
        '<td><button class="link-btn" data-open="' + a.id + '">open</button> ' +
        '<button class="link-btn danger" data-del="' + a.id + '">delete</button></td>' +
        '</tr>';
    }).join('');

    el.innerHTML =
      '<section class="card">' +
      '  <h2>Full-scale score over time</h2>' +
      IQ.charts.trend(attempts) +
      '  <p class="muted">Shaded band = 90% confidence. If two bands overlap heavily, the difference between those sittings is not measurable.</p>' +
      '</section>' +

      '<section class="card">' +
      '  <h2>Reading the trajectory</h2>' +
      (attempts.length === 1
        ? '<p>One point is a baseline, not a trend. Come back in six months.</p>'
        : '<p>You have ' + attempts.length + ' sittings spanning ' +
          (years < 1 ? Math.round(years * 12) + ' months' : years.toFixed(1) + ' years') + '. ' +
          'Remember what the score is: <strong>age-adjusted</strong>. Between 13 and 18 your raw ability is climbing steeply on its own, so a flat line here does not mean you stopped developing, it means you are developing at the same rate as everyone else your age. A line that climbs means you are gaining <em>relative to your age group</em>, which is a much higher bar.</p>') +
      '  <p class="muted">Also expect an artificial bump at sitting two. Format familiarity is worth several points and it is spent almost entirely on the first retest.</p>' +
      '</section>' +

      '<section class="card wide">' +
      '  <h2>All sittings</h2>' +
      '  <div class="tbl-scroll"><table class="tbl"><thead><tr>' +
      '    <th>Date</th><th>Age</th><th>Form</th><th class="num">FSIQ</th><th class="num">90% band</th>' +
      IQ.scoring.INDEX_ORDER.map(function (k) { return '<th class="num">' + IQ.scoring.INDEX_META[k].short + '</th>'; }).join('') +
      '    <th></th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
      '</section>' +

      ioBlock();

    $$('[data-open]', el).forEach(function (b) {
      b.addEventListener('click', function () {
        const a = attempts.filter(function (x) { return x.id === b.dataset.open; })[0];
        if (a) go('result', { attempt: a });
      });
    });
    $$('[data-del]', el).forEach(function (b) {
      b.addEventListener('click', function () {
        if (!confirm('Delete this sitting permanently? This cannot be undone.')) return;
        IQ.store.removeAttempt(b.dataset.del);
        views.history();
      });
    });
    wireIo(el);
  };

  /* Shared by History and Settings. Uses data attributes rather than ids so
     the same markup can appear in two views without duplicate ids. */
  function ioButtons() {
    return '<div class="btn-row">' +
      '  <button class="btn btn-primary" data-io="export">Export backup (.json)</button>' +
      '  <label class="btn btn-ghost file-btn">Import backup<input type="file" data-io="import" accept="application/json,.json" hidden /></label>' +
      '  <button class="btn btn-ghost danger" data-io="wipe">Erase everything</button>' +
      '</div>';
  }

  function ioBlock() {
    return '<section class="card io-card">' +
      '  <h2>Keep your data</h2>' +
      '  <p class="muted">Everything lives in this browser only. Clearing site data, switching laptop or using a different browser loses it, so if you plan to track yourself for years, export a backup after every sitting.</p>' +
      ioButtons() +
      '</section>';
  }

  function wireIo(el) {
    const ex = $('[data-io="export"]', el);
    if (ex) ex.addEventListener('click', function () {
      const blob = new Blob([IQ.store.exportJson()], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'iq-lab-backup-' + new Date().toISOString().slice(0, 10) + '.json';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    });

    const imp = $('[data-io="import"]', el);
    if (imp) imp.addEventListener('change', function () {
      const file = imp.files && imp.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = function () {
        try {
          const n = IQ.store.importJson(String(reader.result));
          alert(n + ' sitting' + (n === 1 ? '' : 's') + ' imported.');
          views.history();
        } catch (e) {
          alert('Could not import that file: ' + e.message);
        }
      };
      reader.readAsText(file);
    });

    const wipe = $('[data-io="wipe"]', el);
    if (wipe) wipe.addEventListener('click', function () {
      const signedIn = IQ.cloud && IQ.cloud.state().signedIn;
      const scope = signedIn
        ? 'This erases every sitting and your profile BOTH in this browser and in your account, on every device that syncs.'
        : 'This erases every sitting and your profile stored in this browser.';
      if (!confirm(scope + '\n\nThis cannot be undone.')) return;
      if (!confirm('Really erase everything? Export a backup first if you are not sure.')) return;

      const done = function () {
        IQ.store.clearAll();
        IQ.store.clearDraft();
        if (signedIn) {
          alert('Erased. Your sign-in still exists, deleting the account itself is a Supabase Dashboard action ' +
            '(Authentication → Users), because it needs a key that must not live in a web page.');
        }
        go('home');
      };

      if (signedIn) {
        wipe.disabled = true;
        wipe.textContent = 'Erasing…';
        IQ.cloud.eraseCloudData().then(function (r) {
          if (!r.erased) alert('The cloud copy could not be erased (' + (r.reason || 'unknown error') +
            '). Nothing local has been touched, try again when you are back online.');
          if (r.erased) done(); else views.settings();
        });
      } else {
        done();
      }
    });
  }

  /* ============================ THEME ============================ */

  const THEME_KEY = 'iqlab.theme';
  const systemDark = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  function themePref() {
    try { return localStorage.getItem(THEME_KEY) || 'light'; } catch (e) { return 'light'; }
  }

  function applyTheme() {
    const pref = themePref();
    const resolved = pref === 'system'
      ? (systemDark && systemDark.matches ? 'dark' : 'light')
      : pref;
    document.documentElement.dataset.theme = resolved;
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', resolved === 'dark' ? '#15101f' : '#fdf7ef');
    return resolved;
  }

  function setTheme(pref) {
    try { localStorage.setItem(THEME_KEY, pref); } catch (e) { /* private mode */ }
    applyTheme();
  }

  /* ============================ SETTINGS ============================ */

  const THEME_ICONS = {
    light: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.2 5.2l1.4 1.4M17.4 17.4l1.4 1.4M18.8 5.2l-1.4 1.4M6.6 17.4l-1.4 1.4"/></svg>',
    dark: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M20 14.2A8.2 8.2 0 0 1 9.8 4a8.4 8.4 0 1 0 10.2 10.2z"/></svg>',
    system: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="2.5" y="4" width="19" height="12.5" rx="2"/><path d="M8.5 20.5h7"/></svg>'
  };

  /* ---- Account panel: email sign-in and sync status ---- */

  let pendingEmail = '';

  function accountCard() {
    const c = IQ.cloud ? IQ.cloud.state() : { configured: false };

    let body;
    if (!c.configured) {
      body =
        '<p class="muted">Results live in this browser only. Cloud sync (Supabase) is not included in this download.</p>';
    } else if (!c.available) {
      body = '<p class="warn">' + esc(c.error || 'Could not reach Supabase. The app still works locally.') + '</p>';
    } else if (c.signedIn) {
      body =
        '<p class="account-line"><span class="dot dot-on"></span> Signed in as <strong>' + esc(c.email) + '</strong></p>' +
        '<p class="muted">' + (c.syncing ? 'Syncing…' :
          c.lastSync ? 'Last synced ' + new Date(c.lastSync).toLocaleString() : 'Not synced yet.') + '</p>' +
        (c.error ? '<p class="warn">' + esc(c.error) + '</p>' : '') +
        '<div class="btn-row">' +
        '  <button class="btn btn-ghost" data-acct="sync"' + (c.syncing ? ' disabled' : '') + '>Sync now</button>' +
        '  <button class="btn btn-ghost" data-acct="signout">Sign out</button>' +
        '</div>';
    } else if (pendingEmail) {
      body =
        '<p class="muted">Sent to <strong>' + esc(pendingEmail) + '</strong>. Enter the six-digit code from the email ' +
        '(or click the link in it, if this page is served over http).</p>' +
        (c.error ? '<p class="warn">' + esc(c.error) + '</p>' : '') +
        '<div class="field-row">' +
        '  <label class="field"><span>Code</span>' +
        '    <input type="text" id="acctCode" inputmode="numeric" autocomplete="one-time-code" placeholder="123456" /></label>' +
        '</div>' +
        '<div class="btn-row">' +
        '  <button class="btn btn-primary" data-acct="verify">Verify</button>' +
        '  <button class="btn btn-ghost" data-acct="cancel">Use a different email</button>' +
        '</div>';
    } else {
      body =
        '<p class="muted">Sign in with your email to back your history up and pick it up on another device. ' +
        'There is no password, Supabase emails you a code.</p>' +
        (c.error ? '<p class="warn">' + esc(c.error) + '</p>' : '') +
        '<div class="field-row">' +
        '  <label class="field"><span>Email</span>' +
        '    <input type="email" id="acctEmail" autocomplete="email" placeholder="you@example.com" /></label>' +
        '</div>' +
        '<div class="btn-row"><button class="btn btn-primary" data-acct="send">Email me a code</button></div>';
    }

    return '<section class="card"><div class="set-group"><h3>Account</h3>' + body + '</div></section>';
  }

  function wireAccount(el) {
    const act = function (name) { return $('[data-acct="' + name + '"]', el); };
    const busy = function (btn, label) {
      if (!btn) return;
      btn.disabled = true;
      btn.dataset.was = btn.textContent;
      btn.textContent = label;
    };

    const send = act('send');
    if (send) send.addEventListener('click', function () {
      const email = ($('#acctEmail', el).value || '').trim();
      if (!email || email.indexOf('@') < 0) { alert('Enter a valid email address.'); return; }
      busy(send, 'Sending…');
      IQ.cloud.sendCode(email)
        .then(function () { pendingEmail = email; views.settings(); })
        .catch(function () { views.settings(); });
    });

    const verify = act('verify');
    if (verify) verify.addEventListener('click', function () {
      const code = ($('#acctCode', el).value || '').trim();
      if (!code) { alert('Enter the code from the email.'); return; }
      busy(verify, 'Verifying…');
      IQ.cloud.verifyCode(pendingEmail, code)
        .then(function () { pendingEmail = ''; views.settings(); })
        .catch(function () { views.settings(); });
    });

    const cancel = act('cancel');
    if (cancel) cancel.addEventListener('click', function () { pendingEmail = ''; views.settings(); });

    const syncBtn = act('sync');
    if (syncBtn) syncBtn.addEventListener('click', function () {
      busy(syncBtn, 'Syncing…');
      IQ.cloud.sync().then(function () { views.settings(); });
    });

    const out = act('signout');
    if (out) out.addEventListener('click', function () {
      if (!confirm('Sign out? Your sittings stay in this browser, and sync resumes when you sign back in.')) return;
      IQ.cloud.signOut().then(function () { views.settings(); });
    });

    const code = $('#acctCode', el);
    if (code) {
      code.focus();
      code.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); act('verify').click(); }
      });
    }
  }

  views.settings = function () {
    const el = $('[data-view="settings"]');
    const p = IQ.store.profile();
    const pref = themePref();
    const birth = IQ.store.validateBirth(p.birth);
    const bounds = IQ.store.birthBounds();
    const count = IQ.store.attempts().length;

    const themeBtns = ['light', 'dark', 'system'].map(function (k) {
      const label = k === 'system' ? 'Match system' : k.charAt(0).toUpperCase() + k.slice(1);
      return '<button data-theme-set="' + k + '" class="' + (pref === k ? 'on' : '') + '">' +
        THEME_ICONS[k] + label + '</button>';
    }).join('');

    el.innerHTML =
      '<section class="hero">' +
      '  <p class="eyebrow">Settings</p>' +
      '  <h1>Account, preferences &amp; your data</h1>' +
      '</section>' +

      accountCard() +

      '<section class="card">' +
      '  <div class="set-group">' +
      '    <h3>Appearance</h3>' +
      '    <p class="muted">Light is the default. "Match system" follows your operating system and switches with it.</p>' +
      '    <div class="seg" id="themeSeg">' + themeBtns + '</div>' +
      '  </div>' +
      '</section>' +

      '<section class="card">' +
      '  <div class="set-group">' +
      '    <h3>Your details</h3>' +
      '    <p class="muted">Age drives the norms, so changing the date of birth changes what future scores mean. Past results keep the age they were taken at.</p>' +
      '    <div class="field-row">' +
      '      <label class="field"><span>Name <em>(optional)</em></span>' +
      '        <input type="text" id="sName" value="' + esc(p.name) + '" placeholder="For your own records" /></label>' +
      '      <label class="field"><span>Date of birth</span>' +
      '        <input type="date" id="sBirth" value="' + esc(p.birth) + '" min="' + bounds.min + '" max="' + bounds.max + '" /></label>' +
      '    </div>' +
      '    <p class="' + (birth.ok ? 'age-readout' : 'warn') + '" id="sAgeOut">' + esc(birth.message) + '</p>' +
      '  </div>' +
      '</section>' +

      '<section class="card">' +
      '  <div class="set-group">' +
      '    <h3>Your data</h3>' +
      '    <p class="muted">' + count + ' sitting' + (count === 1 ? '' : 's') + ' stored in this browser' +
      (IQ.cloud && IQ.cloud.state().signedIn
        ? ', and mirrored to your account. Signing in on another device pulls the same history down.'
        : ' only. Clearing site data or switching browser loses it, so export a backup after each sitting if you mean to track yourself for years.') + '</p>' +
      ioButtons() +
      '  </div>' +
      '</section>';

    $$('[data-theme-set]', el).forEach(function (b) {
      b.addEventListener('click', function () {
        setTheme(b.dataset.themeSet);
        views.settings();
      });
    });

    const nameEl = $('#sName', el), birthEl = $('#sBirth', el);
    function save() {
      IQ.store.setProfile({ name: nameEl.value.trim(), birth: birthEl.value });
      const v = IQ.store.validateBirth(birthEl.value);
      const out = $('#sAgeOut', el);
      out.textContent = v.message;
      out.className = v.ok ? 'age-readout' : 'warn';
    }
    nameEl.addEventListener('change', save);
    birthEl.addEventListener('input', save);
    birthEl.addEventListener('change', save);

    wireAccount(el);
    wireIo(el);
  };

  /* ============================ BOOT ============================ */

  function boot() {
    document.addEventListener('click', function (e) {
      const nav = e.target.closest('[data-nav], [data-nav-link]');
      if (!nav) return;
      e.preventDefault();
      go(nav.dataset.nav || nav.dataset.navLink);
    });

    /* One-time wipe of everything this app previously stored in this browser.
       Runs before the theme is read, so a purged browser starts from defaults.
       Gated internally by a flag, so it fires once and is inert afterwards. */
    const purge = IQ.store.purgeLegacyData();
    if (purge.ran && purge.removed.length) {
      console.info('[IQ Lab] Cleared previous local data:', purge.removed.join(', '));
    }

    applyTheme();
    if (systemDark && systemDark.addEventListener) {
      systemDark.addEventListener('change', function () {
        if (themePref() === 'system') applyTheme();
      });
    }

    /* Cloud is entirely optional: with no config it disables itself and the
       app behaves exactly as it did before sync existed. */
    if (IQ.cloud) {
      IQ.cloud.init();
      IQ.cloud.onChange(function () {
        if (current === 'settings') views.settings();
      });
    }

    window.addEventListener('beforeunload', function (e) {
      if (current !== 'test') return;
      e.preventDefault();
      e.returnValue = '';
    });

    go('home');
  }

  IQ.app = { go: go, boot: boot };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})(window.IQ);
