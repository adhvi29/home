/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   IQ LAB · Battery assembly
   Builds a whole sitting from a seed. Same seed, same test
   useful for checking the app, and it means every attempt records
   exactly which form it used.
   ============================================================ */
window.IQ = window.IQ || {};

(function (IQ) {
  'use strict';

  const FORMS = {
    full: {
      id: 'full',
      name: 'Full battery',
      minutes: '35-45 min',
      note: 'All five indices, 58 reasoning items plus three timed tasks. Use this one for your yearly benchmark.',
      counts: { matrix: 12, series: 8, logic: 8, weights: 6, verbal: 14, spatial: 10 },
      spans: ['digits', 'mixed'],
      speedSeconds: 90
    },
    short: {
      id: 'short',
      name: 'Short form',
      minutes: '18-22 min',
      note: 'Half the items, so roughly 1.4x wider error bars. Good for a quick check, not for your benchmark.',
      counts: { matrix: 7, series: 5, logic: 4, weights: 4, verbal: 7, spatial: 6 },
      spans: ['digits'],
      speedSeconds: 60
    },
    reasoning: {
      id: 'reasoning',
      name: 'Reasoning only',
      minutes: '25-30 min',
      note: 'Matrices, series, logic, balance scales and spatial. No verbal, memory or speed, this is the purest read on fluid reasoning.',
      counts: { matrix: 12, series: 8, logic: 8, weights: 6, verbal: 0, spatial: 10 },
      spans: [],
      speedSeconds: 0
    }
  };

  function build(seed, formId) {
    const form = FORMS[formId] || FORMS.full;
    const rng = IQ.rng.makeRng(seed);
    const c = form.counts;
    const sections = [];

    if (c.matrix) sections.push({
      id: 'matrix', domain: 'gf', kind: 'mc',
      title: 'Pattern Matrices',
      lead: 'Each grid follows hidden rules that run across the rows. Work out the rules, then pick the figure that belongs in the empty square.',
      tip: 'These get harder as you go. Later grids have several rules running at once.',
      items: IQ.gen.matrix.build(rng, c.matrix)
    });

    if (c.verbal) sections.push({
      id: 'verbal', domain: 'gc', kind: 'mc',
      title: 'Verbal Reasoning',
      lead: 'Word relationships, meanings and categories.',
      tip: 'If a word is unfamiliar, work from the relationship rather than the definition.',
      items: IQ.gen.verbal.build(rng, c.verbal)
    });

    if (c.series) sections.push({
      id: 'series', domain: 'gf', kind: 'mc',
      title: 'Number Series',
      lead: 'Find the rule that generates the sequence, then give the next term.',
      tip: 'Look at the differences first. If those do not settle it, check ratios, then try reading it as two interleaved runs.',
      items: IQ.gen.series.build(rng, c.series)
    });

    if (c.spatial) sections.push({
      id: 'spatial', domain: 'gv', kind: 'mc',
      title: 'Spatial Reasoning',
      lead: 'Rotating figures and folded paper.',
      tip: 'For rotation items, find one distinctive corner of the target and track where it must end up.',
      items: IQ.gen.spatial.build(rng, c.spatial)
    });

    if (c.logic) sections.push({
      id: 'logic', domain: 'gf', kind: 'mc',
      title: 'Deductive Reasoning',
      lead: 'What follows from the statements, and only from the statements.',
      tip: 'Judge the argument, not whether the conclusion sounds sensible. "Nothing definite follows" is sometimes the right answer.',
      items: IQ.gen.logic.build(rng, c.logic)
    });

    if (c.weights) sections.push({
      id: 'weights', domain: 'gf', kind: 'mc',
      title: 'Balance Scales',
      lead: 'The scales at the top balance. Work out how the shapes trade against each other, then find the group that balances the last scale.',
      tip: 'Reduce everything to one shape. If two circles balance a triangle, rewrite every triangle as two circles and the arithmetic becomes easy.',
      items: IQ.gen.weights.build(rng, c.weights)
    });

    (form.spans || []).forEach(function (task) {
      sections.push({
        id: 'span-' + task, domain: 'gwm', kind: 'span', task: task,
        title: task === 'digits' ? 'Memory Span, Digits' : 'Memory Span, Letters & Numbers',
        lead: task === 'digits'
          ? 'Digits appear one at a time. Type them back in reverse order.'
          : 'Letters and digits appear one at a time. Type the numbers in ascending order first, then the letters alphabetically.',
        tip: 'Sequences get longer until you miss two in a row at the same length. Do not write anything down.'
      });
    });

    if (form.speedSeconds) sections.push({
      id: 'speed', domain: 'gs', kind: 'speed', seconds: form.speedSeconds,
      title: 'Processing Speed',
      lead: 'Two target symbols on the left, five to search on the right. Does either target appear among the five?',
      tip: 'Use the arrow keys. Wrong answers subtract, so go as fast as you can while staying accurate.'
    });

    /* Interleave so one ability is not tested only when you are tired */
    const order = ['matrix', 'verbal', 'series', 'spatial', 'span-digits', 'logic', 'weights', 'span-mixed', 'speed'];
    sections.sort(function (a, b) { return order.indexOf(a.id) - order.indexOf(b.id); });

    let itemCount = 0;
    sections.forEach(function (s) { if (s.items) itemCount += s.items.length; });

    return { seed: seed, form: form.id, formName: form.name, sections: sections, itemCount: itemCount };
  }

  IQ.battery = { build: build, FORMS: FORMS };
})(window.IQ);
