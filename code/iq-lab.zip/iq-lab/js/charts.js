/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   IQ LAB · Charts (hand-rolled SVG, no libraries)
   ============================================================ */
window.IQ = window.IQ || {};

(function (IQ) {
  'use strict';

  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  function fmtDate(iso) {
    const d = new Date(iso);
    return d.toLocaleDateString(undefined, { month: 'short', year: 'numeric' });
  }

  /* ---------- Trend over time, with confidence bands ---------- */
  function trend(attempts, opts) {
    opts = opts || {};
    const W = 760, H = 320;
    const P = { l: 46, r: 18, t: 18, b: 42 };
    const iw = W - P.l - P.r, ih = H - P.t - P.b;

    if (!attempts.length) return '<p class="empty">No results yet.</p>';

    const pts = attempts.map(function (a) {
      return {
        t: new Date(a.date).getTime(),
        v: a.score.fsiq,
        lo: a.score.ci[0],
        hi: a.score.ci[1],
        date: a.date,
        form: a.formName || a.form
      };
    });

    let lo = Math.min.apply(null, pts.map(function (p) { return p.lo; }));
    let hi = Math.max.apply(null, pts.map(function (p) { return p.hi; }));
    lo = Math.min(lo, 88); hi = Math.max(hi, 112);
    lo = Math.floor((lo - 4) / 5) * 5; hi = Math.ceil((hi + 4) / 5) * 5;

    const tMin = pts[0].t, tMax = pts[pts.length - 1].t;
    const span = Math.max(tMax - tMin, 1000 * 3600 * 24 * 30);
    const x = function (t) { return P.l + (pts.length === 1 ? iw / 2 : ((t - tMin) / span) * iw); };
    const y = function (v) { return P.t + ih - ((v - lo) / (hi - lo)) * ih; };

    let grid = '';
    for (let v = lo; v <= hi; v += 5) {
      const gy = y(v);
      const major = v % 10 === 0;
      grid += '<line x1="' + P.l + '" y1="' + gy.toFixed(1) + '" x2="' + (W - P.r) + '" y2="' + gy.toFixed(1) +
        '" stroke="currentColor" stroke-opacity="' + (major ? 0.16 : 0.07) + '" stroke-width="1"/>';
      if (major) {
        grid += '<text x="' + (P.l - 10) + '" y="' + (gy + 4).toFixed(1) + '" text-anchor="end" class="axis-lbl">' + v + '</text>';
      }
    }
    // the 100 line gets emphasis: it is the population average
    grid += '<line x1="' + P.l + '" y1="' + y(100).toFixed(1) + '" x2="' + (W - P.r) + '" y2="' + y(100).toFixed(1) +
      '" stroke="currentColor" stroke-opacity="0.38" stroke-width="1.4" stroke-dasharray="5 4"/>';

    let band = '';
    if (pts.length > 1) {
      const top = pts.map(function (p) { return x(p.t).toFixed(1) + ',' + y(p.hi).toFixed(1); });
      const bot = pts.slice().reverse().map(function (p) { return x(p.t).toFixed(1) + ',' + y(p.lo).toFixed(1); });
      band = '<polygon points="' + top.concat(bot).join(' ') + '" fill="var(--accent)" fill-opacity="0.13"/>';
    }

    const line = pts.length > 1
      ? '<polyline points="' + pts.map(function (p) { return x(p.t).toFixed(1) + ',' + y(p.v).toFixed(1); }).join(' ') +
        '" fill="none" stroke="var(--accent)" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round"/>'
      : '';

    let marks = '';
    pts.forEach(function (p) {
      const px = x(p.t), py = y(p.v);
      marks += '<line x1="' + px.toFixed(1) + '" y1="' + y(p.hi).toFixed(1) + '" x2="' + px.toFixed(1) + '" y2="' + y(p.lo).toFixed(1) +
        '" stroke="var(--accent)" stroke-opacity="0.5" stroke-width="1.6"/>';
      marks += '<circle cx="' + px.toFixed(1) + '" cy="' + py.toFixed(1) + '" r="5.5" fill="var(--bg)" stroke="var(--accent)" stroke-width="2.6">' +
        '<title>' + esc(Math.round(p.v) + '  (' + Math.round(p.lo) + '-' + Math.round(p.hi) + ')  ' + new Date(p.date).toLocaleDateString()) + '</title></circle>';
    });

    let xlabels = '';
    const step = Math.max(1, Math.ceil(pts.length / 6));
    pts.forEach(function (p, i) {
      if (i % step !== 0 && i !== pts.length - 1) return;
      xlabels += '<text x="' + x(p.t).toFixed(1) + '" y="' + (H - 14) + '" text-anchor="middle" class="axis-lbl">' + fmtDate(p.date) + '</text>';
    });

    return '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Score over time">' +
      grid + band + line + marks + xlabels + '</svg>';
  }

  /* ---------- Index profile radar ---------- */
  function radar(indices, compare) {
    const W = 360, H = 330, cx = W / 2, cy = 168, R = 118;
    const order = IQ.scoring.INDEX_ORDER;
    const n = order.length;
    const angle = function (i) { return -Math.PI / 2 + (i * 2 * Math.PI) / n; };
    const rad = function (iq) {
      const clamped = Math.max(55, Math.min(145, iq));
      return R * (0.12 + ((clamped - 55) / 90) * 0.88);
    };
    const pt = function (i, iq) {
      const a = angle(i), r = rad(iq);
      return [cx + r * Math.cos(a), cy + r * Math.sin(a)];
    };

    let rings = '';
    [70, 85, 100, 115, 130].forEach(function (v) {
      const poly = [];
      for (let i = 0; i < n; i++) {
        const a = angle(i), r = rad(v);
        poly.push((cx + r * Math.cos(a)).toFixed(1) + ',' + (cy + r * Math.sin(a)).toFixed(1));
      }
      rings += '<polygon points="' + poly.join(' ') + '" fill="none" stroke="currentColor" stroke-opacity="' +
        (v === 100 ? 0.34 : 0.12) + '" stroke-width="' + (v === 100 ? 1.5 : 1) + '"' +
        (v === 100 ? ' stroke-dasharray="4 3"' : '') + '/>';
    });

    let spokes = '';
    for (let i = 0; i < n; i++) {
      const a = angle(i);
      spokes += '<line x1="' + cx + '" y1="' + cy + '" x2="' + (cx + R * Math.cos(a)).toFixed(1) +
        '" y2="' + (cy + R * Math.sin(a)).toFixed(1) + '" stroke="currentColor" stroke-opacity="0.12"/>';
    }

    function shape(src, color, opacity, width, dash) {
      const poly = order.map(function (k, i) {
        const p = pt(i, src[k] ? src[k].iq : 100);
        return p[0].toFixed(1) + ',' + p[1].toFixed(1);
      });
      return '<polygon points="' + poly.join(' ') + '" fill="' + color + '" fill-opacity="' + opacity +
        '" stroke="' + color + '" stroke-width="' + width + '" stroke-linejoin="round"' + (dash ? ' stroke-dasharray="5 4"' : '') + '/>';
    }

    let body = rings + spokes;
    if (compare) body += shape(compare, 'var(--text-dim)', 0.05, 1.8, true);
    body += shape(indices, 'var(--accent)', 0.20, 2.6, false);

    let dots = '', labels = '';
    order.forEach(function (k, i) {
      const meta = IQ.scoring.INDEX_META[k];
      const iq = indices[k] ? indices[k].iq : 100;
      const p = pt(i, iq);
      dots += '<circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="4.5" fill="' + meta.color + '"/>';
      const a = angle(i);
      const lx = cx + (R + 26) * Math.cos(a);
      const ly = cy + (R + 26) * Math.sin(a);
      const anchor = Math.abs(Math.cos(a)) < 0.3 ? 'middle' : (Math.cos(a) > 0 ? 'start' : 'end');
      labels += '<text x="' + lx.toFixed(1) + '" y="' + (ly + 4).toFixed(1) + '" text-anchor="' + anchor + '" class="radar-lbl">' +
        meta.short + '</text>';
      labels += '<text x="' + lx.toFixed(1) + '" y="' + (ly + 19).toFixed(1) + '" text-anchor="' + anchor +
        '" class="radar-val" fill="' + meta.color + '">' + Math.round(iq) + '</text>';
    });

    return '<svg class="chart radar" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Index profile">' +
      body + dots + labels + '</svg>';
  }

  /* ---------- Index bars with error bars ---------- */
  function indexBars(indices) {
    const order = IQ.scoring.INDEX_ORDER;
    const W = 720, rowH = 50, H = order.length * rowH + 30;
    const P = { l: 168, r: 56 };
    const iw = W - P.l - P.r;
    const lo = 55, hi = 145;
    const x = function (v) { return P.l + ((Math.max(lo, Math.min(hi, v)) - lo) / (hi - lo)) * iw; };

    let body = '';
    [70, 85, 100, 115, 130].forEach(function (v) {
      body += '<line x1="' + x(v).toFixed(1) + '" y1="8" x2="' + x(v).toFixed(1) + '" y2="' + (H - 22) +
        '" stroke="currentColor" stroke-opacity="' + (v === 100 ? 0.3 : 0.1) + '"' + (v === 100 ? ' stroke-dasharray="4 3"' : '') + '/>';
      body += '<text x="' + x(v).toFixed(1) + '" y="' + (H - 6) + '" text-anchor="middle" class="axis-lbl">' + v + '</text>';
    });

    order.forEach(function (k, i) {
      const meta = IQ.scoring.INDEX_META[k];
      const idx = indices[k];
      if (!idx) return;
      const cy = 22 + i * rowH;
      const band = 1.645 * 15 * idx.se;
      const x0 = x(idx.iq - band), x1 = x(idx.iq + band), xc = x(idx.iq);
      body += '<text x="' + (P.l - 16) + '" y="' + (cy + 5) + '" text-anchor="end" class="bar-lbl">' + esc(meta.name) + '</text>';
      body += '<line x1="' + x0.toFixed(1) + '" y1="' + cy + '" x2="' + x1.toFixed(1) + '" y2="' + cy +
        '" stroke="' + meta.color + '" stroke-opacity="0.30" stroke-width="11" stroke-linecap="round"/>';
      body += '<circle cx="' + xc.toFixed(1) + '" cy="' + cy + '" r="7.5" fill="' + meta.color + '"/>';
      body += '<text x="' + (W - 12) + '" y="' + (cy + 5) + '" text-anchor="end" class="bar-val">' + Math.round(idx.iq) + '</text>';
    });

    return '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Index scores">' + body + '</svg>';
  }

  /* ---------- The bell curve, with the score marked ---------- */
  function bell(iq, band) {
    const W = 720, H = 210, P = { l: 24, r: 24, t: 14, b: 34 };
    const iw = W - P.l - P.r, ih = H - P.t - P.b;
    const lo = 55, hi = 145;
    const x = function (v) { return P.l + ((v - lo) / (hi - lo)) * iw; };
    const phi = function (v) { const z = (v - 100) / 15; return Math.exp(-0.5 * z * z); };

    let path = '';
    for (let v = lo; v <= hi; v += 1) {
      const px = x(v), py = P.t + ih - phi(v) * ih * 0.94;
      path += (v === lo ? 'M' : 'L') + px.toFixed(1) + ',' + py.toFixed(1);
    }

    // shade the band under the curve
    let shade = 'M' + x(Math.max(lo, iq - band)).toFixed(1) + ',' + (P.t + ih);
    for (let v = Math.max(lo, iq - band); v <= Math.min(hi, iq + band); v += 1) {
      shade += 'L' + x(v).toFixed(1) + ',' + (P.t + ih - phi(v) * ih * 0.94).toFixed(1);
    }
    shade += 'L' + x(Math.min(hi, iq + band)).toFixed(1) + ',' + (P.t + ih) + 'Z';

    let ticks = '';
    [70, 85, 100, 115, 130].forEach(function (v) {
      ticks += '<line x1="' + x(v).toFixed(1) + '" y1="' + (P.t + ih) + '" x2="' + x(v).toFixed(1) + '" y2="' + (P.t + ih + 6) +
        '" stroke="currentColor" stroke-opacity="0.35"/>';
      ticks += '<text x="' + x(v).toFixed(1) + '" y="' + (H - 12) + '" text-anchor="middle" class="axis-lbl">' + v + '</text>';
    });

    const mx = x(Math.max(lo, Math.min(hi, iq)));
    return '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Where this score sits in the population">' +
      '<path d="' + shade + '" fill="var(--accent)" fill-opacity="0.22"/>' +
      '<path d="' + path + '" fill="none" stroke="currentColor" stroke-opacity="0.45" stroke-width="2"/>' +
      '<line x1="' + P.l + '" y1="' + (P.t + ih) + '" x2="' + (W - P.r) + '" y2="' + (P.t + ih) + '" stroke="currentColor" stroke-opacity="0.25"/>' +
      ticks +
      '<line x1="' + mx.toFixed(1) + '" y1="' + P.t + '" x2="' + mx.toFixed(1) + '" y2="' + (P.t + ih) +
      '" stroke="var(--accent)" stroke-width="2.4"/>' +
      '<circle cx="' + mx.toFixed(1) + '" cy="' + P.t + '" r="5" fill="var(--accent)"/>' +
      '</svg>';
  }

  IQ.charts = { trend: trend, radar: radar, indexBars: indexBars, bell: bell };
})(window.IQ);
