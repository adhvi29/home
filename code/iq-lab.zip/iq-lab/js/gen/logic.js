/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   IQ LAB · Deductive reasoning
   Three families: categorical syllogisms, conditional (if-then)
   reasoning, and linear orderings.

   Syllogism terms are invented words on purpose. Real category
   names let people answer from world knowledge instead of from the
   logic, which is exactly the "belief bias" that ruins the item.
   ============================================================ */
window.IQ = window.IQ || {};

(function (IQ) {
  'use strict';

  const NONSENSE = [
    'Kelts', 'Vorns', 'Dremps', 'Talvers', 'Yumes', 'Brints', 'Wexels', 'Nardles',
    'Pomes', 'Zarnies', 'Glints', 'Craves', 'Fendles', 'Mirops', 'Suvans', 'Ovels'
  ];

  const NAMES = ['Ana', 'Ben', 'Cara', 'Dev', 'Elif', 'Finn', 'Gita', 'Hugo'];

  /* ---------- Categorical syllogisms ----------
     Each template names premises in terms of S (subject of the
     conclusion), P (predicate) and M (middle term). `concl` is the
     index into CONCLUSIONS of the strongest conclusion that must
     be true; 4 means nothing follows. */
  const CONCLUSIONS = [
    'All {S} are {P}.',
    'No {S} are {P}.',
    'Some {S} are {P}.',
    'Some {S} are not {P}.',
    'Nothing definite follows.'
  ];

  const SYLLOGISMS = [
    { p: ['All {M} are {P}.', 'All {S} are {M}.'], concl: 0, b: -1.45 },   // Barbara
    { p: ['No {M} are {P}.', 'All {S} are {M}.'], concl: 1, b: -1.10 },    // Celarent
    { p: ['All {M} are {P}.', 'Some {S} are {M}.'], concl: 2, b: -0.40 },  // Darii
    { p: ['No {M} are {P}.', 'Some {S} are {M}.'], concl: 3, b: 0.20 },    // Ferio
    { p: ['No {P} are {M}.', 'All {S} are {M}.'], concl: 1, b: 0.35 },     // Cesare
    { p: ['All {P} are {M}.', 'No {S} are {M}.'], concl: 1, b: 0.70 },     // Camestres
    { p: ['Some {M} are not {P}.', 'All {M} are {S}.'], concl: 3, b: 1.40 }, // Bocardo
    { p: ['All {P} are {M}.', 'Some {S} are not {M}.'], concl: 3, b: 1.55 }, // Baroco
    { p: ['All {P} are {M}.', 'All {S} are {M}.'], concl: 4, b: 0.85 },    // undistributed middle
    { p: ['All {M} are {P}.', 'No {S} are {M}.'], concl: 4, b: 1.05 },     // denying the middle
    { p: ['Some {M} are {P}.', 'Some {S} are {M}.'], concl: 4, b: 0.95 },  // two particulars
    { p: ['No {M} are {P}.', 'No {S} are {M}.'], concl: 4, b: 1.20 }       // two negatives
  ];

  function syllogism(rng, tier) {
    const band = SYLLOGISMS.filter(function (t) {
      if (tier <= 0) return t.b < -0.5;
      if (tier === 1) return t.b >= -0.5 && t.b < 0.5;
      if (tier === 2) return t.b >= 0.5 && t.b < 1.1;
      return t.b >= 1.1;
    });
    const tpl = rng.pick(band.length ? band : SYLLOGISMS);
    const terms = rng.sample(NONSENSE, 3);
    const map = { S: terms[0], P: terms[1], M: terms[2] };
    const fill = function (s) { return s.replace(/\{(\w)\}/g, function (_, k) { return map[k]; }); };

    const options = CONCLUSIONS.map(fill);
    return {
      domain: 'gf',
      type: 'syllogism',
      b: tpl.b,
      prompt: 'Assume both statements are true. Select the strongest conclusion that <em>must</em> be true.',
      stemHtml: '<div class="premises">' +
        tpl.p.map(function (s) { return '<p>' + fill(s) + '</p>'; }).join('') + '</div>',
      optionsHtml: options.map(function (s) { return '<span class="opt-line">' + s + '</span>'; }),
      optionClass: 'opt-text opt-stack',
      fixedOrder: true,
      answer: tpl.concl,
      meta: { form: tpl.p.join(' ') }
    };
  }

  /* ---------- Conditional reasoning ---------- */
  const EVENTS = [
    ['the alarm is armed', 'the door is locked'],
    ['the sample is acidic', 'the strip turns red'],
    ['the drive is full', 'the backup fails'],
    ['the valve is open', 'water reaches the tank'],
    ['the badge scans', 'the gate opens'],
    ['the culture grows', 'the dish turns cloudy'],
    ['the relay trips', 'the light goes out'],
    ['the seed is viable', 'the shoot appears']
  ];

  const COND_FORMS = [
    { id: 'ponens', b: -1.90 },
    { id: 'disjunctive', b: -1.00 },
    { id: 'chain', b: -0.55 },
    { id: 'tollens', b: 0.55 },
    { id: 'affirmConsequent', b: 0.90 },
    { id: 'denyAntecedent', b: 1.00 },
    { id: 'chainTollens', b: 1.50 }
  ];

  function conditional(rng, tier) {
    const band = COND_FORMS.filter(function (f) {
      if (tier <= 0) return f.b < -0.8;
      if (tier === 1) return f.b >= -0.8 && f.b < 0.6;
      if (tier === 2) return f.b >= 0.6 && f.b < 1.2;
      return f.b >= 1.2;
    });
    const form = rng.pick(band.length ? band : COND_FORMS);
    const pair = rng.pick(EVENTS);
    const other = rng.pick(EVENTS.filter(function (e) { return e !== pair; }));
    const P = pair[0], Q = pair[1], R = other[1];

    const cap = function (s) { return s.charAt(0).toUpperCase() + s.slice(1); };
    let premises, opts, ans;

    if (form.id === 'ponens') {
      premises = ['If ' + P + ', then ' + Q + '.', cap(P) + '.'];
      opts = [cap(Q) + '.', cap(Q) + ' does not happen.', cap(P) + ' does not happen.', 'Nothing definite follows.'];
      ans = 0;
    } else if (form.id === 'tollens') {
      premises = ['If ' + P + ', then ' + Q + '.', cap(Q) + ' does not happen.'];
      opts = [cap(P) + ' does not happen.', cap(P) + '.', cap(Q) + '.', 'Nothing definite follows.'];
      ans = 0;
    } else if (form.id === 'affirmConsequent') {
      premises = ['If ' + P + ', then ' + Q + '.', cap(Q) + '.'];
      opts = [cap(P) + '.', cap(P) + ' does not happen.', cap(Q) + ' does not happen.', 'Nothing definite follows.'];
      ans = 3;
    } else if (form.id === 'denyAntecedent') {
      premises = ['If ' + P + ', then ' + Q + '.', cap(P) + ' does not happen.'];
      opts = [cap(Q) + ' does not happen.', cap(Q) + '.', cap(P) + '.', 'Nothing definite follows.'];
      ans = 3;
    } else if (form.id === 'disjunctive') {
      premises = ['Either ' + P + ' or ' + Q + ' (or both).', cap(P) + ' does not happen.'];
      opts = [cap(Q) + '.', cap(Q) + ' does not happen.', cap(P) + '.', 'Nothing definite follows.'];
      ans = 0;
    } else if (form.id === 'chain') {
      premises = ['If ' + P + ', then ' + Q + '.', 'If ' + Q + ', then ' + R + '.', cap(P) + '.'];
      opts = [cap(R) + '.', cap(R) + ' does not happen.', cap(Q) + ' does not happen.', 'Nothing definite follows.'];
      ans = 0;
    } else {
      premises = ['If ' + P + ', then ' + Q + '.', 'If ' + Q + ', then ' + R + '.', cap(R) + ' does not happen.'];
      opts = [cap(P) + ' does not happen.', cap(P) + '.', cap(Q) + '.', 'Nothing definite follows.'];
      ans = 0;
    }

    return {
      domain: 'gf',
      type: 'conditional',
      b: form.b,
      prompt: 'Assume every statement is true. What follows?',
      stemHtml: '<div class="premises">' + premises.map(function (s) { return '<p>' + s + '</p>'; }).join('') + '</div>',
      optionsHtml: opts.map(function (s) { return '<span class="opt-line">' + s + '</span>'; }),
      optionClass: 'opt-text opt-stack',
      fixedOrder: true,
      answer: ans,
      meta: { form: form.id }
    };
  }

  /* ---------- Linear ordering ---------- */
  const SCALES = [
    { adj: 'taller', inv: 'shorter', sup: 'tallest', least: 'shortest' },
    { adj: 'faster', inv: 'slower', sup: 'fastest', least: 'slowest' },
    { adj: 'older', inv: 'younger', sup: 'oldest', least: 'youngest' },
    { adj: 'heavier', inv: 'lighter', sup: 'heaviest', least: 'lightest' }
  ];

  function ordering(rng, tier) {
    const n = tier <= 0 ? 4 : tier === 1 ? 4 : tier === 2 ? 5 : 6;
    const invertRate = tier <= 0 ? 0 : tier === 1 ? 0.35 : 0.5;
    const people = rng.sample(NAMES, n);
    const scale = rng.pick(SCALES);

    // people[0] is the "most", people[n-1] the "least"
    const order = people.slice();
    const statements = [];
    for (let i = 0; i < n - 1; i++) {
      const hi = order[i], lo = order[i + 1];
      if (rng.chance(invertRate)) statements.push(lo + ' is ' + scale.inv + ' than ' + hi + '.');
      else statements.push(hi + ' is ' + scale.adj + ' than ' + lo + '.');
    }
    // one extra non-adjacent statement adds load without changing the answer
    if (tier >= 2) {
      const i = rng.int(0, n - 3);
      statements.push(order[i] + ' is ' + scale.adj + ' than ' + order[i + 2] + '.');
    }

    const askMost = rng.chance(0.5);
    const question = askMost
      ? 'Who is the ' + scale.sup + '?'
      : 'Who is the ' + scale.least + '?';
    const correct = askMost ? order[0] : order[n - 1];

    const opts = rng.shuffle(people.slice()).slice(0, Math.min(n, 5));
    if (opts.indexOf(correct) < 0) opts[0] = correct;
    const shuffled = rng.shuffle(opts);

    const b = -1.35 + (n - 4) * 0.75 + (invertRate > 0 ? 0.45 : 0) + (tier >= 2 ? 0.25 : 0);

    return {
      domain: 'gf',
      type: 'ordering',
      b: b,
      prompt: question,
      stemHtml: '<div class="premises">' +
        rng.shuffle(statements).map(function (s) { return '<p>' + s + '</p>'; }).join('') + '</div>',
      optionsHtml: shuffled.map(function (s) { return '<span class="opt-line">' + s + '</span>'; }),
      optionClass: 'opt-text opt-stack',
      fixedOrder: true,
      answer: shuffled.indexOf(correct),
      meta: { n: n }
    };
  }

  function generate(rng, tier) {
    const kind = rng.pick(['syllogism', 'conditional', 'ordering']);
    if (kind === 'syllogism') return syllogism(rng, tier);
    if (kind === 'conditional') return conditional(rng, tier);
    return ordering(rng, tier);
  }

  function build(rng, n) {
    const out = [];
    const kinds = [];
    for (let i = 0; i < n; i++) kinds.push(['syllogism', 'conditional', 'ordering'][i % 3]);
    const order = rng.shuffle(kinds);
    for (let i = 0; i < n; i++) {
      const frac = n === 1 ? 0.5 : i / (n - 1);
      const tier = Math.min(3, Math.floor(frac * 4));
      const k = order[i];
      out.push(k === 'syllogism' ? syllogism(rng, tier) : k === 'conditional' ? conditional(rng, tier) : ordering(rng, tier));
    }
    return out;
  }

  IQ.gen = IQ.gen || {};
  IQ.gen.logic = { generate: generate, build: build };
})(window.IQ);
