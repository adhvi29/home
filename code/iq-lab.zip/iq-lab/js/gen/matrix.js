/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   IQ LAB · Matrix reasoning (Raven-style progressive matrices)
   ------------------------------------------------------------
   A 3x3 grid of figures. Each visual attribute is either held
   constant or governed by one relational rule applied across the
   rows. The bottom-right cell is missing.

   Difficulty is known by construction rather than guessed: it is a
   function of how many attributes carry a rule and how hard those
   rule types are. That is what lets the scoring model treat these
   as calibrated items.
   ============================================================ */
window.IQ = window.IQ || {};

(function (IQ) {
  'use strict';

  const S = IQ.shapes;

  /* Attribute domains */
  const ATTRS = {
    shape: { values: [0, 1, 2, 3, 4, 5, 6, 7], wrap: 8 },
    count: { values: [1, 2, 3, 4, 5], wrap: 5 },
    fill:  { values: [0, 1, 2, 3], wrap: 4 },
    rot:   { values: [0, 1, 2, 3], wrap: 4 },
    size:  { values: [0, 1, 2], wrap: 3 }
  };

  /* Rule types and their contribution to item difficulty, in logits */
  const RULES = {
    constRow:    { cost: 0.00 },  // constant along each row, differs between rows
    constCol:    { cost: 0.10 },  // constant down each column
    progression: { cost: 0.30 },  // steps by +/-1 or +/-2 across the row
    latin:       { cost: 0.55 },  // each value appears once per row and per column
    arithmetic:  { cost: 0.80 }   // third = first +/- second (count only)
  };

  /* ---- Rule appliers: each returns a 3x3 grid of attribute values ---- */

  function gridConstRow(rng, dom) {
    const vals = rng.sample(dom.values, 3);
    return [0, 1, 2].map(function (r) { return [vals[r], vals[r], vals[r]]; });
  }

  function gridConstCol(rng, dom) {
    const vals = rng.sample(dom.values, 3);
    return [0, 1, 2].map(function () { return vals.slice(); });
  }

  function gridProgression(rng, dom) {
    const step = rng.pick([1, 2, dom.wrap - 1]);       // wrap-1 reads as a decrement
    const starts = rng.sample(dom.values, 3);
    return [0, 1, 2].map(function (r) {
      const i = dom.values.indexOf(starts[r]);
      return [0, 1, 2].map(function (c) {
        return dom.values[(i + c * step) % dom.wrap];
      });
    });
  }

  function gridLatin(rng, dom) {
    const vals = rng.sample(dom.values, 3);
    const shift = rng.int(1, 2);
    return [0, 1, 2].map(function (r) {
      return [0, 1, 2].map(function (c) { return vals[(c + r * shift) % 3]; });
    });
  }

  /* count only: col3 = col1 + col2, or col3 = col1 - col2 */
  function gridArithmetic(rng) {
    const add = rng.chance(0.6);
    const rows = [];
    const used = {};
    let guard = 0;
    while (rows.length < 3 && guard++ < 400) {
      let a, b, c;
      if (add) { a = rng.int(1, 3); b = rng.int(1, 5 - a); c = a + b; }
      else { a = rng.int(3, 5); b = rng.int(1, a - 1); c = a - b; }
      if (c < 1 || c > 5) continue;
      const key = a + ',' + b;
      if (used[key]) continue;
      used[key] = true;
      rows.push([a, b, c]);
    }
    while (rows.length < 3) rows.push([1, 2, 3]);
    return rows;
  }

  function buildGrid(rng, attrName, ruleName, domOverride) {
    const dom = domOverride || ATTRS[attrName];
    if (ruleName === 'constRow') return gridConstRow(rng, dom);
    if (ruleName === 'constCol') return gridConstCol(rng, dom);
    if (ruleName === 'progression') return gridProgression(rng, dom);
    if (ruleName === 'latin') return gridLatin(rng, dom);
    if (ruleName === 'arithmetic') return gridArithmetic(rng);
    return gridConstRow(rng, dom);
  }

  /* ---- Item construction ---- */

  /* How many of the four quarter-turns are visually distinct for each shape.
     A square or a diamond turned 90 degrees is the same picture, so rotation
     cannot carry a rule on those, and a "rotated" distractor built from one
     would be an exact duplicate of the correct answer. */
  const ROT_STATES = [1, 4, 1, 1, 4, 2, 4, 4];
  //                 circle, triangle, square, diamond, pentagon, hexagon, star, arrow

  // Shapes with four distinct orientations: the only ones rotation may govern
  const ORIENTED = [1, 4, 6, 7];      // triangle, pentagon, star, arrow
  const ALL_SHAPES = [0, 1, 2, 3, 4, 5, 6, 7];

  function generate(rng, targetRules) {
    const nRules = Math.max(1, Math.min(4, targetRules));
    const pool = ['shape', 'count', 'fill', 'rot', 'size'];
    const active = rng.sample(pool, nRules);
    const rotActive = active.indexOf('rot') >= 0;
    const shapePool = rotActive ? ORIENTED : ALL_SHAPES;

    const grids = {};
    const ruleChoice = {};
    let ruleCost = 0;

    for (let k = 0; k < active.length; k++) {
      const attr = active[k];
      let options;
      if (attr === 'count') options = ['constRow', 'constCol', 'progression', 'latin', 'arithmetic'];
      else if (attr === 'size') options = ['constRow', 'constCol', 'latin'];
      else options = ['constRow', 'constCol', 'progression', 'latin'];

      const rule = rng.pick(options);
      ruleChoice[attr] = rule;
      ruleCost += RULES[rule].cost;

      if (attr === 'shape') {
        const vals = rng.sample(shapePool, Math.min(shapePool.length, 5));
        grids[attr] = buildGrid(rng, 'shape', rule, { values: vals, wrap: vals.length });
      } else {
        grids[attr] = buildGrid(rng, attr, rule);
      }
    }

    /* Inactive attributes are frozen at one value for the whole matrix */
    const frozen = {};
    for (let i = 0; i < pool.length; i++) {
      const attr = pool[i];
      if (active.indexOf(attr) >= 0) continue;
      if (attr === 'shape') frozen.shape = rng.pick(shapePool);
      else if (attr === 'count') frozen.count = rng.int(1, 3);
      else if (attr === 'fill') frozen.fill = rng.pick([0, 2, 3]);
      else if (attr === 'rot') frozen.rot = 0;
      else if (attr === 'size') frozen.size = 2;
    }

    function toCell(raw) {
      return {
        shape: S.SHAPES[raw.shape],
        count: raw.count,
        fill: raw.fill,
        rot: raw.rot * 90,
        size: raw.size,
        raw: raw
      };
    }

    function cellAt(r, c) {
      const raw = {};
      for (let i = 0; i < pool.length; i++) {
        const attr = pool[i];
        raw[attr] = active.indexOf(attr) >= 0 ? grids[attr][r][c] : frozen[attr];
      }
      return toCell(raw);
    }

    const cells = [];
    for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) cells.push(cellAt(r, c));
    const correct = cells[8];

    /* ---- Distractors ----
       Raven distractors are not random: they are the near-misses a partially
       correct rule inference would actually produce. Candidates are ranked so
       the most confusable ones are used first, then deduplicated on the
       RENDERED figure rather than on the attribute vector, two different
       attribute vectors can draw the same picture. */

    function variantsOf(base, attr) {
      const out = [];
      const raw = base.raw;
      if (attr === 'shape') {
        for (let i = 0; i < shapePool.length; i++) {
          if (shapePool[i] === raw.shape) continue;
          out.push(toCell(Object.assign({}, raw, { shape: shapePool[i] })));
        }
      } else if (attr === 'count') {
        for (let v = 1; v <= 5; v++) {
          if (v === raw.count) continue;
          out.push(toCell(Object.assign({}, raw, { count: v })));
        }
      } else if (attr === 'rot') {
        const states = ROT_STATES[raw.shape];
        if (states > 1) {
          const stride = 4 / states;
          for (let k = 1; k < states; k++) {
            out.push(toCell(Object.assign({}, raw, { rot: (raw.rot + k * stride) % 4 })));
          }
        }
      } else {
        const dom = ATTRS[attr];
        for (let v = 0; v < dom.wrap; v++) {
          if (v === raw[attr]) continue;
          out.push(toCell(Object.assign({}, raw, { [attr]: v })));
        }
      }
      return rng.shuffle(out);
    }

    function twoAttrVariant() {
      if (active.length < 2) return [];
      const picks = rng.sample(active, 2);
      const first = variantsOf(correct, picks[0]);
      if (!first.length) return [];
      const second = variantsOf(first[0], picks[1]);
      return second.length ? [second[0]] : [];
    }

    /* Ordering matters. A distractor that differs only on an attribute the
       matrix holds CONSTANT tests whether you noticed it is constant, which is
       fair, but only if the difference is actually visible. A near-identical
       figure one size step smaller is an eyesight test, not a reasoning test.
       So: rule-bearing attributes first, then salient constants, and size or
       rotation only if we still need options to reach six. */
    const SALIENT = ['shape', 'count', 'fill'];
    const SUBTLE = ['size', 'rot'];

    let candidates = [];
    rng.shuffle(active).forEach(function (attr) {
      candidates = candidates.concat(variantsOf(correct, attr).slice(0, 2));
    });
    candidates = candidates.concat([cells[7], cells[5], cells[4], cells[6]]); // "continued the wrong line"
    candidates = candidates.concat(twoAttrVariant());
    rng.shuffle(SALIENT).forEach(function (attr) {
      candidates = candidates.concat(variantsOf(correct, attr));
    });
    rng.shuffle(SUBTLE).forEach(function (attr) {
      candidates = candidates.concat(variantsOf(correct, attr));
    });

    const render = function (cell) { return S.renderCell(cell, { size: 72 }); };
    const correctOpt = { cell: correct, key: render(correct) };
    const seenKeys = {};
    seenKeys[correctOpt.key] = true;
    const wrongOpts = [];
    for (let i = 0; i < candidates.length && wrongOpts.length < 5; i++) {
      const k = render(candidates[i]);
      if (seenKeys[k]) continue;
      seenKeys[k] = true;
      wrongOpts.push({ cell: candidates[i], key: k });
    }

    const built = IQ.rng.assemble(rng, correctOpt, wrongOpts, 6);

    /* Difficulty in logits, calibrated so a 2-rule matrix sits near the
       population average (b ~ 0) and a 4-rule matrix is clearly hard. */
    const b = -2.83 + 0.92 * nRules + ruleCost + (rotActive ? 0.18 : 0);

    let gridHtml = '';
    for (let i = 0; i < 8; i++) {
      gridHtml += '<div class="mx-cell">' + S.renderCell(cells[i], { size: 78 }) + '</div>';
    }
    gridHtml += '<div class="mx-cell mx-missing"><span>?</span></div>';

    return {
      domain: 'gf',
      type: 'matrix',
      b: b,
      prompt: 'Which figure completes the pattern?',
      stemHtml: '<div class="mx-grid">' + gridHtml + '</div>',
      optionsHtml: built.options.map(function (o) { return S.renderCell(o.cell, { size: 72 }); }),
      optionClass: 'opt-fig',
      answer: built.answer,
      meta: { rules: ruleChoice, nRules: nRules }
    };
  }

  /* Produce n matrices spread across a difficulty ladder.
     Weighted toward the harder end: easy items add almost no information
     about where someone actually sits, they just stop the test feeling
     hostile from item one. */
  function build(rng, n) {
    const out = [];
    for (let i = 0; i < n; i++) {
      const frac = n === 1 ? 0.5 : i / (n - 1);
      const rules = frac < 0.14 ? 1 : frac < 0.40 ? 2 : frac < 0.70 ? 3 : 4;
      out.push(generate(rng, rules));
    }
    return out;
  }

  IQ.gen = IQ.gen || {};
  IQ.gen.matrix = { generate: generate, build: build };
})(window.IQ);
