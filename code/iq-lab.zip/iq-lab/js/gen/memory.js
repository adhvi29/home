/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   IQ LAB · Working memory (Gwm)
   ------------------------------------------------------------
   Two classic span tasks, run as an adaptive staircase rather than
   a fixed list. The staircase is what real span testing does: it
   converges on your limit in far fewer trials than a fixed set,
   and the resulting span is directly comparable to published norms.

   - Backward digit span: repeat the digits in reverse.
   - Letter-number sequencing: give the numbers in ascending order,
     then the letters in alphabetical order.

   Rule: two trials per span length, advance on either one correct,
   stop after failing both at the same length.
   ============================================================ */
window.IQ = window.IQ || {};

(function (IQ) {
  'use strict';

  const LETTERS = 'BCDFGHJKLMNPQRSTVWXZ'.split('');   // no vowels: avoids chunking into words

  function makeDigits(rng, n) {
    const seq = [];
    let last = -1;
    for (let i = 0; i < n; i++) {
      let d;
      let guard = 0;
      do { d = rng.int(1, 9); guard++; } while ((d === last || (i > 0 && d === seq[i - 1] + 1)) && guard < 20);
      seq.push(d);
      last = d;
    }
    return seq;
  }

  function makeMixed(rng, n) {
    const nNums = Math.ceil(n / 2);
    const nLets = n - nNums;
    const nums = rng.sample([1, 2, 3, 4, 5, 6, 7, 8, 9], nNums);
    const lets = rng.sample(LETTERS, nLets);
    return rng.shuffle(nums.concat(lets));
  }

  function expected(task, seq) {
    if (task === 'digits') return seq.slice().reverse().join('');
    const nums = seq.filter(function (s) { return typeof s === 'number'; }).sort(function (a, b) { return a - b; });
    const lets = seq.filter(function (s) { return typeof s === 'string'; }).sort();
    return nums.join('') + lets.join('');
  }

  function normalise(str) {
    return String(str).toUpperCase().replace(/[^0-9A-Z]/g, '');
  }

  /* Runs the whole staircase inside `el`, calls done({ span, trials }) */
  function mount(el, opts, done) {
    const rng = opts.rng;
    const task = opts.task;                 // 'digits' | 'mixed'
    const startSpan = opts.startSpan || 3;
    const maxSpan = opts.maxSpan || 9;

    let span = startSpan;
    let attemptsAtSpan = 0;
    let correctAtSpan = 0;
    let bestSpan = 0;
    const trials = [];

    const label = task === 'digits'
      ? 'Type the digits in <strong>reverse</strong> order.'
      : 'Type the <strong>numbers in ascending order</strong>, then the <strong>letters alphabetically</strong>.';

    el.innerHTML =
      '<div class="span-task">' +
      '  <p class="task-hint">' + label + '</p>' +
      '  <div class="span-stage" id="spanStage"><button class="btn btn-primary" id="spanStart">Start</button></div>' +
      '  <div class="span-input" id="spanInput" hidden>' +
      '    <input type="text" id="spanAnswer" autocomplete="off" autocapitalize="characters" spellcheck="false" ' +
      '           inputmode="' + (task === 'digits' ? 'numeric' : 'text') + '" placeholder="your answer" />' +
      '    <button class="btn btn-primary" id="spanSubmit">Submit</button>' +
      '  </div>' +
      '  <p class="span-meta"><span id="spanLevel">Length ' + span + '</span></p>' +
      '</div>';

    const stage = el.querySelector('#spanStage');
    const inputWrap = el.querySelector('#spanInput');
    const answerEl = el.querySelector('#spanAnswer');
    const levelEl = el.querySelector('#spanLevel');
    let current = null;
    let timer = null;

    function present() {
      const seq = task === 'digits' ? makeDigits(rng, span) : makeMixed(rng, span);
      current = { seq: seq, span: span, want: expected(task, seq) };
      levelEl.textContent = 'Length ' + span;
      inputWrap.hidden = true;
      stage.innerHTML = '<div class="span-token" id="spanToken">&nbsp;</div>';
      const tokenEl = stage.querySelector('#spanToken');

      let i = -1;
      const ON = 750, OFF = 320;
      function step() {
        i++;
        if (i >= seq.length) {
          tokenEl.textContent = '';
          tokenEl.classList.remove('lit');
          inputWrap.hidden = false;
          answerEl.value = '';
          answerEl.focus();
          return;
        }
        tokenEl.textContent = seq[i];
        tokenEl.classList.add('lit');
        timer = setTimeout(function () {
          tokenEl.classList.remove('lit');
          tokenEl.innerHTML = '&nbsp;';
          timer = setTimeout(step, OFF);
        }, ON);
      }
      timer = setTimeout(step, 600);
    }

    function submit() {
      if (!current) return;
      const given = normalise(answerEl.value);
      const ok = given === normalise(current.want);
      trials.push({ span: current.span, ok: ok, given: given, want: current.want });

      attemptsAtSpan++;
      if (ok) {
        correctAtSpan++;
        if (current.span > bestSpan) bestSpan = current.span;
      }

      if (correctAtSpan >= 1 && attemptsAtSpan >= 1) {
        // passed this length: move up
        span++;
        attemptsAtSpan = 0;
        correctAtSpan = 0;
        if (span > maxSpan) return finish();
        return next();
      }
      if (attemptsAtSpan >= 2) {
        // failed both trials at this length: that is the ceiling
        return finish();
      }
      next();
    }

    function next() {
      inputWrap.hidden = true;
      stage.innerHTML = '<div class="span-wait">Next sequence&hellip;</div>';
      timer = setTimeout(present, 900);
    }

    function finish() {
      if (timer) clearTimeout(timer);
      inputWrap.hidden = true;
      stage.innerHTML = '<div class="span-wait">Done.</div>';
      done({ span: bestSpan, trials: trials, task: task });
    }

    el.querySelector('#spanStart').addEventListener('click', present);
    el.querySelector('#spanSubmit').addEventListener('click', submit);
    answerEl.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); submit(); }
    });

    return function cleanup() { if (timer) clearTimeout(timer); };
  }

  IQ.gen = IQ.gen || {};
  IQ.gen.memory = { mount: mount, expected: expected };
})(window.IQ);
