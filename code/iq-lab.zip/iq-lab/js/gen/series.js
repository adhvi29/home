/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   IQ LAB · Number & letter series (inductive reasoning)
   Each rule family has a fixed difficulty in logits, so the item's
   b-value is known the moment it is generated.
   ============================================================ */
window.IQ = window.IQ || {};

(function (IQ) {
  'use strict';

  const ALPHA = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

  /* Each family returns { terms, next, label } or null if it degenerated */
  const FAMILIES = [
    {
      id: 'addConst', b: -2.10,
      make: function (rng) {
        const d = rng.pick([2, 3, 4, 5, 6, 7, 9, 11]) * (rng.chance(0.2) ? -1 : 1);
        const a0 = rng.int(2, 40);
        const t = []; for (let i = 0; i < 6; i++) t.push(a0 + i * d);
        return { terms: t.slice(0, 5), next: t[5], label: 'add ' + d };
      }
    },
    {
      id: 'mulConst', b: -1.25,
      make: function (rng) {
        const k = rng.pick([2, 2, 3, 4]);
        const a0 = rng.int(2, 6);
        const t = []; for (let i = 0; i < 6; i++) t.push(a0 * Math.pow(k, i));
        if (t[5] > 20000) return null;
        return { terms: t.slice(0, 5), next: t[5], label: 'multiply by ' + k };
      }
    },
    {
      id: 'addGrowing', b: -0.55,
      make: function (rng) {
        const d0 = rng.int(1, 5), inc = rng.pick([1, 2, 3]);
        let v = rng.int(1, 12), d = d0;
        const t = [v];
        for (let i = 0; i < 5; i++) { v += d; d += inc; t.push(v); }
        return { terms: t.slice(0, 5), next: t[5], label: 'differences grow by ' + inc };
      }
    },
    {
      id: 'alternating', b: 0.15,
      make: function (rng) {
        const d1 = rng.pick([2, 3, 4, 5, 6]), d2 = rng.pick([-1, -2, -3, 1, 7, 8]);
        if (d1 === d2) return null;
        let a = rng.int(3, 20), b2 = rng.int(3, 20);
        const t = [];
        for (let i = 0; i < 3; i++) { t.push(a); t.push(b2); a += d1; b2 += d2; }
        return { terms: t.slice(0, 5), next: t[5], label: 'two interleaved runs' };
      }
    },
    {
      id: 'fibonacci', b: 0.35,
      make: function (rng) {
        let a = rng.int(1, 8), b2 = rng.int(2, 11);
        const t = [a, b2];
        for (let i = 0; i < 4; i++) { const c = t[t.length - 1] + t[t.length - 2]; t.push(c); }
        return { terms: t.slice(0, 5), next: t[5], label: 'each term is the sum of the two before it' };
      }
    },
    {
      id: 'mulAdd', b: 0.80,
      make: function (rng) {
        const k = rng.pick([2, 2, 3]), c = rng.pick([1, 2, 3, -1, -2, 4, 5]);
        let v = rng.int(1, 6);
        const t = [v];
        for (let i = 0; i < 5; i++) { v = v * k + c; t.push(v); }
        if (Math.abs(t[5]) > 40000) return null;
        return { terms: t.slice(0, 5), next: t[5], label: 'x' + k + (c >= 0 ? ' +' : ' ') + c };
      }
    },
    {
      id: 'squaresOffset', b: 1.05,
      make: function (rng) {
        const off = rng.pick([-3, -2, -1, 0, 1, 2, 3]);
        const start = rng.int(2, 6);
        const t = []; for (let i = 0; i < 6; i++) { const n = start + i; t.push(n * n + off); }
        return { terms: t.slice(0, 5), next: t[5], label: 'perfect squares shifted by ' + off };
      }
    },
    {
      id: 'interleavedOps', b: 1.55,
      make: function (rng) {
        const k = rng.pick([2, 3]), d = rng.pick([3, 4, 5, 6, 7]);
        let a = rng.int(2, 5), b2 = rng.int(4, 15);
        const t = [];
        for (let i = 0; i < 3; i++) { t.push(a); t.push(b2); a = a * k; b2 = b2 + d; }
        if (t[5] > 30000) return null;
        return { terms: t.slice(0, 5), next: t[5], label: 'one run multiplies, the other adds' };
      }
    },
    {
      id: 'diffOfDiff', b: 1.85,
      make: function (rng) {
        const a = rng.pick([1, 2, 3]), b2 = rng.pick([-4, -2, 1, 3, 5]), c = rng.int(1, 9);
        const f = function (n) { return a * n * n + b2 * n + c; };
        const t = []; for (let i = 1; i <= 6; i++) t.push(f(i));
        return { terms: t.slice(0, 5), next: t[5], label: 'second differences are constant' };
      }
    },
    {
      /* Three operations applied in rotation. Hard, but every term follows
         from a rule fixed before the first one is emitted.

         NOTE: anything random inside this loop makes the item UNSOLVABLE.
         A previous version picked a "minus 0 or 1" per term, which produced
         sequences like 3, 3, 9, 26, 234 where 3x9 gives 27, not 26, there was
         no rule to find. Every parameter must be drawn before the loop. */
      id: 'cyclicOps', b: 2.05,
      make: function (rng) {
        const ops = rng.shuffle([
          { k: 1, c: rng.pick([3, 4, 5, 6]) },
          { k: rng.pick([2, 3]), c: 0 },
          { k: 1, c: -rng.pick([2, 3, 4]) }
        ]);
        let v = rng.int(2, 9);
        const t = [v];
        for (let i = 0; i < 7; i++) {
          const op = ops[i % 3];
          v = v * op.k + op.c;
          t.push(v);
        }
        if (t.some(function (x) { return x < 1 || x > 8000; })) return null;
        if (new Set(t).size < t.length) return null;

        /* Each operation must be DEMONSTRATED TWICE before it is needed,
           otherwise the item is ambiguous: a single 8 -> 16 step is equally
           consistent with "x2" and "+8", and the two give different answers.
           Showing seven terms puts every operation on screen twice, and two
           instances of an affine map pin down k and c uniquely -- provided the
           two inputs differ, which is what this checks. */
        if (t[0] === t[3] || t[1] === t[4] || t[2] === t[5]) return null;

        return { terms: t.slice(0, 7), next: t[7], label: 'three operations repeating in a cycle' };
      }
    },
    {
      /* Product of the two previous terms, with a constant offset */
      id: 'productOfPair', b: 2.25,
      make: function (rng) {
        const off = rng.pick([0, 0, 1, -1]);
        let a = rng.int(2, 4), b2 = rng.int(2, 5);
        const t = [a, b2];
        for (let i = 0; i < 4; i++) {
          const c = t[t.length - 1] * t[t.length - 2] + off;
          if (c > 100000) return null;
          t.push(c);
        }
        return {
          terms: t.slice(0, 5), next: t[5],
          label: 'product of the two before it' + (off ? (off > 0 ? ', plus 1' : ', minus 1') : '')
        };
      }
    }
  ];

  /* Letter series, same inductive demand, different surface form */
  function letterSeries(rng) {
    const mode = rng.pick(['step', 'twoStep', 'mirror']);
    if (mode === 'step') {
      const d = rng.pick([2, 3, 4, 5]);
      let i = rng.int(0, 8);
      const t = []; for (let k = 0; k < 6; k++) { t.push(ALPHA[(i + k * d) % 26]); }
      return { terms: t.slice(0, 5), next: t[5], b: -1.35, label: 'skip ' + d + ' letters' };
    }
    if (mode === 'twoStep') {
      const d1 = rng.int(1, 4), d2 = rng.int(1, 4);
      if (d1 === d2) return null;
      let i = rng.int(0, 6);
      const t = [];
      for (let k = 0; k < 6; k++) { t.push(ALPHA[i % 26]); i += (k % 2 === 0) ? d1 : d2; }
      return { terms: t.slice(0, 5), next: t[5], b: 0.45, label: 'alternating skips of ' + d1 + ' and ' + d2 };
    }
    const start = rng.int(0, 5), d = rng.int(1, 3);
    const t = [];
    for (let k = 0; k < 6; k++) t.push(ALPHA[(start + k * d) % 26] + ALPHA[(25 - start - k * d + 26) % 26]);
    return { terms: t.slice(0, 5), next: t[5], b: 1.30, label: 'one letter runs forward, the other backward' };
  }

  function numericDistractors(rng, terms, next) {
    const last = terms[terms.length - 1];
    const d = next - last;
    const cands = [
      next + (d === 0 ? 1 : Math.sign(d) * Math.max(1, Math.round(Math.abs(d) * 0.5))),
      next - (d === 0 ? 1 : Math.sign(d) * Math.max(1, Math.round(Math.abs(d) * 0.5))),
      last + (terms[terms.length - 1] - terms[terms.length - 2]),   // continued the previous difference
      next + rng.pick([1, 2, -1, -2]),
      next + rng.pick([3, -3, 5, -5]),
      Math.round(next * rng.pick([0.5, 1.5, 2])),
      last * 2,
      next + rng.pick([10, -10])
    ];
    return cands;
  }

  function generate(rng, tier) {
    /* tier 0..3 selects a band of the difficulty ladder */
    const useLetters = rng.chance(0.18);
    let spec = null, b = 0;

    if (useLetters) {
      for (let i = 0; i < 12 && !spec; i++) spec = letterSeries(rng);
      if (!spec) return generate(rng, tier);
      b = spec.b;
    } else {
      const bands = [
        FAMILIES.filter(function (f) { return f.b < -1.0; }),
        FAMILIES.filter(function (f) { return f.b >= -1.0 && f.b < 0.4; }),
        FAMILIES.filter(function (f) { return f.b >= 0.4 && f.b < 1.4; }),
        FAMILIES.filter(function (f) { return f.b >= 1.4; })
      ];
      const band = bands[Math.max(0, Math.min(3, tier))];
      const fam = rng.pick(band.length ? band : FAMILIES);
      for (let i = 0; i < 20 && !spec; i++) spec = fam.make(rng);
      if (!spec) return generate(rng, tier);
      b = fam.b;
    }

    const isNum = typeof spec.next === 'number';
    let raw;
    if (isNum) {
      raw = numericDistractors(rng, spec.terms, spec.next);
    } else {
      const pool = [];
      for (let i = 0; i < 14; i++) {
        if (spec.next.length === 2) {
          pool.push(ALPHA[rng.int(0, 25)] + ALPHA[rng.int(0, 25)]);
        } else {
          pool.push(ALPHA[rng.int(0, 25)]);
        }
      }
      raw = pool;
    }

    const correctOpt = { val: spec.next, key: String(spec.next) };
    const wrong = raw.map(function (v) { return { val: v, key: String(v) }; })
      .filter(function (o) { return o.key !== correctOpt.key; });

    const built = IQ.rng.assemble(rng, correctOpt, wrong, 5);

    return {
      domain: 'gf',
      type: 'series',
      b: b,
      prompt: 'What comes next in the sequence?',
      stemHtml: '<div class="series">' +
        spec.terms.map(function (t) { return '<span class="term">' + t + '</span>'; }).join('<span class="sep">,</span>') +
        '<span class="sep">,</span><span class="term term-q">?</span></div>',
      optionsHtml: built.options.map(function (o) { return '<span class="opt-num">' + o.val + '</span>'; }),
      optionClass: 'opt-text',
      answer: built.answer,
      explain: 'Rule: ' + spec.label + '.',
      meta: { rule: spec.label }
    };
  }

  function build(rng, n) {
    const out = [];
    for (let i = 0; i < n; i++) {
      const frac = n === 1 ? 0.5 : i / (n - 1);
      out.push(generate(rng, Math.min(3, Math.floor(frac * 4))));
    }
    return out;
  }

  IQ.gen = IQ.gen || {};
  IQ.gen.series = { generate: generate, build: build };
})(window.IQ);
