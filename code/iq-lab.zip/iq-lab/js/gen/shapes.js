/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   IQ LAB · Shared SVG shape renderer
   Used by the matrix and spatial subtests. Every figure is drawn
   from code, no image assets, so item pools are unlimited.
   ============================================================ */
window.IQ = window.IQ || {};

(function (IQ) {
  'use strict';

  const SHAPES = ['circle', 'triangle', 'square', 'diamond', 'pentagon', 'hexagon', 'star', 'arrow'];

  function polygonPoints(sides, cx, cy, r, startAngle) {
    const pts = [];
    for (let i = 0; i < sides; i++) {
      const a = startAngle + (i * 2 * Math.PI) / sides;
      pts.push((cx + r * Math.cos(a)).toFixed(2) + ',' + (cy + r * Math.sin(a)).toFixed(2));
    }
    return pts.join(' ');
  }

  function starPoints(cx, cy, r) {
    const pts = [];
    for (let i = 0; i < 10; i++) {
      const rad = i % 2 === 0 ? r : r * 0.44;
      const a = -Math.PI / 2 + (i * Math.PI) / 5;
      pts.push((cx + rad * Math.cos(a)).toFixed(2) + ',' + (cy + rad * Math.sin(a)).toFixed(2));
    }
    return pts.join(' ');
  }

  /* One shape primitive, centred on (cx, cy) with radius r */
  function shapePath(shape, cx, cy, r) {
    switch (shape) {
      case 'circle':
        return `<circle cx="${cx}" cy="${cy}" r="${r.toFixed(2)}"/>`;
      case 'square': {
        const s = r * 0.88;
        return `<rect x="${(cx - s).toFixed(2)}" y="${(cy - s).toFixed(2)}" width="${(s * 2).toFixed(2)}" height="${(s * 2).toFixed(2)}"/>`;
      }
      case 'diamond':
        return `<polygon points="${polygonPoints(4, cx, cy, r, -Math.PI / 2)}"/>`;
      case 'triangle':
        return `<polygon points="${polygonPoints(3, cx, cy, r, -Math.PI / 2)}"/>`;
      case 'pentagon':
        return `<polygon points="${polygonPoints(5, cx, cy, r, -Math.PI / 2)}"/>`;
      case 'hexagon':
        return `<polygon points="${polygonPoints(6, cx, cy, r, -Math.PI / 2)}"/>`;
      case 'star':
        return `<polygon points="${starPoints(cx, cy, r)}"/>`;
      case 'arrow': {
        const w = r * 0.42, h = r;
        const p = [
          [cx, cy - h], [cx + w * 1.7, cy - h * 0.05], [cx + w * 0.62, cy - h * 0.05],
          [cx + w * 0.62, cy + h], [cx - w * 0.62, cy + h], [cx - w * 0.62, cy - h * 0.05],
          [cx - w * 1.7, cy - h * 0.05]
        ].map((q) => q[0].toFixed(2) + ',' + q[1].toFixed(2)).join(' ');
        return `<polygon points="${p}"/>`;
      }
      default:
        return '';
    }
  }

  /* Slot layouts for 1..5 repeated shapes inside a 100x100 box */
  const SLOTS = {
    1: [[50, 50]],
    2: [[31, 50], [69, 50]],
    3: [[50, 28], [29, 66], [71, 66]],
    4: [[31, 31], [69, 31], [31, 69], [69, 69]],
    5: [[50, 24], [25, 44], [75, 44], [36, 76], [64, 76]]
  };

  const FILL_OPACITY = [0, 0.22, 0.58, 1];

  /* Render a matrix cell from an attribute vector.
     attrs = { shape, count, fill, rot, size } */
  function renderCell(attrs, opts) {
    opts = opts || {};
    const size = opts.size || 96;
    const slots = SLOTS[attrs.count] || SLOTS[1];
    const base = attrs.count <= 2 ? 25 : attrs.count === 3 ? 20 : 17;
    const r = base * [0.66, 0.84, 1][attrs.size == null ? 2 : attrs.size];
    const fillOp = FILL_OPACITY[attrs.fill == null ? 0 : attrs.fill];
    const rot = attrs.rot == null ? 0 : attrs.rot;

    let body = '';
    for (const [cx, cy] of slots) {
      const inner = shapePath(attrs.shape, cx, cy, r);
      body += `<g transform="rotate(${rot} ${cx} ${cy})">${inner}</g>`;
    }

    return `<svg class="fig" viewBox="0 0 100 100" width="${size}" height="${size}" aria-hidden="true">
      <g fill="currentColor" fill-opacity="${fillOp}" stroke="currentColor" stroke-width="3.2"
         stroke-linejoin="round" vector-effect="non-scaling-stroke">${body}</g>
    </svg>`;
  }

  function cellKey(a) {
    return [a.shape, a.count, a.fill, a.rot, a.size].join('|');
  }

  IQ.shapes = { SHAPES, renderCell, cellKey, shapePath, polygonPoints };
})(window.IQ);
