/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   IQ LAB · Visual-spatial reasoning (Gv)
   Two families: mental rotation of polyomino figures, and paper
   folding (fold, punch, predict the unfolded sheet).

   Both are fully procedural, so the pool is effectively infinite
   and a retest never reuses a figure.
   ============================================================ */
window.IQ = window.IQ || {};

(function (IQ) {
  'use strict';

  /* ================= Mental rotation ================= */

  function normalize(cells) {
    let minX = Infinity, minY = Infinity;
    for (let i = 0; i < cells.length; i++) {
      if (cells[i][0] < minX) minX = cells[i][0];
      if (cells[i][1] < minY) minY = cells[i][1];
    }
    return cells.map(function (c) { return [c[0] - minX, c[1] - minY]; });
  }

  function key(cells) {
    return cells.map(function (c) { return c[0] + ',' + c[1]; }).sort().join(' ');
  }

  function extent(cells) {
    let w = 0, h = 0;
    for (let i = 0; i < cells.length; i++) {
      if (cells[i][0] + 1 > w) w = cells[i][0] + 1;
      if (cells[i][1] + 1 > h) h = cells[i][1] + 1;
    }
    return [w, h];
  }

  function rot90(cells) {
    const h = extent(cells)[1];
    return normalize(cells.map(function (c) { return [h - 1 - c[1], c[0]]; }));
  }

  function rotate(cells, quarters) {
    let out = cells;
    for (let i = 0; i < ((quarters % 4) + 4) % 4; i++) out = rot90(out);
    return out;
  }

  function mirror(cells) {
    const w = extent(cells)[0];
    return normalize(cells.map(function (c) { return [w - 1 - c[0], c[1]]; }));
  }

  function canonical(cells) {
    let best = null;
    for (let q = 0; q < 4; q++) {
      const k = key(rotate(cells, q));
      if (best === null || k < best) best = k;
    }
    return best;
  }

  function randomPolyomino(rng, n) {
    const cells = [[0, 0]];
    const has = {};
    has['0,0'] = true;
    let guard = 0;
    while (cells.length < n && guard++ < 500) {
      const base = rng.pick(cells);
      const dir = rng.pick([[1, 0], [-1, 0], [0, 1], [0, -1]]);
      const c = [base[0] + dir[0], base[1] + dir[1]];
      const k = c[0] + ',' + c[1];
      if (has[k]) continue;
      // keep figures reasonably compact so they stay legible
      const test = normalize(cells.concat([c]));
      const e = extent(test);
      if (e[0] > 4 || e[1] > 4) continue;
      has[k] = true;
      cells.push(c);
    }
    return normalize(cells);
  }

  function renderPoly(cells, opts) {
    opts = opts || {};
    const px = opts.size || 96;
    const e = extent(cells);
    const grid = Math.max(e[0], e[1], 3);
    const unit = 100 / grid;
    const offX = (100 - e[0] * unit) / 2;
    const offY = (100 - e[1] * unit) / 2;
    let body = '';
    for (let i = 0; i < cells.length; i++) {
      const x = offX + cells[i][0] * unit;
      const y = offY + cells[i][1] * unit;
      body += '<rect x="' + x.toFixed(2) + '" y="' + y.toFixed(2) + '" width="' + unit.toFixed(2) +
        '" height="' + unit.toFixed(2) + '" rx="' + (unit * 0.1).toFixed(2) + '"/>';
    }
    return '<svg class="fig" viewBox="0 0 100 100" width="' + px + '" height="' + px + '" aria-hidden="true">' +
      '<g fill="currentColor" fill-opacity="0.55" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round">' +
      body + '</g></svg>';
  }

  function rotationItem(rng, tier) {
    const n = tier <= 0 ? 5 : tier === 1 ? 6 : tier === 2 ? 7 : 8;
    let base = null;
    for (let attempt = 0; attempt < 40; attempt++) {
      const cand = randomPolyomino(rng, n);
      if (cand.length < n) continue;
      if (canonical(mirror(cand)) === canonical(cand)) continue;   // achiral: mirrors would be valid answers
      base = cand;
      break;
    }
    if (!base) base = normalize([[0, 0], [1, 0], [2, 0], [0, 1], [0, 2]]);

    const quarters = rng.pick([1, 2, 3]);
    const correctCells = rotate(base, quarters);
    const baseCanon = canonical(base);

    const cands = [];
    const mir = mirror(base);
    for (let q = 0; q < 4; q++) cands.push(rotate(mir, q));            // reflections: the key distractors
    // one figure with a single cell relocated
    for (let attempt = 0; attempt < 12; attempt++) {
      const moved = base.slice();
      moved.splice(rng.int(0, moved.length - 1), 1);
      const anchor = rng.pick(moved);
      const dir = rng.pick([[1, 0], [-1, 0], [0, 1], [0, -1]]);
      const c = [anchor[0] + dir[0], anchor[1] + dir[1]];
      if (moved.some(function (m) { return m[0] === c[0] && m[1] === c[1]; })) continue;
      const cand = normalize(moved.concat([c]));
      if (canonical(cand) === baseCanon) continue;
      cands.push(rotate(cand, rng.int(0, 3)));
      break;
    }

    const correct = { cells: correctCells, key: key(correctCells) };
    const wrong = cands
      .map(function (c) { return { cells: c, key: key(c) }; })
      .filter(function (o) { return canonical(o.cells) !== baseCanon; });

    const built = IQ.rng.assemble(rng, correct, wrong, 5);

    const b = -1.30 + 0.42 * (n - 5) + (quarters === 2 ? 0.30 : 0.55);

    return {
      domain: 'gv',
      type: 'rotation',
      b: b,
      prompt: 'Which figure is the <em>same shape</em> as the target, just turned? Flipped (mirror-image) figures do not count.',
      stemHtml: '<div class="target-fig">' + renderPoly(base, { size: 120 }) + '<span class="target-tag">target</span></div>',
      optionsHtml: built.options.map(function (o) { return renderPoly(o.cells, { size: 78 }); }),
      optionClass: 'opt-fig',
      answer: built.answer,
      meta: { cells: n, quarters: quarters }
    };
  }

  /* ================= Paper folding ================= */

  const N = 4;

  function renderSheet(holes, opts) {
    opts = opts || {};
    const px = opts.size || 96;
    const unit = 88 / N;
    const off = 6;
    let body = '<rect x="' + off + '" y="' + off + '" width="' + (unit * N) + '" height="' + (unit * N) +
      '" rx="3" fill="currentColor" fill-opacity="0.07" stroke="currentColor" stroke-width="2.2"/>';
    for (let i = 1; i < N; i++) {
      const p = off + i * unit;
      body += '<line x1="' + p + '" y1="' + off + '" x2="' + p + '" y2="' + (off + unit * N) +
        '" stroke="currentColor" stroke-width="0.7" stroke-opacity="0.25"/>';
      body += '<line x1="' + off + '" y1="' + p + '" x2="' + (off + unit * N) + '" y2="' + p +
        '" stroke="currentColor" stroke-width="0.7" stroke-opacity="0.25"/>';
    }
    for (const h of holes) {
      const parts = h.split(',');
      const cx = off + (Number(parts[0]) + 0.5) * unit;
      const cy = off + (Number(parts[1]) + 0.5) * unit;
      body += '<circle cx="' + cx.toFixed(2) + '" cy="' + cy.toFixed(2) + '" r="' + (unit * 0.27).toFixed(2) +
        '" fill="var(--bg)" stroke="currentColor" stroke-width="2.2"/>';
    }
    return '<svg class="fig" viewBox="0 0 100 100" width="' + px + '" height="' + px + '" aria-hidden="true">' +
      '<g color="currentColor">' + body + '</g></svg>';
  }

  /* One step of the fold diagram: the paper as it is BEFORE this fold,
     with the crease dashed and an arrow showing which flap moves. */
  function renderFoldStep(region, fold, size) {
    const unit = 88 / N, off = 6;
    const x = off + region.x0 * unit, y = off + region.y0 * unit;
    const w = (region.x1 - region.x0 + 1) * unit, h = (region.y1 - region.y0 + 1) * unit;
    let body = '<rect x="' + x.toFixed(2) + '" y="' + y.toFixed(2) + '" width="' + w.toFixed(2) +
      '" height="' + h.toFixed(2) + '" rx="3" fill="currentColor" fill-opacity="0.07" stroke="currentColor" stroke-width="2.2"/>';

    let ax1, ay1, ax2, ay2;
    if (fold.axis === 'v') {
      const cx = x + w / 2;
      body += '<line x1="' + cx.toFixed(2) + '" y1="' + y.toFixed(2) + '" x2="' + cx.toFixed(2) + '" y2="' + (y + h).toFixed(2) +
        '" stroke="currentColor" stroke-width="2" stroke-dasharray="4 3" stroke-opacity="0.75"/>';
      const cy = y + h / 2;
      if (fold.dir === 'L') { ax1 = x + w * 0.22; ax2 = x + w * 0.78; }
      else { ax1 = x + w * 0.78; ax2 = x + w * 0.22; }
      ay1 = cy; ay2 = cy;
    } else {
      const cy = y + h / 2;
      body += '<line x1="' + x.toFixed(2) + '" y1="' + cy.toFixed(2) + '" x2="' + (x + w).toFixed(2) + '" y2="' + cy.toFixed(2) +
        '" stroke="currentColor" stroke-width="2" stroke-dasharray="4 3" stroke-opacity="0.75"/>';
      const cx = x + w / 2;
      if (fold.dir === 'T') { ay1 = y + h * 0.22; ay2 = y + h * 0.78; }
      else { ay1 = y + h * 0.78; ay2 = y + h * 0.22; }
      ax1 = cx; ax2 = cx;
    }
    body += '<defs><marker id="ar" markerWidth="6" markerHeight="6" refX="4" refY="3" orient="auto">' +
      '<path d="M0,0 L6,3 L0,6 z" fill="var(--accent)"/></marker></defs>' +
      '<line x1="' + ax1.toFixed(2) + '" y1="' + ay1.toFixed(2) + '" x2="' + ax2.toFixed(2) + '" y2="' + ay2.toFixed(2) +
      '" stroke="var(--accent)" stroke-width="2.4" marker-end="url(#ar)"/>';

    return '<svg class="fig" viewBox="0 0 100 100" width="' + size + '" height="' + size + '" aria-hidden="true">' + body + '</svg>';
  }

  function foldingItem(rng, tier) {
    const nFolds = tier <= 0 ? 1 : tier === 1 ? 2 : tier === 2 ? 2 : 3;
    const nHoles = tier >= 2 && rng.chance(0.5) ? 2 : 1;

    let region = { x0: 0, x1: N - 1, y0: 0, y1: N - 1 };
    const folds = [];
    const stepsHtml = [];

    for (let i = 0; i < nFolds; i++) {
      const w = region.x1 - region.x0 + 1, h = region.y1 - region.y0 + 1;
      const canV = w % 2 === 0 && w > 1;
      const canH = h % 2 === 0 && h > 1;
      if (!canV && !canH) break;
      const axis = canV && canH ? rng.pick(['v', 'h']) : (canV ? 'v' : 'h');
      const dir = axis === 'v' ? rng.pick(['L', 'R']) : rng.pick(['T', 'B']);
      const fold = { axis: axis, dir: dir };

      stepsHtml.push(renderFoldStep(region, fold, 78));

      if (axis === 'v') {
        const mid = region.x0 + w / 2;
        fold.mid = mid;
        region = dir === 'L'
          ? { x0: mid, x1: region.x1, y0: region.y0, y1: region.y1 }
          : { x0: region.x0, x1: mid - 1, y0: region.y0, y1: region.y1 };
      } else {
        const mid = region.y0 + h / 2;
        fold.mid = mid;
        region = dir === 'T'
          ? { x0: region.x0, x1: region.x1, y0: mid, y1: region.y1 }
          : { x0: region.x0, x1: region.x1, y0: region.y0, y1: mid - 1 };
      }
      folds.push(fold);
    }

    /* Punch holes inside the folded region */
    const slots = [];
    for (let x = region.x0; x <= region.x1; x++) {
      for (let y = region.y0; y <= region.y1; y++) slots.push(x + ',' + y);
    }
    const punched = rng.sample(slots, Math.min(nHoles, slots.length));

    /* Unfold: mirror the hole set back across each crease, last fold first */
    function unfold(holeList, foldList) {
      let set = holeList.slice();
      for (let i = foldList.length - 1; i >= 0; i--) {
        const f = foldList[i];
        const added = [];
        for (let j = 0; j < set.length; j++) {
          const p = set[j].split(',').map(Number);
          const q = f.axis === 'v' ? [2 * f.mid - 1 - p[0], p[1]] : [p[0], 2 * f.mid - 1 - p[1]];
          added.push(q[0] + ',' + q[1]);
        }
        const seen = {};
        set = set.concat(added).filter(function (k) {
          if (seen[k]) return false;
          seen[k] = true;
          return true;
        });
      }
      return set.sort();
    }

    const correctHoles = unfold(punched, folds);
    const correct = { holes: correctHoles, key: correctHoles.join(' ') };

    /* Distractors are the mistakes people actually make */
    const wrongSets = [];
    // stopped unfolding one crease early
    if (folds.length > 1) wrongSets.push(unfold(punched, folds.slice(0, folds.length - 1)));
    // mirrored across the wrong axis on the last crease
    if (folds.length) {
      const flipped = folds.slice();
      const last = Object.assign({}, flipped[flipped.length - 1]);
      last.axis = last.axis === 'v' ? 'h' : 'v';
      last.mid = last.axis === 'v' ? N / 2 : N / 2;
      flipped[flipped.length - 1] = last;
      wrongSets.push(unfold(punched, flipped));
    }
    // the punched positions alone, never unfolded
    wrongSets.push(punched.slice().sort());
    // correct set shifted
    wrongSets.push(correctHoles.map(function (k) {
      const p = k.split(',').map(Number);
      return Math.min(N - 1, p[0] + 1) + ',' + p[1];
    }).filter(function (v, i, a) { return a.indexOf(v) === i; }).sort());
    // correct set with one hole dropped
    if (correctHoles.length > 1) wrongSets.push(correctHoles.slice(1));
    // correct set with an extra hole
    const extra = correctHoles.slice();
    for (let guard = 0; guard < 20; guard++) {
      const k = rng.int(0, N - 1) + ',' + rng.int(0, N - 1);
      if (extra.indexOf(k) < 0) { extra.push(k); break; }
    }
    wrongSets.push(extra.sort());

    const wrong = wrongSets
      .map(function (h) { return { holes: h, key: h.join(' ') }; })
      .filter(function (o) { return o.key !== correct.key && o.holes.length > 0; });

    const built = IQ.rng.assemble(rng, correct, wrong, 5);
    const b = -1.30 + 0.95 * (folds.length - 1) + (nHoles === 2 ? 0.30 : 0);

    const stemHtml =
      '<div class="fold-strip">' +
      stepsHtml.map(function (s, i) {
        return '<div class="fold-step">' + s + '<span class="fold-lbl">fold ' + (i + 1) + '</span></div>' +
          '<span class="fold-arrow">&rarr;</span>';
      }).join('') +
      '<div class="fold-step">' + renderSheet(punched, { size: 78 }) + '<span class="fold-lbl">punch</span></div>' +
      '</div>';

    return {
      domain: 'gv',
      type: 'folding',
      b: b,
      prompt: 'The square sheet is folded as shown, then ' + (nHoles === 1 ? 'a hole is' : 'two holes are') +
        ' punched through. How does the sheet look unfolded?',
      stemHtml: stemHtml,
      optionsHtml: built.options.map(function (o) { return renderSheet(o.holes, { size: 78 }); }),
      optionClass: 'opt-fig',
      answer: built.answer,
      meta: { folds: folds.length, holes: nHoles }
    };
  }

  function build(rng, n) {
    const out = [];
    for (let i = 0; i < n; i++) {
      const frac = n === 1 ? 0.5 : i / (n - 1);
      const tier = Math.min(3, Math.floor(frac * 4));
      out.push(i % 2 === 0 ? rotationItem(rng, tier) : foldingItem(rng, tier));
    }
    return out;
  }

  IQ.gen = IQ.gen || {};
  IQ.gen.spatial = { build: build, rotationItem: rotationItem, foldingItem: foldingItem };
})(window.IQ);
