/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   IQ LAB · Processing speed (Gs), symbol search
   ------------------------------------------------------------
   Two target symbols, then a search row of five. Decide whether
   either target appears in the row. Ninety seconds, as many rows
   as you can. Scored correct minus incorrect, which is how the
   equivalent clinical subtest is scored: it stops guessing from
   paying, so the score reflects speed AND accuracy together.
   ============================================================ */
window.IQ = window.IQ || {};

(function (IQ) {
  'use strict';

  const S = IQ.shapes;
  const FILLS = [0, 2, 3];

  /* Distinct quarter-turns per shape. A rotated square is the same square, so
     including rot 1..3 for it would put two identical-looking symbols in the
     same row and make "is the target present?" unanswerable. */
  const ROT_STATES = [1, 4, 1, 1, 4, 2, 4, 4];

  /* Enumerate every visually distinct symbol once */
  const POOL = (function () {
    const out = [];
    for (let shape = 0; shape < 8; shape++) {
      for (let f = 0; f < FILLS.length; f++) {
        const stride = 4 / ROT_STATES[shape];
        for (let k = 0; k < ROT_STATES[shape]; k++) {
          out.push({ shape: shape, fill: FILLS[f], rot: k * stride });
        }
      }
    }
    return out;
  })();

  function symbolKey(s) { return s.shape + '-' + s.fill + '-' + s.rot; }

  function randomSymbol(rng) { return rng.pick(POOL); }

  function renderSymbol(sym, size) {
    return S.renderCell({
      shape: S.SHAPES[sym.shape],
      count: 1,
      fill: sym.fill,
      rot: sym.rot * 90,
      size: 2
    }, { size: size || 46 });
  }

  function makeRow(rng) {
    const present = rng.chance(0.5);
    const used = {};
    const targets = [];
    while (targets.length < 2) {
      const s = randomSymbol(rng);
      if (used[symbolKey(s)]) continue;
      used[symbolKey(s)] = true;
      targets.push(s);
    }

    const search = [];
    while (search.length < 5) {
      const s = randomSymbol(rng);
      if (used[symbolKey(s)]) continue;
      used[symbolKey(s)] = true;
      search.push(s);
    }

    if (present) {
      // swap one search slot for one of the targets
      search[rng.int(0, 4)] = rng.pick(targets);
    }

    return { targets: targets, search: search, present: present };
  }

  function mount(el, opts, done) {
    const rng = opts.rng;
    const seconds = opts.seconds || 90;

    let correct = 0, incorrect = 0, attempted = 0;
    let row = null;
    let running = true;
    let tick = null;
    let endAt = 0;
    const log = [];
    let rowShownAt = 0;

    el.innerHTML =
      '<div class="speed-task">' +
      '  <div class="speed-head">' +
      '    <div class="speed-timer"><span id="spdTime">' + seconds + '</span>s</div>' +
      '    <div class="speed-count">Answered <span id="spdCount">0</span></div>' +
      '  </div>' +
      '  <div class="speed-board" id="spdBoard"></div>' +
      '  <div class="speed-keys">' +
      '    <button class="btn btn-answer" data-ans="yes">Yes &mdash; a target is there <kbd>&larr;</kbd></button>' +
      '    <button class="btn btn-answer" data-ans="no">No &mdash; none of them <kbd>&rarr;</kbd></button>' +
      '  </div>' +
      '  <p class="task-hint">Wrong answers subtract from your score, so do not guess blindly.</p>' +
      '</div>';

    const board = el.querySelector('#spdBoard');
    const timeEl = el.querySelector('#spdTime');
    const countEl = el.querySelector('#spdCount');

    function draw() {
      row = makeRow(rng);
      rowShownAt = performance.now();
      board.innerHTML =
        '<div class="speed-targets">' +
        row.targets.map(function (s) { return '<div class="sym">' + renderSymbol(s, 44) + '</div>'; }).join('') +
        '</div>' +
        '<div class="speed-divider"></div>' +
        '<div class="speed-search">' +
        row.search.map(function (s) { return '<div class="sym">' + renderSymbol(s, 44) + '</div>'; }).join('') +
        '</div>';
    }

    function answer(saidYes) {
      if (!running || !row) return;
      const ok = saidYes === row.present;
      attempted++;
      if (ok) correct++; else incorrect++;
      log.push({ ok: ok, rt: Math.round(performance.now() - rowShownAt), present: row.present });
      countEl.textContent = String(attempted);
      board.classList.add(ok ? 'flash-ok' : 'flash-bad');
      setTimeout(function () { board.classList.remove('flash-ok', 'flash-bad'); }, 110);
      draw();
    }

    function onKey(e) {
      if (e.key === 'ArrowLeft') { e.preventDefault(); answer(true); }
      else if (e.key === 'ArrowRight') { e.preventDefault(); answer(false); }
    }

    el.querySelectorAll('[data-ans]').forEach(function (btn) {
      btn.addEventListener('click', function () { answer(btn.dataset.ans === 'yes'); });
    });
    document.addEventListener('keydown', onKey);

    function finish() {
      running = false;
      clearInterval(tick);
      document.removeEventListener('keydown', onKey);
      const rts = log.filter(function (l) { return l.ok; }).map(function (l) { return l.rt; }).sort(function (a, b) { return a - b; });
      const median = rts.length ? rts[Math.floor(rts.length / 2)] : null;
      done({ raw: correct - incorrect, correct: correct, incorrect: incorrect, attempted: attempted, medianRt: median, seconds: seconds });
    }

    endAt = Date.now() + seconds * 1000;
    tick = setInterval(function () {
      const left = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
      timeEl.textContent = String(left);
      if (left <= 0) finish();
    }, 200);

    draw();

    return function cleanup() {
      running = false;
      clearInterval(tick);
      document.removeEventListener('keydown', onKey);
    };
  }

  IQ.gen = IQ.gen || {};
  IQ.gen.speed = { mount: mount };
})(window.IQ);
