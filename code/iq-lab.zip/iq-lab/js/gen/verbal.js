/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   IQ LAB · Verbal reasoning (crystallised ability, Gc)
   ------------------------------------------------------------
   Unlike the figural subtests, verbal items cannot be generated
   procedurally without becoming nonsense, so this is a curated
   bank. Each item carries a hand-assigned difficulty in logits and
   items are sampled without replacement per sitting, with the pool
   large enough that consecutive sittings rarely overlap much.

   Row format:
     analogy:  [A, B, C, correct, d1, d2, d3, d4, b]
     vocab:    [word, correct, d1, d2, d3, d4, b]
     oddOne:   [[members...], correctIndex, b]
   ============================================================ */
window.IQ = window.IQ || {};

(function (IQ) {
  'use strict';

  const ANALOGIES = [
    // --- easy ---
    ['hot', 'cold', 'day', 'night', 'morning', 'sunlight', 'warm', 'week', -1.90],
    ['puppy', 'dog', 'kitten', 'cat', 'lion', 'fur', 'pet', 'mouse', -1.80],
    ['big', 'small', 'tall', 'short', 'wide', 'heavy', 'high', 'long', -1.85],
    ['fish', 'swim', 'bird', 'fly', 'nest', 'feather', 'sing', 'perch', -1.75],
    ['finger', 'hand', 'toe', 'foot', 'leg', 'shoe', 'nail', 'ankle', -1.70],
    ['doctor', 'hospital', 'teacher', 'school', 'student', 'lesson', 'book', 'desk', -1.60],
    ['glove', 'hand', 'sock', 'foot', 'shoe', 'wool', 'leg', 'toe', -1.55],
    ['bird', 'nest', 'bee', 'hive', 'honey', 'flower', 'sting', 'swarm', -1.50],
    ['pen', 'write', 'knife', 'cut', 'sharp', 'blade', 'kitchen', 'metal', -1.50],
    ['book', 'read', 'song', 'listen', 'sing', 'music', 'radio', 'loud', -1.40],
    ['wheel', 'car', 'wing', 'aeroplane', 'bird', 'sky', 'feather', 'engine', -1.30],
    ['hungry', 'eat', 'tired', 'sleep', 'rest', 'yawn', 'bed', 'night', -1.30],
    ['leaf', 'tree', 'petal', 'flower', 'stem', 'garden', 'root', 'seed', -1.20],
    ['water', 'thirst', 'food', 'hunger', 'taste', 'meal', 'appetite', 'energy', -1.15],
    ['circle', 'round', 'square', 'angular', 'flat', 'wide', 'solid', 'equal', -1.00],

    // --- moderate ---
    ['cub', 'bear', 'foal', 'horse', 'stable', 'saddle', 'mare', 'donkey', -0.80],
    ['hive', 'bee', 'colony', 'ant', 'insect', 'queen', 'tunnel', 'swarm', -0.70],
    ['thermometer', 'temperature', 'scale', 'weight', 'height', 'pressure', 'balance', 'mass', -0.70],
    ['island', 'ocean', 'oasis', 'desert', 'sand', 'water', 'palm', 'camel', -0.60],
    ['author', 'novel', 'composer', 'symphony', 'orchestra', 'piano', 'concert', 'melody', -0.50],
    ['famine', 'food', 'drought', 'water', 'rain', 'heat', 'crops', 'desert', -0.40],
    ['anchor', 'ship', 'root', 'plant', 'soil', 'leaf', 'branch', 'seed', -0.40],
    ['optimist', 'hopeful', 'pessimist', 'gloomy', 'quiet', 'realistic', 'angry', 'cautious', -0.30],
    ['sculptor', 'clay', 'poet', 'words', 'paper', 'rhyme', 'verse', 'ideas', -0.25],
    ['novice', 'expert', 'seedling', 'tree', 'garden', 'soil', 'flower', 'branch', -0.20],
    ['clock', 'time', 'odometer', 'distance', 'speed', 'fuel', 'engine', 'direction', -0.10],
    ['drizzle', 'downpour', 'breeze', 'gale', 'cloud', 'storm', 'chill', 'draught', -0.10],
    ['verdict', 'jury', 'diagnosis', 'doctor', 'patient', 'illness', 'hospital', 'symptom', 0.00],
    ['medicine', 'illness', 'law', 'crime', 'court', 'police', 'justice', 'prison', 0.10],
    ['cartographer', 'map', 'architect', 'blueprint', 'building', 'design', 'city', 'bridge', 0.10],
    ['whisper', 'shout', 'glimpse', 'stare', 'blink', 'glance', 'watch', 'squint', 0.20],
    ['prologue', 'book', 'overture', 'opera', 'stage', 'singer', 'finale', 'score', 0.25],

    // --- hard ---
    ['lexicon', 'words', 'atlas', 'maps', 'countries', 'travel', 'globe', 'routes', 0.40],
    ['prune', 'branches', 'edit', 'text', 'author', 'grammar', 'publish', 'shorten', 0.50],
    ['penicillin', 'infection', 'antidote', 'poison', 'illness', 'venom', 'cure', 'snake', 0.55],
    ['tributary', 'river', 'twig', 'branch', 'leaf', 'trunk', 'forest', 'root', 0.60],
    ['scaffold', 'building', 'outline', 'essay', 'paragraph', 'author', 'library', 'chapter', 0.65],
    ['herald', 'announce', 'sentinel', 'guard', 'march', 'salute', 'patrol', 'defend', 0.70],
    ['arid', 'moisture', 'barren', 'life', 'soil', 'harvest', 'heat', 'stone', 0.75],
    ['ostracise', 'group', 'exile', 'country', 'prison', 'family', 'citizen', 'border', 0.75],
    ['placate', 'anger', 'assuage', 'grief', 'joy', 'memory', 'sorrow', 'comfort', 0.80],
    ['cacophony', 'sound', 'eyesore', 'sight', 'colour', 'painting', 'noise', 'blindness', 0.85],
    ['quarantine', 'disease', 'embargo', 'trade', 'ships', 'war', 'tariff', 'border', 0.90],
    ['frugal', 'miserly', 'confident', 'arrogant', 'timid', 'wealthy', 'careful', 'generous', 0.95],
    ['gullible', 'deceived', 'docile', 'led', 'trained', 'obeyed', 'tamed', 'ignored', 1.00],
    ['crescendo', 'loudness', 'ascent', 'height', 'speed', 'mountain', 'descent', 'distance', 1.05],
    ['maverick', 'conform', 'hermit', 'socialise', 'travel', 'speak', 'believe', 'withdraw', 1.10],
    ['ephemeral', 'permanence', 'opaque', 'clarity', 'colour', 'darkness', 'weight', 'shadow', 1.15],
    ['filibuster', 'delay', 'subterfuge', 'deceive', 'attack', 'persuade', 'conceal', 'retreat', 1.20],

    // --- very hard ---
    ['iconoclast', 'tradition', 'heretic', 'doctrine', 'church', 'prayer', 'scripture', 'ritual', 1.40],
    ['propitiate', 'hostility', 'mollify', 'resentment', 'affection', 'memory', 'ambition', 'silence', 1.50],
    ['calumny', 'reputation', 'vandalism', 'property', 'law', 'wealth', 'privacy', 'peace', 1.60],
    ['ersatz', 'genuine', 'spurious', 'authentic', 'expensive', 'ancient', 'fragile', 'common', 1.65],
    ['lugubrious', 'mournful', 'ebullient', 'cheerful', 'talkative', 'careless', 'graceful', 'restless', 1.70],
    ['ineffable', 'express', 'intractable', 'manage', 'measure', 'explain', 'imagine', 'endure', 1.75],
    ['panegyric', 'praise', 'diatribe', 'criticism', 'humour', 'apology', 'instruction', 'sorrow', 1.85],
    ['sinecure', 'work', 'windfall', 'effort', 'money', 'planning', 'luck', 'talent', 1.90],
    ['inchoate', 'formed', 'nascent', 'developed', 'noticed', 'written', 'proven', 'accepted', 1.95],
    ['peccadillo', 'sin', 'quibble', 'objection', 'argument', 'apology', 'insult', 'question', 2.05]
  ];

  const VOCAB = [
    ['enormous', 'extremely large', 'slightly unusual', 'poorly made', 'very fast', 'clearly visible', -1.85],
    ['conceal', 'to hide', 'to repair', 'to discover', 'to enlarge', 'to announce', -1.75],
    ['vacant', 'empty', 'noisy', 'broken', 'crowded', 'distant', -1.55],
    ['reluctant', 'unwilling', 'exhausted', 'dishonest', 'forgetful', 'impatient', -1.40],
    ['brittle', 'easily broken', 'very heavy', 'sharply bent', 'newly made', 'tightly sealed', -1.25],
    ['candid', 'honest and direct', 'quietly amused', 'carefully hidden', 'brightly lit', 'deeply worried', -0.55],
    ['meticulous', 'extremely careful about detail', 'unusually slow', 'overly generous', 'easily annoyed', 'highly competitive', -0.40],
    ['prudent', 'showing careful good judgement', 'openly critical', 'physically strong', 'socially awkward', 'financially poor', -0.25],
    ['ambiguous', 'open to more than one meaning', 'entirely false', 'extremely detailed', 'spoken too quietly', 'written by hand', -0.10],
    ['tenacious', 'holding on firmly and persistently', 'moving very quietly', 'easily discouraged', 'rich in flavour', 'unusually thin', 0.10],
    ['arbitrary', 'based on whim rather than reason', 'agreed by everyone', 'decided by a court', 'repeated regularly', 'kept deliberately secret', 0.30],
    ['plausible', 'seeming reasonable or probable', 'openly praised', 'legally binding', 'easily measured', 'widely disliked', 0.35],
    ['ubiquitous', 'present everywhere at once', 'extremely rare', 'strangely shaped', 'no longer used', 'growing quickly', 0.60],
    ['tacit', 'understood without being stated', 'stated very loudly', 'written in law', 'proven by evidence', 'agreed reluctantly', 0.80],
    ['salient', 'most noticeable or important', 'slightly salty', 'kept in reserve', 'happening slowly', 'placed at the end', 0.90],
    ['austere', 'severely plain and without comfort', 'bitterly cold', 'openly hostile', 'ancient in origin', 'richly decorated', 1.00],
    ['pragmatic', 'concerned with practical results', 'guided by strict rules', 'driven by emotion', 'unable to decide', 'based on tradition', 1.05],
    ['esoteric', 'understood by only a small group', 'repeated very often', 'written in verse', 'harmful if swallowed', 'formed underground', 1.15],
    ['intransigent', 'refusing to compromise', 'travelling constantly', 'lacking transparency', 'changing frequently', 'easily persuaded', 1.30],
    ['equivocate', 'to speak vaguely to avoid committing', 'to argue loudly', 'to divide equally', 'to repeat exactly', 'to agree at once', 1.45],
    ['perfunctory', 'done routinely and without care', 'finished ahead of time', 'performed in public', 'carried out perfectly', 'repeated for practice', 1.60],
    ['obfuscate', 'to make deliberately unclear', 'to polish until bright', 'to accuse falsely', 'to cut into pieces', 'to fall out of use', 1.70],
    ['quotidian', 'ordinary and everyday', 'divided into quarters', 'quoted from a source', 'occurring once a year', 'settled by a quota', 1.80],
    ['anodyne', 'unlikely to offend anyone', 'painfully sharp', 'chemically unstable', 'spoken in anger', 'made of metal', 1.90],
    ['recondite', 'dealing with obscure, difficult subject matter', 'rebuilt after damage', 'agreed in secret', 'returned to a sender', 'hidden underground', 2.00],
    ['sedulous', 'showing dedicated, persistent diligence', 'quietly deceitful', 'smoothly flattering', 'slow to anger', 'seated comfortably', 2.10]
  ];

  const ODD_ONE_OUT = [
    [['violin', 'cello', 'flute', 'viola', 'double bass'], 2, -1.40],
    [['rose', 'tulip', 'daisy', 'oak', 'lily'], 3, -1.30],
    [['ruby', 'emerald', 'sapphire', 'granite', 'diamond'], 3, -1.15],
    [['placid', 'serene', 'tranquil', 'turbulent', 'calm'], 3, -0.55],
    [['kilogram', 'litre', 'metre', 'second', 'temperature'], 4, 0.20],
    [['amble', 'saunter', 'stroll', 'sprint', 'meander'], 3, 0.30],
    [['lieutenant', 'colonel', 'sergeant', 'admiral', 'corporal'], 3, 0.55],
    [['Mercury', 'Venus', 'Earth', 'Ceres', 'Mars'], 3, 0.90],
    [['allegro', 'adagio', 'presto', 'sonata', 'andante'], 3, 1.05],
    [['hypothesis', 'theory', 'conjecture', 'axiom', 'surmise'], 3, 1.40]
  ];

  function analogyItem(rng, row) {
    const correct = { val: row[3], key: row[3] };
    const wrong = [row[4], row[5], row[6], row[7]].map(function (w) { return { val: w, key: w }; });
    const built = IQ.rng.assemble(rng, correct, wrong, 5);
    return {
      domain: 'gc',
      type: 'analogy',
      b: row[8],
      prompt: 'Complete the analogy.',
      stemHtml: '<div class="analogy"><span class="w">' + row[0] + '</span><span class="rel">is to</span>' +
        '<span class="w">' + row[1] + '</span><span class="rel">as</span><span class="w">' + row[2] +
        '</span><span class="rel">is to</span><span class="w w-q">?</span></div>',
      optionsHtml: built.options.map(function (o) { return '<span class="opt-line">' + o.val + '</span>'; }),
      optionClass: 'opt-text opt-wrap',
      answer: built.answer
    };
  }

  function vocabItem(rng, row) {
    const correct = { val: row[1], key: row[1] };
    const wrong = [row[2], row[3], row[4], row[5]].map(function (w) { return { val: w, key: w }; });
    const built = IQ.rng.assemble(rng, correct, wrong, 5);
    return {
      domain: 'gc',
      type: 'vocab',
      b: row[6],
      prompt: 'Which choice is closest in meaning?',
      stemHtml: '<div class="analogy"><span class="w w-lead">' + row[0] + '</span></div>',
      optionsHtml: built.options.map(function (o) { return '<span class="opt-line">' + o.val + '</span>'; }),
      optionClass: 'opt-text opt-stack',
      answer: built.answer
    };
  }

  function oddItem(rng, row) {
    const members = row[0], idx = row[1];
    const correctWord = members[idx];
    const shuffled = rng.shuffle(members.slice());
    return {
      domain: 'gc',
      type: 'oddOne',
      b: row[2],
      prompt: 'Which one does not belong with the others?',
      stemHtml: '',
      optionsHtml: shuffled.map(function (w) { return '<span class="opt-line">' + w + '</span>'; }),
      optionClass: 'opt-text opt-wrap',
      fixedOrder: true,
      answer: shuffled.indexOf(correctWord)
    };
  }

  /* Sample n items spread across the difficulty ladder, without repeats */
  function build(rng, n) {
    const pool = []
      .concat(ANALOGIES.map(function (r) { return { b: r[8], make: function (g) { return analogyItem(g, r); } }; }))
      .concat(VOCAB.map(function (r) { return { b: r[6], make: function (g) { return vocabItem(g, r); } }; }))
      .concat(ODD_ONE_OUT.map(function (r) { return { b: r[2], make: function (g) { return oddItem(g, r); } }; }));

    const out = [];
    const used = {};
    for (let i = 0; i < n; i++) {
      const frac = n === 1 ? 0.5 : i / (n - 1);
      // target difficulty sweeps the ladder from easy to hard
      const target = -1.9 + frac * 3.9;
      const candidates = pool
        .map(function (p, idx) { return { p: p, idx: idx, d: Math.abs(p.b - target) }; })
        .filter(function (c) { return !used[c.idx]; })
        .sort(function (a, b) { return a.d - b.d; })
        .slice(0, 5);
      if (!candidates.length) break;
      const chosen = rng.pick(candidates);
      used[chosen.idx] = true;
      out.push(chosen.p.make(rng));
    }
    return out;
  }

  IQ.gen = IQ.gen || {};
  IQ.gen.verbal = { build: build, poolSize: ANALOGIES.length + VOCAB.length + ODD_ONE_OUT.length };
})(window.IQ);
