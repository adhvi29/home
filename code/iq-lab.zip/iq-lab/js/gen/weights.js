/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   IQ LAB · Figure Weights (quantitative reasoning)
   ------------------------------------------------------------
   Balance scales establish relationships between objects; you work
   out what balances the last one. Modelled on the WAIS-IV subtest
   of the same name, which loads on the Fluid Reasoning index.

   The thing that makes this hard to generate correctly is
   SOLVABILITY. Building equations from secret weights guarantees
   they are TRUE, but not that they are SUFFICIENT, the premises
   must pin down every ratio, or the item has more than one
   defensible answer.

   Each premise is a vector v where v[i] = (count left) - (count
   right), and the premise holds when v . w = 0. The weights that
   satisfy every premise form the null space of that matrix. If the
   null space is one-dimensional, the only freedom left is overall
   scale, so every RATIO is determined and the item has exactly one
   answer. So: keep adding independent premises until the rank of
   the matrix reaches n-1, and reject the item otherwise.
   ============================================================ */
window.IQ = window.IQ || {};

(function (IQ) {
  'use strict';

  const S = IQ.shapes;
  const OBJECTS = ['circle', 'triangle', 'square', 'star', 'hexagon'];

  /* ---------- linear algebra over the premise vectors ---------- */

  function rank(rows, n) {
    if (!rows.length) return 0;
    const m = rows.map(function (r) { return r.slice(); });
    let rk = 0;
    for (let col = 0; col < n && rk < m.length; col++) {
      let piv = -1, best = 1e-9;
      for (let r = rk; r < m.length; r++) {
        if (Math.abs(m[r][col]) > best) { best = Math.abs(m[r][col]); piv = r; }
      }
      if (piv < 0) continue;
      const tmp = m[rk]; m[rk] = m[piv]; m[piv] = tmp;
      const p = m[rk][col];
      for (let c = col; c < n; c++) m[rk][c] /= p;
      for (let r = 0; r < m.length; r++) {
        if (r === rk) continue;
        const f = m[r][col];
        if (Math.abs(f) < 1e-12) continue;
        for (let c = col; c < n; c++) m[r][c] -= f * m[rk][c];
      }
      rk++;
    }
    return rk;
  }

  /* ---------- multiset helpers ---------- */

  /* Every multiset of 1..maxSize objects drawn from n types */
  function allMultisets(n, maxSize) {
    const out = [];
    const rec = function (start, counts, left) {
      const total = counts.reduce(function (a, b) { return a + b; }, 0);
      if (total >= 1) out.push(counts.slice());
      if (left === 0) return;
      for (let i = start; i < n; i++) {
        counts[i]++;
        rec(i, counts, left - 1);
        counts[i]--;
      }
    };
    rec(0, new Array(n).fill(0), maxSize);
    return out;
  }

  function weightOf(counts, w) {
    let t = 0;
    for (let i = 0; i < counts.length; i++) t += counts[i] * w[i];
    return t;
  }

  function sizeOf(counts) {
    return counts.reduce(function (a, b) { return a + b; }, 0);
  }

  function sameSet(a, b) {
    for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
    return true;
  }

  function disjoint(a, b) {
    for (let i = 0; i < a.length; i++) if (a[i] > 0 && b[i] > 0) return false;
    return true;
  }

  function msKey(counts) { return counts.join(','); }

  /* ---------- item construction ---------- */

  function pairsOfEqualWeight(sets, w) {
    const byWeight = {};
    sets.forEach(function (s) {
      const k = weightOf(s, w);
      (byWeight[k] = byWeight[k] || []).push(s);
    });
    const out = [];
    Object.keys(byWeight).forEach(function (k) {
      const group = byWeight[k];
      for (let i = 0; i < group.length; i++) {
        for (let j = 0; j < group.length; j++) {
          if (i === j) continue;
          if (!disjoint(group[i], group[j])) continue;
          out.push({ left: group[i], right: group[j] });
        }
      }
    });
    return out;
  }

  function buildItem(rng, n, maxSide, qSide) {
    // secret weights: distinct small integers
    const w = rng.sample([1, 2, 3, 4, 5, 6, 8], n).sort(function (a, b) { return a - b; });

    const sets = allMultisets(n, maxSide);
    const candidates = pairsOfEqualWeight(sets, w);
    if (candidates.length < 2) return null;

    /* The question may use bigger pans than the premises, so that a two-object
       item can still ask something real: given 3 circles = 1 triangle, asking
       for 2 triangles requires scaling the relation rather than reading it
       straight off. Without this, every possible question just restates a
       premise and the tier never produces an item. */
    const qSets = qSide > maxSide ? allMultisets(n, qSide) : sets;
    const qPairs = qSide > maxSide ? pairsOfEqualWeight(qSets, w) : candidates;

    /* Add independent premises until every ratio is pinned down */
    const premises = [], vecs = [];
    const shuffled = rng.shuffle(candidates);
    for (let i = 0; i < shuffled.length && rank(vecs, n) < n - 1; i++) {
      const p = shuffled[i];
      const v = p.left.map(function (c, idx) { return c - p.right[idx]; });
      const before = rank(vecs, n);
      if (rank(vecs.concat([v]), n) <= before) continue;   // adds no information
      vecs.push(v);
      premises.push(p);
    }
    if (rank(vecs, n) !== n - 1) return null;
    if (premises.length !== n - 1) return null;            // keep it tight

    /* Only objects actually shown in the premises may appear in the question */
    const seen = new Array(n).fill(false);
    premises.forEach(function (p) {
      for (let i = 0; i < n; i++) if (p.left[i] || p.right[i]) seen[i] = true;
    });
    if (seen.some(function (s) { return !s; })) return null;

    /* The question: a left pan, and the matching right pan as the answer */
    const qCandidates = rng.shuffle(qPairs.slice());
    let question = null;
    for (let i = 0; i < qCandidates.length; i++) {
      const q = qCandidates[i];
      // do not simply restate a premise, in either direction
      const restates = premises.some(function (p) {
        return (sameSet(p.left, q.left) && sameSet(p.right, q.right)) ||
               (sameSet(p.left, q.right) && sameSet(p.right, q.left));
      });
      if (restates) continue;
      if (sizeOf(q.left) > qSide || sizeOf(q.right) > qSide) continue;
      question = q;
      break;
    }
    if (!question) return null;

    const targetWeight = weightOf(question.right, w);

    /* Distractors: plausible pans of the WRONG weight. Preferring pans built
       from the same object types as the answer makes the error a counting
       error rather than an obvious mismatch. */
    const answerKey = msKey(question.right);
    const near = [], far = [];
    qSets.forEach(function (s) {
      if (msKey(s) === answerKey) return;
      if (!disjoint(s, question.left)) return;          // must be expressible
      const diff = Math.abs(weightOf(s, w) - targetWeight);
      if (diff === 0) return;                            // equally correct: never a distractor
      if (sizeOf(s) > qSide) return;
      const sameTypes = question.right.every(function (c, i) { return (c > 0) === (s[i] > 0); });
      (sameTypes && diff <= Math.max(2, targetWeight * 0.5) ? near : far).push(s);
    });

    const pool = rng.shuffle(near).concat(rng.shuffle(far));
    if (pool.length < 4) return null;

    const correct = { set: question.right, key: answerKey };
    const wrong = pool.slice(0, 12).map(function (s) { return { set: s, key: msKey(s) }; });
    const built = IQ.rng.assemble(rng, correct, wrong, 5);

    return {
      w: w, n: n, premises: premises, question: question,
      options: built.options, answer: built.answer
    };
  }

  /* ---------- rendering ---------- */

  function renderObjects(counts, r, gap) {
    const list = [];
    for (let i = 0; i < counts.length; i++) {
      for (let k = 0; k < counts[i]; k++) list.push(i);
    }
    const total = list.length;
    const width = total * gap;
    let body = '';
    list.forEach(function (idx, j) {
      const cx = -width / 2 + gap / 2 + j * gap;
      body += '<g class="fw-o' + idx + '">' + S.shapePath(OBJECTS[idx], cx, 0, r) + '</g>';
    });
    return { body: body, width: width };
  }

  const FILLS = [1, 0, 0.55, 0, 0.8];

  function objectStyles() {
    let css = '';
    for (let i = 0; i < OBJECTS.length; i++) {
      css += '.fw-o' + i + '{fill:currentColor;fill-opacity:' + FILLS[i] + ';stroke:currentColor;stroke-width:2.2;stroke-linejoin:round}';
    }
    return '<style>' + css + '</style>';
  }

  /* One balance scale. rightCounts === null draws a question mark instead.
     The pans size themselves to their contents: a fixed-width pan either
     wastes space or crams six shapes together so tightly that counting them
     becomes the hard part of the item, which is not what is being measured. */
  const R = 11, GAP = 26;

  function renderScale(leftCounts, rightCounts, opts) {
    opts = opts || {};
    const nLeft = sizeOf(leftCounts);
    const nRight = rightCounts ? sizeOf(rightCounts) : 1;

    /* Each pan is sized from ITS OWN contents. Using the wider of the two for
       both put the pan arcs on top of each other whenever the pans differed
       in size, three shapes on the left against one on the right overlapped. */
    const leftHalf = Math.max(22, nLeft * GAP / 2 + 8);
    const rightHalf = Math.max(22, nRight * GAP / 2 + 8);
    const GUTTER = 46;

    const H = 132, beamY = 48, panY = 82;
    const lx = leftHalf + 8;
    const rx = lx + leftHalf + GUTTER + rightHalf;
    const W = rx + rightHalf + 8;
    const cx = (lx + rx) / 2;

    let body =
      '<line x1="' + lx + '" y1="' + beamY + '" x2="' + rx + '" y2="' + beamY + '" stroke="currentColor" stroke-width="3.2" stroke-linecap="round"/>' +
      '<line x1="' + cx + '" y1="' + beamY + '" x2="' + cx + '" y2="98" stroke="currentColor" stroke-width="3.2"/>' +
      '<polygon points="' + cx + ',92 ' + (cx - 13) + ',114 ' + (cx + 13) + ',114" fill="currentColor" fill-opacity="0.22" stroke="currentColor" stroke-width="2.6" stroke-linejoin="round"/>' +
      '<line x1="' + (cx - 19) + '" y1="114" x2="' + (cx + 19) + '" y2="114" stroke="currentColor" stroke-width="3.2" stroke-linecap="round"/>';

    [[lx, leftHalf], [rx, rightHalf]].forEach(function (pair) {
      const px = pair[0];
      const half = pair[1];
      body += '<line x1="' + px + '" y1="' + beamY + '" x2="' + px + '" y2="' + panY + '" stroke="currentColor" stroke-width="2" stroke-opacity="0.65"/>' +
        '<path d="M' + (px - half) + ',' + panY + ' Q' + px + ',' + (panY + 16) + ' ' + (px + half) + ',' + panY +
        '" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>';
    });

    body += '<g transform="translate(' + lx + ',' + (panY - 15) + ')">' + renderObjects(leftCounts, R, GAP).body + '</g>';

    if (rightCounts) {
      body += '<g transform="translate(' + rx + ',' + (panY - 15) + ')">' + renderObjects(rightCounts, R, GAP).body + '</g>';
    } else {
      body += '<text x="' + rx + '" y="' + (panY - 6) + '" text-anchor="middle" font-size="30" font-weight="800" fill="var(--accent)">?</text>';
    }

    return '<svg class="fig fw-scale" viewBox="0 0 ' + W + ' ' + H + '" width="' + Math.min(opts.size || W, W) +
      '" aria-hidden="true">' + objectStyles() + body + '</svg>';
  }

  /* An option: just the group of objects, no scale */
  function renderGroup(counts) {
    const g = renderObjects(counts, R, GAP);
    const w = Math.max(52, g.width + 18);
    return '<svg class="fig fw-group" viewBox="' + (-w / 2) + ' -18 ' + w + ' 36" width="' + w + '" height="36" aria-hidden="true">' +
      objectStyles() + g.body + '</svg>';
  }

  /* ---------- public ---------- */

  const SPECS = [
    { n: 2, side: 3, qSide: 6 },
    { n: 3, side: 3, qSide: 4 },
    { n: 3, side: 4, qSide: 5 },
    { n: 4, side: 4, qSide: 5 }
  ];

  /* Last resort if every random attempt fails: a fixed, known-good item.
     Returning this is far better than looping, an earlier version recursed
     with Math.max(0, tier - 1), which at tier 0 called itself forever. */
  function fallback(rng) {
    return {
      w: [1, 2], n: 2,
      premises: [{ left: [2, 0], right: [0, 1] }],
      question: { left: [4, 0], right: [0, 2] },
      options: null, answer: 0
    };
  }

  function generate(rng, tier) {
    const start = Math.max(0, Math.min(SPECS.length - 1, tier));

    // try the requested tier, then easier ones, then harder ones, never recurse
    const order = [start];
    for (let d = 1; d < SPECS.length; d++) {
      if (start - d >= 0) order.push(start - d);
      if (start + d < SPECS.length) order.push(start + d);
    }

    let item = null;
    for (let oi = 0; oi < order.length && !item; oi++) {
      const spec = SPECS[order[oi]];
      for (let attempt = 0; attempt < 80 && !item; attempt++) {
        item = buildItem(rng, spec.n, spec.side, spec.qSide);
      }
    }
    if (!item) {
      item = fallback(rng);
      const opts = [[0, 2], [0, 1], [0, 3], [2, 0], [0, 4]];
      const shuffled = rng.shuffle(opts.map(function (s) { return { set: s, key: msKey(s) }; }));
      item.options = shuffled;
      item.answer = shuffled.findIndex(function (o) { return o.key === '0,2'; });
    }

    const mixedAnswer = item.question.right.filter(function (c) { return c > 0; }).length > 1;
    const bigSide = item.premises.some(function (p) { return sizeOf(p.left) > 2 || sizeOf(p.right) > 2; });
    const base = { 2: -1.70, 3: -0.20, 4: 1.30 }[item.n];
    const b = base + (mixedAnswer ? 0.30 : 0) + (bigSide ? 0.22 : 0);

    const premHtml = item.premises.map(function (p) {
      return '<div class="fw-row">' + renderScale(p.left, p.right, {}) + '</div>';
    }).join('');

    return {
      domain: 'gf',
      type: 'weights',
      b: b,
      prompt: 'The first scales balance. Which group balances the last scale?',
      stemHtml: '<div class="fw-stack">' + premHtml +
        '<div class="fw-rule"></div>' +
        '<div class="fw-row fw-target">' + renderScale(item.question.left, null, {}) + '</div></div>',
      optionsHtml: item.options.map(function (o) { return renderGroup(o.set); }),
      optionClass: 'opt-fig',
      answer: item.answer,
      meta: { n: item.n, premises: item.premises.length }
    };
  }

  function build(rng, n) {
    const out = [];
    for (let i = 0; i < n; i++) {
      const frac = n === 1 ? 0.5 : i / (n - 1);
      out.push(generate(rng, Math.min(3, Math.floor(frac * 4))));
    }
    return out;
  }

  IQ.gen = IQ.gen || {};
  IQ.gen.weights = { generate: generate, build: build, rank: rank };
})(window.IQ);
