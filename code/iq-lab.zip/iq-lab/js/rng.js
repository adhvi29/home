/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   IQ LAB · Seeded RNG + generator helpers
   Every test form is derived from a seed, so any attempt can be
   reproduced exactly (useful for debugging and for sharing a form).
   ============================================================ */
window.IQ = window.IQ || {};

(function (IQ) {
  'use strict';

  /* mulberry32, small, fast, good enough distribution for item generation */
  function makeRng(seed) {
    let a = seed >>> 0;
    const r = function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    r.int = (min, max) => min + Math.floor(r() * (max - min + 1));
    r.pick = (arr) => arr[Math.floor(r() * arr.length)];
    r.shuffle = (arr) => {
      const a2 = arr.slice();
      for (let i = a2.length - 1; i > 0; i--) {
        const j = Math.floor(r() * (i + 1));
        [a2[i], a2[j]] = [a2[j], a2[i]];
      }
      return a2;
    };
    r.sample = (arr, n) => r.shuffle(arr).slice(0, n);
    r.chance = (p) => r() < p;
    return r;
  }

  /* Seed from a string, so named forms are stable */
  function hashSeed(str) {
    let h = 2166136261 >>> 0;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  }

  function newSeed() {
    return (Date.now() ^ Math.floor(Math.random() * 0xffffffff)) >>> 0;
  }

  /* Deduplicate option lists by a signature string, keeping order */
  function uniqueBy(list, keyFn) {
    const seen = new Set();
    const out = [];
    for (const item of list) {
      const k = keyFn(item);
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(item);
    }
    return out;
  }

  /* Place the correct answer at a random index among distractors.
     Returns { options, answer } */
  function assemble(rng, correct, distractors, total) {
    const keyed = uniqueBy([correct].concat(distractors), (o) => o.key);
    const wrong = keyed.slice(1, total);
    const opts = rng.shuffle([correct].concat(wrong));
    return { options: opts, answer: opts.indexOf(correct) };
  }

  IQ.rng = { makeRng, hashSeed, newSeed, uniqueBy, assemble };
})(window.IQ);
