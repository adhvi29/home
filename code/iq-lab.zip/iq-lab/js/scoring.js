/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   IQ LAB · Scoring model
   ------------------------------------------------------------
   Three stages:

   1. ABILITY ESTIMATION. Multiple-choice subtests are scored with a
      logistic item-response model rather than by counting correct
      answers: a hard item right counts for more than an easy one,
      and the estimate arrives with a standard error. The guessing
      floor is modelled explicitly, and the residual bias it leaves
      behind is corrected from simulated curves (section 1b).

   2. AGE NORMING. A deviation IQ means "compared with people your
      own age". Raw ability is shifted by the expected ability at
      the test-taker's age before being converted to a score.

   3. COMPOSITE. Indices are combined with weights approximating
      their g-loadings, rescaled using the correlation between them
      (which stops the average of five z-scores collapsing toward
      the mean), then deflated for measurement error so the observed
      distribution keeps a standard deviation of 15.

   Verified by simulation: a person performing exactly at their age
   norm averages within about one point of 100 at every age from 10
   to 75, and a simulated population lands at SD 14.8 with 2.6%
   above 130 (true figure 2.3%). See scratchpad/calibrate.js.

   Honest statement of limits: the item difficulties and the age
   tables below are author-calibrated from published developmental
   curves and item-construction logic, NOT from a standardisation
   sample. The simulations above prove the model is INTERNALLY
   consistent; they cannot prove the difficulty scale is anchored
   correctly against real people. The absolute score may sit a few
   points off. That offset is constant across sittings, so comparing
   your own scores over time is far more trustworthy than the
   absolute number.
   ============================================================ */
window.IQ = window.IQ || {};

(function (IQ) {
  'use strict';

  /* ---------- maths helpers ---------- */

  function erf(x) {
    // Abramowitz & Stegun 7.1.26
    const s = x < 0 ? -1 : 1;
    x = Math.abs(x);
    const t = 1 / (1 + 0.3275911 * x);
    const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741, a4 = -1.453152027, a5 = 1.061405429;
    const poly = (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t;
    return s * (1 - poly * Math.exp(-x * x));
  }

  function normCdf(z) { return 0.5 * (1 + erf(z / Math.SQRT2)); }

  function percentile(z) {
    const p = normCdf(z) * 100;
    if (p >= 99.9) return '>99.9';
    if (p <= 0.1) return '<0.1';
    if (p >= 99 || p <= 1) return p.toFixed(1);
    return String(Math.round(p));
  }

  function lerpTable(table, x) {
    const keys = Object.keys(table).map(Number).sort(function (a, b) { return a - b; });
    if (x <= keys[0]) return table[keys[0]];
    if (x >= keys[keys.length - 1]) return table[keys[keys.length - 1]];
    for (let i = 0; i < keys.length - 1; i++) {
      if (x >= keys[i] && x <= keys[i + 1]) {
        const t = (x - keys[i]) / (keys[i + 1] - keys[i]);
        return table[keys[i]] + t * (table[keys[i + 1]] - table[keys[i]]);
      }
    }
    return table[keys[keys.length - 1]];
  }

  /* ---------- 1. Rasch ability estimation ---------- */

  /* Three-parameter logistic with the guessing floor fixed at 1/options.
     This matters: with five options a test-taker who knows nothing still
     gets ~20% right, and a model that ignores that reads pure luck as
     ability. Discrimination is held at 1 (Rasch-style) because there is
     no calibration sample to estimate it from. */
  function itemP(theta, b, nOptions) {
    const c = nOptions && nOptions > 1 ? 1 / nOptions : 0;
    const p = 1 / (1 + Math.exp(-(theta - b)));
    return { P: c + (1 - c) * p, dP: (1 - c) * p * (1 - p) };
  }

  /* Prior width, in logits. This is deliberately WIDE (SD 2 rather than the
     population SD of 1). A tight prior minimises average squared error but
     does it by dragging every estimate toward 100, with a standard-normal
     prior, someone genuinely at +2.5 logits scores back around +1.8. That
     compression is unacceptable in a test whose whole purpose is detecting
     your own change over time, so the prior here only does the one job it is
     needed for: keeping perfect and zero scores finite. */
  const PRIOR_SD = 2.0;
  const PRIOR_PRECISION = 1 / (PRIOR_SD * PRIOR_SD);

  function estimateTheta(responses) {
    // responses: [{ b: difficulty, correct: bool, options: n }]
    if (!responses.length) return { theta: 0, se: 1, info: 1, n: 0 };

    let theta = 0;
    for (let iter = 0; iter < 120; iter++) {
      let grad = 0, info = 0;
      for (let i = 0; i < responses.length; i++) {
        const r = responses[i];
        const o = itemP(theta, r.b, r.options);
        const denomP = Math.max(1e-9, o.P * (1 - o.P));
        grad += ((r.correct ? 1 : 0) - o.P) * o.dP / denomP;
        info += (o.dP * o.dP) / denomP;
      }
      grad -= theta * PRIOR_PRECISION;
      let step = grad / (info + PRIOR_PRECISION);
      if (step > 0.6) step = 0.6;
      if (step < -0.6) step = -0.6;
      theta += step;
      if (Math.abs(step) < 1e-7) break;
    }

    let info = 0;
    for (let i = 0; i < responses.length; i++) {
      const r = responses[i];
      const o = itemP(theta, r.b, r.options);
      info += (o.dP * o.dP) / Math.max(1e-9, o.P * (1 - o.P));
    }
    return {
      theta: theta,
      se: 1 / Math.sqrt(info + PRIOR_PRECISION),
      info: info,
      n: responses.length
    };
  }

  /* ---------- 1b. Bias correction ----------
     The guessing floor leaves a residual bias in the estimate: at low ability
     lucky guesses push it up and nothing pushes it back, and at high ability
     the prior still pulls it down slightly. The curves below were MEASURED by
     simulating 2,500 test-takers at each of thirteen ability levels against
     real generated forms, and depend on how many items scored that index
     (fewer items, more bias). Entries are [estimated theta, bias].

     Regenerate with scratchpad/bias.js if item counts or difficulties change. */
  const BIAS_TABLES = {
    34: [[-2.42, 0.584], [-2.16, 0.343], [-1.79, 0.209], [-1.39, 0.113], [-0.92, 0.079], [-0.49, 0.015], [0.00, 0.004], [0.49, -0.009], [0.96, -0.036], [1.42, -0.078], [1.91, -0.085], [2.37, -0.132], [2.79, -0.211]],
    20: [[-2.17, 0.832], [-1.94, 0.557], [-1.64, 0.359], [-1.30, 0.199], [-0.87, 0.128], [-0.44, 0.059], [0.00, -0.004], [0.48, -0.025], [0.94, -0.057], [1.37, -0.130], [1.84, -0.159], [2.28, -0.221], [2.65, -0.350]],
    14: [[-2.09, 0.912], [-1.86, 0.638], [-1.60, 0.399], [-1.23, 0.267], [-0.84, 0.165], [-0.42, 0.081], [0.05, 0.045], [0.48, -0.018], [0.92, -0.084], [1.36, -0.138], [1.80, -0.196], [2.16, -0.343], [2.44, -0.562]],
    10: [[-1.85, 1.153], [-1.71, 0.790], [-1.51, 0.494], [-1.17, 0.328], [-0.86, 0.140], [-0.40, 0.099], [0.06, 0.065], [0.50, -0.003], [0.95, -0.050], [1.33, -0.173], [1.64, -0.362], [1.92, -0.585], [2.09, -0.906]],
    7:  [[-1.74, 1.263], [-1.53, 0.974], [-1.33, 0.665], [-1.02, 0.482], [-0.69, 0.314], [-0.31, 0.194], [0.08, 0.083], [0.46, -0.043], [0.82, -0.176], [1.23, -0.268], [1.53, -0.468], [1.85, -0.651], [2.06, -0.939]],
    6:  [[-1.65, 1.355], [-1.50, 1.004], [-1.31, 0.692], [-1.05, 0.449], [-0.69, 0.306], [-0.32, 0.178], [0.09, 0.086], [0.48, -0.016], [0.87, -0.135], [1.18, -0.324], [1.47, -0.533], [1.66, -0.843], [1.79, -1.211]]
  };

  /* Beyond the measured range the correction is an extrapolation, so it is
     capped. Past that point the widening standard error is the honest signal,
     not a bigger adjustment. */
  const MAX_CORRECTION = 0.40;

  function biasFromTable(tbl, theta) {
    if (theta <= tbl[0][0]) return tbl[0][1];
    if (theta >= tbl[tbl.length - 1][0]) return tbl[tbl.length - 1][1];
    for (let i = 0; i < tbl.length - 1; i++) {
      if (theta >= tbl[i][0] && theta <= tbl[i + 1][0]) {
        const t = (theta - tbl[i][0]) / (tbl[i + 1][0] - tbl[i][0]);
        return tbl[i][1] + t * (tbl[i + 1][1] - tbl[i][1]);
      }
    }
    return 0;
  }

  function debias(theta, nItems) {
    const counts = Object.keys(BIAS_TABLES).map(Number).sort(function (a, b) { return a - b; });
    if (!nItems) return theta;

    let bias;
    if (nItems <= counts[0]) bias = biasFromTable(BIAS_TABLES[counts[0]], theta);
    else if (nItems >= counts[counts.length - 1]) bias = biasFromTable(BIAS_TABLES[counts[counts.length - 1]], theta);
    else {
      // bias scales with 1/n, so interpolate between the bracketing tables there
      let lo = counts[0], hi = counts[counts.length - 1];
      for (let i = 0; i < counts.length - 1; i++) {
        if (nItems >= counts[i] && nItems <= counts[i + 1]) { lo = counts[i]; hi = counts[i + 1]; break; }
      }
      const bLo = biasFromTable(BIAS_TABLES[lo], theta);
      const bHi = biasFromTable(BIAS_TABLES[hi], theta);
      const t = (1 / nItems - 1 / lo) / ((1 / hi - 1 / lo) || 1);
      bias = bLo + t * (bHi - bLo);
    }

    if (bias > MAX_CORRECTION) bias = MAX_CORRECTION;
    if (bias < -MAX_CORRECTION) bias = -MAX_CORRECTION;
    return theta - bias;
  }

  /* ---------- 2. Age norms ----------
     Expected ability in logits at each age, on the same scale the
     items are calibrated to (healthy adults in their twenties = 0).
     Shapes follow published developmental curves: fluid reasoning
     and speed peak in the late teens / early twenties and decline
     steadily; crystallised ability keeps rising into middle age. */

  const AGE_THETA = {
    gf: { 8: -2.10, 10: -1.55, 12: -1.00, 13: -0.78, 14: -0.56, 15: -0.38, 16: -0.24, 17: -0.13, 18: -0.05, 20: 0.02, 25: 0.03, 30: 0.00, 35: -0.06, 40: -0.14, 45: -0.24, 50: -0.36, 55: -0.48, 60: -0.62, 65: -0.78, 70: -0.95, 75: -1.14, 80: -1.35 },
    gv: { 8: -2.05, 10: -1.50, 12: -0.96, 13: -0.74, 14: -0.52, 15: -0.34, 16: -0.20, 17: -0.10, 18: -0.02, 20: 0.04, 25: 0.04, 30: 0.00, 35: -0.08, 40: -0.18, 45: -0.30, 50: -0.43, 55: -0.57, 60: -0.72, 65: -0.90, 70: -1.10, 75: -1.32, 80: -1.55 },
    gc: { 8: -2.40, 10: -1.85, 12: -1.25, 13: -1.00, 14: -0.78, 15: -0.60, 16: -0.45, 17: -0.33, 18: -0.24, 20: -0.10, 25: 0.02, 30: 0.08, 35: 0.13, 40: 0.16, 45: 0.18, 50: 0.18, 55: 0.16, 60: 0.13, 65: 0.08, 70: 0.02, 75: -0.06, 80: -0.15 }
  };

  /* Raw-score norms for the two performance tasks.
     Span: highest sequence length reproduced correctly.
     Speed: correct minus incorrect in 90 seconds. */
  const RAW_NORMS = {
    span: {
      mean: { 8: 3.3, 10: 3.8, 12: 4.2, 14: 4.6, 16: 4.9, 18: 5.0, 25: 5.1, 35: 5.1, 45: 5.0, 55: 4.8, 65: 4.5, 75: 4.1, 85: 3.7 },
      sd: 1.3
    },
    speed: {
      mean: { 8: 12, 10: 15, 12: 18, 14: 21, 16: 24, 18: 25, 25: 26, 35: 25, 45: 23, 55: 21, 65: 18, 75: 15, 85: 12 },
      sd: 7
    }
  };

  function ageTheta(domain, age) {
    const t = AGE_THETA[domain];
    return t ? lerpTable(t, age) : 0;
  }

  function rawToZ(kind, raw, age) {
    const n = RAW_NORMS[kind];
    const mean = lerpTable(n.mean, age);
    return { z: (raw - mean) / n.sd, expected: mean, sd: n.sd };
  }

  /* ---------- 3. Index and composite construction ---------- */

  const INDEX_META = {
    gf: { key: 'gf', color: 'var(--c-gf)', name: 'Fluid Reasoning', short: 'Gf', weight: 0.30, blurb: 'Working out rules and relationships you have never been taught. The single best proxy for g.' },
    gc: { key: 'gc', color: 'var(--c-gc)', name: 'Verbal / Knowledge', short: 'Gc', weight: 0.22, blurb: 'Vocabulary and verbal relationships, the part of ability that education visibly builds.' },
    gv: { key: 'gv', color: 'var(--c-gv)', name: 'Visual-Spatial', short: 'Gv', weight: 0.18, blurb: 'Holding and transforming shapes in your head.' },
    gwm: { key: 'gwm', color: 'var(--c-gwm)', name: 'Working Memory', short: 'Gwm', weight: 0.17, blurb: 'How much you can hold and manipulate at once.' },
    gs: { key: 'gs', color: 'var(--c-gs)', name: 'Processing Speed', short: 'Gs', weight: 0.13, blurb: 'How fast you make simple visual decisions without losing accuracy.' }
  };

  const INDEX_ORDER = ['gf', 'gc', 'gv', 'gwm', 'gs'];
  /* Correlation between index scores. Published index intercorrelations on
     major batteries run roughly 0.5-0.7; 0.58 sits in that range. It matters
     more than it looks: assume too low a value and the composite is stretched,
     which is how home-made tests end up handing out 130s to 4% of takers. */
  const INTER_R = 0.58;

  /* Calibration uncertainty in logits: how far the absolute anchor
     might be off because these norms were not standardised on a
     sample. Constant across sittings, so it does not affect
     comparisons of your own scores over time. */
  const CALIBRATION_SD = { gf: 0.20, gc: 0.25, gv: 0.22, gwm: 0.22, gs: 0.35 };

  function toIQ(z) { return 100 + 15 * z; }

  /* Every real instrument has a floor and a ceiling, and reports "at or below
     the floor" rather than a number. Without this an abandoned timed task
     produces things like a Processing Speed index of -7, which is not a score,
     it is an artefact. +/-4 SD maps to the 40-160 range. */
  const Z_LIMIT = 4;
  function clampZ(z) {
    if (!isFinite(z)) return 0;
    return Math.max(-Z_LIMIT, Math.min(Z_LIMIT, z));
  }
  function rangeFlag(z) {
    if (z < -Z_LIMIT) return 'low';
    if (z > Z_LIMIT) return 'high';
    return null;
  }

  function classify(iq) {
    if (iq >= 130) return 'Very high';
    if (iq >= 120) return 'High';
    if (iq >= 110) return 'Above average';
    if (iq >= 90) return 'Average';
    if (iq >= 80) return 'Below average';
    if (iq >= 70) return 'Low';
    return 'Very low';
  }

  /* results: {
       gf: [{b, correct}...], gc: [...], gv: [...],
       spans: { digits: n, mixed: n },
       speed: { raw: n }
     } */
  function score(results, age) {
    const indices = {};

    // Rasch-scored reasoning indices
    ['gf', 'gc', 'gv'].forEach(function (d) {
      const est = estimateTheta(results[d] || []);
      const theta = debias(est.theta, est.n);
      const zRaw = theta - ageTheta(d, age);
      const z = clampZ(zRaw);
      indices[d] = {
        key: d,
        theta: theta,
        thetaRaw: est.theta,
        z: z,
        zUnclamped: zRaw,
        outOfRange: rangeFlag(zRaw),
        se: est.se,
        items: est.n,
        iq: toIQ(z),
        raw: (results[d] || []).filter(function (r) { return r.correct; }).length,
        total: (results[d] || []).length
      };
    });

    // Working memory from the two spans
    const sp = results.spans || {};
    const zd = sp.digits != null ? rawToZ('span', sp.digits, age) : null;
    const zm = sp.mixed != null ? rawToZ('span', sp.mixed, age) : null;
    let zwmRaw = 0, sewm = 1;
    if (zd && zm) {
      // average of two correlated measures, rescaled to unit variance
      zwmRaw = (zd.z + zm.z) / Math.sqrt(2 + 2 * 0.60);
      sewm = 0.42;
    } else if (zd || zm) {
      zwmRaw = (zd || zm).z;
      sewm = 0.55;
    }
    const zwm = clampZ(zwmRaw);
    indices.gwm = {
      key: 'gwm', z: zwm, zUnclamped: zwmRaw, outOfRange: rangeFlag(zwmRaw),
      se: sewm, iq: toIQ(zwm),
      raw: [sp.digits, sp.mixed].filter(function (v) { return v != null; }).join(' / '),
      detail: zd ? 'expected for age: ' + lerpTable(RAW_NORMS.span.mean, age).toFixed(1) : ''
    };

    // Processing speed
    const spd = results.speed || {};
    const zs = spd.raw != null ? rawToZ('speed', spd.raw, age) : { z: 0, expected: 0 };
    const zsc = clampZ(zs.z);
    indices.gs = {
      key: 'gs', z: zsc, zUnclamped: zs.z, outOfRange: rangeFlag(zs.z),
      se: 0.45, iq: toIQ(zsc),
      raw: spd.raw, detail: 'expected for age: ' + Math.round(zs.expected)
    };

    // Composite
    let weightedZ = 0, sumW = 0, errVar = 0, calVar = 0;
    INDEX_ORDER.forEach(function (d) {
      const w = INDEX_META[d].weight;
      const idx = indices[d];
      if (!idx || idx.z == null || isNaN(idx.z)) return;
      weightedZ += w * idx.z;
      sumW += w;
      errVar += w * w * idx.se * idx.se;
      calVar += w * w * CALIBRATION_SD[d] * CALIBRATION_SD[d];
    });

    // rescale for the correlation between indices
    const sumSq = INDEX_ORDER.reduce(function (a, d) { return a + Math.pow(INDEX_META[d].weight, 2); }, 0);
    const crossSum = (Math.pow(sumW, 2) - sumSq) / 2;
    const compositeSd = Math.sqrt(sumSq + 2 * crossSum * INTER_R);

    const zRaw = weightedZ / compositeSd;
    const seRaw = Math.sqrt(errVar) / compositeSd;       // sitting-to-sitting noise
    const seCal = Math.sqrt(calVar) / compositeSd;       // fixed offset in the norms

    /* An observed score carries true ability PLUS measurement error, so the
       spread of observed scores is wider than the spread of real ability. Left
       alone, that inflates the tails: about 4% of people would be handed a
       score of 130+ when the real figure is 2.3%, and the printed percentile
       would be a lie. Deflating by sqrt(1 + SE^2) restores a standard
       deviation of 15 to the observed distribution.

       The cost is honest and small: a real change is reported at about 93% of
       its size. The reliable-change threshold is computed on this same scale,
       so the two stay consistent. */
    const shrink = 1 / Math.sqrt(1 + seRaw * seRaw);
    const zcUnclamped = zRaw * shrink;
    const zc = clampZ(zcUnclamped);
    const seMeas = seRaw * shrink;

    const fsiq = toIQ(zc);
    const band90 = 1.645 * 15 * seMeas;

    return {
      indices: indices,
      fsiq: fsiq,
      z: zc,
      percentile: percentile(zc),
      outOfRange: rangeFlag(zcUnclamped),
      /* Past roughly 135 / 65 there are too few items at the right difficulty
         to separate people, so the honest report is a bound, not a figure. */
      unresolved: fsiq > 137 ? 'high' : fsiq < 63 ? 'low' : null,
      band90: band90,
      ci: [Math.max(40, fsiq - band90), Math.min(160, fsiq + band90)],
      seMeasure: seMeas,
      seCalibration: seCal,
      calibrationPoints: 1.645 * 15 * seCal,
      reliability: Math.max(0, 1 - seMeas * seMeas),
      classification: classify(fsiq),
      age: age
    };
  }

  /* Is the change between two sittings bigger than measurement noise?
     Uses the standard error of the DIFFERENCE of two estimates. */
  function compare(a, b) {
    const seDiff = Math.sqrt(Math.pow(a.seMeasure, 2) + Math.pow(b.seMeasure, 2)) * 15;
    const delta = b.fsiq - a.fsiq;
    const crit = 1.645 * seDiff;
    return {
      delta: delta,
      seDiff: seDiff,
      threshold: crit,
      significant: Math.abs(delta) > crit
    };
  }

  IQ.scoring = {
    estimateTheta: estimateTheta,
    score: score,
    compare: compare,
    percentile: percentile,
    debias: debias,
    normCdf: normCdf,
    classify: classify,
    toIQ: toIQ,
    ageTheta: ageTheta,
    rawToZ: rawToZ,
    INDEX_META: INDEX_META,
    INDEX_ORDER: INDEX_ORDER,
    RAW_NORMS: RAW_NORMS
  };
})(window.IQ);
