/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   IQ LAB · Local history (the working copy)
   ------------------------------------------------------------
   This is the source of truth while the app is running. Nothing
   here touches the network: js/cloud.js subscribes via onChange
   and mirrors writes to Supabase in the background, so a sitting
   is never at the mercy of a connection.

   With cloud sync switched off, this file behaves exactly as it
   always did, everything stays in this browser, and the JSON
   export is the only way a decade of results survives a new
   laptop.
   ============================================================ */
window.IQ = window.IQ || {};

(function (IQ) {
  'use strict';

  const KEY = 'iqlab.v1';

  const blank = function () {
    return {
      version: 2,
      profile: { name: '', birth: '', updatedAt: null },
      attempts: [],
      /* Ids of sittings deleted here. Kept rather than forgotten: without a
         tombstone, a second device that still holds the sitting would re-upload
         it on its next sync and the deletion would silently undo itself. */
      deleted: []
    };
  };

  let cache = null;
  let changeListeners = [];

  /* Anything that wants to react to a local write (the cloud sync layer)
     subscribes here, so the store itself stays free of network concerns. */
  function onChange(fn) {
    changeListeners.push(fn);
    return function () { changeListeners = changeListeners.filter(function (f) { return f !== fn; }); };
  }

  function emit(reason) {
    changeListeners.slice().forEach(function (fn) {
      try { fn(reason); } catch (e) { /* a listener must never break a save */ }
    });
  }

  function load() {
    if (cache) return cache;
    try {
      const raw = localStorage.getItem(KEY);
      cache = raw ? JSON.parse(raw) : blank();
    } catch (e) {
      cache = blank();
    }
    if (!cache.attempts) cache.attempts = [];
    if (!cache.deleted) cache.deleted = [];
    if (!cache.profile) cache.profile = { name: '', birth: '', updatedAt: null };
    return cache;
  }

  function save(reason) {
    let ok = true;
    try {
      localStorage.setItem(KEY, JSON.stringify(load()));
    } catch (e) {
      ok = false;
    }
    if (reason !== 'silent') emit(reason);
    return ok;
  }

  function profile() { return load().profile; }

  function setProfile(p) {
    const db = load();
    db.profile = Object.assign({}, db.profile, p, { updatedAt: new Date().toISOString() });
    save('profile');
    return db.profile;
  }

  /* Applied from the server: must NOT bump updatedAt or it would look like a
     local edit and ping-pong back on the next sync. */
  function applyRemoteProfile(p) {
    const db = load();
    db.profile = { name: p.name || '', birth: p.birth || '', updatedAt: p.updatedAt || null };
    save('silent');
    return db.profile;
  }

  /* The norms only span roughly 8 to 100. Outside that the age tables clamp,
     which would silently score a mistyped year (0001, say) against the oldest
     band and hand back a confident, meaningless number. */
  const MIN_AGE = 8;
  const MAX_AGE = 100;

  /* Decimal age from an ISO birth date */
  function ageAt(birth, when) {
    if (!birth) return null;
    const b = new Date(birth + 'T00:00:00');
    const d = when ? new Date(when) : new Date();
    if (isNaN(b.getTime())) return null;
    const ms = d - b;
    if (ms <= 0) return null;
    const years = ms / (365.2425 * 24 * 3600 * 1000);
    if (years < MIN_AGE || years > MAX_AGE) return null;
    return years;
  }

  /* Same check, but says WHY it failed so the UI can explain itself */
  function validateBirth(birth) {
    if (!birth) return { ok: false, age: null, message: 'Enter a date of birth to unlock the test.' };
    const b = new Date(birth + 'T00:00:00');
    if (isNaN(b.getTime())) return { ok: false, age: null, message: 'That is not a valid date.' };
    const years = (new Date() - b) / (365.2425 * 24 * 3600 * 1000);
    if (years <= 0) return { ok: false, age: null, message: 'That date is in the future, check the year.' };
    if (years < MIN_AGE) {
      return { ok: false, age: years, message: 'That works out as age ' + years.toFixed(1) +
        '. These norms start at ' + MIN_AGE + ', check the year.' };
    }
    if (years > MAX_AGE) {
      return { ok: false, age: years, message: 'That works out as age ' + Math.round(years) +
        '. Check the year is four digits.' };
    }
    return { ok: true, age: years, message: 'Age ' + years.toFixed(1) + ' years, norms set.' };
  }

  /* Bounds for the date input, so the picker cannot offer a bad value */
  function birthBounds() {
    const now = new Date();
    const iso = function (d) { return d.toISOString().slice(0, 10); };
    const max = new Date(now); max.setFullYear(max.getFullYear() - MIN_AGE);
    const min = new Date(now); min.setFullYear(min.getFullYear() - MAX_AGE);
    return { min: iso(min), max: iso(max) };
  }

  function attempts() {
    return load().attempts.slice().sort(function (a, b) {
      return new Date(a.date) - new Date(b.date);
    });
  }

  function addAttempt(rec) {
    const db = load();
    rec.id = rec.id || ('a' + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36));
    db.attempts.push(rec);
    save('attempt');
    return rec;
  }

  function removeAttempt(id) {
    const db = load();
    const before = db.attempts.length;
    db.attempts = db.attempts.filter(function (a) { return a.id !== id; });
    if (db.deleted.indexOf(id) < 0) db.deleted.push(id);
    save('delete');
    return db.attempts.length !== before;
  }

  function tombstones() { return load().deleted.slice(); }

  /* Merge rows pulled from the server. Never emits a change event: doing so
     would schedule another sync, which would pull the same rows again. */
  function applyRemote(payload) {
    const db = load();
    let touched = false;

    (payload.tombstones || []).forEach(function (id) {
      if (db.deleted.indexOf(id) < 0) { db.deleted.push(id); touched = true; }
      const before = db.attempts.length;
      db.attempts = db.attempts.filter(function (a) { return a.id !== id; });
      if (db.attempts.length !== before) touched = true;
    });

    const have = {};
    db.attempts.forEach(function (a) { have[a.id] = true; });
    (payload.attempts || []).forEach(function (a) {
      if (have[a.id]) return;
      if (db.deleted.indexOf(a.id) >= 0) return;
      db.attempts.push(a);
      touched = true;
    });

    if (touched) save('silent');
    return touched;
  }

  function clearAll() {
    cache = blank();
    save('clear');
  }

  /* ------------------------------------------------------------
     One-time purge of everything this app has ever written here.

     Requested as "remove current user data, fully, from everywhere".
     Code in this page is the only thing that can reach a given
     browser's storage, so the wipe has to run client-side on the next
     load rather than being something that can be done from outside.

     It is gated on PURGE_FLAG so it happens exactly once: without the
     flag it would erase every new sitting on every reload. Delete this
     function and its call in app.js once it has run, or leave it, the
     flag makes it inert either way.
     ------------------------------------------------------------ */
  const PURGE_FLAG = 'iqlab.purged.v2';

  function purgeLegacyData() {
    let already = false;
    try { already = localStorage.getItem(PURGE_FLAG) === '1'; } catch (e) { return { ran: false, removed: [] }; }
    if (already) return { ran: false, removed: [] };

    const removed = [];
    [localStorage, sessionStorage].forEach(function (storage) {
      if (!storage) return;
      const doomed = [];
      try {
        for (let i = 0; i < storage.length; i++) {
          const k = storage.key(i);
          if (!k) continue;
          // this app's own keys, plus any Supabase session left behind
          if (k.indexOf('iqlab.') === 0 || /^sb-.*-auth-token/.test(k)) doomed.push(k);
        }
        doomed.forEach(function (k) { storage.removeItem(k); removed.push(k); });
      } catch (e) { /* blocked storage: nothing to purge */ }
    });

    cache = blank();
    try {
      localStorage.setItem(KEY, JSON.stringify(cache));
      localStorage.setItem(PURGE_FLAG, '1');
    } catch (e) { /* private mode */ }

    return { ran: true, removed: removed };
  }

  function exportJson() {
    return JSON.stringify(load(), null, 2);
  }

  function importJson(text) {
    const parsed = JSON.parse(text);
    if (!parsed || !Array.isArray(parsed.attempts)) throw new Error('That file does not look like an IQ Lab export.');
    const db = load();
    const seen = {};
    db.attempts.forEach(function (a) { seen[a.id] = true; });
    let added = 0;
    parsed.attempts.forEach(function (a) {
      if (a && a.id && !seen[a.id]) { db.attempts.push(a); added++; }
    });
    if (parsed.profile && !db.profile.birth) db.profile = parsed.profile;
    save();
    return added;
  }

  /* Draft support: a sitting survives an accidental refresh */
  const DRAFT = 'iqlab.draft.v1';
  function saveDraft(d) {
    try { localStorage.setItem(DRAFT, JSON.stringify(d)); } catch (e) { /* quota */ }
  }
  function loadDraft() {
    try {
      const raw = localStorage.getItem(DRAFT);
      return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
  }
  function clearDraft() {
    try { localStorage.removeItem(DRAFT); } catch (e) { /* ignore */ }
  }

  IQ.store = {
    profile: profile, setProfile: setProfile, ageAt: ageAt,
    validateBirth: validateBirth, birthBounds: birthBounds,
    attempts: attempts, addAttempt: addAttempt, removeAttempt: removeAttempt,
    clearAll: clearAll, exportJson: exportJson, importJson: importJson,
    saveDraft: saveDraft, loadDraft: loadDraft, clearDraft: clearDraft,
    onChange: onChange, tombstones: tombstones,
    applyRemote: applyRemote, applyRemoteProfile: applyRemoteProfile,
    purgeLegacyData: purgeLegacyData
  };
})(window.IQ);
