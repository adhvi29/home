/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   IQ LAB · Sitting runner
   Walks through the battery section by section and collects
   responses. The whole form is rebuildable from its seed, so a
   refresh mid-test only needs the answers and the position.
   ============================================================ */
window.IQ = window.IQ || {};

(function (IQ) {
  'use strict';

  let S = null;            // active session
  let cleanup = null;      // teardown for span / speed tasks
  let onFinish = null;
  let root = null;

  function start(el, opts, done) {
    root = el;
    onFinish = done;
    const seed = opts.seed;
    S = {
      seed: seed,
      form: opts.form,
      battery: IQ.battery.build(seed, opts.form),
      sectionIdx: 0,
      itemIdx: 0,
      phase: 'intro',
      responses: { gf: [], gc: [], gv: [] },
      spans: {},
      speed: {},
      log: [],
      startedAt: opts.startedAt || new Date().toISOString(),
      itemStart: 0
    };
    if (opts.restore) Object.assign(S, opts.restore, { battery: S.battery });
    render();
  }

  function abort() {
    if (cleanup) { cleanup(); cleanup = null; }
    S = null;
    root = null;
  }

  function section() { return S.battery.sections[S.sectionIdx]; }

  function persist() {
    IQ.store.saveDraft({
      seed: S.seed, form: S.form, sectionIdx: S.sectionIdx, itemIdx: S.itemIdx,
      phase: S.phase, responses: S.responses, spans: S.spans, speed: S.speed,
      log: S.log, startedAt: S.startedAt
    });
  }

  function progress() {
    const secs = S.battery.sections;
    let total = 0, done = 0;
    secs.forEach(function (sec, i) {
      const units = sec.items ? sec.items.length : 1;
      total += units;
      if (i < S.sectionIdx) done += units;
      else if (i === S.sectionIdx && sec.items) done += S.itemIdx;
    });
    return { done: done, total: total, pct: total ? (done / total) * 100 : 0 };
  }

  function chrome(inner, opts) {
    opts = opts || {};
    const p = progress();
    const sec = section();
    return '' +
      '<div class="test-shell">' +
      '  <header class="test-top">' +
      '    <div class="test-crumb">' +
      '      <span class="crumb-sec">' + (S.sectionIdx + 1) + ' / ' + S.battery.sections.length + ' &middot; ' + sec.title + '</span>' +
      (opts.counter ? '<span class="crumb-item">' + opts.counter + '</span>' : '') +
      '    </div>' +
      '    <button class="btn btn-ghost btn-sm" id="quitBtn">Save &amp; exit</button>' +
      '  </header>' +
      '  <div class="progress"><span style="width:' + p.pct.toFixed(1) + '%"></span></div>' +
      '  <main class="test-body">' + inner + '</main>' +
      '</div>';
  }

  function render() {
    if (cleanup) { cleanup(); cleanup = null; }
    if (!S) return;
    if (S.sectionIdx >= S.battery.sections.length) return finish();
    const sec = section();
    if (S.phase === 'intro') return renderIntro(sec);
    if (sec.kind === 'mc') return renderItem(sec);
    if (sec.kind === 'span') return renderSpan(sec);
    if (sec.kind === 'speed') return renderSpeed(sec);
  }

  function renderIntro(sec) {
    const units = sec.items ? sec.items.length + ' items' :
      sec.kind === 'speed' ? sec.seconds + ' seconds' : 'adaptive length';
    root.innerHTML = chrome(
      '<div class="sec-intro">' +
      '  <p class="eyebrow">Section ' + (S.sectionIdx + 1) + ' &middot; ' + units + '</p>' +
      '  <h2>' + sec.title + '</h2>' +
      '  <p class="lead">' + sec.lead + '</p>' +
      '  <div class="tip"><strong>How to approach it</strong><p>' + sec.tip + '</p></div>' +
      '  <button class="btn btn-primary btn-lg" id="beginBtn">Begin section</button>' +
      '</div>'
    );
    root.querySelector('#beginBtn').addEventListener('click', function () {
      S.phase = 'run';
      S.itemStart = performance.now();
      persist();
      render();
    });
    wireQuit();
  }

  /* ---------- multiple choice ---------- */
  function renderItem(sec) {
    const item = sec.items[S.itemIdx];
    if (!item) return nextSection();

    const optsHtml = item.optionsHtml.map(function (html, i) {
      return '<button class="opt ' + (item.optionClass || '') + '" data-i="' + i + '">' +
        '<span class="opt-key">' + (i + 1) + '</span>' +
        '<span class="opt-body">' + html + '</span></button>';
    }).join('');

    root.innerHTML = chrome(
      '<div class="item">' +
      '  <p class="item-prompt">' + item.prompt + '</p>' +
      (item.stemHtml ? '<div class="item-stem">' + item.stemHtml + '</div>' : '') +
      '  <div class="opts">' + optsHtml + '</div>' +
      '  <div class="item-foot">' +
      '    <button class="btn btn-ghost" id="unsureBtn">Not sure &mdash; move on</button>' +
      '    <button class="btn btn-primary" id="nextBtn" disabled>Next</button>' +
      '  </div>' +
      '</div>',
      { counter: 'Item ' + (S.itemIdx + 1) + ' of ' + sec.items.length }
    );

    let chosen = null;
    const nextBtn = root.querySelector('#nextBtn');
    const buttons = Array.prototype.slice.call(root.querySelectorAll('.opt'));

    function select(i) {
      chosen = i;
      buttons.forEach(function (b, j) { b.classList.toggle('selected', i === j); });
      nextBtn.disabled = false;
    }

    buttons.forEach(function (b) {
      b.addEventListener('click', function () { select(Number(b.dataset.i)); });
    });

    function commit(answerIdx) {
      const rt = Math.round(performance.now() - S.itemStart);
      const correct = answerIdx === item.answer;
      (S.responses[item.domain] = S.responses[item.domain] || []).push({
        b: item.b, correct: correct, options: item.optionsHtml.length
      });
      S.log.push({
        sec: sec.id, type: item.type, b: Number(item.b.toFixed(2)),
        correct: correct, rt: rt, skipped: answerIdx === -1
      });
      S.itemIdx++;
      S.itemStart = performance.now();
      persist();
      if (S.itemIdx >= sec.items.length) return nextSection();
      render();
    }

    nextBtn.addEventListener('click', function () { if (chosen !== null) commit(chosen); });
    root.querySelector('#unsureBtn').addEventListener('click', function () { commit(-1); });

    const onKey = function (e) {
      const n = Number(e.key);
      if (n >= 1 && n <= buttons.length) { e.preventDefault(); select(n - 1); }
      else if (e.key === 'Enter' && chosen !== null) { e.preventDefault(); commit(chosen); }
    };
    document.addEventListener('keydown', onKey);
    cleanup = function () { document.removeEventListener('keydown', onKey); };

    wireQuit();
  }

  /* ---------- span tasks ---------- */
  function renderSpan(sec) {
    root.innerHTML = chrome('<div class="item"><div id="taskMount"></div></div>');
    const mount = root.querySelector('#taskMount');
    cleanup = IQ.gen.memory.mount(mount, {
      rng: IQ.rng.makeRng(IQ.rng.hashSeed(S.seed + ':' + sec.id)),
      task: sec.task
    }, function (res) {
      S.spans[sec.task] = res.span;
      S.log.push({ sec: sec.id, type: 'span', span: res.span, trials: res.trials.length });
      persist();
      nextSection();
    });
    wireQuit();
  }

  /* ---------- speed task ---------- */
  function renderSpeed(sec) {
    root.innerHTML = chrome('<div class="item"><div id="taskMount"></div></div>');
    const mount = root.querySelector('#taskMount');
    cleanup = IQ.gen.speed.mount(mount, {
      rng: IQ.rng.makeRng(IQ.rng.hashSeed(S.seed + ':speed')),
      seconds: sec.seconds
    }, function (res) {
      S.speed = res;
      S.log.push({ sec: sec.id, type: 'speed', raw: res.raw, correct: res.correct, incorrect: res.incorrect });
      persist();
      nextSection();
    });
    wireQuit();
  }

  function nextSection() {
    S.sectionIdx++;
    S.itemIdx = 0;
    S.phase = 'intro';
    persist();
    if (S.sectionIdx >= S.battery.sections.length) return finish();
    render();
  }

  function wireQuit() {
    const b = root.querySelector('#quitBtn');
    if (!b) return;
    b.addEventListener('click', function () {
      if (!confirm('Leave the test? Your progress is saved and you can resume from the home screen.')) return;
      persist();
      if (cleanup) { cleanup(); cleanup = null; }
      IQ.app.go('home');
    });
  }

  function finish() {
    if (cleanup) { cleanup(); cleanup = null; }
    const payload = {
      seed: S.seed, form: S.form, formName: S.battery.formName,
      responses: S.responses, spans: S.spans, speed: S.speed,
      log: S.log, startedAt: S.startedAt, finishedAt: new Date().toISOString()
    };
    IQ.store.clearDraft();
    const cb = onFinish;
    S = null;
    if (cb) cb(payload);
  }

  IQ.test = { start: start, abort: abort };
})(window.IQ);
