/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* Measure the estimator's bias curve for each Rasch-scored domain, so it can
   be corrected in scoring.js. Bias comes from the guessing floor: at low
   ability, lucky guesses push the estimate up and nothing pushes it back. */
const fs = require('fs'), path = require('path'), vm = require('vm');
const ROOT = require('path').join(__dirname, '..');
const files = ['js/rng.js', 'js/gen/shapes.js', 'js/gen/matrix.js', 'js/gen/series.js',
  'js/gen/verbal.js', 'js/gen/spatial.js', 'js/gen/logic.js', 'js/gen/weights.js', 'js/scoring.js', 'js/battery.js'];
const sandbox = { window: {}, console };
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
files.forEach(f => vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), sandbox, { filename: f }));
const IQ = sandbox.window.IQ;
const rnd = IQ.rng.makeRng(4242);

const FORM = process.argv[2] || 'full';
const forms = [];
for (let f = 0; f < 60; f++) {
  const bat = IQ.battery.build(9000 + f, FORM);
  const g = { gf: [], gc: [], gv: [] };
  bat.sections.forEach(s => (s.items || []).forEach(it => {
    g[it.domain].push({ b: it.b, options: it.optionsHtml.length });
  }));
  forms.push(g);
}

const GRID = [-3, -2.5, -2, -1.5, -1, -0.5, 0, 0.5, 1, 1.5, 2, 2.5, 3];
console.log('form: ' + FORM);
['gf', 'gc', 'gv'].forEach(d => {
  if (!forms[0][d].length) return;
  const out = [];
  GRID.forEach(trueT => {
    const ests = [];
    for (let rep = 0; rep < 2500; rep++) {
      const items = forms[rep % forms.length][d];
      const resp = items.map(it => {
        const c = 1 / it.options;
        const p = c + (1 - c) / (1 + Math.exp(-(trueT - it.b)));
        return { b: it.b, options: it.options, correct: rnd() < p };
      });
      ests.push(IQ.scoring.estimateTheta(resp).theta);
    }
    const mean = ests.reduce((a, b) => a + b, 0) / ests.length;
    out.push({ est: mean, bias: mean - trueT });
  });
  // emit a table keyed by the OBSERVED estimate, which is what we can look up
  console.log('  ' + d + ' (n=' + forms[0][d].length + ' items): { ' +
    out.map(o => o.est.toFixed(2) + ': ' + o.bias.toFixed(3)).join(', ') + ' }');
});
