/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* Calibration check: does the scale actually centre on 100 at every age,
   and does it recover ability without compressing the ends? */
const fs = require('fs'), path = require('path'), vm = require('vm');
const ROOT = require('path').join(__dirname, '..');
const files = ['js/rng.js', 'js/gen/shapes.js', 'js/gen/matrix.js', 'js/gen/series.js',
  'js/gen/verbal.js', 'js/gen/spatial.js', 'js/gen/logic.js', 'js/gen/weights.js', 'js/scoring.js', 'js/battery.js'];
const sandbox = { window: {}, console };
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
files.forEach(f => vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), sandbox, { filename: f }));
const IQ = sandbox.window.IQ;
const SC = IQ.scoring;

const rnd = IQ.rng.makeRng(20260916);

/* ---- 1. theta recovery on the real gf ladder ---- */
console.log('== Ability recovery (gf ladder, full battery) ==');
{
  // pool difficulties across 40 different generated forms so this is not
  // a verdict on one lucky seed
  const forms = [];
  for (let f = 0; f < 40; f++) {
    const bat = IQ.battery.build(1000 + f, 'full');
    const gf = [];
    bat.sections.forEach(s => (s.items || []).forEach(it => {
      if (it.domain === 'gf') gf.push({ b: it.b, options: it.optionsHtml.length });
    }));
    forms.push(gf);
  }
  const allB = forms.flat().map(i => i.b).sort((a, b) => a - b);
  console.log('  gf difficulty: min ' + allB[0].toFixed(2) +
    '  p25 ' + allB[Math.floor(allB.length * .25)].toFixed(2) +
    '  median ' + allB[Math.floor(allB.length * .5)].toFixed(2) +
    '  p75 ' + allB[Math.floor(allB.length * .75)].toFixed(2) +
    '  max ' + allB[allB.length - 1].toFixed(2));

  [-2.5, -2, -1, -0.5, 0, 0.5, 1, 1.5, 2, 2.5, 3].forEach(trueT => {
    const ests = [], ses = [];
    for (let rep = 0; rep < 1200; rep++) {
      const items = forms[rep % forms.length];
      const resp = items.map(it => {
        const c = 1 / it.options;
        const p = c + (1 - c) / (1 + Math.exp(-(trueT - it.b)));
        return { b: it.b, options: it.options, correct: rnd() < p };
      });
      const r = SC.estimateTheta(resp);
      ests.push(r.theta); ses.push(r.se);
    }
    const mean = ests.reduce((a, b) => a + b, 0) / ests.length;
    const sd = Math.sqrt(ests.reduce((a, b) => a + (b - mean) ** 2, 0) / ests.length);
    const mse = ses.reduce((a, b) => a + b, 0) / ses.length;
    const flag = Math.abs(mean - trueT) > 0.25 ? '  <-- bias' : '';
    console.log('  true ' + trueT.toFixed(1).padStart(5) + '  est ' + mean.toFixed(2).padStart(6) +
      '  bias ' + (mean - trueT).toFixed(2).padStart(6) +
      '  emp.SD ' + sd.toFixed(2) + '  model SE ' + mse.toFixed(2) + flag);
  });
}

/* ---- 2. Does an age-typical performer average 100? ---- */
console.log('\n== Scale centring: a person performing exactly at their age norm ==');
{
  const forms = [];
  for (let f = 0; f < 30; f++) {
    const bat = IQ.battery.build(5000 + f, 'full');
    const g = { gf: [], gc: [], gv: [] };
    bat.sections.forEach(s => (s.items || []).forEach(it => {
      g[it.domain].push({ b: it.b, options: it.optionsHtml.length });
    }));
    forms.push(g);
  }

  function lerp(tbl, x) {
    const k = Object.keys(tbl).map(Number).sort((a, b) => a - b);
    if (x <= k[0]) return tbl[k[0]];
    if (x >= k[k.length - 1]) return tbl[k[k.length - 1]];
    for (let i = 0; i < k.length - 1; i++) {
      if (x >= k[i] && x <= k[i + 1]) {
        const t = (x - k[i]) / (k[i + 1] - k[i]);
        return tbl[k[i]] + t * (tbl[k[i + 1]] - tbl[k[i]]);
      }
    }
  }

  [10, 12, 14, 15, 16, 18, 25, 40, 60, 75].forEach(age => {
    const expSpan = lerp(SC.RAW_NORMS.span.mean, age);
    const expSpeed = lerp(SC.RAW_NORMS.speed.mean, age);
    const scores = [];
    for (let rep = 0; rep < 900; rep++) {
      const g = forms[rep % forms.length];
      const res = {
        spans: { digits: Math.round(expSpan), mixed: Math.round(expSpan) },
        speed: { raw: Math.round(expSpeed) }
      };
      ['gf', 'gc', 'gv'].forEach(d => {
        const trueT = SC.ageTheta(d, age);
        res[d] = g[d].map(it => {
          const c = 1 / it.options;
          const p = c + (1 - c) / (1 + Math.exp(-(trueT - it.b)));
          return { b: it.b, options: it.options, correct: rnd() < p };
        });
      });
      scores.push(SC.score(res, age).fsiq);
    }
    const m = scores.reduce((a, b) => a + b, 0) / scores.length;
    const sd = Math.sqrt(scores.reduce((a, b) => a + (b - m) ** 2, 0) / scores.length);
    const flag = Math.abs(m - 100) > 4 ? '   <-- off centre' : '';
    console.log('  age ' + String(age).padStart(2) + '  mean FSIQ ' + m.toFixed(1).padStart(6) +
      '  (sitting-to-sitting SD ' + sd.toFixed(1) + ')' + flag);
  });
}

/* ---- 3. Does the scale have the right spread? ---- */
console.log('\n== Scale spread: simulate a population of 15-year-olds ==');
{
  const bat = IQ.battery.build(777, 'full');
  const g = { gf: [], gc: [], gv: [] };
  bat.sections.forEach(s => (s.items || []).forEach(it => {
    g[it.domain].push({ b: it.b, options: it.optionsHtml.length });
  }));

  function gauss() {
    let u = 0, v = 0;
    while (u === 0) u = rnd();
    while (v === 0) v = rnd();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  const age = 15, scores = [];
  for (let person = 0; person < 3000; person++) {
    const gFactor = gauss();                       // true general ability, z
    const res = {
      spans: {
        digits: Math.max(2, Math.round(4.9 + 1.3 * (0.75 * gFactor + 0.66 * gauss()))),
        mixed: Math.max(2, Math.round(4.9 + 1.3 * (0.75 * gFactor + 0.66 * gauss())))
      },
      speed: { raw: Math.max(0, Math.round(24 + 7 * (0.6 * gFactor + 0.8 * gauss()))) }
    };
    ['gf', 'gc', 'gv'].forEach(d => {
      // index-specific ability: correlated with g, plus specific variance
      const load = d === 'gf' ? 0.85 : 0.75;
      const z = load * gFactor + Math.sqrt(1 - load * load) * gauss();
      const trueT = SC.ageTheta(d, age) + z;
      res[d] = g[d].map(it => {
        const c = 1 / it.options;
        const p = c + (1 - c) / (1 + Math.exp(-(trueT - it.b)));
        return { b: it.b, options: it.options, correct: rnd() < p };
      });
    });
    scores.push(SC.score(res, age).fsiq);
  }
  scores.sort((a, b) => a - b);
  const m = scores.reduce((a, b) => a + b, 0) / scores.length;
  const sd = Math.sqrt(scores.reduce((a, b) => a + (b - m) ** 2, 0) / scores.length);
  const pct = p => scores[Math.floor(scores.length * p)].toFixed(0);
  console.log('  mean ' + m.toFixed(1) + '  SD ' + sd.toFixed(1) + '   (target: mean 100, SD 15)');
  console.log('  percentiles  2nd=' + pct(.02) + '  16th=' + pct(.16) + '  50th=' + pct(.50) +
    '  84th=' + pct(.84) + '  98th=' + pct(.98));
  console.log('  (target      2nd=70    16th=85     50th=100    84th=115    98th=130)');
  console.log('  share above 130: ' + (100 * scores.filter(s => s >= 130).length / scores.length).toFixed(1) +
    '%   (target ~2.3%)     below 70: ' +
    (100 * scores.filter(s => s <= 70).length / scores.length).toFixed(1) + '%  (target ~2.3%)');
}
