/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   Solvability audit for the number-series generator.

   For every generated item, take the shown terms PLUS the keyed
   answer and try to fit a catalogue of rules to the whole run. If
   no rule fits, the item is unsolvable: there is no relation a
   test-taker could find that produces the answer.

   This is the check that would have caught 3, 3, 9, 26, 234, the
   product rule holds at 3x3=9 and 9x26=234 but breaks at 3x9=27!=26.
   ============================================================ */
const fs = require('fs'), path = require('path'), vm = require('vm');
const ROOT = require('path').join(__dirname, '..');
const sb = { window: {}, console };
sb.globalThis = sb;
vm.createContext(sb);
['js/rng.js', 'js/gen/shapes.js', 'js/gen/series.js']
  .forEach(f => vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), sb, { filename: f }));
const IQ = sb.window.IQ;

const EPS = 1e-9;
const eq = (a, b) => Math.abs(a - b) < 1e-6;

/* ---- rule fitters: each takes the full run and returns true if it fits ---- */

function arithmetic(t) {
  const d = t[1] - t[0];
  return t.every((v, i) => i === 0 || eq(v - t[i - 1], d));
}

function geometric(t) {
  if (Math.abs(t[0]) < EPS) return false;
  const r = t[1] / t[0];
  return t.every((v, i) => i === 0 || eq(v, t[i - 1] * r));
}

function quadratic(t) {
  if (t.length < 4) return false;
  const d2 = [];
  for (let i = 2; i < t.length; i++) d2.push((t[i] - t[i - 1]) - (t[i - 1] - t[i - 2]));
  return d2.every(v => eq(v, d2[0]));
}

function growingDiff(t) {
  // differences themselves form an arithmetic run
  const d = [];
  for (let i = 1; i < t.length; i++) d.push(t[i] - t[i - 1]);
  return d.length >= 3 && arithmetic(d);
}

function fibPlusC(t) {
  if (t.length < 4) return false;
  const c = t[2] - t[1] - t[0];
  for (let i = 2; i < t.length; i++) if (!eq(t[i], t[i - 1] + t[i - 2] + c)) return false;
  return true;
}

function affine(t) {
  // t[i] = k*t[i-1] + c, fitted from the first two steps
  if (t.length < 4) return false;
  const den = t[1] - t[0];
  if (Math.abs(den) < EPS) return false;
  const k = (t[2] - t[1]) / den;
  const c = t[1] - k * t[0];
  for (let i = 1; i < t.length; i++) if (!eq(t[i], k * t[i - 1] + c)) return false;
  return true;
}

function productPair(t) {
  if (t.length < 4) return false;
  const c = t[2] - t[0] * t[1];
  for (let i = 2; i < t.length; i++) if (!eq(t[i], t[i - 1] * t[i - 2] + c)) return false;
  return true;
}

function squaresOffset(t) {
  // t[i] = (s+i)^2 + off
  for (let s = -30; s <= 60; s++) {
    const off = t[0] - s * s;
    let ok = true;
    for (let i = 0; i < t.length; i++) {
      if (!eq(t[i], (s + i) * (s + i) + off)) { ok = false; break; }
    }
    if (ok) return true;
  }
  return false;
}

function interleaved(t) {
  const a = t.filter((_, i) => i % 2 === 0);
  const b = t.filter((_, i) => i % 2 === 1);
  if (a.length < 3 || b.length < 2) return false;
  const fits = s => s.length < 2 || arithmetic(s) || geometric(s) || growingDiff(s);
  return fits(a) && fits(b);
}

/* period-3 cycle of affine maps; each map must appear twice to be identified */
function cyclic3(t) {
  if (t.length < 7) return false;
  const maps = [];
  for (let j = 0; j < 3; j++) {
    // transitions at indices j and j+3
    if (j + 4 >= t.length) return false;
    const x1 = t[j], y1 = t[j + 1], x2 = t[j + 3], y2 = t[j + 4];
    if (Math.abs(x2 - x1) < EPS) return false;          // not identifiable
    const k = (y2 - y1) / (x2 - x1);
    const c = y1 - k * x1;
    maps.push({ k, c });
  }
  for (let i = 0; i + 1 < t.length; i++) {
    const m = maps[i % 3];
    if (!eq(t[i + 1], m.k * t[i] + m.c)) return false;
  }
  return true;
}

const RULES = [
  ['arithmetic', arithmetic], ['geometric', geometric], ['quadratic', quadratic],
  ['growingDiff', growingDiff], ['fibPlusC', fibPlusC], ['affine', affine],
  ['productPair', productPair], ['squaresOffset', squaresOffset],
  ['interleaved', interleaved], ['cyclic3', cyclic3]
];

function explain(t) {
  return RULES.filter(([, f]) => { try { return f(t); } catch (e) { return false; } }).map(([n]) => n);
}

/* ---- audit ---- */
let checked = 0, unsolvable = 0;
const byRule = {};
const failures = [];

for (let i = 0; i < 20000; i++) {
  const rng = IQ.rng.makeRng(400000 + i);
  const it = IQ.gen.series.generate(rng, i % 4);
  if (it.type !== 'series') continue;

  // reconstruct the numeric run: shown terms + the keyed answer
  const shown = it.stemHtml.match(/<span class="term">([^<]+)<\/span>/g)
    .map(s => s.replace(/<[^>]+>/g, ''));
  if (shown.some(s => !/^-?\d+$/.test(s))) continue;         // letter series: skipped
  const ansHtml = it.optionsHtml[it.answer].replace(/<[^>]+>/g, '');
  if (!/^-?\d+$/.test(ansHtml)) continue;

  const run = shown.map(Number).concat([Number(ansHtml)]);
  checked++;
  const fits = explain(run);
  const rule = it.meta && it.meta.rule ? it.meta.rule : '?';
  byRule[rule] = byRule[rule] || { n: 0, bad: 0 };
  byRule[rule].n++;
  if (!fits.length) {
    unsolvable++;
    byRule[rule].bad++;
    if (failures.length < 8) failures.push({ run, rule, b: it.b.toFixed(2) });
  }
}

console.log('Numeric series audited: ' + checked);
console.log('UNSOLVABLE (no rule fits shown terms + keyed answer): ' + unsolvable +
  '  (' + (100 * unsolvable / checked).toFixed(2) + '%)');
console.log('');
console.log('by generating rule:');
Object.keys(byRule).sort().forEach(k => {
  const r = byRule[k];
  const flag = r.bad ? '   <-- ' + r.bad + ' UNSOLVABLE' : '';
  console.log('  ' + (r.bad ? '!' : ' ') + ' ' + k.padEnd(52) + ' n=' + String(r.n).padStart(5) + flag);
});
if (failures.length) {
  console.log('\nexamples of unsolvable items:');
  failures.forEach(f => console.log('  [' + f.run.join(', ') + ']  rule="' + f.rule + '" b=' + f.b));
}
process.exit(unsolvable === 0 ? 0 : 1);
