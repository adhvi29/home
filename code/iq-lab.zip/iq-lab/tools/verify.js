/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* Headless verification harness for IQ Lab generators + scoring */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = require('path').join(__dirname, '..');
const files = [
  'js/rng.js', 'js/gen/shapes.js', 'js/gen/matrix.js', 'js/gen/series.js',
  'js/gen/verbal.js', 'js/gen/spatial.js', 'js/gen/logic.js', 'js/gen/weights.js',
  'js/scoring.js', 'js/battery.js'
];

const sandbox = { window: {}, console, performance: { now: () => Date.now() } };
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
for (const f of files) {
  vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), sandbox, { filename: f });
}
const IQ = sandbox.window.IQ;

let fails = 0;
function check(name, cond, extra) {
  if (!cond) { fails++; console.log('  FAIL  ' + name + (extra ? '  ' + extra : '')); }
}
function head(s) { console.log('\n== ' + s + ' =='); }

/* ---------------- 1. Matrix items ---------------- */
head('Matrix reasoning');
{
  const bByRules = {};
  let optCounts = {};
  for (let i = 0; i < 4000; i++) {
    const rng = IQ.rng.makeRng(1000 + i);
    const nRules = 1 + (i % 4);
    const it = IQ.gen.matrix.generate(rng, nRules);
    check('answer index in range', it.answer >= 0 && it.answer < it.optionsHtml.length, JSON.stringify(it.answer));
    check('has 6 options', it.optionsHtml.length === 6, 'got ' + it.optionsHtml.length);
    const uniq = new Set(it.optionsHtml);
    check('options visually distinct', uniq.size === it.optionsHtml.length, 'dupes at i=' + i);
    check('b finite', isFinite(it.b));
    (bByRules[it.meta.nRules] = bByRules[it.meta.nRules] || []).push(it.b);
    optCounts[it.optionsHtml.length] = (optCounts[it.optionsHtml.length] || 0) + 1;
  }
  for (const k of Object.keys(bByRules).sort()) {
    const a = bByRules[k];
    const m = a.reduce((x, y) => x + y, 0) / a.length;
    console.log('  ' + k + ' rule(s): mean b = ' + m.toFixed(2) +
      '  range ' + Math.min(...a).toFixed(2) + '..' + Math.max(...a).toFixed(2) + '  n=' + a.length);
  }
}

/* ---------------- 2. Series ---------------- */
head('Number series');
{
  const byTier = {};
  for (let i = 0; i < 3000; i++) {
    const rng = IQ.rng.makeRng(50000 + i);
    const tier = i % 4;
    const it = IQ.gen.series.generate(rng, tier);
    check('answer in range', it.answer >= 0 && it.answer < it.optionsHtml.length);
    check('5 options', it.optionsHtml.length === 5, 'got ' + it.optionsHtml.length + ' tier ' + tier);
    check('options distinct', new Set(it.optionsHtml).size === it.optionsHtml.length);
    check('b finite', isFinite(it.b));
    const nums = it.optionsHtml.map(h => h.replace(/<[^>]+>/g, ''));
    check('no NaN/undefined option', nums.every(n => n !== 'NaN' && n !== 'undefined' && n !== ''), nums.join('|'));
    (byTier[tier] = byTier[tier] || []).push(it.b);
  }
  for (const k of Object.keys(byTier).sort()) {
    const a = byTier[k];
    console.log('  tier ' + k + ': mean b = ' + (a.reduce((x, y) => x + y, 0) / a.length).toFixed(2) + '  n=' + a.length);
  }
}

/* ---------------- 3. Spatial ---------------- */
head('Spatial');
{
  let rot = 0, fold = 0;
  for (let i = 0; i < 1500; i++) {
    const rng = IQ.rng.makeRng(90000 + i);
    const tier = i % 4;
    const a = IQ.gen.spatial.rotationItem(rng, tier);
    check('rotation answer in range', a.answer >= 0 && a.answer < a.optionsHtml.length);
    check('rotation options distinct', new Set(a.optionsHtml).size === a.optionsHtml.length, 'i=' + i);
    check('rotation has >=4 options', a.optionsHtml.length >= 4, 'got ' + a.optionsHtml.length);
    rot++;
    const b = IQ.gen.spatial.foldingItem(rng, tier);
    check('folding answer in range', b.answer >= 0 && b.answer < b.optionsHtml.length);
    check('folding options distinct', new Set(b.optionsHtml).size === b.optionsHtml.length, 'i=' + i);
    check('folding has >=4 options', b.optionsHtml.length >= 4, 'got ' + b.optionsHtml.length + ' tier ' + tier);
    fold++;
  }
  console.log('  generated ' + rot + ' rotation + ' + fold + ' folding items');
}

/* ---------------- 4. Logic ---------------- */
head('Logic');
{
  const kinds = {};
  for (let i = 0; i < 3000; i++) {
    const rng = IQ.rng.makeRng(30000 + i);
    const it = IQ.gen.logic.generate(rng, i % 4);
    check('answer in range', it.answer >= 0 && it.answer < it.optionsHtml.length, it.type + ' ' + it.answer);
    check('b finite', isFinite(it.b));
    check('options distinct', new Set(it.optionsHtml).size === it.optionsHtml.length, it.type + ' i=' + i);
    kinds[it.type] = (kinds[it.type] || 0) + 1;
  }
  console.log('  ' + JSON.stringify(kinds));
}

/* ---------------- 5. Verbal ---------------- */
head('Verbal');
{
  for (let i = 0; i < 400; i++) {
    const rng = IQ.rng.makeRng(7000 + i);
    const items = IQ.gen.verbal.build(rng, 14);
    check('built 14', items.length === 14, 'got ' + items.length);
    const seen = new Set();
    items.forEach(it => {
      check('answer in range', it.answer >= 0 && it.answer < it.optionsHtml.length);
      check('options distinct', new Set(it.optionsHtml).size === it.optionsHtml.length, it.type);
      check('no repeat within sitting', !seen.has(it.stemHtml + '#' + it.optionsHtml.slice().sort().join(',')), 'dupe');
      seen.add(it.stemHtml + '#' + it.optionsHtml.slice().sort().join(','));
    });
  }
  console.log('  pool size: ' + IQ.gen.verbal.poolSize + ' items');
}

/* ---------------- 6. Battery assembly ---------------- */
head('Battery');
{
  ['full', 'short', 'reasoning'].forEach(form => {
    const b = IQ.battery.build(12345, form);
    const domains = {};
    b.sections.forEach(s => {
      if (s.items) s.items.forEach(it => { domains[it.domain] = (domains[it.domain] || 0) + 1; });
    });
    console.log('  ' + form + ': ' + b.sections.length + ' sections, ' + b.itemCount + ' items ' + JSON.stringify(domains));
    // determinism
    const b2 = IQ.battery.build(12345, form);
    check(form + ' is deterministic from seed',
      JSON.stringify(b.sections.map(s => (s.items || []).map(i => i.answer))) ===
      JSON.stringify(b2.sections.map(s => (s.items || []).map(i => i.answer))));
  });
}

/* ---------------- 7. Scoring recovery (the real test) ---------------- */
head('Ability recovery, simulated test-takers');
{
  function simulate(trueTheta, items, rnd) {
    return items.map(it => {
      const c = 1 / it.options;
      const p = c + (1 - c) / (1 + Math.exp(-(trueTheta - it.b)));
      return { b: it.b, options: it.options, correct: rnd() < p };
    });
  }

  // build the item difficulty set the real full battery uses
  const bat = IQ.battery.build(4242, 'full');
  const gfItems = [], gcItems = [], gvItems = [];
  bat.sections.forEach(s => {
    if (!s.items) return;
    s.items.forEach(it => {
      const rec = { b: it.b, options: it.optionsHtml.length };
      if (it.domain === 'gf') gfItems.push(rec);
      else if (it.domain === 'gc') gcItems.push(rec);
      else if (it.domain === 'gv') gvItems.push(rec);
    });
  });
  console.log('  item counts  gf=' + gfItems.length + '  gc=' + gcItems.length + '  gv=' + gvItems.length);
  console.log('  gf difficulty range ' + Math.min(...gfItems.map(i => i.b)).toFixed(2) +
    ' .. ' + Math.max(...gfItems.map(i => i.b)).toFixed(2));

  const rnd = IQ.rng.makeRng(777);
  [-2, -1, -0.5, 0, 0.5, 1, 1.5, 2, 2.5].forEach(trueT => {
    const ests = [], ses = [];
    for (let rep = 0; rep < 600; rep++) {
      const r = IQ.scoring.estimateTheta(simulate(trueT, gfItems, rnd));
      ests.push(r.theta); ses.push(r.se);
    }
    const mean = ests.reduce((a, b) => a + b, 0) / ests.length;
    const sd = Math.sqrt(ests.reduce((a, b) => a + (b - mean) ** 2, 0) / ests.length);
    const meanSe = ses.reduce((a, b) => a + b, 0) / ses.length;
    console.log('  true θ=' + trueT.toFixed(1).padStart(5) +
      '  est=' + mean.toFixed(2).padStart(6) +
      '  bias=' + (mean - trueT).toFixed(2).padStart(6) +
      '  empirical SD=' + sd.toFixed(2) +
      '  model SE=' + meanSe.toFixed(2) +
      '  (IQ pts: ' + (meanSe * 15).toFixed(1) + ')');
  });
}

/* ---------------- 8. Full composite for a plausible 15-year-old ---------------- */
head('End-to-end composite');
{
  const rnd = IQ.rng.makeRng(31337);
  const bat = IQ.battery.build(999, 'full');
  const items = { gf: [], gc: [], gv: [] };
  bat.sections.forEach(s => {
    if (!s.items) return;
    s.items.forEach(it => items[it.domain].push({ b: it.b, options: it.optionsHtml.length }));
  });

  function oneSitting(trueTheta, age, spanD, spanM, speedRaw) {
    const res = { spans: { digits: spanD, mixed: spanM }, speed: { raw: speedRaw } };
    ['gf', 'gc', 'gv'].forEach(d => {
      res[d] = items[d].map(it => {
        const c = 1 / it.options;
        const p = c + (1 - c) / (1 + Math.exp(-(trueTheta - it.b)));
        return { b: it.b, options: it.options, correct: rnd() < p };
      });
    });
    return IQ.scoring.score(res, age);
  }

  /* A single sitting has a standard error of ~5 points, so asserting on one
     draw is a coin flip. Average over many so the check tests calibration
     rather than luck. */
  function sitting(trueTheta, age, spanD, spanM, speedRaw) {
    const reps = 400;
    let sum = 0, last = null;
    for (let i = 0; i < reps; i++) {
      last = oneSitting(trueTheta, age, spanD, spanM, speedRaw);
      sum += last.fsiq;
    }
    last.fsiq = sum / reps;             // report the expected score
    last.ci = [last.fsiq - last.band90, last.fsiq + last.band90];
    last.percentile = IQ.scoring.percentile((last.fsiq - 100) / 15);
    last.classification = IQ.scoring.classify(last.fsiq);
    return last;
  }

  console.log('  A 15-year-old performing exactly at the ADULT average (θ=0), span 5/5, speed 26:');
  const s1 = sitting(0, 15, 5, 5, 26);
  console.log('    FSIQ ' + s1.fsiq.toFixed(1) + '  [' + s1.ci[0].toFixed(0) + '-' + s1.ci[1].toFixed(0) + ']  ' +
    s1.percentile + 'th  ' + s1.classification);
  console.log('    indices: ' + IQ.scoring.INDEX_ORDER.map(k => k + '=' + s1.indices[k].iq.toFixed(0)).join(' '));
  check('15yo at adult average scores clearly above 100', s1.fsiq > 103, 'got ' + s1.fsiq.toFixed(1));

  console.log('  A 15-year-old at the typical level FOR 15 (θ=-0.38), span 4.8~5, speed 23:');
  const s2 = sitting(-0.38, 15, 5, 4, 23);
  console.log('    FSIQ ' + s2.fsiq.toFixed(1) + '  [' + s2.ci[0].toFixed(0) + '-' + s2.ci[1].toFixed(0) + ']  ' + s2.percentile + 'th');
  check('typical-for-age lands near 100', Math.abs(s2.fsiq - 100) < 9, 'got ' + s2.fsiq.toFixed(1));

  console.log('  A 30-year-old at the adult average (θ=0), span 5/5, speed 25:');
  const s3 = sitting(0, 30, 5, 5, 25);
  console.log('    FSIQ ' + s3.fsiq.toFixed(1) + '  [' + s3.ci[0].toFixed(0) + '-' + s3.ci[1].toFixed(0) + ']  ' + s3.percentile + 'th');
  check('adult average lands near 100', Math.abs(s3.fsiq - 100) < 7, 'got ' + s3.fsiq.toFixed(1));

  console.log('  A strong 15-year-old (θ=1.4), span 7/6, speed 32:');
  const s4 = sitting(1.4, 15, 7, 6, 32);
  console.log('    FSIQ ' + s4.fsiq.toFixed(1) + '  [' + s4.ci[0].toFixed(0) + '-' + s4.ci[1].toFixed(0) + ']  ' + s4.percentile + 'th  ' + s4.classification);

  console.log('  measurement SE = ' + (s1.seMeasure * 15).toFixed(1) + ' IQ pts, ' +
    'calibration SE = ' + (s1.seCalibration * 15).toFixed(1) + ' pts, reliability = ' + s1.reliability.toFixed(2));

  const cmp = IQ.scoring.compare(s2, s4);
  console.log('  reliable-change threshold between two full sittings: ' + cmp.threshold.toFixed(1) + ' pts');
  check('threshold is plausible', cmp.threshold > 5 && cmp.threshold < 20, 'got ' + cmp.threshold.toFixed(1));
}

/* ---------------- 9. Percentile sanity ---------------- */
head('Percentile mapping');
{
  [[100, '50'], [115, '84'], [130, '98'], [85, '16'], [70, '2']].forEach(([iq, want]) => {
    const got = IQ.scoring.percentile((iq - 100) / 15);
    console.log('  IQ ' + iq + ' -> ' + got + 'th (expect ~' + want + ')');
  });
}

console.log('\n' + (fails === 0 ? 'ALL CHECKS PASSED' : fails + ' CHECK FAILURES'));
process.exit(fails === 0 ? 0 : 1);
