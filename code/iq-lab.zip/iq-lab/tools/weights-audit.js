/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * IQ Lab - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   Solvability audit for Figure Weights.

   An item is only fair if the premises force ONE answer. This
   re-derives that from scratch, ignoring the secret weights the
   generator used:

   1. Solve the premise system for the space of all weight vectors
      consistent with the scales shown.
   2. For every option, check whether it balances the question pan
      under EVERY consistent weight vector (correct), under none
      (a clean distractor), or under some but not others (ambiguous
      the item would have more than one defensible answer).
   ============================================================ */
const fs = require('fs'), path = require('path'), vm = require('vm');
const ROOT = require('path').join(__dirname, '..');
const sb = { window: {}, console };
sb.globalThis = sb;
vm.createContext(sb);
['js/rng.js', 'js/gen/shapes.js', 'js/gen/weights.js']
  .forEach(f => vm.runInContext(fs.readFileSync(path.join(ROOT, f), 'utf8'), sb, { filename: f }));
const IQ = sb.window.IQ;

/* Parse an item back out of its rendered SVG, so the audit tests what the
   test-taker actually sees rather than the generator's internal state. */
function parseGroups(svg) {
  // each object is <g class="fw-oN">
  const counts = {};
  const re = /class="fw-o(\d)"/g;
  let m;
  while ((m = re.exec(svg))) counts[m[1]] = (counts[m[1]] || 0) + 1;
  return counts;
}

function scalePans(scaleSvg) {
  // two <g transform="translate(...)"> groups: left pan then right pan
  const parts = scaleSvg.split(/<g transform="translate\(/).slice(1);
  return parts.map(p => parseGroups(p.split('</g></svg>')[0]));
}

function toVec(counts, n) {
  const v = new Array(n).fill(0);
  Object.keys(counts).forEach(k => { v[Number(k)] = counts[k]; });
  return v;
}

/* Null-space basis of the premise matrix, by Gaussian elimination */
function nullSpace(rows, n) {
  const m = rows.map(r => r.slice());
  const pivotOf = [];
  let rk = 0;
  for (let col = 0; col < n && rk < m.length; col++) {
    let piv = -1, best = 1e-9;
    for (let r = rk; r < m.length; r++) {
      if (Math.abs(m[r][col]) > best) { best = Math.abs(m[r][col]); piv = r; }
    }
    if (piv < 0) continue;
    [m[rk], m[piv]] = [m[piv], m[rk]];
    const p = m[rk][col];
    for (let c = 0; c < n; c++) m[rk][c] /= p;
    for (let r = 0; r < m.length; r++) {
      if (r === rk) continue;
      const f = m[r][col];
      if (Math.abs(f) < 1e-12) continue;
      for (let c = 0; c < n; c++) m[r][c] -= f * m[rk][c];
    }
    pivotOf.push(col);
    rk++;
  }
  const free = [];
  for (let c = 0; c < n; c++) if (pivotOf.indexOf(c) < 0) free.push(c);
  return free.map(fc => {
    const v = new Array(n).fill(0);
    v[fc] = 1;
    pivotOf.forEach((pc, ri) => { v[pc] = -m[ri][fc]; });
    return v;
  });
}

let checked = 0, ambiguous = 0, noUnique = 0, wrongKey = 0, badNull = 0;
const examples = [];

for (let i = 0; i < 6000; i++) {
  const rng = IQ.rng.makeRng(880000 + i);
  const it = IQ.gen.weights.generate(rng, i % 4);
  checked++;

  const scales = it.stemHtml.match(/<svg class="fig fw-scale"[\s\S]*?<\/svg>/g) || [];
  if (scales.length < 2) { badNull++; continue; }
  const N = 5;
  const premiseVecs = [];
  for (let s = 0; s < scales.length - 1; s++) {
    const pans = scalePans(scales[s]);
    const L = toVec(pans[0] || {}, N), R = toVec(pans[1] || {}, N);
    premiseVecs.push(L.map((v, k) => v - R[k]));
  }
  const qPans = scalePans(scales[scales.length - 1]);
  const qLeft = toVec(qPans[0] || {}, N);

  const basis = nullSpace(premiseVecs, N);
  // restrict to the objects actually used anywhere in the item
  const used = new Array(N).fill(false);
  premiseVecs.forEach(v => v.forEach((x, k) => { if (x !== 0) used[k] = true; }));
  qLeft.forEach((x, k) => { if (x !== 0) used[k] = true; });
  it.optionsHtml.forEach(o => {
    const c = parseGroups(o);
    Object.keys(c).forEach(k => { used[Number(k)] = true; });
  });

  // sample weight vectors from the consistent space and test each option
  const samples = [];
  for (let t = 0; t < 40; t++) {
    const coef = basis.map(() => 1 + Math.random() * 4);
    const v = new Array(N).fill(0);
    basis.forEach((bv, bi) => bv.forEach((x, k) => { v[k] += coef[bi] * x; }));
    if (v.some((x, k) => used[k] && x <= 1e-9)) continue;   // weights must be positive
    samples.push(v);
  }
  if (!samples.length) { badNull++; continue; }

  const verdicts = it.optionsHtml.map(o => {
    const vec = toVec(parseGroups(o), N);
    let bal = 0;
    samples.forEach(w => {
      const lw = qLeft.reduce((a, x, k) => a + x * w[k], 0);
      const rw = vec.reduce((a, x, k) => a + x * w[k], 0);
      if (Math.abs(lw - rw) < 1e-6 * Math.max(1, lw)) bal++;
    });
    return bal === samples.length ? 'always' : bal === 0 ? 'never' : 'sometimes';
  });

  const alwaysIdx = verdicts.map((v, j) => v === 'always' ? j : -1).filter(j => j >= 0);
  const someIdx = verdicts.filter(v => v === 'sometimes').length;

  if (someIdx > 0) { ambiguous++; if (examples.length < 5) examples.push({ i, why: 'option balances under some consistent weights but not others', verdicts }); }
  else if (alwaysIdx.length !== 1) { noUnique++; if (examples.length < 5) examples.push({ i, why: alwaysIdx.length + ' options always balance', verdicts }); }
  else if (alwaysIdx[0] !== it.answer) { wrongKey++; if (examples.length < 5) examples.push({ i, why: 'keyed answer ' + it.answer + ' but solution is ' + alwaysIdx[0], verdicts }); }
}

console.log('Figure Weights items audited: ' + checked);
console.log('  ambiguous (answer depends on unconstrained weights): ' + ambiguous);
console.log('  no unique solution (0 or >1 options balance):        ' + noUnique);
console.log('  keyed answer disagrees with the derivation:          ' + wrongKey);
console.log('  unparseable:                                        ' + badNull);
const bad = ambiguous + noUnique + wrongKey + badNull;
console.log('\n' + (bad === 0 ? 'ALL ITEMS HAVE EXACTLY ONE DERIVABLE ANSWER' : bad + ' PROBLEM ITEMS'));
examples.forEach(e => console.log('  seed#' + e.i + ': ' + e.why + '  [' + e.verdicts.join(',') + ']'));
process.exit(bad === 0 ? 0 : 1);
