@REM Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
@REM Lumina - https://github.com/adhvi29
@REM You may view and run this code for personal and educational use only.
@REM You may not copy it into other projects, redistribute, sell, or present
@REM it as your own work without written permission from the author.
@REM Removing or changing this notice is not permitted. See LICENSE.txt.
@echo off
rem  Double-click to install Lumina as a real Windows app
rem  (Start-menu search, desktop shortcut, Settings > Apps).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
pause
