@REM Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
@REM Lumina - https://github.com/adhvi29
@REM You may view and run this code for personal and educational use only.
@REM You may not copy it into other projects, redistribute, sell, or present
@REM it as your own work without written permission from the author.
@REM Removing or changing this notice is not permitted. See LICENSE.txt.
@echo off
rem  Lumina - private diary desktop app launcher
cd /d "%~dp0"

rem  Make sure pywebview is installed (first run only)
python -c "import webview" >nul 2>&1
if errorlevel 1 (
    echo Installing Lumina's window engine ^(pywebview^) - one time only...
    python -m pip install --user pywebview
)

rem  Launch in its own window with no console (pythonw)
start "" pythonw lumina_app.py
