> Copyright (c) 2026 Adhvik Mahesh. All rights reserved.  
> Lumina - https://github.com/adhvi29  
> You may view and run this code for personal and educational use only.  
> You may not copy it into other projects, redistribute, sell, or present  
> it as your own work without written permission from the author.  
> Removing or changing this notice is not permitted. See LICENSE.txt.

# 📖 Lumina, A World-Class Premium Diary

A beautiful, private, feature-rich journaling web app. No accounts, no servers, no tracking, everything lives on your device in `localStorage`. Built with vanilla HTML, CSS, and JavaScript (zero dependencies, zero build step).

![Lumina](https://img.shields.io/badge/dependencies-none-success) ![Lumina](https://img.shields.io/badge/build-none-success) ![Lumina](https://img.shields.io/badge/privacy-100%25%20local-blueviolet)

---

## ✨ Features

### Writing experience
- **Rich text editor**, bold, italic, underline, headings, quotes, bullet & numbered lists, highlight, clear formatting
- **Mood tracking**, 9 expressive moods, each with its own color that flows through cards & the calendar
- **Weather tracking**, capture the sky over each entry
- **Tags**, organize entries with hashtags; type and press Enter
- **Writing prompts**, 20 thoughtful prompts to beat the blank page, shuffle for a new one
- **Photo attachments**, add photos to any entry; the first becomes the card's cover, with a tap-to-zoom lightbox (images are auto-compressed to stay light)
- **Live stats**, word count, character count, and reading time as you type
- **Autosave**, every keystroke is quietly saved; never lose a thought

### Organize & rediscover
- **Diary timeline**, entries grouped by month, pinned notes float to the top
- **Instant search**, filter your whole journal as you type (press `/`)
- **Filter & sort**, by mood, by tag, newest / oldest / A, Z / longest
- **Favorites**, star the entries that matter most
- **Calendar view**, see your month at a glance, color-coded by mood
- **On this day**, revisit entries from previous years
- **Insights dashboard**, total entries, words written, current & longest streaks, mood distribution, a weekly writing-rhythm chart, a 26-week consistency heatmap, and your most-used tags

### Premium & private
- **Dark / Light / Auto themes** with smooth transitions
- **6 accent palettes**, Aurora, Sunset, Rose, Ocean, Forest, Gold
- **PIN lock**, protect your diary with a 4-digit PIN, plus a **Lock tab** to lock instantly anytime
- **Auto-lock**, automatically lock after 1 / 5 / 15 / 30 minutes of inactivity
- **Daily writing reminder**, a gentle nudge (browser notification + in-app banner) at a time you choose, if you haven't written that day
- **Starts empty & real**, no demo content; every entry is one you actually wrote
- **Export / Import**, download your whole journal as JSON, restore anytime
- **Writing streaks**, gamified consistency to keep the habit alive
- **Gorgeous design**, glassmorphism, an ambient animated backdrop, premium serif typography, and delightful micro-interactions
- **Fully responsive**, looks great on desktop, tablet, and phone
- **Keyboard shortcuts**`/` search · `n` new entry · `Ctrl/⌘+S` save · `Esc` close
- **Accessible**, respects `prefers-reduced-motion`

### 🤖 Lumi, built-in AI assistant
A dedicated **Lumi** tab adds an AI study companion. Pick your engine in setup or Settings (your key/token is stored only on your device):
- **Hugging Face**, free access token from [huggingface.co/settings/tokens](https://huggingface.co/settings/tokens)
- **Puter**, no key at all, works instantly
- **Google Gemini**, free API key from Google AI Studio

Lumi can **chat** (streaming replies, Markdown), **create images** from a prompt (and save them straight into a diary entry), generate **flashcards**, run interactive **quizzes** with scoring, **summarize** notes into study guides, and build day-by-day **study plans**. The AI provider is a single swappable module (`js/ai.js`). Your diary stays 100% local, only what you type into Lumi is sent to the provider.

---

## 🚀 Running it

### ⭐ Install it as an *always-current* app (recommended)
Double-click **`Install Lumina (Always Current).bat`**. Same real-app integration (Start-menu search, desktop icon, Settings → Apps), but the shortcuts launch the **live** app, so **any update shows up the next time you open it. No rebuilding, ever.** (Uses Python, which you have.)

### 📌 Install the frozen .exe version
Double-click **`Install Lumina.bat`** to install the standalone `dist/Lumina.exe` (no Python needed to run). Because it's a frozen snapshot, you must re-run `build_exe.bat` **and** re-install after changes. It registers with Windows the same way, **100% free, no admin needed**:
- 🔎 **Shows up in Start-menu search**, tap `⊞ Win`, type "Lumina"
- 🖥️ **Desktop shortcut** (with the app icon), pin it to Start or the taskbar
- ⚙️ **Listed in Settings → Apps**, uninstall cleanly anytime (your diary data is kept)

Installs to `%LOCALAPPDATA%\Programs\Lumina\`; your entries live in `%LOCALAPPDATA%\Lumina\`.
*(First launch, Windows SmartScreen may say "unknown publisher" since the app isn't code-signed, click **More info → Run anyway**. Normal for self-built apps.)*

### 🏆 Or just run the standalone .exe
There's a prebuilt **`dist/Lumina.exe`**, **double-click it**, no Python, no install. To rebuild after changing the app, double-click **`build_exe.bat`**.

### 🖥️ As a native window via Python
Lumina also ships a native-window launcher (via [pywebview](https://pywebview.flowlib.org/)), runs in its **own window**, no browser.

```bash
pip install pywebview      # one time
```
Then **double-click `Lumina.bat`** (Windows), or run `pythonw lumina_app.py`.

- Opens in a real app window (uses the Microsoft **Edge WebView2** runtime, preinstalled on Win 11 / updated Win 10).
- Your entries persist in a local `.lumina-store/` folder beside the app.
- Fonts are **bundled locally**, so it works with **no internet connection at all**. *(Only the optional Lumi AI tab ever reaches the network, and only when you use it.)*

### 🌐 Or in a browser
- **Just open it:** double-click `index.html`. *(Some browsers limit `localStorage` on `file://`; if entries don't persist, serve it instead.)*
- **Serve locally:** `python -m http.server 5050 --directory lumina-diary` → open `http://localhost:5050`

---

## 🗂️ Project structure

```
lumina-diary/
├── index.html        # App shell & markup
├── Lumina.bat        # Double-click launcher (Windows desktop app)
├── lumina_app.py     # pywebview native-window launcher
├── requirements.txt  # pywebview
├── fonts/            # Locally-bundled fonts (fully offline) + fonts.css
├── css/
│   └── styles.css    # Design system, themes, components, responsive
└── js/
    ├── icons.js      # Moods, weather, accents, prompts, quotes (config)
    ├── store.js      # State, localStorage persistence, queries & statistics
    ├── ai.js         # Lumi AI provider layer (Hugging Face / Puter / Gemini)
    └── app.js        # Views, editor, Home, command palette, Lumi, routing
```

## 🔒 Privacy

Lumina never sends your words anywhere. All data is stored locally in your browser. Export regularly to keep your own backups. The only network request is to Google Fonts for typography.

---

*Made with care. Your story, beautifully kept.*
