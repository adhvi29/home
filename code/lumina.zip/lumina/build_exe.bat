@REM Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
@REM Lumina - https://github.com/adhvi29
@REM You may view and run this code for personal and educational use only.
@REM You may not copy it into other projects, redistribute, sell, or present
@REM it as your own work without written permission from the author.
@REM Removing or changing this notice is not permitted. See LICENSE.txt.
@echo off
rem  Build Lumina into a single double-click .exe (the result needs no Python).
cd /d "%~dp0"

echo Installing build tools (one time)...
python -m pip install --user pyinstaller pywebview Pillow

echo.
echo Building Lumina.exe  -  this can take a minute or two...
python -m PyInstaller --noconfirm --onefile --windowed --name Lumina ^
  --icon lumina.ico ^
  --add-data "index.html;." ^
  --add-data "css;css" ^
  --add-data "js;js" ^
  --add-data "fonts;fonts" ^
  --collect-all webview ^
  lumina_app.py

echo.
echo ============================================================
echo  Done!  Your app is here:   dist\Lumina.exe
echo  Double-click it to run - no Python required.
echo ============================================================
pause
