# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Lumina - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Generates lumina.ico, a gradient rounded square with a serif 'L'. Build-time helper."""
from PIL import Image, ImageDraw, ImageFont

S = 256
img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(img)

# vertical gradient: teal -> indigo (the 'aurora' accent)
top, bot = (94, 234, 212), (129, 140, 248)
for y in range(S):
    t = y / (S - 1)
    d.line([(0, y), (S, y)], fill=(
        int(top[0] * (1 - t) + bot[0] * t),
        int(top[1] * (1 - t) + bot[1] * t),
        int(top[2] * (1 - t) + bot[2] * t), 255))

# rounded-corner mask
mask = Image.new("L", (S, S), 0)
ImageDraw.Draw(mask).rounded_rectangle([0, 0, S - 1, S - 1], radius=56, fill=255)
img.putalpha(mask)

# serif "L"
font = None
for path in ("C:/Windows/Fonts/georgiab.ttf", "C:/Windows/Fonts/georgia.ttf", "C:/Windows/Fonts/timesbd.ttf"):
    try:
        font = ImageFont.truetype(path, 172)
        break
    except OSError:
        continue
if font is None:
    font = ImageFont.load_default()

d = ImageDraw.Draw(img)
bbox = d.textbbox((0, 0), "L", font=font)
w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
d.text(((S - w) / 2 - bbox[0], (S - h) / 2 - bbox[1] - 6), "L", font=font, fill=(255, 255, 255, 238))

img.save("lumina.ico", sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print("icon saved -> lumina.ico")
