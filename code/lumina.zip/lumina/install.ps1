# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Lumina - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

# ============================================================
#  Lumina installer - registers the app with Windows so it
#  shows up in Start-menu search, on the desktop, and in
#  Settings > Apps. 100% built-in tools, no admin needed.
# ============================================================
$ErrorActionPreference = 'Stop'
$src = $PSScriptRoot

$exeSrc = Join-Path $src 'dist\Lumina.exe'
if (-not (Test-Path $exeSrc)) {
    Write-Host "Could not find dist\Lumina.exe - run build_exe.bat first." -ForegroundColor Red
    exit 1
}
$icoSrc = Join-Path $src 'lumina.ico'

# 1) Copy the app into a per-user Programs folder
$installDir = Join-Path $env:LOCALAPPDATA 'Programs\Lumina'
New-Item -ItemType Directory -Force $installDir | Out-Null
Copy-Item $exeSrc (Join-Path $installDir 'Lumina.exe') -Force
if (Test-Path $icoSrc) { Copy-Item $icoSrc (Join-Path $installDir 'lumina.ico') -Force }

$exe = Join-Path $installDir 'Lumina.exe'
$ico = Join-Path $installDir 'lumina.ico'
$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
$desktop = [Environment]::GetFolderPath('Desktop')

# 2) Create shortcuts (Start menu -> searchable; Desktop -> icon)
$ws = New-Object -ComObject WScript.Shell
function New-Lnk($path) {
    $s = $ws.CreateShortcut($path)
    $s.TargetPath = $exe
    $s.WorkingDirectory = $installDir
    $s.IconLocation = "$ico,0"
    $s.Description = 'Lumina - your private diary'
    $s.Save()
}
New-Lnk (Join-Path $startMenu 'Lumina.lnk')
New-Lnk (Join-Path $desktop 'Lumina.lnk')

# 3) Register in Settings > Apps (per-user, so it's a real "installed" app)
$key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Lumina'
New-Item -Path $key -Force | Out-Null
Set-ItemProperty $key DisplayName    'Lumina'
Set-ItemProperty $key DisplayIcon    $ico
Set-ItemProperty $key DisplayVersion '1.0'
Set-ItemProperty $key Publisher      'Lumina (self-built)'
Set-ItemProperty $key InstallLocation $installDir
Set-ItemProperty $key UninstallString ('"{0}\uninstall.bat"' -f $installDir)
Set-ItemProperty $key NoModify 1
Set-ItemProperty $key NoRepair 1

# 4) Write an uninstaller (keeps your diary data in %LOCALAPPDATA%\Lumina)
$uninstPs = @'
$ErrorActionPreference = 'SilentlyContinue'
Remove-Item -Force (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Lumina.lnk')
Remove-Item -Force (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Lumina.lnk')
Remove-Item -Recurse -Force 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Lumina'
$dir = Join-Path $env:LOCALAPPDATA 'Programs\Lumina'
Set-Location $env:TEMP
Start-Sleep 1
Remove-Item -Recurse -Force $dir
Write-Host 'Lumina uninstalled. (Your diary data was kept in %LOCALAPPDATA%\Lumina.)'
'@
Set-Content (Join-Path $installDir 'uninstall.ps1') $uninstPs -Encoding UTF8

$uninstBat = @'
@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
'@
Set-Content (Join-Path $installDir 'uninstall.bat') $uninstBat -Encoding ASCII

Write-Host ""
Write-Host "  Lumina is installed! " -ForegroundColor Green
Write-Host "  - Tap the Windows key and type 'Lumina' to find it in search"
Write-Host "  - Or use the new desktop shortcut (you can pin it to taskbar/Start)"
Write-Host "  - Uninstall anytime from Settings > Apps, or run uninstall.bat"
Write-Host ""
