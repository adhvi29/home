# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Lumina - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

# ============================================================
#  Lumina - "always current" installer.
#  Registers Lumina with Windows (Start search, desktop, Apps),
#  but the shortcuts launch the LIVE app from this folder - so
#  any update shows up the next time you open it. No rebuilds.
#  (Needs Python, which you have. No admin required.)
# ============================================================
$ErrorActionPreference = 'Stop'
$proj   = $PSScriptRoot
$script = Join-Path $proj 'lumina_app.py'
$ico    = Join-Path $proj 'lumina.ico'

if (-not (Test-Path $script)) { Write-Host "lumina_app.py not found in $proj" -ForegroundColor Red; exit 1 }

# Resolve python / pythonw (pythonw = no console window)
$py = (Get-Command python -ErrorAction SilentlyContinue).Source
if (-not $py) { Write-Host "Python isn't on PATH - install Python first." -ForegroundColor Red; exit 1 }
$pyw = Join-Path (Split-Path $py) 'pythonw.exe'
if (-not (Test-Path $pyw)) { $pyw = $py }

# Make sure pywebview is installed
& python -c "import webview" 2>$null
if ($LASTEXITCODE -ne 0) { Write-Host "Installing pywebview (one time)..."; & python -m pip install --user --quiet pywebview }

# Shortcuts -> launch the live app
$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
$desktop   = [Environment]::GetFolderPath('Desktop')
$ws = New-Object -ComObject WScript.Shell
function New-Lnk($path) {
    $s = $ws.CreateShortcut($path)
    $s.TargetPath = $pyw
    $s.Arguments = ('"{0}"' -f $script)
    $s.WorkingDirectory = $proj
    if (Test-Path $ico) { $s.IconLocation = "$ico,0" }
    $s.Description = 'Lumina - your private diary'
    $s.Save()
}
New-Lnk (Join-Path $startMenu 'Lumina.lnk')
New-Lnk (Join-Path $desktop 'Lumina.lnk')

# Uninstaller (in the data folder; leaves your diary + app files alone)
$dataDir = Join-Path $env:LOCALAPPDATA 'Lumina'
New-Item -ItemType Directory -Force $dataDir | Out-Null
$uninst = @'
$ErrorActionPreference='SilentlyContinue'
Remove-Item -Force (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Lumina.lnk')
Remove-Item -Force (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Lumina.lnk')
Remove-Item -Recurse -Force 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Lumina'
Write-Host 'Lumina uninstalled. (Your diary data and app files were kept.)'
'@
Set-Content (Join-Path $dataDir 'uninstall.ps1') $uninst -Encoding UTF8

# Register in Settings > Apps
$key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Lumina'
New-Item -Path $key -Force | Out-Null
Set-ItemProperty $key DisplayName    'Lumina'
Set-ItemProperty $key DisplayIcon    $ico
Set-ItemProperty $key DisplayVersion '1.0'
Set-ItemProperty $key Publisher      'Lumina (self-built)'
Set-ItemProperty $key InstallLocation $proj
Set-ItemProperty $key UninstallString ('powershell -NoProfile -ExecutionPolicy Bypass -File "{0}\uninstall.ps1"' -f $dataDir)
Set-ItemProperty $key NoModify 1
Set-ItemProperty $key NoRepair 1

Write-Host ""
Write-Host "  Lumina installed (always-current mode)!" -ForegroundColor Green
Write-Host "  - Press Win and type 'Lumina', or use the desktop icon"
Write-Host "  - It runs the live app from:  $proj"
Write-Host "  - Every update now shows up next time you open it. No rebuilds!"
Write-Host ""
