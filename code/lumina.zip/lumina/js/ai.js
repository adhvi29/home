/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * Lumina - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   LUMINA · AI provider layer (multi-provider, swappable)
   Providers:
     • puter, no API key, free (loads js.puter.com on demand)
     • hf, Hugging Face (free access token)
     • gemini, Google Gemini (free API key)
   The app only depends on this interface:
     AI.provider() · AI.ready() · AI.chatStream() · AI.complete()
     AI.completeJSON() · AI.generateImage()
   Global: window.AI
   ============================================================ */
window.AI = (function () {
  const S = () => (window.Store ? window.Store.getSettings() : {});

  function provider() { return S().aiProvider || 'puter'; }
  function hfToken() { return (S().hfToken || '').trim(); }
  function geminiKey() { return (S().geminiKey || '').trim(); }

  function ready() {
    const p = provider();
    if (p === 'puter') return true;          // no key needed
    if (p === 'hf') return !!hfToken();
    if (p === 'gemini') return !!geminiKey();
    return false;
  }

  function buildMessages(thread, system) {
    const out = [];
    if (system) out.push({ role: 'system', content: system });
    thread.filter(m => m && (m.text != null && m.text !== '' || (m.images && m.images.length)))
      .forEach(m => {
        const role = m.role === 'model' ? 'assistant' : 'user';
        if (role === 'user' && m.images && m.images.length) {
          const content = [];
          if (m.text) content.push({ type: 'text', text: String(m.text) });
          m.images.forEach(d => content.push({ type: 'image_url', image_url: { url: d } }));
          out.push({ role, content });
        } else {
          out.push({ role, content: String(m.text || '') });
        }
      });
    return out;
  }
  function parseDataUrl(d) { const m = /^data:([^;]+);base64,(.*)$/.exec(d || ''); return m ? { mime: m[1], data: m[2] } : null; }

  function blobToDataURL(blob) {
    return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(blob); });
  }

  function parseLooseJSON(raw) {
    let s = (raw || '').trim().replace(/^```(?:json)?/i, '').replace(/```$/i, '').trim();
    const m = s.match(/[\[{][\s\S]*[\]}]/); if (m) s = m[0];
    return JSON.parse(s);
  }

  /* ===================== PUTER (no key) ===================== */
  let puterPromise = null;
  function loadPuter() {
    if (window.puter) return Promise.resolve();
    if (puterPromise) return puterPromise;
    puterPromise = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://js.puter.com/v2/';
      s.onload = () => { try { if (window.puter) window.puter.quiet = true; } catch (e) {} resolve(); };
      s.onerror = () => { puterPromise = null; reject(new Error('Could not load Puter (check your connection).')); };
      document.head.appendChild(s);
    });
    return puterPromise;
  }
  function puterText(resp) {
    if (resp == null) return '';
    if (typeof resp === 'string') return resp;
    if (resp.message && resp.message.content != null) {
      const c = resp.message.content;
      return typeof c === 'string' ? c : (Array.isArray(c) ? c.map(x => x.text || '').join('') : String(c));
    }
    if (resp.text) return resp.text;
    if (resp.content) return resp.content;
    return String(resp);
  }
  async function puterChat(thread, system) {
    await loadPuter();
    const resp = await puter.ai.chat(buildMessages(thread, system), { model: 'gpt-4o-mini' });
    return puterText(resp).trim();
  }
  async function puterStream(thread, system, onToken) {
    await loadPuter();
    let full = '';
    try {
      const resp = await puter.ai.chat(buildMessages(thread, system), { model: 'gpt-4o-mini', stream: true });
      for await (const part of resp) {
        const t = (part && (part.text || (part.message && part.message.content))) || '';
        if (t) { full += t; onToken && onToken(t, full); }
      }
      if (full.trim()) return full;
    } catch (e) { /* fall back to non-streaming */ }
    const text = await puterChat(thread, system);
    onToken && onToken(text, text);
    return text;
  }
  async function puterImage(prompt) {
    await loadPuter();
    const res = await puter.ai.txt2img(prompt);
    let src = '';
    if (typeof res === 'string') src = res;
    else if (res instanceof HTMLImageElement) src = res.src;
    else if (res && res.src) src = res.src;
    if (!src) throw new Error('No image was returned.');
    return { image: src, text: '' };
  }

  /* ===================== HUGGING FACE ====================== */
  const HF_CHAT_MODEL = 'meta-llama/Llama-3.1-8B-Instruct';
  const HF_IMAGE_MODEL = 'black-forest-labs/FLUX.1-schnell';
  function hfErr(status, raw) {
    if (status === 401 || status === 403) return 'Invalid or missing Hugging Face token.';
    if (status === 402) return 'Hugging Face free credits are used up for now.';
    if (status === 429) return 'Rate limited by Hugging Face, wait a moment and retry.';
    if (status === 503) return raw || 'Model is warming up, try again in a few seconds.';
    return raw || `Hugging Face request failed (${status}).`;
  }
  async function hfChat(thread, system, onToken) {
    if (!hfToken()) throw new Error('Add your Hugging Face token in Settings.');
    const res = await fetch('https://router.huggingface.co/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + hfToken() },
      body: JSON.stringify({ model: HF_CHAT_MODEL, messages: buildMessages(thread, system), stream: !!onToken }),
    });
    if (!res.ok) { const t = await res.text().catch(() => ''); throw new Error(hfErr(res.status, safeMsg(t))); }
    if (onToken && res.body) {
      const reader = res.body.getReader(); const dec = new TextDecoder(); let buf = '', full = '';
      while (true) {
        const { done, value } = await reader.read(); if (done) break;
        buf += dec.decode(value, { stream: true });
        let nl; while ((nl = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, nl).trim(); buf = buf.slice(nl + 1);
          if (!line.startsWith('data:')) continue;
          const p = line.slice(5).trim(); if (!p || p === '[DONE]') continue;
          try { const o = JSON.parse(p); const t = o.choices && o.choices[0] && o.choices[0].delta && o.choices[0].delta.content; if (t) { full += t; onToken(t, full); } } catch (_) {}
        }
      }
      return full;
    }
    const data = await res.json();
    return (data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || '';
  }
  async function hfImage(prompt) {
    if (!hfToken()) throw new Error('Add your Hugging Face token in Settings.');
    // Use the router host (allows browser CORS); api-inference.huggingface.co does not.
    const res = await fetch('https://router.huggingface.co/hf-inference/models/' + HF_IMAGE_MODEL, {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + hfToken(), 'Content-Type': 'application/json', 'Accept': 'image/png' },
      body: JSON.stringify({ inputs: prompt }),
    });
    if (!res.ok) {
      let msg = `Request failed (${res.status})`;
      try { const j = await res.json(); if (j.error) msg = j.error + (j.estimated_time ? ` (warming up ~${Math.ceil(j.estimated_time)}s)` : ''); } catch (_) {}
      throw new Error(hfErr(res.status, msg));
    }
    return { image: await blobToDataURL(await res.blob()), text: '' };
  }
  function safeMsg(t) { try { const j = JSON.parse(t); return (j.error && (j.error.message || j.error)) || t; } catch (_) { return t; } }

  /* ===================== GEMINI ============================ */
  const G_BASE = 'https://generativelanguage.googleapis.com/v1beta/models';
  const G_TEXT = 'gemini-2.0-flash';
  const G_IMAGE = 'gemini-2.0-flash-preview-image-generation';
  function gUrl(model, method, extra = '') { return `${G_BASE}/${model}:${method}?key=${encodeURIComponent(geminiKey())}${extra}`; }
  function gContents(thread) {
    return thread.filter(m => m && (m.text != null && m.text !== '' || (m.images && m.images.length)))
      .map(m => {
        const parts = [];
        if (m.text) parts.push({ text: String(m.text) });
        if (m.role !== 'model' && m.images && m.images.length) {
          m.images.forEach(d => { const p = parseDataUrl(d); if (p) parts.push({ inlineData: { mimeType: p.mime, data: p.data } }); });
        }
        if (!parts.length) parts.push({ text: '' });
        return { role: m.role === 'model' ? 'model' : 'user', parts };
      });
  }
  function gText(data) {
    const parts = (data && data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts) || [];
    return parts.map(p => p.text || '').join('').trim();
  }
  async function gGenerate(model, body) {
    if (!geminiKey()) throw new Error('Add your Gemini API key in Settings.');
    const res = await fetch(gUrl(model, 'generateContent'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error((data && data.error && data.error.message) || `Request failed (${res.status})`);
    return data;
  }
  async function geminiStream(thread, system, onToken) {
    const body = { contents: gContents(thread), generationConfig: { temperature: 0.85 } };
    if (system) body.system_instruction = { parts: [{ text: system }] };
    let res;
    try { res = await fetch(gUrl(G_TEXT, 'streamGenerateContent', '&alt=sse'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); }
    catch (e) { throw new Error('Network error, check your connection.'); }
    if (!res.ok || !res.body) {
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error((data && data.error && data.error.message) || `Request failed (${res.status})`);
      const t = gText(data); onToken && onToken(t, t); return t;
    }
    const reader = res.body.getReader(); const dec = new TextDecoder(); let buf = '', full = '';
    while (true) {
      const { done, value } = await reader.read(); if (done) break;
      buf += dec.decode(value, { stream: true });
      let nl; while ((nl = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, nl).trim(); buf = buf.slice(nl + 1);
        if (!line.startsWith('data:')) continue;
        const p = line.slice(5).trim(); if (!p || p === '[DONE]') continue;
        try { const o = JSON.parse(p); const t = gText(o); if (t) { full += t; onToken && onToken(t, full); } } catch (_) {}
      }
    }
    return full;
  }
  async function geminiComplete(prompt, system, temperature) {
    const body = { contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature: temperature == null ? 0.7 : temperature } };
    if (system) body.system_instruction = { parts: [{ text: system }] };
    return gText(await gGenerate(G_TEXT, body));
  }
  async function geminiImage(prompt) {
    const body = { contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { responseModalities: ['TEXT', 'IMAGE'] } };
    const data = await gGenerate(G_IMAGE, body);
    const parts = (data && data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts) || [];
    let image = null, text = '';
    for (const p of parts) { if (p.inlineData && p.inlineData.data) image = `data:${p.inlineData.mimeType || 'image/png'};base64,${p.inlineData.data}`; else if (p.text) text += p.text; }
    if (!image) throw new Error(text || 'No image was returned, the image model may be unavailable on the free tier.');
    return { image, text: text.trim() };
  }

  /* ===================== unified API ====================== */
  async function chatStream(thread, system, onToken) {
    const p = provider();
    if (p === 'hf') return hfChat(thread, system, onToken);
    if (p === 'gemini') return geminiStream(thread, system, onToken);
    return puterStream(thread, system, onToken);
  }
  async function complete(prompt, system, temp) {
    const p = provider();
    if (p === 'hf') return hfChat([{ role: 'user', text: prompt }], system, null);
    if (p === 'gemini') return geminiComplete(prompt, system, temp);
    return puterChat([{ role: 'user', text: prompt }], system);
  }
  async function completeJSON(prompt, system) {
    const raw = await complete(prompt + '\n\nReturn ONLY valid JSON. No prose, no markdown code fences.', system, 0.6);
    return parseLooseJSON(raw);
  }
  async function generateImage(prompt) {
    const p = provider();
    if (p === 'hf') return hfImage(prompt);
    if (p === 'gemini') return geminiImage(prompt);
    return puterImage(prompt);
  }

  const PROVIDERS = {
    puter: { id: 'puter', name: 'Puter', tag: 'No key needed', needs: null },
    hf: { id: 'hf', name: 'Hugging Face', tag: 'Free token', needs: 'hfToken', link: 'https://huggingface.co/settings/tokens' },
    gemini: { id: 'gemini', name: 'Google Gemini', tag: 'Free key', needs: 'geminiKey', link: 'https://aistudio.google.com/app/apikey' },
  };

  return { provider, ready, hasKey: ready, chatStream, complete, completeJSON, generateImage, PROVIDERS };
})();
