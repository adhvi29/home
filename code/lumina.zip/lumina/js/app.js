/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * Lumina - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   LUMINA · App, views, editor, interactions
   ============================================================ */
(function () {
  const L = window.LUMINA;
  const S = window.Store;

  /* ---------- tiny DOM helpers ---------- */
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const raf = (fn) => requestAnimationFrame(() => requestAnimationFrame(fn));

  /* ---------- date helpers ---------- */
  const WD = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const MO = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  function fmtLong(iso) { const d = S.fromISO(iso); return `${WD[d.getDay()]}, ${MO[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`; }
  function relDay(iso) {
    const t = S.todayISO();
    const y = new Date(); y.setDate(y.getDate() - 1);
    if (iso === t) return 'Today';
    if (iso === S.toISO(y)) return 'Yesterday';
    return fmtLong(iso);
  }
  function monthKeyLabel(key) { const [y, m] = key.split('-'); return `${MO[+m - 1]} ${y}`; }

  /* ---------- app state ---------- */
  const App = {
    view: 'journal',
    filters: { query: '', mood: '', tag: '', sort: 'newest' },
    editing: null,
    editingIsNew: false,
    editingPersisted: false,
    autosaveTimer: null,
    calCursor: new Date(),
    pinBuffer: '',
    pinMode: 'unlock', // 'unlock' | 'set'
    pinSetStep: null,
  };

  /* ============================================================
     LOCK-SCREEN MEDIA  (your own images/GIFs, stored in IndexedDB)
     ============================================================ */
  const LockDB = (function () {
    let dbp = null;
    function open() {
      if (dbp) return dbp;
      dbp = new Promise((res, rej) => {
        const r = indexedDB.open('lumina-media', 1);
        r.onupgradeneeded = (e) => { const db = e.target.result; if (!db.objectStoreNames.contains('lock')) db.createObjectStore('lock', { keyPath: 'id' }); };
        r.onsuccess = (e) => res(e.target.result);
        r.onerror = () => rej(r.error);
      });
      return dbp;
    }
    function store(mode) { return open().then(db => db.transaction('lock', mode).objectStore('lock')); }
    function p(req) { return new Promise((res, rej) => { req.onsuccess = () => res(req.result); req.onerror = () => rej(req.error); }); }
    return {
      async add(rec) { const st = await store('readwrite'); return p(st.add(rec)); },
      async all() { try { const st = await store('readonly'); return (await p(st.getAll())) || []; } catch (e) { return []; } },
      async remove(id) { const st = await store('readwrite'); return p(st.delete(id)); },
    };
  })();
  function lockId() { return 'L' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

  async function applyLockImage() {
    const bg = $('#lockBg'), photo = $('#lockPhoto'), video = $('#lockVideo');
    if (!bg) return;
    const imgs = await LockDB.all();
    if (!imgs.length) { bg.classList.remove('has-photo'); return; }
    // pick a fresh random one each time the lock appears, avoiding an immediate repeat
    let rec;
    if (imgs.length === 1) rec = imgs[0];
    else { const prev = App.lockImageId; do { rec = imgs[Math.floor(Math.random() * imgs.length)]; } while (rec.id === prev); }
    App.lockImageId = rec.id;
    if (App._lockUrl) { try { URL.revokeObjectURL(App._lockUrl); } catch (e) {} }
    App._lockUrl = URL.createObjectURL(rec.blob);
    if ((rec.type || '').startsWith('video/')) {
      if (video) { video.src = App._lockUrl; video.classList.add('active'); video.play().catch(() => {}); }
      if (photo) { photo.classList.remove('active'); photo.removeAttribute('src'); }
    } else {
      if (photo) { photo.src = App._lockUrl; photo.classList.add('active'); }
      if (video) { video.classList.remove('active'); try { video.pause(); } catch (e) {} video.removeAttribute('src'); }
    }
    bg.classList.add('has-photo');
  }

  async function renderLockImages() {
    const grid = $('#lockImgGrid'); if (!grid) return;
    const imgs = await LockDB.all();
    grid.innerHTML = imgs.map(rec => {
      const url = URL.createObjectURL(rec.blob);
      const media = (rec.type || '').startsWith('video/')
        ? `<video src="${url}" muted playsinline></video><span class="lockimg-badge">🎬</span>`
        : `<img src="${url}" alt="">`;
      return `<div class="lockimg-thumb">${media}<button class="lockimg-del" data-del-lock="${rec.id}" title="Remove">×</button></div>`;
    }).join('');
    $$('#lockImgGrid [data-del-lock]').forEach(b => b.onclick = async () => { await LockDB.remove(b.dataset.delLock); if (App.lockImageId === b.dataset.delLock) App.lockImageId = null; renderLockImages(); });
  }
  async function handleLockImages(fileList) {
    const files = [...fileList].filter(f => f.type.startsWith('image/') || f.type.startsWith('video/'));
    if (!files.length) return;
    let added = 0;
    for (const f of files) {
      if (f.size > 80 * 1024 * 1024) { toast('⚠️', `${f.name} is too big (keep clips under ~80MB)`); continue; }
      try { await LockDB.add({ id: lockId(), blob: f, name: f.name, type: f.type, added: Date.now() }); added++; }
      catch (e) { toast('⚠️', 'Could not add ' + f.name); }
    }
    if (added) {
      App.lockImageId = null;
      if (S.getSettings().lockMode !== 'images') { S.setSetting('lockMode', 'images'); const lms = $('#lockModeSelect'); if (lms) lms.value = 'images'; const row = $('#lockImagesRow'); if (row) row.style.display = ''; }
      toast('🖼️', added === 1 ? 'Added to lock screen' : added + ' added to lock screen');
      renderLockImages();
    }
  }

  /* ============================================================
     INIT
     ============================================================ */
  function init() {
    S.load();
    applyTheme(); applyAccent();
    buildPinPad();
    bindGlobalEvents();
    bindEditorEvents();
    startReminderWatch();
    attachActivityListeners();

    // Pick the lock-screen nature scene once per app open (changes when reopened/reloaded)
    App.lockScene = 1 + Math.floor(Math.random() * 6);
    setInterval(() => { if (!$('#lockScreen').classList.contains('hidden')) updateLockClock(); }, 10000);

    const st = S.getSettings();
    if (!st.onboarded) { showOnboarding(); }
    else if (st.pinEnabled && st.pin) { showLock('unlock'); }
    else { startApp(); }

    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    setTimeout(hideSplash, reduce ? 0 : 1300);
  }

  function hideSplash() {
    const sp = document.getElementById('splash');
    if (!sp || sp.classList.contains('hide')) return;
    sp.classList.add('hide');
    setTimeout(() => { if (sp.parentNode) sp.remove(); }, 600);
  }

  /* ============================================================
     THEME & ACCENT
     ============================================================ */
  function applyTheme() {
    const t = S.getSettings().theme;
    const eff = t === 'auto' ? (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark') : t;
    document.documentElement.setAttribute('data-theme', eff);
  }
  function applyAccent() { document.documentElement.setAttribute('data-accent', S.getSettings().accent); }
  function toggleTheme() {
    const cur = document.documentElement.getAttribute('data-theme');
    const next = cur === 'dark' ? 'light' : 'dark';
    S.setSetting('theme', next);
    document.documentElement.setAttribute('data-theme', next);
    toast(next === 'dark' ? '🌙' : '☀️', `${next === 'dark' ? 'Dark' : 'Light'} mode`);
  }

  /* ============================================================
     ONBOARDING
     ============================================================ */
  function showOnboarding() {
    const o = $('#onboarding'); o.classList.remove('hidden');
    const input = $('#onboardName');
    setTimeout(() => input.focus(), 200);
    const start = () => {
      const name = input.value.trim();
      S.setSetting('name', name);
      S.setSetting('onboarded', true);
      o.classList.add('hidden');
      startApp();
      setTimeout(() => toast('📖', name ? `Welcome, ${name}!` : 'Welcome to Lumina!'), 400);
      setTimeout(() => toast('✍️', 'Tap “New Entry” to write your first page'), 2600);
    };
    $('#onboardStart').onclick = start;
    input.onkeydown = (e) => { if (e.key === 'Enter') start(); };
  }

  /* ============================================================
     LOCK SCREEN / PIN
     ============================================================ */
  function buildPinPad() {
    const pad = $('#pinPad');
    const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', '⌫'];
    pad.innerHTML = '';
    keys.forEach(k => {
      if (k === '') { pad.appendChild(document.createElement('span')); return; }
      const b = document.createElement('button');
      b.className = 'pin-key' + (k === '⌫' ? ' wide' : '');
      b.textContent = k;
      b.onclick = () => pinPress(k);
      pad.appendChild(b);
    });
  }
  function renderPinDots() {
    const dots = $('#pinDots'); dots.innerHTML = '';
    for (let i = 0; i < 4; i++) {
      const d = document.createElement('span');
      d.className = 'dot' + (i < App.pinBuffer.length ? ' filled' : '');
      dots.appendChild(d);
    }
  }
  function showLock(mode) {
    App.pinMode = mode; App.pinBuffer = ''; App.pinSetStep = mode === 'set' ? { stage: 1, first: '' } : null;
    const ls = $('#lockScreen'); ls.classList.remove('hidden');
    // fresh nature scene each time the lock appears (avoid immediate repeat)
    if (App.lockScene == null) App.lockScene = 1 + Math.floor(Math.random() * 6);
    else { let n; do { n = 1 + Math.floor(Math.random() * 6); } while (n === App.lockScene); App.lockScene = n; }
    const bg = $('#lockBg'); if (bg) bg.className = 'lock-bg lscene-' + App.lockScene;
    if (S.getSettings().lockMode === 'images') applyLockImage();
    updateLockClock();
    hideLockInfo();
    // 'set' goes straight to the PIN view; 'unlock' starts at the resting clock (click/key to sign in)
    ls.classList.toggle('signing-in', mode === 'set');
    $('.lock-card h2').textContent = mode === 'set' ? 'Create a PIN' : (S.getSettings().name ? 'Welcome back, ' + S.getSettings().name : 'Welcome back');
    $('.lock-sub').textContent = mode === 'set' ? 'Choose a 4-digit PIN to lock your diary' : 'Enter your PIN to open your diary';
    $('#pinError').textContent = '';
    renderPinDots();
  }

  function lockToSignIn() {
    const ls = $('#lockScreen'); if (!ls || ls.classList.contains('hidden')) return;
    ls.classList.add('signing-in');
    hideLockInfo();
  }
  function lockToResting() {
    if (App.pinMode === 'set') return; // can't go back to clock while creating a PIN
    const ls = $('#lockScreen'); if (ls) ls.classList.remove('signing-in');
    App.pinBuffer = ''; renderPinDots(); $('#pinError').textContent = '';
  }
  function handleLockKey(e) {
    const ls = $('#lockScreen');
    if (e.key === 'Escape') { if (ls.classList.contains('signing-in')) lockToResting(); return; }
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    if (!ls.classList.contains('signing-in')) lockToSignIn();
    if (/^[0-9]$/.test(e.key)) { e.preventDefault(); pinPress(e.key); }
    else if (e.key === 'Backspace') { e.preventDefault(); pinPress('⌫'); }
  }
  function toggleLockInfo() {
    const pop = $('#lockInfoPop'); if (!pop) return;
    if (pop.classList.contains('hidden')) {
      const now = new Date();
      pop.innerHTML = `<div class="lip-title">🔒 Lumina</div><div class="lip-sub">Your private diary, locked</div><div class="lip-row">${WD[now.getDay()]}, ${MO[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}</div><div class="lip-hint">Click anywhere or press a key to sign in.</div>`;
      pop.classList.remove('hidden');
    } else pop.classList.add('hidden');
  }
  function hideLockInfo() { const pop = $('#lockInfoPop'); if (pop) pop.classList.add('hidden'); }

  function updateLockClock() {
    const now = new Date();
    const h12 = now.getHours() % 12 || 12;
    const t = $('#lockTime'); if (t) t.textContent = `${h12}:${String(now.getMinutes()).padStart(2, '0')}`;
    const d = $('#lockDate'); if (d) d.textContent = `${WD[now.getDay()]}, ${MO[now.getMonth()]} ${now.getDate()}`;
  }
  function pinPress(k) {
    const err = $('#pinError');
    if (k === '⌫') { App.pinBuffer = App.pinBuffer.slice(0, -1); renderPinDots(); return; }
    if (App.pinBuffer.length >= 4) return;
    App.pinBuffer += k; renderPinDots();
    if (App.pinBuffer.length === 4) {
      setTimeout(() => {
        if (App.pinMode === 'unlock') {
          if (App.pinBuffer === S.getSettings().pin) { $('#lockScreen').classList.add('hidden'); startApp(); }
          else { err.textContent = 'Incorrect PIN. Try again.'; $('.lock-card').classList.add('shake'); App.pinBuffer = ''; renderPinDots(); setTimeout(() => $('.lock-card').classList.remove('shake'), 400); }
        } else { // set
          if (App.pinSetStep.stage === 1) { App.pinSetStep.first = App.pinBuffer; App.pinSetStep.stage = 2; App.pinBuffer = ''; renderPinDots(); $('.lock-sub').textContent = 'Confirm your PIN'; err.textContent = ''; }
          else {
            if (App.pinBuffer === App.pinSetStep.first) { S.setSetting('pin', App.pinBuffer); S.setSetting('pinEnabled', true); $('#lockScreen').classList.add('hidden'); toast('🔒', 'PIN lock enabled'); if (App.view === 'settings') route('settings'); }
            else { err.textContent = 'PINs did not match. Start over.'; $('.lock-card').classList.add('shake'); App.pinSetStep = { stage: 1, first: '' }; App.pinBuffer = ''; renderPinDots(); $('.lock-sub').textContent = 'Choose a 4-digit PIN'; setTimeout(() => $('.lock-card').classList.remove('shake'), 400); }
          }
        }
      }, 120);
    }
  }

  // Lock the diary on demand (from the Lock tab)
  function lockNow() {
    const st = S.getSettings();
    if (st.pinEnabled && st.pin) {
      $('#app').classList.add('hidden');
      $('#app').classList.remove('nav-open');
      showLock('unlock');
    } else {
      toast('🔒', 'Set a 4-digit PIN to enable lock');
      showLock('set');
    }
  }

  /* ============================================================
     START APP
     ============================================================ */
  function startApp() {
    $('#app').classList.remove('hidden');
    refreshShell();
    route('home');
    resetAutoLock();
  }

  function refreshShell() {
    const st = S.getSettings();
    const initial = (st.name || 'L').trim().charAt(0).toUpperCase() || 'L';
    $('#avatarInitial').textContent = initial;
    const entries = S.getEntries();
    $('#countJournal').textContent = entries.length;
    $('#countFav').textContent = entries.filter(e => e.favorite).length;
    const stk = S.streak();
    $('#streakNum').textContent = stk;
    $('#streakPill').title = stk ? `You've written ${stk} day${stk > 1 ? 's' : ''} in a row` : 'Start a streak by writing today';
  }

  /* ============================================================
     ROUTER
     ============================================================ */
  function route(view) {
    App.view = view;
    $$('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.view === view));
    $('#app').classList.remove('nav-open');
    const c = $('#viewContainer');
    c.style.opacity = '0';
    setTimeout(() => {
      if (view === 'home') renderHome(c);
      else if (view === 'journal') renderJournal(c);
      else if (view === 'calendar') renderCalendar(c);
      else if (view === 'insights') renderInsights(c);
      else if (view === 'favorites') renderFavorites(c);
      else if (view === 'lumi') renderLumi(c);
      else if (view === 'settings') renderSettings(c);
      c.style.opacity = '1';
      $('.view-scroll').scrollTop = 0;
    }, 120);
  }

  /* ============================================================
     HOME DASHBOARD
     ============================================================ */
  function renderHome(c) {
    const st = S.getSettings();
    const stats = S.stats();
    const all = S.sorted(S.getEntries(), 'newest');
    const recent = all.slice(0, 3);
    const prompt = L.pick(L.PROMPTS);
    const otd = S.onThisDay();
    const moods = all.slice(0, 7).reverse().map(e => L.moodById(e.mood)).filter(Boolean);
    const now = new Date();
    const dateStr = `${WD[now.getDay()]}, ${MO[now.getMonth()]} ${now.getDate()}`;
    const name = st.name ? ', ' + esc(st.name) : '';
    const wordsLabel = stats.words > 999 ? (stats.words / 1000).toFixed(1) + 'k' : stats.words;

    c.innerHTML = `
      <div class="home-hero">
        <div class="home-greet">${esc(L.greeting())}${name} ✦</div>
        <h1 class="home-title">Welcome home</h1>
        <div class="home-date">${dateStr}${stats.streak ? ` · 🔥 ${stats.streak} day streak` : ''}</div>
      </div>
      <div class="home-grid">
        <div class="home-col">
          <div class="home-prompt">
            <div class="hp-label">✦ Today's prompt</div>
            <div class="hp-text">“${esc(prompt)}”</div>
            <button class="btn btn-primary" id="homeWrite">Write about this</button>
          </div>
          <div class="home-actions">
            <button class="home-action" id="homeNew"><span class="ha-ic">✍️</span><span><div class="ha-label">New entry</div><div class="ha-sub">Capture a thought</div></span></button>
            <button class="home-action" id="homeAskBtn"><span class="ha-ic">✨</span><span><div class="ha-label">Ask Lumi</div><div class="ha-sub">Chat · study · create</div></span></button>
            <button class="home-action" data-go="calendar"><span class="ha-ic">📅</span><span><div class="ha-label">Calendar</div><div class="ha-sub">Your month</div></span></button>
            <button class="home-action" data-go="insights"><span class="ha-ic">📊</span><span><div class="ha-label">Insights</div><div class="ha-sub">Patterns & streaks</div></span></button>
          </div>
          ${recent.length
        ? `<div><div class="home-section-title">Recent entries <button class="chip" data-go="journal">View all →</button></div><div class="entries-grid">${recent.map(cardHTML).join('')}</div></div>`
        : `<div class="empty-state" style="padding:34px"><span class="empty-emoji">🌱</span><h3>Your story starts here</h3><p>Write your first entry to bring your home to life.</p><button class="btn btn-primary" id="homeNew2">Write your first entry</button></div>`}
        </div>
        <div class="home-col">
          <div class="home-stats">
            <div class="home-stat"><div class="hs-val">${stats.total}</div><div class="hs-label">entries</div></div>
            <div class="home-stat"><div class="hs-val">${stats.streak}</div><div class="hs-label">day streak</div></div>
            <div class="home-stat"><div class="hs-val">${wordsLabel}</div><div class="hs-label">words</div></div>
          </div>
          <div class="home-card">
            <div class="hc-title">✨ Ask Lumi</div>
            <div class="home-ask-row"><input type="text" id="homeAsk" class="text-input" placeholder="Ask anything…" autocomplete="off"><button class="btn btn-primary" id="homeAskSend">→</button></div>
          </div>
          ${moods.length ? `<div class="home-card"><div class="hc-title">🎭 Recent moods</div><div class="home-mood-row">${moods.map(m => `<span class="home-mood-emoji" title="${m.label}">${m.emoji}</span>`).join('')}</div></div>` : ''}
          ${otd.length ? `<div class="otd-banner" data-otd="1"><span class="otd-icon">🕰️</span><div class="otd-text"><strong>On this day</strong><p>${otd.length} memor${otd.length > 1 ? 'ies' : 'y'} from past years</p></div><span class="otd-arrow">→</span></div>` : ''}
        </div>
      </div>`;

    const openNew = () => newEntry();
    ['#homeWrite', '#homeNew', '#homeNew2'].forEach(sel => { const el = $(sel); if (el) el.onclick = openNew; });
    const askBtn = $('#homeAskBtn'); if (askBtn) askBtn.onclick = () => askLumiFromHome('');
    const ask = () => askLumiFromHome($('#homeAsk').value.trim());
    const askSend = $('#homeAskSend'); if (askSend) askSend.onclick = ask;
    const askInput = $('#homeAsk'); if (askInput) askInput.onkeydown = (e) => { if (e.key === 'Enter') ask(); };
    $$('[data-go]').forEach(b => b.onclick = () => route(b.dataset.go));
    afterCardsRender();
  }

  function askLumiFromHome(text) {
    if (!App.lumi) App.lumi = Object.assign({ mode: 'chat', busy: false }, lumiLoad());
    lumiNewChat();
    App.lumi.mode = 'chat';
    route('lumi');
    if (text && S.getSettings().aiConfigured && AI.ready()) {
      setTimeout(() => { const i = $('#lumiInput'); if (i) { i.value = text; sendChat(); } }, 320);
    }
  }

  /* ============================================================
     JOURNAL VIEW
     ============================================================ */
  function renderJournal(c) {
    const st = S.getSettings();
    const q = L.pick(L.QUOTES);
    let html = `
      <div class="view-header">
        <div class="view-greeting">${esc(L.greeting())}${st.name ? ', ' + esc(st.name) : ''} ✦</div>
        <h1 class="view-title">Your Diary</h1>
        <p class="view-sub">“${esc(q.t)}”, <em>${esc(q.a)}</em></p>
      </div>`;

    // Daily reminder nudge
    if (reminderDue()) {
      html += `<div class="reminder-banner"><span class="otd-icon">🔔</span><div class="otd-text"><strong>Time to write today</strong><p>You haven't added an entry yet today, a few lines is plenty.</p></div><button class="btn btn-primary btn-sm" data-new="1">Write now</button></div>`;
    }

    // On this day
    const otd = S.onThisDay();
    if (otd.length) {
      html += `<div class="otd-banner" data-otd="1">
        <span class="otd-icon">🕰️</span>
        <div class="otd-text"><strong>On this day</strong><p>${otd.length} memor${otd.length > 1 ? 'ies' : 'y'} from previous years, tap to revisit</p></div>
        <span class="otd-arrow">→</span>
      </div>`;
    }

    html += toolbarHTML();

    const list = S.sorted(S.filter({ query: App.filters.query, mood: App.filters.mood, tag: App.filters.tag }), App.filters.sort);
    html += `<div id="entriesArea">${list.length ? groupedEntriesHTML(list) : emptyJournalHTML()}</div>`;
    c.innerHTML = html;
    afterCardsRender();
  }

  function toolbarHTML() {
    const tags = S.allTags().slice(0, 8);
    let chips = `<button class="chip ${!App.filters.mood && !App.filters.tag ? 'active' : ''}" data-filter-clear="1">All</button>`;
    L.MOODS.forEach(m => {
      const n = S.getEntries().filter(e => e.mood === m.id).length;
      if (!n) return;
      chips += `<button class="chip ${App.filters.mood === m.id ? 'active' : ''}" data-mood="${m.id}"><span class="chip-emoji">${m.emoji}</span>${m.label}</button>`;
    });
    let tagChips = tags.map(t => `<button class="chip ${App.filters.tag === t.tag ? 'active' : ''}" data-tag="${esc(t.tag)}">#${esc(t.tag)}</button>`).join('');
    return `<div class="view-toolbar">
      ${chips}
      ${tagChips ? '<span class="tb-div" style="width:1px;height:22px;background:var(--line)"></span>' + tagChips : ''}
      <span class="toolbar-spacer"></span>
      <select class="select-mini" id="sortSelect">
        <option value="newest" ${App.filters.sort === 'newest' ? 'selected' : ''}>Newest first</option>
        <option value="oldest" ${App.filters.sort === 'oldest' ? 'selected' : ''}>Oldest first</option>
        <option value="az" ${App.filters.sort === 'az' ? 'selected' : ''}>Title A, Z</option>
        <option value="words" ${App.filters.sort === 'words' ? 'selected' : ''}>Longest</option>
      </select>
    </div>`;
  }

  function groupedEntriesHTML(list) {
    // group by month label
    const groups = {};
    list.forEach(e => { const k = e.date.slice(0, 7); (groups[k] = groups[k] || []).push(e); });
    const keys = Object.keys(groups).sort((a, b) => App.filters.sort === 'oldest' ? a.localeCompare(b) : b.localeCompare(a));
    // if sorting az/words, don't group
    if (App.filters.sort === 'az' || App.filters.sort === 'words') {
      return `<div class="entries-grid">${list.map(cardHTML).join('')}</div>`;
    }
    return keys.map(k => `
      <div class="timeline-month">
        <div class="timeline-label">${monthKeyLabel(k)} <span class="timeline-count">${groups[k].length} ${groups[k].length > 1 ? 'entries' : 'entry'}</span></div>
        <div class="entries-grid">${groups[k].map(cardHTML).join('')}</div>
      </div>`).join('');
  }

  function cardHTML(e) {
    const mood = L.moodById(e.mood);
    const w = L.weatherById(e.weather);
    const d = S.fromISO(e.date);
    const words = S.wordCount(e.plainText);
    const preview = e.plainText || 'No words yet…';
    const moodStyle = mood ? `--mood-color:${mood.color};--mood-color-2:${mood.color2}` : '';
    const photos = e.photos || [];
    const cover = photos.length ? `<div class="entry-cover"><img src="${photos[0]}" alt="" loading="lazy" />${photos.length > 1 ? `<span class="entry-cover-count">📷 ${photos.length}</span>` : ''}</div>` : '';
    return `<article class="entry-card ${cover ? 'has-cover' : ''}" data-id="${e.id}" style="${moodStyle}">
      ${cover}
      ${e.pinned ? '<span class="pin-badge">📌</span>' : ''}
      <button class="icon-btn fav-star ${e.favorite ? 'on' : ''}" data-fav="${e.id}" title="Favorite" style="width:28px;height:28px">
        <svg viewBox="0 0 24 24" width="16" height="16"><path d="M12 3l2.9 5.9 6.5.9-4.7 4.6 1.1 6.4L12 17.8 6.2 20.8l1.1-6.4L2.6 9.8l6.5-.9L12 3z" fill="${e.favorite ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg>
      </button>
      <div class="entry-card-top">
        <div class="entry-date-badge">
          <span class="entry-day">${d.getDate()}</span>
          <span class="entry-monthyear">${MO[d.getMonth()].slice(0, 3)}<br>${d.getFullYear()}</span>
        </div>
        ${mood ? `<span class="entry-mood-emoji" title="${mood.label}">${mood.emoji}</span>` : ''}
      </div>
      <h3>${esc(e.title || 'Untitled entry')}</h3>
      <p class="entry-preview">${esc(preview)}</p>
      <div class="entry-card-foot">
        ${(e.tags || []).slice(0, 2).map(t => `<span class="entry-tag">#${esc(t)}</span>`).join('')}
        <span class="entry-card-meta">
          ${w ? `<span class="entry-weather" title="${w.label}">${w.emoji}</span>` : ''}
          <span>${words} words</span>
        </span>
      </div>
    </article>`;
  }

  function emptyJournalHTML() {
    const filtered = App.filters.query || App.filters.mood || App.filters.tag;
    if (filtered) return `<div class="empty-state"><span class="empty-emoji">🔍</span><h3>Nothing matches</h3><p>Try a different search or clear your filters to see all your entries.</p><button class="btn btn-ghost" data-filter-clear="1">Clear filters</button></div>`;
    return `<div class="empty-state"><span class="empty-emoji">🌱</span><h3>Your story starts here</h3><p>You haven't written anything yet. Capture a thought, a moment, or a feeling, your first entry is a click away.</p><button class="btn btn-primary" data-new="1">Write your first entry</button></div>`;
  }

  function afterCardsRender() {
    $$('.entry-card').forEach((card, i) => { card.style.animationDelay = Math.min(i * 35, 400) + 'ms'; });
  }

  /* ============================================================
     FAVORITES VIEW
     ============================================================ */
  function renderFavorites(c) {
    const list = S.sorted(S.filter({ favorite: true }), 'newest');
    let html = `<div class="view-header"><div class="view-greeting">Your treasured moments ✦</div><h1 class="view-title">Favorites</h1><p class="view-sub">The entries you've starred to keep close.</p></div>`;
    html += list.length ? `<div class="entries-grid">${list.map(cardHTML).join('')}</div>`
      : `<div class="empty-state"><span class="empty-emoji">⭐</span><h3>No favorites yet</h3><p>Tap the star on any entry to keep it here, ready to revisit whenever you like.</p></div>`;
    c.innerHTML = html;
    afterCardsRender();
  }

  /* ============================================================
     CALENDAR VIEW
     ============================================================ */
  function renderCalendar(c) {
    const cur = App.calCursor;
    const year = cur.getFullYear(), month = cur.getMonth();
    const first = new Date(year, month, 1);
    const startDow = first.getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const todayIso = S.todayISO();

    let cells = '';
    const dows = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    cells += dows.map(d => `<div class="cal-dow">${d}</div>`).join('');
    for (let i = 0; i < startDow; i++) cells += `<div class="cal-cell empty"></div>`;
    for (let day = 1; day <= daysInMonth; day++) {
      const iso = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const dayEntries = S.entriesByDate(iso);
      const top = dayEntries[0];
      const mood = top ? L.moodById(top.mood) : null;
      const style = mood ? `--mood-color:${mood.color}44` : '';
      cells += `<div class="cal-cell ${dayEntries.length ? 'has-entry' : ''} ${iso === todayIso ? 'today' : ''}" data-date="${iso}" style="${style}">
        <span class="cal-daynum">${day}</span>
        ${mood ? `<span class="cal-cell-mood">${mood.emoji}</span>` : ''}
        ${dayEntries.length > 1 ? `<span class="cal-cell-count">${dayEntries.length}</span>` : ''}
      </div>`;
    }

    const monthCount = S.getEntries().filter(e => e.date.slice(0, 7) === `${year}-${String(month + 1).padStart(2, '0')}`).length;

    c.innerHTML = `
      <div class="view-header"><div class="view-greeting">Your month at a glance ✦</div><h1 class="view-title">Calendar</h1></div>
      <div class="panel">
        <div class="cal-head">
          <div class="cal-title">${MO[month]} ${year}</div>
          <div class="cal-nav">
            <span class="view-sub" style="margin-right:8px">${monthCount} ${monthCount === 1 ? 'entry' : 'entries'}</span>
            <button class="icon-btn" data-cal="-1" title="Previous month"><svg viewBox="0 0 24 24" width="20" height="20"><path d="M15 18l-6-6 6-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
            <button class="btn btn-ghost btn-sm" data-cal="today">Today</button>
            <button class="icon-btn" data-cal="1" title="Next month"><svg viewBox="0 0 24 24" width="20" height="20"><path d="M9 18l6-6-6-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
          </div>
        </div>
        <div class="cal-grid">${cells}</div>
        <div class="cal-legend">
          <div class="cal-legend-item"><span style="width:12px;height:12px;border-radius:4px;background:var(--accent);display:inline-block"></span> Today</div>
          ${L.MOODS.slice(0, 5).map(m => `<div class="cal-legend-item">${m.emoji} ${m.label}</div>`).join('')}
        </div>
      </div>`;
  }

  /* ============================================================
     INSIGHTS VIEW
     ============================================================ */
  function renderInsights(c) {
    const s = S.stats();
    if (!s.total) {
      c.innerHTML = `<div class="view-header"><div class="view-greeting">Patterns in your story ✦</div><h1 class="view-title">Insights</h1></div>
        <div class="empty-state"><span class="empty-emoji">📊</span><h3>No insights yet</h3><p>Write a few entries and this page will fill with the rhythms of your days, moods, streaks, and the shape of your weeks.</p><button class="btn btn-primary" data-new="1">Start writing</button></div>`;
      return;
    }

    const cards = [
      { icon: '📓', value: s.total, label: 'Total entries', sub: `across ${s.days} ${s.days === 1 ? 'day' : 'days'}` },
      { icon: '✍️', value: s.words.toLocaleString(), label: 'Words written', sub: `~${s.avgWords} per entry` },
      { icon: '🔥', value: s.streak, label: 'Current streak', sub: s.streak ? 'keep it going!' : 'write today to start' },
      { icon: '🏆', value: s.longest, label: 'Longest streak', sub: 'days in a row' },
      { icon: '⭐', value: s.favorites, label: 'Favorites', sub: 'starred entries' },
    ];

    let html = `<div class="view-header"><div class="view-greeting">Patterns in your story ✦</div><h1 class="view-title">Insights</h1><p class="view-sub">A reflection of your writing, drawn from ${s.total} ${s.total === 1 ? 'entry' : 'entries'}.</p></div>`;
    html += `<div class="stats-grid">${cards.map((k, i) => `<div class="stat-card" style="animation-delay:${i * 60}ms"><div class="stat-icon">${k.icon}</div><div class="stat-value">${k.value}</div><div class="stat-label">${k.label}</div><div class="stat-sub">${k.sub}</div></div>`).join('')}</div>`;

    // mood distribution
    const dist = S.moodDistribution();
    const distEntries = Object.entries(dist).sort((a, b) => b[1] - a[1]);
    const maxMood = distEntries.length ? distEntries[0][1] : 1;
    if (distEntries.length) {
      html += `<div class="panel"><div class="panel-title">How you've been feeling</div><div class="panel-sub">Your mood across all entries</div><div class="mood-bars">`;
      distEntries.forEach(([id, count]) => {
        const m = L.moodById(id); if (!m) return;
        const pct = Math.round((count / maxMood) * 100);
        html += `<div class="mood-bar-row"><span class="mood-bar-emoji" title="${m.label}">${m.emoji}</span><div class="mood-bar-track"><div class="mood-bar-fill" data-pct="${pct}" style="background:linear-gradient(90deg,${m.color},${m.color2})"></div></div><span class="mood-bar-val">${count}</span></div>`;
      });
      html += `</div></div>`;
    }

    // weekly activity area chart
    html += `<div class="panel"><div class="panel-title">Your writing rhythm</div><div class="panel-sub">Entries per week over the last 12 weeks</div>${areaChartHTML()}</div>`;

    // heatmap
    html += `<div class="panel"><div class="panel-title">Consistency</div><div class="panel-sub">Every day you've written in the last 26 weeks</div>${heatmapHTML()}</div>`;

    // tag cloud
    const tags = S.allTags();
    if (tags.length) {
      html += `<div class="panel"><div class="panel-title">What you write about</div><div class="panel-sub">Your most-used tags</div><div class="tag-cloud">${tags.slice(0, 20).map(t => `<span class="cloud-tag" data-tag="${esc(t.tag)}">#${esc(t.tag)} <em>${t.count}</em></span>`).join('')}</div></div>`;
    }

    c.innerHTML = html;
    raf(() => $$('.mood-bar-fill').forEach(b => { b.style.width = b.dataset.pct + '%'; }));
  }

  function weeklyCounts(weeks) {
    const days = S.heatmap(weeks); // chronological daily counts
    const out = [];
    for (let i = 0; i < days.length; i += 7) {
      const chunk = days.slice(i, i + 7);
      out.push({ count: chunk.reduce((a, d) => a + d.count, 0), end: chunk[chunk.length - 1].date });
    }
    return out;
  }

  function areaChartHTML() {
    const data = weeklyCounts(12);
    const W = 640, H = 200, pad = 24;
    const max = Math.max(1, ...data.map(d => d.count));
    const n = data.length;
    const x = i => pad + (i * (W - pad * 2)) / (n - 1 || 1);
    const y = v => H - pad - (v / max) * (H - pad * 2);
    let line = '', area = `M ${x(0)} ${H - pad} `;
    data.forEach((d, i) => { const px = x(i), py = y(d.count); line += (i ? 'L' : 'M') + ` ${px.toFixed(1)} ${py.toFixed(1)} `; area += `L ${px.toFixed(1)} ${py.toFixed(1)} `; });
    area += `L ${x(n - 1)} ${H - pad} Z`;
    const dots = data.map((d, i) => `<circle class="chart-dot" cx="${x(i).toFixed(1)}" cy="${y(d.count).toFixed(1)}" r="3"></circle>`).join('');
    const labels = data.map((d, i) => (i % 2 === 0) ? `<text class="chart-label" x="${x(i).toFixed(1)}" y="${H - 4}" text-anchor="middle">${d.end.toLocaleString('default', { month: 'short', day: 'numeric' })}</text>` : '').join('');
    return `<div class="chart-wrap"><svg class="chart-svg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">
      <defs><linearGradient id="areaGrad" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="var(--accent)" stop-opacity="0.45"/><stop offset="100%" stop-color="var(--accent)" stop-opacity="0"/></linearGradient></defs>
      <path class="chart-area" d="${area}"/>
      <path class="chart-line" d="${line}"/>
      ${dots}${labels}
    </svg></div>`;
  }

  function heatmapHTML() {
    const cells = S.heatmap(26);
    const max = Math.max(1, ...cells.map(c => c.count));
    const level = v => v === 0 ? 0 : v >= max * 0.75 ? 4 : v >= max * 0.5 ? 3 : v >= max * 0.25 ? 2 : 1;
    const inner = cells.map(c => {
      const lv = level(c.count);
      const t = `${c.iso} · ${c.count} ${c.count === 1 ? 'entry' : 'entries'}`;
      return `<div class="heat-cell ${lv ? 'heat-' + lv : ''}" title="${t}" data-date="${c.iso}"></div>`;
    }).join('');
    return `<div class="heatmap-scroll"><div class="heatmap">${inner}</div></div>
      <div class="heatmap-legend">Less <span class="heat-cell"></span><span class="heat-cell heat-1"></span><span class="heat-cell heat-2"></span><span class="heat-cell heat-3"></span><span class="heat-cell heat-4"></span> More</div>`;
  }

  /* ============================================================
     SETTINGS VIEW
     ============================================================ */
  function renderSettings(c) {
    const st = S.getSettings();
    const accents = L.ACCENTS.map(a => `<span class="accent-dot ${st.accent === a.id ? 'active' : ''}" data-accent="${a.id}" title="${a.label}" style="background:linear-gradient(135deg,${a.a},${a.b})"></span>`).join('');
    const themes = ['dark', 'light', 'auto'].map(t => `<button class="theme-opt ${st.theme === t ? 'active' : ''}" data-theme-opt="${t}">${t[0].toUpperCase() + t.slice(1)}</button>`).join('');

    c.innerHTML = `
      <div class="view-header"><div class="view-greeting">Make it yours ✦</div><h1 class="view-title">Settings</h1></div>

      <div class="settings-section">
        <div class="settings-row">
          <div class="settings-row-text"><strong>Your name</strong><p>Shown in your greeting and on your avatar.</p></div>
          <input type="text" class="text-input" id="setName" value="${esc(st.name)}" placeholder="Your name" style="max-width:200px">
        </div>
        <div class="settings-row">
          <div class="settings-row-text"><strong>Appearance</strong><p>Choose how Lumina looks.</p></div>
          <div class="theme-picker">${themes}</div>
        </div>
        <div class="settings-row">
          <div class="settings-row-text"><strong>Accent color</strong><p>A splash of personality across the app.</p></div>
          <div class="accent-picker">${accents}</div>
        </div>
      </div>

      <div class="settings-section">
        <div class="settings-row">
          <div class="settings-row-text"><strong>PIN lock</strong><p>${st.pinEnabled ? 'Your diary is locked with a 4-digit PIN.' : 'Require a 4-digit PIN to open your diary.'}</p></div>
          <div class="toggle ${st.pinEnabled ? 'on' : ''}" id="pinToggle" role="switch" aria-checked="${st.pinEnabled}"></div>
        </div>
        <div class="settings-row">
          <div class="settings-row-text"><strong>Auto-lock</strong><p>${st.pinEnabled ? 'Lock automatically after a stretch of inactivity.' : 'Lock after inactivity, needs PIN lock (above) to take effect.'}</p></div>
          <select class="select-mini" id="autoLockSelect">
            <option value="0">Off</option>
            <option value="1">After 1 min</option>
            <option value="5">After 5 min</option>
            <option value="15">After 15 min</option>
            <option value="30">After 30 min</option>
          </select>
        </div>
        <div class="settings-row">
          <div class="settings-row-text"><strong>Daily writing reminder</strong><p>${st.reminderEnabled ? `Nudges you at ${fmtTime(st.reminderTime)} if you haven't written. Works while Lumina is open.` : 'A gentle daily nudge to write. Works while Lumina is open in a tab.'}</p></div>
          <div class="settings-inline">
            <input type="time" id="reminderTime" class="text-input time-input" value="${esc(st.reminderTime)}" ${st.reminderEnabled ? '' : 'disabled'} />
            <div class="toggle ${st.reminderEnabled ? 'on' : ''}" id="reminderToggle" role="switch" aria-checked="${st.reminderEnabled}"></div>
          </div>
        </div>
      </div>

      <div class="settings-section">
        <div class="settings-row">
          <div class="settings-row-text"><strong>Lumi AI engine</strong><p>Which provider powers the Lumi assistant (chat, images, study tools).</p></div>
          <select class="select-mini" id="aiProviderSelect">
            <option value="hf">Hugging Face</option>
            <option value="puter">Puter (no key)</option>
            <option value="gemini">Google Gemini</option>
          </select>
        </div>
        <div class="settings-row" id="hfKeyRow">
          <div class="settings-row-text"><strong>Hugging Face token</strong><p>Stored only on this device. <a href="https://huggingface.co/settings/tokens" target="_blank" rel="noopener" style="color:var(--accent)">Get a free token →</a></p></div>
          <input type="password" id="setHfToken" class="text-input" value="${esc(st.hfToken)}" placeholder="hf_…" style="max-width:200px" autocomplete="off">
        </div>
        <div class="settings-row" id="geminiKeyRow">
          <div class="settings-row-text"><strong>Gemini API key</strong><p>Stored only on this device. <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener" style="color:var(--accent)">Get a free key →</a></p></div>
          <input type="password" id="setGeminiKey" class="text-input" value="${esc(st.geminiKey)}" placeholder="Gemini API key" style="max-width:200px" autocomplete="off">
        </div>
      </div>

      <div class="settings-section">
        <div class="settings-row">
          <div class="settings-row-text"><strong>Lock screen background</strong><p>Nature scenes, or your own images, GIFs &amp; short videos, a random one each time you open the app.</p></div>
          <select class="select-mini" id="lockModeSelect">
            <option value="nature">Nature scenes</option>
            <option value="images">My images / videos</option>
          </select>
        </div>
        <div class="settings-row" id="lockImagesRow">
          <div class="settings-row-text"><strong>Your lock media</strong><p>Add photos, GIFs, or short video clips (they loop, muted). Stored privately on this device, shown only on your lock screen.</p><div class="lockimg-grid" id="lockImgGrid"></div></div>
          <button class="btn btn-ghost" id="lockImgAdd">Add media</button>
          <input type="file" id="lockImgInput" accept="image/*,video/*" multiple hidden>
        </div>
      </div>

      <div class="settings-section">
        <div class="settings-row">
          <div class="settings-row-text"><strong>Export diary</strong><p>Download all your entries as a backup file (JSON).</p></div>
          <button class="btn btn-ghost" id="exportBtn">Export</button>
        </div>
        <div class="settings-row">
          <div class="settings-row-text"><strong>Import diary</strong><p>Restore entries from a previously exported file.</p></div>
          <button class="btn btn-ghost" id="importBtn">Import</button>
          <input type="file" id="importFile" accept="application/json" hidden>
        </div>
        <div class="settings-row">
          <div class="settings-row-text"><strong>Clear all entries</strong><p>Permanently delete every entry. This cannot be undone.</p></div>
          <button class="btn btn-danger" id="clearBtn">Delete all</button>
        </div>
      </div>

      <div class="settings-section" style="text-align:center;color:var(--text-dim);font-size:13px;padding:20px">
        <div style="font-family:var(--font-serif);font-size:18px;color:var(--text-soft)">📖 Lumina</div>
        <p style="margin-top:4px">A premium diary experience · v1.0 · Your data lives only on this device.</p>
      </div>`;

    bindSettingsEvents();
  }

  function bindSettingsEvents() {
    $('#setName').oninput = (e) => { S.setSetting('name', e.target.value.trim()); refreshShell(); };
    $$('[data-theme-opt]').forEach(b => b.onclick = () => { S.setSetting('theme', b.dataset.themeOpt); applyTheme(); route('settings'); });
    $$('.accent-dot').forEach(d => d.onclick = () => { S.setSetting('accent', d.dataset.accent); applyAccent(); $$('.accent-dot').forEach(x => x.classList.toggle('active', x === d)); toast('🎨', 'Accent updated'); });

    $('#pinToggle').onclick = () => {
      const st = S.getSettings();
      if (st.pinEnabled) {
        confirmModal('Remove PIN lock?', 'Your diary will open without a PIN.', 'Remove', () => { S.setSetting('pinEnabled', false); S.setSetting('pin', ''); toast('🔓', 'PIN lock removed'); route('settings'); });
      } else { showLock('set'); }
    };

    const als = $('#autoLockSelect');
    als.value = String(S.getSettings().autoLockMinutes);
    als.onchange = (e) => {
      const mins = Number(e.target.value);
      S.setSetting('autoLockMinutes', mins);
      resetAutoLock();
      if (mins && !S.getSettings().pinEnabled) toast('🔒', 'Turn on PIN lock for auto-lock to work');
      else toast('🔒', mins ? `Auto-lock after ${mins} min` : 'Auto-lock turned off');
      route('settings');
    };

    $('#reminderToggle').onclick = async () => {
      const en = !S.getSettings().reminderEnabled;
      if (en && 'Notification' in window && Notification.permission === 'default') {
        try { await Notification.requestPermission(); } catch (_) {}
      }
      S.setSetting('reminderEnabled', en);
      S.setSetting('lastReminded', '');
      startReminderWatch();
      toast(en ? '🔔' : '🔕', en ? 'Daily reminder on' : 'Daily reminder off');
      route('settings');
    };
    $('#reminderTime').onchange = (e) => {
      const t = e.target.value || '20:00';
      S.setSetting('reminderTime', t);
      S.setSetting('lastReminded', '');
      toast('🔔', `Reminder set for ${fmtTime(t)}`);
    };

    const aps = $('#aiProviderSelect');
    if (aps) {
      aps.value = S.getSettings().aiProvider || 'puter';
      const sync = () => { const p = aps.value; const hf = $('#hfKeyRow'), gm = $('#geminiKeyRow'); if (hf) hf.style.display = p === 'hf' ? '' : 'none'; if (gm) gm.style.display = p === 'gemini' ? '' : 'none'; };
      sync();
      aps.onchange = () => { S.setSetting('aiProvider', aps.value); S.setSetting('aiConfigured', true); sync(); toast('✨', 'AI engine: ' + ((AI.PROVIDERS[aps.value] || {}).name || aps.value)); };
    }
    const hk = $('#setHfToken'); if (hk) hk.onchange = (e) => { S.setSetting('hfToken', e.target.value.trim()); S.setSetting('aiConfigured', true); toast('✨', e.target.value.trim() ? 'Hugging Face token saved' : 'Token cleared'); };
    const gk = $('#setGeminiKey'); if (gk) gk.onchange = (e) => { S.setSetting('geminiKey', e.target.value.trim()); S.setSetting('aiConfigured', true); toast('✨', e.target.value.trim() ? 'Gemini key saved' : 'Key cleared'); };

    const lms = $('#lockModeSelect');
    if (lms) {
      lms.value = S.getSettings().lockMode || 'nature';
      lms.onchange = () => { S.setSetting('lockMode', lms.value); App.lockImageId = null; toast('🖼️', lms.value === 'images' ? 'Lock screen: your media' : 'Lock screen: nature scenes'); };
      renderLockImages();   // library is always visible so you can add media anytime
      const add = $('#lockImgAdd'); if (add) add.onclick = () => $('#lockImgInput').click();
      const inp = $('#lockImgInput'); if (inp) inp.onchange = (e) => { handleLockImages(e.target.files); e.target.value = ''; };
    }

    $('#exportBtn').onclick = exportJournal;
    $('#importBtn').onclick = () => $('#importFile').click();
    $('#importFile').onchange = importJournal;
    $('#clearBtn').onclick = () => confirmModal('Delete all entries?', 'This will permanently erase every entry in your diary. This action cannot be undone.', 'Delete everything', () => { S.clearEntries(); toast('🗑️', 'All entries deleted'); refreshShell(); route('settings'); }, true);
  }

  function exportJournal() {
    const blob = new Blob([S.exportData()], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `lumina-diary-${S.todayISO()}.json`;
    a.click(); URL.revokeObjectURL(a.href);
    toast('📥', 'Diary exported');
  }
  function importJournal(e) {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try { S.importData(reader.result); toast('📤', 'Diary imported'); refreshShell(); route('settings'); }
      catch (err) { toast('⚠️', 'Could not import that file'); }
    };
    reader.readAsText(file);
    e.target.value = '';
  }

  /* ============================================================
     LUMI · AI assistant
     ============================================================ */
  const LUMI_KEY = 'lumina.lumi.v1';
  function convId() { return 'c_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function deriveTitle(thread) {
    const first = (thread || []).find(m => m.role === 'user');
    const t = (first ? first.text : '').trim().replace(/\s+/g, ' ');
    if (!t) return (first && first.images && first.images.length) ? '🖼️ Image' : 'New chat';
    return t.length > 42 ? t.slice(0, 42) + '…' : t;
  }
  function relTimeShort(ts) {
    const m = Math.floor((Date.now() - (ts || Date.now())) / 60000);
    if (m < 1) return 'just now';
    if (m < 60) return m + 'm ago';
    const h = Math.floor(m / 60); if (h < 24) return h + 'h ago';
    const d = Math.floor(h / 24); if (d < 7) return d + 'd ago';
    return Math.floor(d / 7) + 'w ago';
  }
  function lumiLoad() {
    let raw = {};
    try { raw = JSON.parse(localStorage.getItem(LUMI_KEY)) || {}; } catch (e) {}
    let conversations = Array.isArray(raw.conversations) ? raw.conversations : [];
    if (!conversations.length && Array.isArray(raw.thread) && raw.thread.length) { // migrate old single-thread format
      conversations = [{ id: convId(), title: deriveTitle(raw.thread), thread: raw.thread, createdAt: Date.now(), updatedAt: Date.now() }];
    }
    const images = Array.isArray(raw.images) ? raw.images : [];
    const currentId = (raw.currentId && conversations.some(c => c.id === raw.currentId)) ? raw.currentId : ((conversations[0] && conversations[0].id) || null);
    return { conversations, currentId, images };
  }
  function lumiSave() { try { localStorage.setItem(LUMI_KEY, JSON.stringify({ conversations: App.lumi.conversations, currentId: App.lumi.currentId, images: App.lumi.images })); } catch (e) {} }
  function lumiConversation() {
    if (!App.lumi.conversations) App.lumi.conversations = [];
    let c = App.lumi.conversations.find(x => x.id === App.lumi.currentId);
    if (!c) {
      if (App.lumi.conversations.length) c = App.lumi.conversations[0];
      else { c = { id: convId(), title: '', thread: [], createdAt: Date.now(), updatedAt: Date.now() }; App.lumi.conversations.unshift(c); }
      App.lumi.currentId = c.id;
    }
    return c;
  }
  function lumiNewChat() {
    const cur = lumiConversation();
    if (!cur.thread.length) return false; // current chat is already empty
    const c = { id: convId(), title: '', thread: [], createdAt: Date.now(), updatedAt: Date.now() };
    App.lumi.conversations.unshift(c); App.lumi.currentId = c.id; lumiSave();
    return true;
  }

  const LUMI_SYSTEM = "You are Lumi, a warm, upbeat study companion living inside a personal diary app called Lumina. You help with studying, explaining concepts simply with everyday examples, brainstorming, and answering questions. Be concise but encouraging. Use Markdown (headings, **bold**, bullet lists, `code`) so answers are easy to scan. When teaching, break things into steps and offer to go deeper or quiz the user.";
  const LUMI_SUGGESTIONS = [
    'Explain photosynthesis like I\'m 12',
    'Quiz me on the planets',
    'Help me plan a week of revision',
    'Summarize the causes of World War I',
    'Give me a memory trick for the periodic table',
    'What\'s the difference between mitosis and meiosis?',
  ];

  function renderLumi(c) {
    if (!App.lumi) { App.lumi = Object.assign({ mode: 'chat', busy: false }, lumiLoad()); lumiSave(); }
    if (!App.lumi.mode) App.lumi.mode = 'chat';

    if (App.lumi.showSetup || !S.getSettings().aiConfigured || !AI.ready()) {
      c.innerHTML = lumiHeadHTML() + lumiSetupHTML(); bindLumiSetup(); return;
    }

    const prov = AI.PROVIDERS[AI.provider()] || { name: 'AI' };
    const modes = [
      ['chat', '💬', 'Chat'], ['image', '🎨', 'Create image'],
      ['flashcards', '🎴', 'Flashcards'], ['quiz', '❓', 'Quiz'],
      ['summarize', '📝', 'Summarize'], ['plan', '🗓️', 'Study plan'],
    ];
    c.innerHTML = lumiHeadHTML()
      + `<div class="lumi-provider-bar">Powered by <strong>${esc(prov.name)}</strong> · <button class="link-btn" id="lumiChangeProvider">change</button></div>`
      + `<div class="lumi-modes">${modes.map(([id, e, l]) => `<button class="lumi-mode ${App.lumi.mode === id ? 'active' : ''}" data-lumi-mode="${id}">${e} ${l}</button>`).join('')}</div>`
      + `<div id="lumiPanel" class="lumi-panel"></div>`;
    $('#lumiChangeProvider').onclick = () => { App.lumi.showSetup = true; renderLumi(c); };
    $$('.lumi-mode').forEach(b => b.onclick = () => setLumiMode(b.dataset.lumiMode));
    renderLumiPanel();
  }

  function lumiHeadHTML() {
    return `<div class="lumi-head"><div class="lumi-avatar">✨</div><div><h1>Lumi</h1><p>Your AI study companion, chat, create images, and learn faster.</p></div></div>`;
  }

  function lumiSetupHTML() {
    const cur = AI.provider();
    const opts = [
      ['hf', '🤗', 'Hugging Face', 'Free, needs a Hugging Face access token (about a minute to create).'],
      ['puter', '⚡', 'Puter', 'No key at all, works instantly. May ask you to make a free Puter account.'],
      ['gemini', '✨', 'Google Gemini', 'Free, needs a Google AI Studio API key.'],
    ];
    return `<div class="tool-card lumi-setup">
      <div class="lumi-avatar">✨</div>
      <h2>Set up Lumi</h2>
      <p>Pick how to power Lumi, you can change this anytime.</p>
      <div class="provider-picker" id="providerPicker">
        ${opts.map(([id, e, name, desc]) => `<button class="provider-opt ${cur === id ? 'active' : ''}" data-prov="${id}"><span class="provider-emoji">${e}</span><span class="provider-name">${name}</span><span class="provider-desc">${desc}</span></button>`).join('')}
      </div>
      <div id="providerBody"></div>
      <p class="lumi-privacy">🔒 Your diary stays 100% on this device. Only the messages you send to Lumi leave it, to generate replies.</p>
    </div>`;
  }
  function bindLumiSetup() {
    let sel = AI.provider();
    const renderBody = () => {
      const st = S.getSettings();
      const el = $('#providerBody');
      if (sel === 'puter') {
        el.innerHTML = `<p class="lumi-privacy" style="margin:14px 0">⚡ No key required. Click start, the first time, Puter may show a quick free sign-in.</p><button class="btn btn-primary btn-block" id="lumiStart">Start using Lumi →</button>`;
      } else if (sel === 'hf') {
        el.innerHTML = `<ol class="lumi-steps"><li>Open <a href="https://huggingface.co/settings/tokens" target="_blank" rel="noopener">huggingface.co/settings/tokens</a></li><li>Click <strong>Create new token</strong> → type <strong>Read</strong> (free).</li><li>Copy it and paste below.</li></ol><div class="key-row"><input type="password" id="provKey" class="text-input" placeholder="hf_… your token" value="${esc(st.hfToken)}" autocomplete="off" /><button class="btn btn-primary" id="lumiStart">Connect</button></div>`;
      } else {
        el.innerHTML = `<ol class="lumi-steps"><li>Open <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener">aistudio.google.com/app/apikey</a></li><li>Click <strong>Create API key</strong>, free, no card.</li><li>Copy it and paste below.</li></ol><div class="key-row"><input type="password" id="provKey" class="text-input" placeholder="Gemini API key" value="${esc(st.geminiKey)}" autocomplete="off" /><button class="btn btn-primary" id="lumiStart">Connect</button></div>`;
      }
      const start = () => {
        if (sel === 'hf') { const k = $('#provKey').value.trim(); if (!k) { $('#provKey').focus(); return; } S.setSetting('hfToken', k); }
        else if (sel === 'gemini') { const k = $('#provKey').value.trim(); if (!k) { $('#provKey').focus(); return; } S.setSetting('geminiKey', k); }
        S.setSetting('aiProvider', sel);
        S.setSetting('aiConfigured', true);
        App.lumi.showSetup = false;
        toast('✨', 'Lumi is ready!');
        route('lumi');
      };
      const b = $('#lumiStart'); if (b) b.onclick = start;
      const k = $('#provKey'); if (k) { k.onkeydown = (e) => { if (e.key === 'Enter') start(); }; setTimeout(() => k.focus(), 60); }
    };
    $$('#providerPicker .provider-opt').forEach(o => o.onclick = () => { sel = o.dataset.prov; $$('#providerPicker .provider-opt').forEach(x => x.classList.toggle('active', x === o)); renderBody(); });
    renderBody();
  }

  function setLumiMode(m) { App.lumi.mode = m; $$('.lumi-mode').forEach(b => b.classList.toggle('active', b.dataset.lumiMode === m)); renderLumiPanel(); }
  function renderLumiPanel() {
    const p = $('#lumiPanel'); if (!p) return;
    ({ chat: renderChat, image: renderImageTool, flashcards: renderFlashTool, quiz: renderQuizTool, summarize: renderSummarizeTool, plan: renderPlanTool }[App.lumi.mode] || renderChat)(p);
  }
  function scrollViewTop() { const s = $('.view-scroll'); if (s) s.scrollTop = 0; }
  function scrollMessages() { const s = $('.view-scroll'); if (s) s.scrollTop = s.scrollHeight; }
  function downloadDataUrl(url, name) { const a = document.createElement('a'); a.href = url; a.download = name; a.click(); }

  /* ---------- chat ---------- */
  function renderChat(p) {
    const conv = lumiConversation();
    const empty = !conv.thread.length;
    const recents = App.lumi.conversations.filter(c => c.thread.length > 0).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    p.innerHTML = `
      <div class="lumi-chat">
        <div class="lumi-chat-bar">
          <button class="chip" id="lumiNewChat">＋ New chat</button>
          ${recents.length ? `<button class="chip" id="lumiRecentsToggle">🕘 Recents <em class="chip-n">${recents.length}</em></button>` : ''}
        </div>
        ${recents.length ? `<div class="lumi-recents hidden" id="lumiRecents">${recents.map(recentItemHTML).join('')}</div>` : ''}
        <div class="lumi-messages" id="lumiMessages">
          ${empty ? `<div class="lumi-suggestions">${LUMI_SUGGESTIONS.map(s => `<button class="lumi-suggestion" data-suggest="${esc(s)}">${esc(s)}</button>`).join('')}</div>` : conv.thread.map(msgHTML).join('')}
        </div>
        <div class="lumi-composer">
          <div class="lumi-attach-preview hidden" id="lumiAttach"></div>
          <div class="lumi-composer-row">
            <button class="lumi-attach-btn" id="lumiAttachBtn" title="Attach an image"><svg viewBox="0 0 24 24" width="20" height="20"><rect x="3" y="5" width="18" height="14" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"/><circle cx="8.5" cy="10" r="1.6" fill="currentColor"/><path d="M21 16l-5-5-7 7" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
            <textarea id="lumiInput" class="lumi-input" rows="1" placeholder="Ask Lumi anything…  (Enter to send, Shift+Enter for a new line)"></textarea>
            <button class="lumi-send" id="lumiSend" title="Send"><svg viewBox="0 0 24 24" width="20" height="20"><path d="M4 12l16-8-6 8 6 8-16-8z" fill="currentColor"/></svg></button>
          </div>
          <input type="file" id="lumiImgInput" accept="image/*" hidden>
        </div>
      </div>`;
    bindChat();
    scrollMessages();
  }
  function recentItemHTML(c) {
    const n = c.thread.filter(m => m.role === 'user').length;
    const active = c.id === App.lumi.currentId;
    return `<div class="recent-item ${active ? 'active' : ''}" data-conv="${c.id}" role="button" tabindex="0">
      <span class="recent-ic">💬</span>
      <span class="recent-main"><span class="recent-title">${esc(c.title || deriveTitle(c.thread))}</span><span class="recent-meta">${n} message${n === 1 ? '' : 's'} · ${relTimeShort(c.updatedAt || c.createdAt)}</span></span>
      <span class="recent-del" data-del-conv="${c.id}" title="Delete chat">×</span>
    </div>`;
  }
  function msgHTML(m) {
    if (m.role === 'user') {
      const imgs = (m.images || []).map(src => `<img class="msg-img" src="${src}" alt="attached image" data-lumi-img="1">`).join('');
      const txt = m.text ? esc(m.text).replace(/\n/g, '<br>') : '';
      return `<div class="msg user"><div class="msg-avatar">🙂</div><div class="msg-bubble">${imgs}${txt}</div></div>`;
    }
    return `<div class="msg lumi"><div class="msg-avatar">✨</div><div class="msg-bubble">${md(m.text)}</div></div>`;
  }
  function bindChat() {
    const input = $('#lumiInput');
    if (input) {
      const grow = () => { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 168) + 'px'; };
      input.oninput = grow;
      input.onkeydown = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChat(); } };
      setTimeout(() => input.focus(), 60);
    }
    const s = $('#lumiSend'); if (s) s.onclick = sendChat;
    const ab = $('#lumiAttachBtn'); if (ab) ab.onclick = () => $('#lumiImgInput').click();
    const li = $('#lumiImgInput'); if (li) li.onchange = (e) => { attachLumiImage(e.target.files); e.target.value = ''; };
    renderLumiAttach();
    const msgsEl = $('#lumiMessages'); if (msgsEl) msgsEl.addEventListener('click', (e) => { const img = e.target.closest('[data-lumi-img]'); if (img) openLightbox(img.src); });
    const nc = $('#lumiNewChat'); if (nc) nc.onclick = () => { if (lumiNewChat()) renderChat($('#lumiPanel')); else { toast('💬', 'Already a fresh chat'); const i = $('#lumiInput'); if (i) i.focus(); } };
    const rt = $('#lumiRecentsToggle'); if (rt) rt.onclick = () => { const r = $('#lumiRecents'); if (r) { r.classList.toggle('hidden'); rt.classList.toggle('active'); } };
    $$('#lumiRecents .recent-item').forEach(it => {
      it.onclick = (e) => { if (e.target.closest('[data-del-conv]')) return; App.lumi.currentId = it.dataset.conv; lumiSave(); renderChat($('#lumiPanel')); };
    });
    $$('#lumiRecents [data-del-conv]').forEach(d => {
      d.onclick = (e) => {
        e.stopPropagation();
        const id = d.dataset.delConv;
        App.lumi.conversations = App.lumi.conversations.filter(c => c.id !== id);
        if (App.lumi.currentId === id) App.lumi.currentId = (App.lumi.conversations[0] && App.lumi.conversations[0].id) || null;
        lumiSave(); renderChat($('#lumiPanel'));
      };
    });
    $$('[data-suggest]').forEach(b => b.onclick = () => { $('#lumiInput').value = b.dataset.suggest; sendChat(); });
  }
  async function attachLumiImage(fileList) {
    const f = [...fileList].find(x => x.type.startsWith('image/'));
    if (!f) return;
    try { App.lumi.pendingImage = await compressImage(f, 1024, 0.82); renderLumiAttach(); }
    catch (e) { toast('⚠️', 'Could not read that image'); }
  }
  function renderLumiAttach() {
    const el = $('#lumiAttach'); if (!el) return;
    if (App.lumi && App.lumi.pendingImage) {
      el.classList.remove('hidden');
      el.innerHTML = `<div class="ap-thumb"><img src="${App.lumi.pendingImage}" alt="attachment"><button class="ap-del" id="lumiAttachDel" title="Remove">×</button></div>`;
      const d = $('#lumiAttachDel'); if (d) d.onclick = () => { App.lumi.pendingImage = null; renderLumiAttach(); };
    } else { el.classList.add('hidden'); el.innerHTML = ''; }
  }

  async function sendChat() {
    const input = $('#lumiInput'); if (!input) return;
    const text = input.value.trim();
    const pending = App.lumi.pendingImage;
    if ((!text && !pending) || App.lumi.busy) return;
    input.value = ''; input.style.height = 'auto';
    App.lumi.busy = true;

    const conv = lumiConversation();
    const wasEmpty = conv.thread.length === 0;
    const userMsg = { role: 'user', text };
    if (pending) userMsg.images = [pending];
    conv.thread.push(userMsg);
    if (!conv.title) conv.title = deriveTitle(conv.thread);
    conv.updatedAt = Date.now();
    lumiSave();
    App.lumi.pendingImage = null; renderLumiAttach();

    if (wasEmpty) {
      renderChat($('#lumiPanel')); // rebuild so the Recents control + first message appear
    } else {
      const m = $('#lumiMessages');
      const sug = m.querySelector('.lumi-suggestions'); if (sug) sug.remove();
      m.insertAdjacentHTML('beforeend', msgHTML(userMsg));
    }

    const sendBtn = $('#lumiSend'); if (sendBtn) sendBtn.disabled = true;
    const msgs = $('#lumiMessages');
    const tid = 'lm' + Date.now();
    msgs.insertAdjacentHTML('beforeend', `<div class="msg lumi" id="${tid}"><div class="msg-avatar">✨</div><div class="msg-bubble"><div class="typing"><span></span><span></span><span></span></div></div></div>`);
    scrollMessages();

    const bubble = () => { const el = document.getElementById(tid); return el ? el.querySelector('.msg-bubble') : null; };
    try {
      let full = '';
      await AI.chatStream(conv.thread, LUMI_SYSTEM, (delta, all) => { full = all; const b = bubble(); if (b) b.innerHTML = md(all); scrollMessages(); });
      if (full.trim()) { conv.thread.push({ role: 'model', text: full }); conv.updatedAt = Date.now(); lumiSave(); }
      else { const b = bubble(); if (b) b.innerHTML = md('_(no response, try again)_'); }
    } catch (e) {
      const b = bubble(); if (b) b.innerHTML = `<div class="lumi-error">⚠️ ${esc(e.message || 'Something went wrong.')}</div>`;
    } finally {
      App.lumi.busy = false; const s = $('#lumiSend'); if (s) s.disabled = false;
      const inp = $('#lumiInput'); if (inp) inp.focus();
      scrollMessages();
    }
  }

  /* ---------- image ---------- */
  function renderImageTool(p) {
    const styles = ['Photographic', 'Digital art', 'Watercolor', '3D render', 'Anime', 'Minimalist', 'Oil painting', 'Pixel art'];
    p.innerHTML = `
      <div class="tool-card">
        <label class="tool-label" for="imgPrompt">Describe the image you want</label>
        <textarea id="imgPrompt" class="tool-textarea" placeholder="e.g. a cozy reading nook by a rainy window, warm lamplight, plants"></textarea>
        <div class="tool-row">${styles.map(s => `<button class="style-chip" data-style="${s}">${s}</button>`).join('')}</div>
        <div class="tool-row"><button class="btn btn-primary" id="imgGenerate">🎨 Generate image</button><span class="view-sub" style="font-size:12px">May take a few seconds</span></div>
      </div>
      <div id="imgOutput"></div>
      ${App.lumi.images.length ? `<div class="tool-card"><div class="tool-head"><label class="tool-label" style="margin:0">Your creations</label><button class="chip" id="imgClearAll">🗑 Clear all</button></div><div class="img-gallery">${App.lumi.images.map((im, i) => `<div class="img-thumb" data-img-i="${i}"><img src="${im.image}" alt="${esc(im.prompt)}"><button class="thumb-del" data-del-img="${i}" title="Delete image">×</button></div>`).join('')}</div></div>` : ''}`;
    let style = '';
    $$('.style-chip').forEach(ch => ch.onclick = () => { const on = ch.classList.contains('active'); $$('.style-chip').forEach(x => x.classList.remove('active')); if (!on) { ch.classList.add('active'); style = ch.dataset.style; } else style = ''; });
    $('#imgGenerate').onclick = async () => {
      const el = $('#imgPrompt'); let prompt = el.value.trim(); if (!prompt) { el.focus(); return; }
      if (style) prompt += `, ${style} style`;
      const btn = $('#imgGenerate'); btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Generating…';
      $('#imgOutput').innerHTML = `<div class="img-loading"><span class="spinner"></span> Painting your image…</div>`;
      try {
        const { image } = await AI.generateImage(prompt);
        App.lumi.images.unshift({ image, prompt }); if (App.lumi.images.length > 24) App.lumi.images.pop(); lumiSave();
        $('#imgOutput').innerHTML = `<div class="img-result"><img src="${image}" alt="${esc(prompt)}"><div class="img-result-bar"><span class="prompt">${esc(prompt)}</span><button class="btn btn-ghost btn-sm" id="imgDl">⬇ Download</button><button class="btn btn-ghost btn-sm" id="imgDiary">📔 Add to diary</button></div></div>`;
        $('#imgDl').onclick = () => downloadDataUrl(image, 'lumi-image-' + Date.now() + '.png');
        $('#imgDiary').onclick = () => { const d = S.createDraft(); d.photos = [image]; d.title = prompt.slice(0, 60); openEditor(d, true); };
      } catch (e) { $('#imgOutput').innerHTML = `<div class="lumi-error">⚠️ ${esc(e.message)}</div>`; }
      finally { btn.disabled = false; btn.innerHTML = '🎨 Generate image'; }
    };
    $$('.img-thumb').forEach(t => t.onclick = (e) => { if (e.target.closest('[data-del-img]')) return; openLightbox(App.lumi.images[+t.dataset.imgI].image); });
    $$('[data-del-img]').forEach(b => b.onclick = (e) => { e.stopPropagation(); App.lumi.images.splice(+b.dataset.delImg, 1); lumiSave(); renderImageTool(p); });
    const clr = $('#imgClearAll'); if (clr) clr.onclick = () => { App.lumi.images = []; lumiSave(); renderImageTool(p); toast('🗑️', 'Cleared your images'); };
  }

  /* ---------- flashcards ---------- */
  function renderFlashTool(p) {
    p.innerHTML = `
      <div class="tool-card">
        <label class="tool-label" for="fcTopic">Topic, or paste your notes</label>
        <textarea id="fcTopic" class="tool-textarea" placeholder="e.g. The water cycle, or paste a paragraph of notes"></textarea>
        <div class="tool-row"><label class="tool-label" style="margin:0">How many</label><input type="number" id="fcCount" class="text-input num-input" value="8" min="3" max="20"><button class="btn btn-primary" id="fcGen">🎴 Make flashcards</button></div>
      </div>
      <div id="fcOutput"></div>`;
    $('#fcGen').onclick = genFlashcards;
  }
  async function genFlashcards() {
    const topic = $('#fcTopic').value.trim(); if (!topic) { $('#fcTopic').focus(); return; }
    const n = Math.max(3, Math.min(20, +$('#fcCount').value || 8));
    const btn = $('#fcGen'); btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Creating…';
    $('#fcOutput').innerHTML = loadingHTML('Building your deck…');
    try {
      const data = await AI.completeJSON(`Create ${n} study flashcards for: ${topic}. Each flashcard is an object with "front" (a question or term) and "back" (a concise answer or definition). Return a JSON array.`, 'You are a helpful study assistant who writes clear, accurate flashcards.');
      const cards = (Array.isArray(data) ? data : data.flashcards || data.cards || []).map(c => ({ front: c.front || c.term || c.q, back: c.back || c.definition || c.a })).filter(c => c.front && c.back);
      if (!cards.length) throw new Error('Could not build flashcards from that, try rephrasing.');
      App.lumi.fc = { cards, i: 0 };
      $('#fcOutput').innerHTML = flashcardHTML(); bindFlashcards();
    } catch (e) { $('#fcOutput').innerHTML = `<div class="lumi-error">⚠️ ${esc(e.message)}</div>`; }
    finally { btn.disabled = false; btn.innerHTML = '🎴 Make flashcards'; }
  }
  function flashcardHTML() {
    const { cards, i } = App.lumi.fc; const c = cards[i];
    return `<div class="tool-card">
      <div class="fc-wrap">
        <button class="fc-del" id="fcDelCard" title="Delete this card">🗑</button>
        <div class="flashcard" id="theCard"><div class="flashcard-inner">
          <div class="flashcard-face flashcard-front"><div class="fc-q">${esc(c.front)}</div><div class="flashcard-hint">click to reveal</div></div>
          <div class="flashcard-face flashcard-back"><div class="fc-a">${esc(c.back)}</div><div class="flashcard-hint">click to flip back</div></div>
        </div></div>
      </div>
      <div class="fc-nav"><button class="icon-btn" id="fcPrev" title="Previous"><svg viewBox="0 0 24 24" width="20" height="20"><path d="M15 18l-6-6 6-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button><span class="fc-count">${i + 1} / ${cards.length}</span><button class="icon-btn" id="fcNext" title="Next"><svg viewBox="0 0 24 24" width="20" height="20"><path d="M9 18l6-6-6-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button><button class="chip" id="fcShuffle">🔀 Shuffle</button><button class="chip" id="fcDiscard">✕ Discard deck</button></div>
    </div>`;
  }
  function bindFlashcards() {
    const card = $('#theCard'); if (card) card.onclick = () => card.classList.toggle('flipped');
    const refresh = () => { $('#fcOutput').innerHTML = flashcardHTML(); bindFlashcards(); };
    $('#fcPrev').onclick = () => { const f = App.lumi.fc; f.i = (f.i - 1 + f.cards.length) % f.cards.length; refresh(); };
    $('#fcNext').onclick = () => { const f = App.lumi.fc; f.i = (f.i + 1) % f.cards.length; refresh(); };
    $('#fcShuffle').onclick = () => { App.lumi.fc.cards.sort(() => Math.random() - 0.5); App.lumi.fc.i = 0; refresh(); };
    $('#fcDelCard').onclick = () => {
      const f = App.lumi.fc; f.cards.splice(f.i, 1);
      if (!f.cards.length) { App.lumi.fc = null; renderFlashTool($('#lumiPanel')); toast('🗑️', 'Deck cleared'); return; }
      if (f.i >= f.cards.length) f.i = f.cards.length - 1;
      refresh();
    };
    $('#fcDiscard').onclick = () => { App.lumi.fc = null; renderFlashTool($('#lumiPanel')); };
  }

  /* ---------- quiz ---------- */
  function renderQuizTool(p) {
    p.innerHTML = `
      <div class="tool-card">
        <label class="tool-label" for="qzTopic">Topic, or paste your notes</label>
        <textarea id="qzTopic" class="tool-textarea" placeholder="e.g. Basic chemistry, atoms and molecules"></textarea>
        <div class="tool-row"><label class="tool-label" style="margin:0">Questions</label><input type="number" id="qzCount" class="text-input num-input" value="5" min="3" max="15"><button class="btn btn-primary" id="qzGen">❓ Make quiz</button></div>
      </div>
      <div id="qzOutput"></div>`;
    $('#qzGen').onclick = genQuiz;
  }
  async function genQuiz() {
    const topic = $('#qzTopic').value.trim(); if (!topic) { $('#qzTopic').focus(); return; }
    const n = Math.max(3, Math.min(15, +$('#qzCount').value || 5));
    const btn = $('#qzGen'); btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Writing…';
    $('#qzOutput').innerHTML = loadingHTML('Writing your quiz…');
    try {
      const data = await AI.completeJSON(`Create a ${n}-question multiple-choice quiz about: ${topic}. Each question is an object: {"question": string, "options": [4 strings], "answer": the index 0-3 of the correct option, "explanation": a short reason}. Return a JSON array.`, 'You write accurate multiple-choice quizzes for studying.');
      const qs = (Array.isArray(data) ? data : data.quiz || data.questions || []).filter(q => q && q.question && Array.isArray(q.options) && q.options.length >= 2).map(q => ({ question: q.question, options: q.options, answer: Number(q.answer) || 0, explanation: q.explanation || '' }));
      if (!qs.length) throw new Error('Could not build a quiz from that, try rephrasing.');
      App.lumi.quiz = { qs, answers: {}, submitted: false };
      renderQuiz();
    } catch (e) { $('#qzOutput').innerHTML = `<div class="lumi-error">⚠️ ${esc(e.message)}</div>`; }
    finally { btn.disabled = false; btn.innerHTML = '❓ Make quiz'; }
  }
  function renderQuiz() {
    const { qs, answers, submitted } = App.lumi.quiz;
    const letters = ['A', 'B', 'C', 'D', 'E', 'F'];
    let score = 0; qs.forEach((q, i) => { if (answers[i] === q.answer) score++; });
    let html = '';
    if (submitted) html += `<div class="quiz-score"><div class="score-num">${score}/${qs.length}</div><div class="view-sub">${score === qs.length ? 'Perfect! 🎉' : score >= qs.length * 0.6 ? 'Nice work! 👏' : 'Keep studying, you\'ve got this 💪'}</div></div>`;
    html += qs.map((q, i) => `
      <div class="quiz-q">
        <div class="quiz-q-title"><em>Q${i + 1}.</em>${esc(q.question)}</div>
        ${q.options.map((o, j) => { let cls = 'quiz-opt'; if (submitted) { cls += ' locked'; if (j === q.answer) cls += ' correct'; else if (answers[i] === j) cls += ' wrong'; } else if (answers[i] === j) cls += ' selected'; return `<div class="${cls}" data-q="${i}" data-o="${j}"><span class="opt-letter">${letters[j]}</span><span>${esc(o)}</span></div>`; }).join('')}
        ${submitted && q.explanation ? `<div class="quiz-explain">💡 ${esc(q.explanation)}</div>` : ''}
      </div>`).join('');
    html += submitted
      ? `<div class="tool-row" style="margin-top:6px"><button class="btn btn-primary" id="qzRetry">Make another quiz</button><button class="btn btn-ghost" id="qzDiscard">Discard</button></div>`
      : `<div class="tool-row" style="margin-top:6px"><button class="btn btn-primary" id="qzSubmit">Submit answers</button><button class="btn btn-ghost" id="qzDiscard">Discard</button></div>`;
    $('#qzOutput').innerHTML = html;
    if (!submitted) {
      $$('#qzOutput .quiz-opt').forEach(o => o.onclick = () => { App.lumi.quiz.answers[+o.dataset.q] = +o.dataset.o; renderQuiz(); });
      const sub = $('#qzSubmit'); if (sub) sub.onclick = () => { App.lumi.quiz.submitted = true; renderQuiz(); scrollViewTop(); };
    } else { const r = $('#qzRetry'); if (r) r.onclick = () => renderQuizTool($('#lumiPanel')); }
    const disc = $('#qzDiscard'); if (disc) disc.onclick = () => { App.lumi.quiz = null; renderQuizTool($('#lumiPanel')); };
  }

  /* ---------- summarize ---------- */
  function renderSummarizeTool(p) {
    p.innerHTML = `
      <div class="tool-card">
        <label class="tool-label" for="smInput">Paste notes, an article, or any text</label>
        <textarea id="smInput" class="tool-textarea" style="min-height:170px" placeholder="Paste the text you want summarized…"></textarea>
        <div class="tool-row"><button class="btn btn-primary" id="smGen">📝 Summarize</button></div>
      </div>
      <div id="smOutput"></div>`;
    $('#smGen').onclick = async () => {
      const text = $('#smInput').value.trim(); if (!text) { $('#smInput').focus(); return; }
      const btn = $('#smGen'); btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Summarizing…';
      $('#smOutput').innerHTML = loadingHTML('Reading and summarizing…');
      try {
        const res = await AI.complete(`Summarize the following for studying. Use this exact Markdown structure:\n## Overview\n(2-3 sentences)\n## Key points\n(bullet list)\n## Review questions\n(3 short questions)\n\nText:\n"""${text}"""`, 'You turn text into clear, accurate study notes.', 0.5);
        $('#smOutput').innerHTML = `<div class="tool-card"><div class="result-head"><label class="tool-label" style="margin:0">Summary</label><button class="chip" id="smClear">✕ Clear</button></div><div class="md-result">${md(res)}</div></div>`;
        $('#smClear').onclick = () => { $('#smOutput').innerHTML = ''; };
      } catch (e) { $('#smOutput').innerHTML = `<div class="lumi-error">⚠️ ${esc(e.message)}</div>`; }
      finally { btn.disabled = false; btn.innerHTML = '📝 Summarize'; }
    };
  }

  /* ---------- study plan ---------- */
  function renderPlanTool(p) {
    p.innerHTML = `
      <div class="tool-card">
        <label class="tool-label" for="plGoal">What are you studying for?</label>
        <textarea id="plGoal" class="tool-textarea" placeholder="e.g. Final biology exam covering cells, genetics, and ecology"></textarea>
        <div class="tool-row"><label class="tool-label" style="margin:0">Days</label><input type="number" id="plDays" class="text-input num-input" value="7" min="1" max="60"><label class="tool-label" style="margin:0">Hrs/day</label><input type="number" id="plHours" class="text-input num-input" value="2" min="1" max="12"><button class="btn btn-primary" id="plGen">🗓️ Build plan</button></div>
      </div>
      <div id="plOutput"></div>`;
    $('#plGen').onclick = async () => {
      const goal = $('#plGoal').value.trim(); if (!goal) { $('#plGoal').focus(); return; }
      const days = Math.max(1, Math.min(60, +$('#plDays').value || 7)), hrs = Math.max(1, Math.min(12, +$('#plHours').value || 2));
      const btn = $('#plGen'); btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Planning…';
      $('#plOutput').innerHTML = loadingHTML('Designing your plan…');
      try {
        const res = await AI.complete(`Create a ${days}-day study plan, about ${hrs} hours per day, for: ${goal}. Use Markdown with a "## Day X" heading for each day, a one-line focus, specific topics/tasks as a bullet list, and a quick tip. End with one motivational line.`, 'You are an expert study coach who builds realistic, encouraging study plans.', 0.6);
        $('#plOutput').innerHTML = `<div class="tool-card"><div class="result-head"><label class="tool-label" style="margin:0">Study plan</label><button class="chip" id="plClear">✕ Clear</button></div><div class="md-result">${md(res)}</div></div>`;
        $('#plClear').onclick = () => { $('#plOutput').innerHTML = ''; };
      } catch (e) { $('#plOutput').innerHTML = `<div class="lumi-error">⚠️ ${esc(e.message)}</div>`; }
      finally { btn.disabled = false; btn.innerHTML = '🗓️ Build plan'; }
    };
  }

  function loadingHTML(label) { return `<div class="img-loading" style="aspect-ratio:auto;height:120px"><span class="spinner"></span> ${esc(label)}</div>`; }

  /* ---------- minimal markdown → safe HTML ---------- */
  function md(t) {
    if (!t) return '';
    var blocks = [], icode = [];
    var s = String(t);
    s = s.replace(/```(\w+)?\n?([\s\S]*?)```/g, function (m, lang, code) { blocks.push('<pre><code>' + esc(code.replace(/\n$/, '')) + '</code></pre>'); return '%%CB' + (blocks.length - 1) + 'CB%%'; });
    s = esc(s);
    s = s.replace(/`([^`]+)`/g, function (m, code) { icode.push('<code>' + code + '</code>'); return '%%IC' + (icode.length - 1) + 'IC%%'; });
    s = s.replace(/^#{4,6}\s+(.*)$/gm, '<h4>$1</h4>').replace(/^#{1,3}\s+(.*)$/gm, '<h3>$1</h3>');
    s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/__([^_]+)__/g, '<strong>$1</strong>');
    s = s.replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<em>$2</em>');
    s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
    s = s.replace(/^&gt;\s?(.*)$/gm, '<blockquote>$1</blockquote>');
    s = s.replace(/^\s*[-*+]\s+(.*)$/gm, '<liu>$1</liu>').replace(/^\s*\d+\.\s+(.*)$/gm, '<lio>$1</lio>');
    s = s.replace(/(?:<liu>[\s\S]*?<\/liu>\s*)+/g, function (m) { return '<ul>' + m.replace(/liu>/g, 'li>') + '</ul>'; });
    s = s.replace(/(?:<lio>[\s\S]*?<\/lio>\s*)+/g, function (m) { return '<ol>' + m.replace(/lio>/g, 'li>') + '</ol>'; });
    s = s.replace(/\n{2,}/g, '</p><p>').replace(/\n/g, '<br>');
    s = '<p>' + s + '</p>';
    s = s.replace(/<p>\s*(<(?:ul|ol|h3|h4|blockquote)[\s\S]*?<\/(?:ul|ol|h3|h4|blockquote)>)\s*<\/p>/g, '$1');
    s = s.replace(/%%IC(\d+)IC%%/g, function (m, i) { return icode[+i]; });
    s = s.replace(/<p>\s*<\/p>/g, '');
    s = s.replace(/%%CB(\d+)CB%%/g, function (m, i) { return blocks[+i]; });
    s = s.replace(/<p>\s*(<pre>[\s\S]*?<\/pre>)\s*<\/p>/g, '$1');
    return s;
  }

  /* ============================================================
     EDITOR
     ============================================================ */
  function openEditor(entry, isNew) {
    App.editing = entry;
    App.editingIsNew = isNew;
    App.editingPersisted = !isNew;

    $('#entryDate').value = entry.date;
    $('#entryTitle').value = entry.title || '';
    $('#entryContent').innerHTML = entry.content || '';
    renderMoodSelector(entry.mood);
    renderWeatherSelector(entry.weather);
    renderTagChips();
    renderPhotos();
    updateFavEditorBtn();
    newPrompt();
    updateCounts();
    $('#saveState').textContent = isNew ? '' : 'Saved';
    $('#saveState').classList.toggle('saved', !isNew);
    $('#deleteEntryBtn').style.display = isNew ? 'none' : '';

    const ov = $('#editorOverlay');
    ov.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
    setTimeout(() => { (entry.title ? $('#entryContent') : $('#entryTitle')).focus(); }, 250);
  }

  function renderMoodSelector(sel) {
    $('#moodSelector').innerHTML = L.MOODS.map(m => `<button class="mood-opt ${sel === m.id ? 'selected' : ''}" data-mood="${m.id}" title="${m.label}">${m.emoji}</button>`).join('');
  }
  function renderWeatherSelector(sel) {
    $('#weatherSelector').innerHTML = L.WEATHER.map(w => `<button class="weather-opt ${sel === w.id ? 'selected' : ''}" data-weather="${w.id}" title="${w.label}">${w.emoji}</button>`).join('');
  }
  function renderTagChips() {
    const chips = (App.editing.tags || []).map(t => `<span class="tag-chip">#${esc(t)}<button data-rmtag="${esc(t)}">×</button></span>`).join('');
    $('#tagChips').innerHTML = chips;
  }

  /* ---------- photos ---------- */
  function renderPhotos() {
    const photos = App.editing.photos || [];
    $('#photoGrid').innerHTML = photos.map((src, i) => `
      <div class="photo-thumb" data-photo-i="${i}">
        <img src="${src}" alt="Photo ${i + 1}" />
        <button class="photo-remove" data-remove-photo="${i}" title="Remove photo" type="button">×</button>
      </div>`).join('');
  }

  // Downscale + compress an image file to a JPEG data URL (keeps localStorage manageable)
  function compressImage(file, maxDim = 1280, quality = 0.82) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          let { width, height } = img;
          if (width > maxDim || height > maxDim) {
            if (width >= height) { height = Math.round(height * maxDim / width); width = maxDim; }
            else { width = Math.round(width * maxDim / height); height = maxDim; }
          }
          const canvas = document.createElement('canvas');
          canvas.width = width; canvas.height = height;
          canvas.getContext('2d').drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', quality));
        };
        img.onerror = reject;
        img.src = reader.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  async function handlePhotoFiles(fileList) {
    const files = [...fileList].filter(f => f.type.startsWith('image/'));
    if (!files.length) return;
    let added = 0;
    for (const file of files) {
      try {
        const dataURL = await compressImage(file);
        App.editing.photos = App.editing.photos || [];
        App.editing.photos.push(dataURL);
        renderPhotos();
        S.upsert(collectEditor());
        if (!S.saveOk()) { // storage quota exceeded, revert this photo
          App.editing.photos.pop();
          renderPhotos();
          S.upsert(collectEditor());
          toast('⚠️', 'Storage full, try fewer or smaller photos');
          break;
        }
        added++;
      } catch (e) { toast('⚠️', 'Could not add that image'); }
    }
    if (added) {
      App.editingPersisted = true;
      $('#saveState').textContent = 'Saved';
      $('#saveState').classList.add('saved');
      toast('📷', added === 1 ? 'Photo added' : `${added} photos added`);
      refreshShell();
    }
  }

  function openLightbox(src) { $('#lightboxImg').src = src; $('#lightbox').classList.remove('hidden'); }
  function closeLightbox() { $('#lightbox').classList.add('hidden'); $('#lightboxImg').src = ''; }
  function updateFavEditorBtn() {
    const on = App.editing.favorite;
    const btn = $('#favEditorBtn');
    btn.classList.toggle('active', on);
    btn.querySelector('path').setAttribute('fill', on ? 'currentColor' : 'none');
  }

  function newPrompt() { $('#promptText').textContent = L.pick(L.PROMPTS); }

  function updateCounts() {
    const text = $('#entryContent').innerText.trim();
    const words = text ? text.split(/\s+/).length : 0;
    const chars = text.length;
    $('#wordCount').textContent = `${words} ${words === 1 ? 'word' : 'words'}`;
    $('#charCount').textContent = `${chars} characters`;
    const mins = words ? Math.max(1, Math.ceil(words / 220)) : 0;
    $('#readTime').textContent = `${mins} min read`;
  }

  function collectEditor() {
    const e = App.editing;
    e.date = $('#entryDate').value || S.todayISO();
    e.title = $('#entryTitle').value.trim();
    e.content = $('#entryContent').innerHTML;
    return e;
  }

  function isEditorEmpty() {
    const e = App.editing;
    const text = $('#entryContent').innerText.trim();
    return !$('#entryTitle').value.trim() && !text && !e.mood && !e.weather && !(e.tags || []).length && !(e.photos || []).length;
  }

  function scheduleAutosave() {
    $('#saveState').textContent = 'Saving…';
    $('#saveState').classList.remove('saved');
    clearTimeout(App.autosaveTimer);
    App.autosaveTimer = setTimeout(() => {
      if (isEditorEmpty()) { $('#saveState').textContent = ''; return; }
      S.upsert(collectEditor());
      App.editingPersisted = true;
      $('#saveState').textContent = 'Saved';
      $('#saveState').classList.add('saved');
      refreshShell();
    }, 700);
  }

  function saveAndClose() {
    if (isEditorEmpty()) { closeEditor(true); return; }
    S.upsert(collectEditor());
    App.editingPersisted = true;
    closeEditor();
    toast('✓', App.editingIsNew ? 'Entry saved' : 'Changes saved');
  }

  function closeEditor(discard) {
    clearTimeout(App.autosaveTimer);
    if (discard && App.editingIsNew && !App.editingPersisted) { /* nothing saved */ }
    $('#editorOverlay').classList.add('hidden');
    document.body.style.overflow = '';
    App.editing = null;
    refreshShell();
    route(App.view);
  }

  function deleteCurrent() {
    confirmModal('Delete this entry?', 'This entry will be permanently removed from your diary.', 'Delete', () => {
      if (App.editing) S.remove(App.editing.id);
      $('#editorOverlay').classList.add('hidden');
      document.body.style.overflow = '';
      App.editing = null;
      toast('🗑️', 'Entry deleted');
      refreshShell();
      route(App.view);
    }, true);
  }

  function bindEditorEvents() {
    $('#closeEditorBtn').onclick = () => closeEditor(true);
    $('#saveEntryBtn').onclick = saveAndClose;
    $('#deleteEntryBtn').onclick = deleteCurrent;

    $('#favEditorBtn').onclick = () => { App.editing.favorite = !App.editing.favorite; updateFavEditorBtn(); scheduleAutosave(); };

    $('#entryContent').addEventListener('input', () => { updateCounts(); scheduleAutosave(); });
    $('#entryTitle').addEventListener('input', scheduleAutosave);
    $('#entryDate').addEventListener('change', scheduleAutosave);

    $('#promptShuffle').onclick = newPrompt;
    $('#promptBanner').addEventListener('click', (e) => { if (e.target.id !== 'promptShuffle') $('#entryContent').focus(); });

    // mood / weather
    $('#moodSelector').addEventListener('click', (e) => {
      const b = e.target.closest('[data-mood]'); if (!b) return;
      const id = b.dataset.mood;
      App.editing.mood = App.editing.mood === id ? '' : id;
      renderMoodSelector(App.editing.mood); scheduleAutosave();
    });
    $('#weatherSelector').addEventListener('click', (e) => {
      const b = e.target.closest('[data-weather]'); if (!b) return;
      const id = b.dataset.weather;
      App.editing.weather = App.editing.weather === id ? '' : id;
      renderWeatherSelector(App.editing.weather); scheduleAutosave();
    });

    // tags
    const tagInput = $('#tagInput');
    tagInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ',') {
        e.preventDefault();
        const v = tagInput.value.trim().replace(/^#/, '').toLowerCase();
        if (v && !(App.editing.tags || []).includes(v)) { (App.editing.tags = App.editing.tags || []).push(v); renderTagChips(); scheduleAutosave(); }
        tagInput.value = '';
      } else if (e.key === 'Backspace' && !tagInput.value && (App.editing.tags || []).length) {
        App.editing.tags.pop(); renderTagChips(); scheduleAutosave();
      }
    });
    $('#tagChips').addEventListener('click', (e) => {
      const b = e.target.closest('[data-rmtag]'); if (!b) return;
      App.editing.tags = (App.editing.tags || []).filter(t => t !== b.dataset.rmtag);
      renderTagChips(); scheduleAutosave();
    });

    // photos
    $('#photoAddBtn').onclick = () => $('#photoInput').click();
    $('#photoInput').onchange = (e) => { handlePhotoFiles(e.target.files); e.target.value = ''; };
    $('#photoGrid').addEventListener('click', (e) => {
      const rm = e.target.closest('[data-remove-photo]');
      if (rm) {
        const i = +rm.dataset.removePhoto;
        App.editing.photos.splice(i, 1);
        renderPhotos();
        S.upsert(collectEditor());
        App.editingPersisted = true;
        $('#saveState').textContent = 'Saved'; $('#saveState').classList.add('saved');
        refreshShell();
        return;
      }
      const thumb = e.target.closest('.photo-thumb');
      if (thumb) openLightbox(App.editing.photos[+thumb.dataset.photoI]);
    });

    // format toolbar
    $('#formatToolbar').addEventListener('click', (e) => {
      const b = e.target.closest('button'); if (!b) return;
      e.preventDefault();
      const cmd = b.dataset.cmd, val = b.dataset.val;
      $('#entryContent').focus();
      if (cmd === 'formatBlock') {
        const cur = document.queryCommandValue('formatBlock');
        document.execCommand('formatBlock', false, (cur && cur.toLowerCase() === val) ? 'p' : val);
      } else if (cmd === 'hiliteColor') {
        document.execCommand('hiliteColor', false, 'var(--accent-tint)') || document.execCommand('backColor', false, '#fde68a');
      } else {
        document.execCommand(cmd, false, null);
      }
      updateToolbarState(); updateCounts(); scheduleAutosave();
    });
    document.addEventListener('selectionchange', () => { if (!$('#editorOverlay').classList.contains('hidden')) updateToolbarState(); });

    // editor keyboard
    $('#editorOverlay').addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); saveAndClose(); }
    });
  }

  function updateToolbarState() {
    try {
      $$('#formatToolbar button[data-cmd]').forEach(b => {
        const cmd = b.dataset.cmd;
        if (['bold', 'italic', 'underline', 'insertUnorderedList', 'insertOrderedList'].includes(cmd)) {
          b.classList.toggle('active', document.queryCommandState(cmd));
        } else if (cmd === 'formatBlock') {
          b.classList.toggle('active', (document.queryCommandValue('formatBlock') || '').toLowerCase() === b.dataset.val);
        }
      });
    } catch (_) {}
  }

  function newEntry(date) {
    const draft = S.createDraft(date);
    openEditor(draft, true);
  }
  function editEntry(id) {
    const e = S.getEntry(id); if (e) openEditor(e, false);
  }

  /* ============================================================
     TOAST & MODAL
     ============================================================ */
  function toast(emoji, msg) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.innerHTML = `<span class="toast-emoji">${emoji}</span><span>${esc(msg)}</span>`;
    $('#toastContainer').appendChild(t);
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 350); }, 2600);
  }

  function confirmModal(title, body, confirmLabel, onConfirm, danger) {
    $('#modalTitle').textContent = title;
    $('#modalBody').textContent = body;
    $('#modalActions').innerHTML = `<button class="btn btn-ghost" data-modal-cancel>Cancel</button><button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-modal-ok>${esc(confirmLabel)}</button>`;
    const ov = $('#modalOverlay'); ov.classList.remove('hidden');
    const close = () => ov.classList.add('hidden');
    $('[data-modal-cancel]', ov).onclick = close;
    $('[data-modal-ok]', ov).onclick = () => { close(); onConfirm && onConfirm(); };
    ov.onclick = (e) => { if (e.target === ov) close(); };
  }

  /* ============================================================
     REMINDERS & AUTO-LOCK
     ============================================================ */
  let reminderInterval = null;
  let autoLockTimer = null;
  let activityThrottle = 0;

  function fmtTime(hhmm) {
    const [h, m] = (hhmm || '20:00').split(':').map(Number);
    const ap = h < 12 ? 'AM' : 'PM';
    return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${ap}`;
  }

  function reminderDue() {
    const st = S.getSettings();
    if (!st.reminderEnabled) return false;
    if (S.entriesByDate(S.todayISO()).length) return false;
    const [h, m] = (st.reminderTime || '20:00').split(':').map(Number);
    const due = new Date(); due.setHours(h, m, 0, 0);
    return new Date() >= due;
  }

  function startReminderWatch() {
    if (reminderInterval) clearInterval(reminderInterval);
    reminderInterval = setInterval(checkReminder, 60000);
    checkReminder();
  }
  function checkReminder() {
    const st = S.getSettings();
    if (!st.reminderEnabled) return;
    const today = S.todayISO();
    if (st.lastReminded === today) return;
    const [h, m] = (st.reminderTime || '20:00').split(':').map(Number);
    const due = new Date(); due.setHours(h, m, 0, 0);
    if (new Date() < due) return;
    S.setSetting('lastReminded', today);
    if (S.entriesByDate(today).length) return; // already wrote today, no nag
    fireReminder();
    if (App.view === 'journal' && !$('#app').classList.contains('hidden')) route('journal');
  }
  function fireReminder() {
    const name = S.getSettings().name;
    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        const n = new Notification('Lumina · Time to write', { body: name ? `${name}, take a moment for your diary today.` : 'Take a moment for your diary today.' });
        n.onclick = () => { window.focus(); n.close(); newEntry(); };
      } catch (_) {}
    }
    toast('🔔', 'A gentle reminder, write a little today ✨');
  }

  function resetAutoLock() {
    if (autoLockTimer) clearTimeout(autoLockTimer);
    const st = S.getSettings();
    if (!st.autoLockMinutes || !st.pinEnabled || !st.pin) return;
    autoLockTimer = setTimeout(triggerAutoLock, st.autoLockMinutes * 60000);
  }
  function triggerAutoLock() {
    const st = S.getSettings();
    if (!st.autoLockMinutes || !st.pinEnabled || !st.pin) return;
    if (!$('#lockScreen').classList.contains('hidden')) return; // already locked
    clearTimeout(App.autosaveTimer);
    if (App.editing && !isEditorEmpty()) S.upsert(collectEditor()); // preserve any open draft
    ['#editorOverlay', '#modalOverlay', '#lightbox'].forEach(s => $(s).classList.add('hidden'));
    document.body.style.overflow = '';
    App.editing = null;
    $('#app').classList.add('hidden');
    $('#app').classList.remove('nav-open');
    showLock('unlock');
    toast('🔒', 'Locked after inactivity');
  }
  function throttledActivity() {
    const now = Date.now();
    if (now - activityThrottle < 2000) return;
    activityThrottle = now;
    if ($('#lockScreen').classList.contains('hidden')) resetAutoLock();
  }
  function attachActivityListeners() {
    ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll', 'click'].forEach(ev =>
      document.addEventListener(ev, throttledActivity, { passive: true }));
  }

  /* ============================================================
     COMMAND PALETTE (⌘K)
     ============================================================ */
  function cmdkActions() {
    return [
      { icon: '✍️', label: 'New entry', hint: 'Write a new diary entry', run: () => newEntry() },
      { icon: '✨', label: 'Ask Lumi (new chat)', hint: 'Start a fresh AI chat', run: () => askLumiFromHome('') },
      { icon: '🏠', label: 'Go to Home', run: () => route('home') },
      { icon: '📔', label: 'Go to Diary', run: () => route('journal') },
      { icon: '📅', label: 'Go to Calendar', run: () => route('calendar') },
      { icon: '📊', label: 'Go to Insights', run: () => route('insights') },
      { icon: '⭐', label: 'Go to Favorites', run: () => route('favorites') },
      { icon: '✨', label: 'Open Lumi', run: () => route('lumi') },
      { icon: '⚙️', label: 'Open Settings', run: () => route('settings') },
      { icon: '🌓', label: 'Toggle theme', hint: 'Light / dark', run: () => toggleTheme() },
      { icon: '🔒', label: 'Lock now', hint: 'Lock your diary', run: () => lockNow() },
      { icon: '📥', label: 'Export diary', hint: 'Download a backup', run: () => exportJournal() },
    ];
  }
  function cmdkItems(q) {
    q = (q || '').trim().toLowerCase();
    let items = cmdkActions()
      .filter(a => !q || (a.label + ' ' + (a.hint || '')).toLowerCase().includes(q))
      .map(a => ({ type: 'action', cat: 'Command', icon: a.icon, label: a.label, hint: a.hint || '', run: a.run }));
    if (q) {
      const entries = S.filter({ query: q }).slice(0, 6).map(e => ({ type: 'entry', cat: 'Entry', id: e.id, icon: (L.moodById(e.mood) || {}).emoji || '📝', label: e.title || 'Untitled entry', hint: relDay(e.date) }));
      const convs = (App.lumi ? App.lumi.conversations : (lumiLoad().conversations || []));
      const chats = convs.filter(cv => cv.thread && cv.thread.length && (cv.title + ' ' + cv.thread.map(m => m.text).join(' ')).toLowerCase().includes(q))
        .slice(0, 5).map(cv => ({ type: 'chat', cat: 'Chat', id: cv.id, icon: '💬', label: cv.title || 'Chat', hint: cv.thread.filter(m => m.role === 'user').length + ' messages' }));
      items = items.concat(entries, chats);
    }
    return items.slice(0, 24);
  }
  function openCmdk() {
    App.cmdk = { items: [], sel: 0 };
    $('#cmdk').classList.remove('hidden');
    const inp = $('#cmdkInput'); inp.value = ''; renderCmdk('');
    setTimeout(() => inp.focus(), 30);
  }
  function closeCmdk() { $('#cmdk').classList.add('hidden'); }
  function cmdkIsOpen() { return !$('#cmdk').classList.contains('hidden'); }
  function renderCmdk(q) {
    const items = cmdkItems(q);
    App.cmdk.items = items; App.cmdk.sel = 0;
    const r = $('#cmdkResults');
    if (!items.length) { r.innerHTML = `<div class="cmdk-empty">No matches for “${esc(q)}”</div>`; return; }
    r.innerHTML = items.map((it, i) => `<div class="cmdk-item ${i === 0 ? 'sel' : ''}" data-i="${i}"><span class="cmdk-item-ic">${it.icon}</span><span class="cmdk-item-main"><span class="cmdk-item-label">${esc(it.label)}</span>${it.hint ? `<span class="cmdk-item-hint">${esc(it.hint)}</span>` : ''}</span><span class="cmdk-item-cat">${it.cat}</span></div>`).join('');
    $$('#cmdkResults .cmdk-item').forEach(el => { el.onmouseenter = () => setCmdkSel(+el.dataset.i); el.onclick = () => execCmdk(+el.dataset.i); });
  }
  function setCmdkSel(i) {
    App.cmdk.sel = i;
    const els = $$('#cmdkResults .cmdk-item');
    els.forEach((el, idx) => el.classList.toggle('sel', idx === i));
    if (els[i]) els[i].scrollIntoView({ block: 'nearest' });
  }
  function execCmdk(i) {
    const it = App.cmdk.items[i]; if (!it) return;
    closeCmdk();
    if (it.type === 'action') it.run();
    else if (it.type === 'entry') editEntry(it.id);
    else if (it.type === 'chat') {
      if (!App.lumi) App.lumi = Object.assign({ mode: 'chat', busy: false }, lumiLoad());
      App.lumi.mode = 'chat'; App.lumi.currentId = it.id; lumiSave(); route('lumi');
    }
  }

  /* ============================================================
     GLOBAL EVENTS
     ============================================================ */
  function bindGlobalEvents() {
    // theme
    $('#themeToggle').onclick = toggleTheme;
    $('#avatarBtn').onclick = () => route('settings');

    // lightbox
    $('#lightboxClose').onclick = closeLightbox;
    $('#lightbox').onclick = (e) => { if (e.target.id === 'lightbox') closeLightbox(); };

    // lock screen, Windows-style: click (or press a key) to reveal the PIN
    $('#lockScreen').addEventListener('click', (e) => {
      if (e.target.closest('#lockInfo') || e.target.closest('#lockInfoPop') || e.target.closest('.lock-card')) return;
      lockToSignIn();
    });
    $('#lockInfo').onclick = (e) => { e.stopPropagation(); toggleLockInfo(); };

    // command palette
    $('#cmdkTrigger').onclick = openCmdk;
    $('#cmdkInput').oninput = (e) => renderCmdk(e.target.value);
    $('#cmdkInput').onkeydown = (e) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); setCmdkSel(Math.min(App.cmdk.sel + 1, App.cmdk.items.length - 1)); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); setCmdkSel(Math.max(App.cmdk.sel - 1, 0)); }
      else if (e.key === 'Enter') { e.preventDefault(); execCmdk(App.cmdk.sel); }
    };
    $('#cmdk').onclick = (e) => { if (e.target.id === 'cmdk') closeCmdk(); };

    // nav
    $('#nav').addEventListener('click', (e) => { const b = e.target.closest('.nav-item'); if (b) route(b.dataset.view); });
    $('.sidebar-foot').addEventListener('click', (e) => {
      const b = e.target.closest('.nav-item'); if (!b) return;
      if (b.id === 'lockNowBtn') { lockNow(); return; }
      if (b.dataset.view) route(b.dataset.view);
    });

    // new entry
    $('#newEntryBtn').onclick = () => newEntry();

    // sidebar collapse / mobile menu
    $('#sidebarCollapse').onclick = () => $('#app').classList.toggle('collapsed');
    $('#menuBtn').onclick = () => $('#app').classList.toggle('nav-open');

    // search
    const search = $('#searchInput');
    search.addEventListener('input', () => {
      App.filters.query = search.value;
      if (App.view !== 'journal') route('journal');
      else { const area = $('#entriesArea'); if (area) { const list = S.sorted(S.filter({ query: App.filters.query, mood: App.filters.mood, tag: App.filters.tag }), App.filters.sort); area.innerHTML = list.length ? groupedEntriesHTML(list) : emptyJournalHTML(); afterCardsRender(); } }
    });

    // delegated clicks in view container
    $('#viewContainer').addEventListener('click', (e) => {
      const fav = e.target.closest('[data-fav]');
      if (fav) { e.stopPropagation(); S.toggleFavorite(fav.dataset.fav); refreshShell(); route(App.view); return; }

      const card = e.target.closest('.entry-card');
      if (card) { editEntry(card.dataset.id); return; }

      const moodChip = e.target.closest('[data-mood]');
      if (moodChip && moodChip.classList.contains('chip')) { App.filters.mood = App.filters.mood === moodChip.dataset.mood ? '' : moodChip.dataset.mood; App.filters.tag = ''; route('journal'); return; }

      const tagChip = e.target.closest('[data-tag]');
      if (tagChip) { App.filters.tag = App.filters.tag === tagChip.dataset.tag ? '' : tagChip.dataset.tag; App.filters.mood = ''; route('journal'); return; }

      if (e.target.closest('[data-filter-clear]')) { App.filters.mood = ''; App.filters.tag = ''; App.filters.query = ''; $('#searchInput').value = ''; route('journal'); return; }
      if (e.target.closest('[data-new]')) { newEntry(); return; }
      if (e.target.closest('[data-otd]')) { const o = S.onThisDay()[0]; if (o) editEntry(o.id); return; }

      const calBtn = e.target.closest('[data-cal]');
      if (calBtn) {
        const v = calBtn.dataset.cal;
        if (v === 'today') App.calCursor = new Date();
        else App.calCursor = new Date(App.calCursor.getFullYear(), App.calCursor.getMonth() + Number(v), 1);
        route('calendar'); return;
      }

      const calCell = e.target.closest('.cal-cell[data-date]');
      if (calCell) { const iso = calCell.dataset.date; const es = S.entriesByDate(iso); if (es.length) editEntry(es[0].id); else newEntry(iso); return; }

      const heat = e.target.closest('.heat-cell[data-date]');
      if (heat && heat.dataset.date) { const es = S.entriesByDate(heat.dataset.date); if (es.length) editEntry(es[0].id); return; }
    });

    // sort select (change)
    $('#viewContainer').addEventListener('change', (e) => {
      if (e.target.id === 'sortSelect') { App.filters.sort = e.target.value; route('journal'); }
    });

    // global keyboard
    document.addEventListener('keydown', (e) => {
      // When locked, the lock screen captures everything (type PIN, Esc -> clock)
      if (!$('#lockScreen').classList.contains('hidden')) { handleLockKey(e); return; }
      // Command palette toggle works anywhere, even while typing
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); cmdkIsOpen() ? closeCmdk() : openCmdk(); return; }
      if (cmdkIsOpen()) { if (e.key === 'Escape') closeCmdk(); return; }

      const editorOpen = !$('#editorOverlay').classList.contains('hidden');
      const modalOpen = !$('#modalOverlay').classList.contains('hidden');
      const typing = /^(INPUT|TEXTAREA)$/.test(document.activeElement.tagName) || document.activeElement.isContentEditable;

      if (e.key === 'Escape') {
        if (!$('#lightbox').classList.contains('hidden')) { closeLightbox(); return; }
        if (modalOpen) { $('#modalOverlay').classList.add('hidden'); return; }
        if (editorOpen) { closeEditor(true); return; }
      }
      if (editorOpen || modalOpen) return;
      if (e.key === '/' && !typing) { e.preventDefault(); openCmdk(); }
      else if ((e.key === 'n' || e.key === 'N') && !typing) { e.preventDefault(); newEntry(); }
      else if (e.key === 'Escape' && App.view !== 'home') route('home');
    });

    // react to system theme changes when in auto
    matchMedia('(prefers-color-scheme: light)').addEventListener('change', () => { if (S.getSettings().theme === 'auto') applyTheme(); });

    // ambient parallax, subtle "alive" depth following the cursor
    if (!matchMedia('(prefers-reduced-motion: reduce)').matches) {
      let pRAF = null;
      window.addEventListener('mousemove', (e) => {
        if (pRAF) return;
        pRAF = requestAnimationFrame(() => {
          pRAF = null;
          const amb = $('.ambient'); if (!amb) return;
          const x = (e.clientX / window.innerWidth - .5) * 16, y = (e.clientY / window.innerHeight - .5) * 16;
          amb.style.transform = `translate(${x.toFixed(1)}px, ${y.toFixed(1)}px)`;
        });
      }, { passive: true });
    }
  }

  /* ---------- go ---------- */
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
