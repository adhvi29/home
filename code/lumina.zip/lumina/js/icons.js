/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * Lumina - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   LUMINA · Config & content constants
   Global namespace: window.LUMINA
   ============================================================ */
window.LUMINA = (function () {
  const MOODS = [
    { id: 'ecstatic', emoji: '🤩', label: 'Ecstatic', color: '#fbbf24', color2: '#f59e0b' },
    { id: 'happy',    emoji: '😊', label: 'Happy',    color: '#4ade80', color2: '#22c55e' },
    { id: 'grateful', emoji: '🥰', label: 'Grateful', color: '#fb7185', color2: '#ec4899' },
    { id: 'calm',     emoji: '😌', label: 'Calm',     color: '#38bdf8', color2: '#0ea5e9' },
    { id: 'neutral',  emoji: '😐', label: 'Neutral',  color: '#94a3b8', color2: '#64748b' },
    { id: 'tired',    emoji: '😪', label: 'Tired',    color: '#a78bfa', color2: '#8b5cf6' },
    { id: 'sad',      emoji: '😢', label: 'Sad',      color: '#60a5fa', color2: '#3b82f6' },
    { id: 'anxious',  emoji: '😰', label: 'Anxious',  color: '#fb923c', color2: '#ea580c' },
    { id: 'angry',    emoji: '😠', label: 'Angry',    color: '#f87171', color2: '#ef4444' },
  ];

  const WEATHER = [
    { id: 'sunny',  emoji: '☀️', label: 'Sunny' },
    { id: 'cloudy', emoji: '⛅', label: 'Cloudy' },
    { id: 'rainy',  emoji: '🌧️', label: 'Rainy' },
    { id: 'stormy', emoji: '⛈️', label: 'Stormy' },
    { id: 'snowy',  emoji: '❄️', label: 'Snowy' },
    { id: 'foggy',  emoji: '🌫️', label: 'Foggy' },
    { id: 'night',  emoji: '🌙', label: 'Night' },
  ];

  const ACCENTS = [
    { id: 'aurora', label: 'Aurora', a: '#5eead4', b: '#818cf8' },
    { id: 'sunset', label: 'Sunset', a: '#fb923c', b: '#f43f5e' },
    { id: 'rose',   label: 'Rose',   a: '#fb7185', b: '#e879f9' },
    { id: 'ocean',  label: 'Ocean',  a: '#38bdf8', b: '#6366f1' },
    { id: 'forest', label: 'Forest', a: '#4ade80', b: '#2dd4bf' },
    { id: 'gold',   label: 'Gold',   a: '#fbbf24', b: '#f59e0b' },
  ];

  const PROMPTS = [
    'What made today memorable?',
    'Describe a small moment that brought you joy.',
    'What are you grateful for right now?',
    'What challenged you today, and how did you respond?',
    'If today had a color, what would it be, and why?',
    'Who did you connect with today?',
    'What is something you learned about yourself?',
    'What would you tell your past self about today?',
    'Describe today in three words, then expand on one.',
    'What is weighing on your mind?',
    'What made you laugh recently?',
    'What are you looking forward to?',
    'Write about a sound, smell, or taste from today.',
    'What did you do today that your future self will thank you for?',
    'When did you feel most like yourself today?',
    'What is one thing you would do differently?',
    'Describe the view from where you are sitting.',
    'What small win can you celebrate?',
    'What is a question you cannot stop thinking about?',
    'If today were a chapter in your story, what would it be titled?',
  ];

  const QUOTES = [
    { t: 'Fill your paper with the breathings of your heart.', a: 'William Wordsworth' },
    { t: 'Journal writing is a voyage to the interior.', a: 'Christina Baldwin' },
    { t: 'Keep a notebook. Travel with it, eat with it, sleep with it.', a: 'Jack London' },
    { t: 'Write hard and clear about what hurts.', a: 'Ernest Hemingway' },
    { t: 'The life of every person is a diary in which they mean to write one story.', a: 'J.M. Barrie' },
    { t: 'I can shake off everything as I write; my sorrows disappear.', a: 'Anne Frank' },
    { t: 'Documenting little details of your everyday life is a way of celebrating it.', a: 'Carolyn V. Hamilton' },
    { t: 'A word after a word after a word is power.', a: 'Margaret Atwood' },
    { t: 'Tomorrow may be hell, but today was a good writing day.', a: 'Shannon Hale' },
    { t: 'In the journal I do not just express myself more openly than I could to any person; I create myself.', a: 'Susan Sontag' },
    { t: 'What a comfort is this journal. I tell myself to myself.', a: 'Anne Lister' },
    { t: 'Start writing, no matter what. The water does not flow until the faucet is turned on.', a: 'Louis L\'Amour' },
  ];

  // Time-of-day greeting
  function greeting() {
    const h = new Date().getHours();
    if (h < 5) return 'Burning the midnight oil';
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    if (h < 21) return 'Good evening';
    return 'Good night';
  }

  function moodById(id) { return MOODS.find(m => m.id === id) || null; }
  function weatherById(id) { return WEATHER.find(w => w.id === id) || null; }
  function accentById(id) { return ACCENTS.find(a => a.id === id) || ACCENTS[0]; }

  function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

  return { MOODS, WEATHER, ACCENTS, PROMPTS, QUOTES, greeting, moodById, weatherById, accentById, pick };
})();
