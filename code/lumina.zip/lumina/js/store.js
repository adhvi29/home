/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * Lumina - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
/* ============================================================
   LUMINA · Store, state, persistence, queries, statistics
   Global: window.Store
   ============================================================ */
window.Store = (function () {
  const KEY = 'lumina.v1';

  const defaults = () => ({
    settings: {
      name: '',
      theme: 'dark',
      accent: 'aurora',
      pinEnabled: false,
      pin: '',
      onboarded: false,
      reminderEnabled: false,
      reminderTime: '20:00',
      lastReminded: '',
      autoLockMinutes: 0,
      aiProvider: 'puter',
      aiConfigured: false,
      hfToken: '',
      geminiKey: '',
      lockMode: 'nature',
    },
    entries: [],
  });

  let state = defaults();
  let lastSaveOk = true;

  /* ---------- persistence ---------- */
  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        state = Object.assign(defaults(), parsed);
        state.settings = Object.assign(defaults().settings, parsed.settings || {});
        state.entries = Array.isArray(parsed.entries) ? parsed.entries : [];
        state.entries.forEach(e => { if (!Array.isArray(e.photos)) e.photos = []; });
      }
    } catch (e) {
      console.warn('Lumina: failed to load, starting fresh.', e);
      state = defaults();
    }
    return state;
  }

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); lastSaveOk = true; }
    catch (e) { lastSaveOk = false; console.warn('Lumina: failed to save.', e); }
    return lastSaveOk;
  }
  function saveOk() { return lastSaveOk; }

  /* ---------- helpers ---------- */
  const uid = () => 'e_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const todayISO = () => toISO(new Date());
  function toISO(d) {
    const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }
  function fromISO(s) { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); }

  function stripHtml(html) {
    const tmp = document.createElement('div');
    tmp.innerHTML = html || '';
    return (tmp.textContent || tmp.innerText || '').replace(/\s+/g, ' ').trim();
  }
  function wordCount(text) { const t = (text || '').trim(); return t ? t.split(/\s+/).length : 0; }

  /* ---------- settings ---------- */
  function getSettings() { return state.settings; }
  function setSetting(key, val) { state.settings[key] = val; save(); }

  /* ---------- entries CRUD ---------- */
  function getEntries() { return state.entries.slice(); }
  function getEntry(id) { return state.entries.find(e => e.id === id) || null; }

  function createDraft(date) {
    return {
      id: uid(),
      title: '',
      content: '',
      plainText: '',
      date: date || todayISO(),
      createdAt: Date.now(),
      updatedAt: Date.now(),
      mood: '',
      weather: '',
      tags: [],
      photos: [],
      favorite: false,
      pinned: false,
    };
  }

  function upsert(entry) {
    entry.plainText = stripHtml(entry.content);
    entry.updatedAt = Date.now();
    const i = state.entries.findIndex(e => e.id === entry.id);
    if (i >= 0) state.entries[i] = entry;
    else state.entries.unshift(entry);
    save();
    return entry;
  }

  function remove(id) {
    state.entries = state.entries.filter(e => e.id !== id);
    save();
  }

  function toggleFavorite(id) {
    const e = getEntry(id);
    if (e) { e.favorite = !e.favorite; e.updatedAt = Date.now(); save(); }
    return e;
  }
  function togglePin(id) {
    const e = getEntry(id);
    if (e) { e.pinned = !e.pinned; e.updatedAt = Date.now(); save(); }
    return e;
  }

  /* ---------- queries ---------- */
  function sorted(list, mode) {
    const arr = list.slice();
    switch (mode) {
      case 'oldest': arr.sort((a, b) => a.date.localeCompare(b.date) || a.createdAt - b.createdAt); break;
      case 'az': arr.sort((a, b) => (a.title || 'Untitled').localeCompare(b.title || 'Untitled')); break;
      case 'words': arr.sort((a, b) => wordCount(b.plainText) - wordCount(a.plainText)); break;
      default: arr.sort((a, b) => b.date.localeCompare(a.date) || b.createdAt - a.createdAt); // newest
    }
    // pinned float to top (except when sorting az/words explicitly? keep pinned priority for newest/oldest)
    if (mode === 'newest' || mode === 'oldest' || !mode) {
      arr.sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0));
    }
    return arr;
  }

  function filter({ query = '', mood = '', tag = '', favorite = false } = {}) {
    const q = query.trim().toLowerCase();
    return state.entries.filter(e => {
      if (favorite && !e.favorite) return false;
      if (mood && e.mood !== mood) return false;
      if (tag && !(e.tags || []).includes(tag)) return false;
      if (q) {
        const hay = ((e.title || '') + ' ' + (e.plainText || '') + ' ' + (e.tags || []).join(' ')).toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }

  function allTags() {
    const counts = {};
    state.entries.forEach(e => (e.tags || []).forEach(t => { counts[t] = (counts[t] || 0) + 1; }));
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).map(([tag, count]) => ({ tag, count }));
  }

  function entriesByDate(iso) { return state.entries.filter(e => e.date === iso); }

  function onThisDay() {
    const now = new Date();
    const mmdd = String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0');
    const curYear = now.getFullYear();
    return state.entries.filter(e => e.date.slice(5) === mmdd && fromISO(e.date).getFullYear() < curYear);
  }

  /* ---------- statistics ---------- */
  function uniqueDates() {
    return Array.from(new Set(state.entries.map(e => e.date))).sort();
  }

  function streak() {
    const dates = new Set(state.entries.map(e => e.date));
    if (!dates.size) return 0;
    let count = 0;
    const d = new Date();
    // allow streak to count if today OR yesterday has an entry
    if (!dates.has(toISO(d))) d.setDate(d.getDate() - 1);
    while (dates.has(toISO(d))) { count++; d.setDate(d.getDate() - 1); }
    return count;
  }

  function longestStreak() {
    const dates = uniqueDates();
    if (!dates.length) return 0;
    let best = 1, cur = 1;
    for (let i = 1; i < dates.length; i++) {
      const prev = fromISO(dates[i - 1]), now = fromISO(dates[i]);
      const diff = Math.round((now - prev) / 86400000);
      if (diff === 1) { cur++; best = Math.max(best, cur); }
      else cur = 1;
    }
    return best;
  }

  function totalWords() {
    return state.entries.reduce((s, e) => s + wordCount(e.plainText), 0);
  }

  function moodDistribution() {
    const counts = {};
    state.entries.forEach(e => { if (e.mood) counts[e.mood] = (counts[e.mood] || 0) + 1; });
    return counts;
  }

  function entriesPerMonth(months = 6) {
    const out = [];
    const now = new Date();
    for (let i = months - 1; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
      const count = state.entries.filter(e => e.date.slice(0, 7) === key).length;
      out.push({ label: d.toLocaleString('default', { month: 'short' }), key, count });
    }
    return out;
  }

  // heatmap for last N weeks (returns array of {iso, count})
  function heatmap(weeks = 26) {
    const days = weeks * 7;
    const counts = {};
    state.entries.forEach(e => { counts[e.date] = (counts[e.date] || 0) + 1; });
    const out = [];
    const today = new Date();
    // start so that the grid ends on this week
    const start = new Date(today);
    start.setDate(start.getDate() - days + 1);
    for (let i = 0; i < days; i++) {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      const iso = toISO(d);
      out.push({ iso, count: counts[iso] || 0, date: d });
    }
    return out;
  }

  function stats() {
    const entries = state.entries;
    const words = totalWords();
    return {
      total: entries.length,
      words,
      avgWords: entries.length ? Math.round(words / entries.length) : 0,
      streak: streak(),
      longest: longestStreak(),
      days: uniqueDates().length,
      favorites: entries.filter(e => e.favorite).length,
    };
  }

  /* ---------- import / export ---------- */
  function exportData() {
    return JSON.stringify({ exportedAt: new Date().toISOString(), app: 'Lumina', ...state }, null, 2);
  }
  function importData(json) {
    const parsed = JSON.parse(json);
    if (!parsed || !Array.isArray(parsed.entries)) throw new Error('Invalid file');
    state.entries = parsed.entries;
    if (parsed.settings) state.settings = Object.assign(state.settings, parsed.settings);
    save();
  }
  function clearEntries() { state.entries = []; save(); }
  function clearAll() { state = defaults(); save(); }

  return {
    load, save, saveOk,
    getSettings, setSetting,
    getEntries, getEntry, createDraft, upsert, remove, toggleFavorite, togglePin,
    sorted, filter, allTags, entriesByDate, onThisDay,
    streak, longestStreak, totalWords, moodDistribution, entriesPerMonth, heatmap, stats, uniqueDates,
    exportData, importData, clearEntries, clearAll,
    // utils
    uid, todayISO, toISO, fromISO, stripHtml, wordCount,
  };
})();
