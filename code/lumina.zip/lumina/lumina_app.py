# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Lumina - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""
Lumina - your private diary, as a native desktop app.

Runs entirely on your machine in its own window. No browser, no account,
and (with fonts now bundled locally) no internet connection required.
Your entries live in a persistent local profile beside this file.

One-time setup:
    pip install pywebview
Launch:
    double-click  Lumina.bat
    or run:       pythonw lumina_app.py     (use 'python' to see errors)

Note (Windows): rendering uses the Microsoft Edge WebView2 runtime, which is
preinstalled on Windows 11 and most updated Windows 10 systems. If the window
looks broken, install the free "WebView2 Runtime" from Microsoft and relaunch.
"""

import os
import sys
import threading
import http.server
import socketserver

try:
    import webview  # pywebview
except ImportError:
    sys.stderr.write(
        "\n[Lumina] pywebview is not installed.\n"
        "Run this once:\n    pip install pywebview\n"
        "then launch Lumina again.\n\n"
    )
    sys.exit(1)

FROZEN = getattr(sys, "frozen", False)
# Web assets: when frozen by PyInstaller they're unpacked to a temp dir (_MEIPASS);
# as a plain script they sit next to this file.
BASE_DIR = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
# Persistent diary data must live OUTSIDE the temp dir so it survives restarts.
if FROZEN:
    APP_HOME = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "Lumina")
else:
    APP_HOME = BASE_DIR
# A FIXED port keeps the origin stable, so your diary (localStorage) persists
# between launches. If 8765 is ever busy, close the other app using it.
PORT = 8765
STORAGE = os.path.join(APP_HOME, ".lumina-store")


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)

    def end_headers(self):
        # Never cache, so edits to the app files always show on the next open.
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        super().end_headers()

    def log_message(self, *args):
        pass  # stay quiet


def serve():
    socketserver.ThreadingTCPServer.allow_reuse_address = True
    with socketserver.ThreadingTCPServer(("127.0.0.1", PORT), Handler) as httpd:
        httpd.serve_forever()


def main():
    os.makedirs(STORAGE, exist_ok=True)
    threading.Thread(target=serve, daemon=True).start()

    webview.create_window(
        "Lumina",
        f"http://127.0.0.1:{PORT}/index.html",
        width=1240,
        height=840,
        min_size=(390, 600),
    )
    # private_mode=False + a fixed storage_path => your diary is saved between sessions.
    webview.start(private_mode=False, storage_path=STORAGE)


if __name__ == "__main__":
    main()
