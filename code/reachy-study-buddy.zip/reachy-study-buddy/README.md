> Copyright (c) 2026 Adhvik Mahesh. All rights reserved.  
> Reachy Study Buddy - https://github.com/adhvi29  
> You may view and run this code for personal and educational use only.  
> You may not copy it into other projects, redistribute, sell, or present  
> it as your own work without written permission from the author.  
> Removing or changing this notice is not permitted. See LICENSE.txt.

---
title: Reachy Study Buddy
emoji: 📚
colorFrom: yellow
colorTo: red
sdk: static
pinned: false
short_description: Voice study buddy that reads worksheets, quizzes you and keeps you focused
tags:
 - reachy_mini
 - reachy_mini_python_app
---

# Reachy Study Buddy

Turns Reachy Mini into a study partner you talk to out loud.

- **Talks and listens.** Say "Reachy" and ask anything. It answers in its own voice, and puts working, equations and mark schemes on your laptop screen.
- **Reads with you.** Say "Reachy, I'm going to read you chapter 9" and read it aloud. It stays quiet, writes everything down, then quizzes you on exactly what you read. Every chapter is saved for later.
- **Sees your worksheets.** "Can you check question 3?" makes it look through its camera. You can also drop a photo or PDF of a worksheet onto the page.
- **Coaches instead of doing it for you.** Hints first, one step at a time, and it marks answers like an IGCSE examiner.
- **Adaptive quizzes.** Questions come from what you read, plus 166 exam questions with mark schemes pulled from your own study guides. What you get wrong comes back sooner.
- **Focus sessions.** Pomodoro blocks and breaks, a "welcome back" when you return, and timers for timed practice.

## Starting and stopping it

1. Plug Reachy's USB cable into the laptop and switch on its **power adapter** (the motors need it).
2. Double-click **`Start Study Buddy.bat`**. Reachy wakes up, says hi, and the study page opens at http://127.0.0.1:8042.
3. To stop, press the red **power button** on the study page. Reachy says bye, goes to sleep, and the program closes (it also frees the GPU).

The web page is only a remote control: Reachy keeps listening even if you close the tab, until you press the power button (or close the black window).

**With the motors on**, Reachy turns its head and base to look at you, bobs its head while it talks, glances around and twitches its antennas when nobody's there, looks down at your desk to read worksheets, and shows feelings with its antennas (wags them like a tail when you get full marks, droops them when you don't). Pushing an antenna wakes it up or cuts it off. Movement commands happen instantly, without the AI: "look up / left / at me", "look around", "dance", "wag your antennas", "be angry / sad / shy / proud...".

**If the motors have no power**, it still talks, listens and sees through its own camera, mic and speaker. The page shows a banner: switch Reachy's power on, then press **Restart** (also in Settings → System).

How it runs on this laptop: Windows Smart App Control blocks GStreamer (the media library the Reachy Mini software normally uses), so Pollen's daemon runs with `--no-media` just for the motors, and Study Buddy handles the camera, mic and speaker itself as ordinary USB devices. Smart App Control stays on.

## Talking to it

| Say | What happens |
|---|---|
| "Reachy" | It wakes up and listens. After a quiet minute it goes back to waiting for its name. |
| "Reachy, I'm going to read you chapter 9, the mole" | Reading mode. Read aloud. Say "Reachy, …" to ask something mid-chapter. |
| "I'm done reading" | Saves the chapter, sums it up, offers a quiz |
| "Quiz me on the mole chapter" | Questions from that chapter, marked out of the marks shown |
| "Give me a past-paper style physics question" | A question from your guides' question bank |
| "Can you check question 2 on my worksheet?" | It takes a photo and helps you work through it |
| "Start a 25 minute focus session, goal: finish chapter 9 worksheet" | Focus timer |
| "Time me for this 6 mark question" | A countdown |
| "Bye Reachy" | Back to waiting for its name |

You can also type in the box, press **Talk to Reachy**, or press **Stop** to cut it off.

## Reachy's brain

Settings → **Reachy's brain**:

- **Free, on this laptop** (default): Qwen 3.5, running in the Ollama app on your GPU. No account, no cost, nothing leaves your laptop. The first answer after starting takes a little while as it loads; after that it answers in about 3 seconds.
- **Claude**: much smarter, especially at reading handwriting and marking. It needs an Anthropic API key. Anthropic accounts are for adults (18+), so a parent has to create the key at console.anthropic.com and should set a spend limit there. The app also has its own daily cap (US$1 by default). Uses Claude Opus 5, with a server-side fallback model if a request is ever declined.

## Safety and privacy

- Speech-to-text runs on your laptop. Recordings of your voice are never stored or uploaded.
- With the local brain, nothing leaves the laptop at all. With Claude, only the text of what you say to Reachy and the photos you ask it to take go to Anthropic.
- The study page only accepts connections from this laptop, and it blocks requests from other websites, so a web page in another tab can't control Reachy or read your chats.
- The API key lives in Windows Credential Manager. The page can save it but never read it back.
- Claude and the local model can only use this app's tools: move the robot, take a photo, show things on screen, run timers and quizzes. They can't open your files, run programs or browse the web.
- Robot moves stay well inside the motor limits and always ease in and out.
- The camera only takes photos when you ask Reachy to look (or send a picture). Face tracking in robot mode runs inside the Reachy Mini software on your laptop.

## Where things are kept

`%LOCALAPPDATA%\reachy_study_buddy\`: settings, progress (`progress.json`), saved chapters (`materials\`), logs and the downloaded voice models. Conversations themselves are not saved.

## For developers

```
uv venv --python 3.12 .venv
uv pip install --python .venv\Scripts\python.exe -e ".[gpu,dev]"
.venv\Scripts\python -m pytest tests
```

- `python -m reachy_study_buddy.robot`: full robot mode (what the launcher runs). Starts the daemon with `--no-media`, then the app; falls back to no-motor mode if the motors don't answer.
- `python -m reachy_study_buddy.laptop --help`: no-motor mode options (`--no-audio` for silent testing, `--webcam-presence`, `--laptop-devices`).
- `python scripts/build_question_bank.py`: rebuild `reachy_study_buddy/data/question_bank.json` after adding questions to the study guides.
- Code map: `engine.py` (states and routing), `hearing.py` (VAD + Whisper), `voice.py` (Piper + sentence streaming), `brain.py` (Claude), `local_brain.py` (Ollama), `tools.py`, `motion.py` (50 Hz head, antenna and base loop), `vision.py` (face following with Pollen's YuNet and the calibrated lens model), `robot_io.py` (motors via the SDK, media as USB devices), `nogi.py` (lets the SDK import without GStreamer), `robot.py` (launcher), `web.py` + `static/` (the page).

## Question bank

The question bank is not included in this download, because it was built from the author's personal study notes. Quizzes from chapters you read aloud still work. To add your own questions, create `reachy_study_buddy/data/question_bank.json` in the format that `scripts/build_question_bank.py` writes.
