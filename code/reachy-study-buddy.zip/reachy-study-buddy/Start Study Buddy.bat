@REM Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
@REM Reachy Study Buddy - https://github.com/adhvi29
@REM You may view and run this code for personal and educational use only.
@REM You may not copy it into other projects, redistribute, sell, or present
@REM it as your own work without written permission from the author.
@REM Removing or changing this notice is not permitted. See LICENSE.txt.
@echo off
rem Starts Reachy Study Buddy (or opens the page if it's already running).
title Reachy Study Buddy
cd /d "%~dp0"

rem Already running? Just open the page.
curl -s -o nul -m 2 http://127.0.0.1:8042/api/state
if not errorlevel 1 (
  echo Study Buddy is already running. Opening the page...
  start "" http://127.0.0.1:8042
  timeout /t 3 /nobreak > nul
  exit /b 0
)

if not exist ".venv\Scripts\python.exe" (
  echo The app isn't installed in this folder. Expected: %~dp0.venv\Scripts\python.exe
  pause
  exit /b 1
)

rem The free local brain needs the Ollama app running in the background.
curl -s -o nul -m 2 http://127.0.0.1:11434/api/version
if errorlevel 1 (
  if exist "%LOCALAPPDATA%\Programs\Ollama\ollama app.exe" (
    echo Starting Ollama...
    start "" "%LOCALAPPDATA%\Programs\Ollama\ollama app.exe"
    timeout /t 5 /nobreak > nul
  )
)

echo Starting Study Buddy... the page opens by itself in about 30 seconds.
echo Keep this window open. Closing it turns Reachy off.
set HF_HUB_DISABLE_SYMLINKS_WARNING=1
".venv\Scripts\python.exe" -m reachy_study_buddy.robot %*
echo.
echo Study Buddy has stopped.
pause
