# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Brain: the conversation with Claude.

One ``run_turn`` = the student's message in, Reachy's spoken reply out, with any tool
calls in between. Replies stream, and each finished sentence goes straight to the
voice so Reachy starts talking before Claude has finished writing.
"""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass
from typing import Any, Callable

import anthropic

from .prompts import build_system_prompt
from .store import MODELS, Progress, Settings, get_api_key
from .tools import TOOLS, ToolBox
from .voice import SentenceChunker

logger = logging.getLogger(__name__)

# Models that take adaptive thinking + effort, and models with server-side refusal fallbacks.
ADAPTIVE_MODELS = {"claude-opus-5", "claude-sonnet-5"}
FALLBACK_MODELS = {"claude-opus-5"}
MAX_TOOL_ROUNDS = 8
MAX_TOKENS = 32000


class Cancelled(Exception):
    pass


@dataclass
class TurnResult:
    spoken: str = ""
    cancelled: bool = False
    error: str | None = None
    cost_usd: float = 0.0


def estimate_cost(model: str, usage: Any) -> tuple[float, int, int]:
    """Rough dollar cost of one response, from its usage block."""
    def price(m: str | None) -> tuple[float, float]:
        entry = MODELS.get(m or model) or MODELS.get(model) or ("", 5.0, 25.0)
        return entry[1], entry[2]

    items = [u for u in (getattr(usage, "iterations", None) or []) if (getattr(u, "output_tokens", 0) or 0) > 0]
    if not items:
        items = [usage]
    usd, tin, tout = 0.0, 0, 0
    for u in items:
        p_in, p_out = price(getattr(u, "model", None))
        inp = getattr(u, "input_tokens", 0) or 0
        cw = getattr(u, "cache_creation_input_tokens", 0) or 0
        cr = getattr(u, "cache_read_input_tokens", 0) or 0
        out = getattr(u, "output_tokens", 0) or 0
        usd += (inp * p_in + cw * p_in * 1.25 + cr * p_in * 0.1 + out * p_out) / 1e6
        tin += inp + cw + cr
        tout += out
    return usd, tin, tout


def echo_content(content: list[Any]) -> list[Any]:
    """Assistant content to send back next time.

    After a mid-reply fallback to another model, only the text before the last
    ``fallback`` marker may be echoed back; thinking and tool calls from the declined
    attempt are dropped. Everything after the marker echoes normally.
    """
    last = max((i for i, b in enumerate(content) if getattr(b, "type", "") == "fallback"), default=-1)
    if last < 0:
        return list(content)
    before = [b for b in content[:last] if getattr(b, "type", "") == "text"]
    return before + list(content[last + 1:])


class Brain:
    def __init__(self, settings: Settings, progress: Progress, toolbox: ToolBox, speak: Callable[[str], None],
                 emit: Callable[[str, dict[str, Any]], None]) -> None:
        self.settings = settings
        self.progress = progress
        self.toolbox = toolbox
        self.speak = speak
        self.emit = emit
        self.messages: list[dict[str, Any]] = []
        self._client: anthropic.Anthropic | None = None
        self._client_key: str | None = None
        self.lock = threading.Lock()

    def reset(self) -> None:
        with self.lock:
            self.messages = []
        self.toolbox.reset()

    def rollback_last_turn(self) -> None:
        """Forget the last turn entirely (used when it was cancelled before Reachy said anything)."""
        with self.lock:
            del self.messages[getattr(self, "_turn_start", len(self.messages)):]

    @property
    def turns(self) -> int:
        return sum(1 for m in self.messages if m["role"] == "user" and isinstance(m["content"], list)
                   and any(isinstance(b, dict) and b.get("type") == "text" for b in m["content"]))

    def client(self) -> anthropic.Anthropic | None:
        key = get_api_key()
        if not key:
            return None
        if self._client is None or key != self._client_key:
            self._client = anthropic.Anthropic(api_key=key, max_retries=2, timeout=anthropic.Timeout(120.0, connect=10.0))
            self._client_key = key
        return self._client

    def _request(self) -> dict[str, Any]:
        s = self.settings.all()
        model = s["model"]
        system = build_system_prompt(s["student_name"], s["subjects"], s["focus_minutes"], s["break_minutes"])
        req: dict[str, Any] = {
            "model": model,
            "max_tokens": MAX_TOKENS,
            "system": [{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
            "tools": TOOLS,
            "messages": self.messages,
            "cache_control": {"type": "ephemeral"},  # also cache the growing conversation
        }
        if model in ADAPTIVE_MODELS:
            req["thinking"] = {"type": "adaptive"}
            req["output_config"] = {"effort": s["effort"]}
        if model in FALLBACK_MODELS:
            # If a safety classifier declines, retry on Anthropic's recommended fallback model.
            req["fallbacks"] = "default"
            req["betas"] = ["server-side-fallback-2026-07-01"]
        return req

    def run_turn(self, content: list[dict[str, Any]], cancel: threading.Event) -> TurnResult:
        result = TurnResult()
        client = self.client()
        if client is None:
            msg = "I need an Anthropic API key before I can think. Open the Study Buddy page on your laptop and add one in Settings."
            self.speak(msg)
            return TurnResult(spoken=msg, error="no_api_key")
        budget = float(self.settings.get("daily_budget_usd"))
        if budget <= 0 or self.progress.spent_today() >= budget:
            msg = "I've reached today's spending limit, so I can't think any more today. You can raise it in Settings."
            self.speak(msg)
            return TurnResult(spoken=msg, error="budget")

        with self.lock:
            self._turn_start = len(self.messages)
            self.messages.append({"role": "user", "content": content})
            json_retries = 0
            rounds = 0
            while rounds < MAX_TOOL_ROUNDS:
                rounds += 1
                chunker = SentenceChunker()
                try:
                    final = self._stream(client, chunker, cancel, result)
                except Cancelled:
                    result.cancelled = True
                    return result
                except ValueError as e:
                    # A streamed tool input that could not be parsed at all: re-issue the round.
                    json_retries += 1
                    logger.warning("Unparseable tool input (%s), retry %d", e, json_retries)
                    if json_retries > 2:
                        result.error = "bad_tool_json"
                        break
                    rounds -= 1
                    continue
                except anthropic.AuthenticationError:
                    return self._fail(result, "auth", "My API key was rejected. Please check it in Settings on the laptop page.")
                except anthropic.PermissionDeniedError:
                    return self._fail(result, "permission", "My API key isn't allowed to use this model. Try another model in Settings.")
                except anthropic.NotFoundError:
                    return self._fail(result, "model", "I couldn't find that Claude model. Pick another one in Settings.")
                except anthropic.RateLimitError:
                    return self._fail(result, "rate_limit", "I'm being rate limited. Give me a minute and ask again.")
                except anthropic.BadRequestError as e:
                    logger.error("Bad request: %s", e)
                    self.reset()  # a broken history would fail every turn, so start clean
                    return self._fail(result, "bad_request", "Something went wrong with my memory of this chat, so I've started fresh. Could you say that again?")
                except anthropic.APIStatusError as e:
                    return self._fail(result, f"api_{e.status_code}", "Claude's servers are having trouble right now. Try again in a moment.")
                except anthropic.APIConnectionError:
                    return self._fail(result, "offline", "I can't reach the internet right now. Check the Wi-Fi and try again.")

                cost, tin, tout = estimate_cost(self.settings.get("model"), final.usage)
                result.cost_usd += cost
                spent = self.progress.add_usage(cost, tin, tout)
                self.emit("usage", {"today_usd": round(spent, 4), "turn_usd": round(cost, 4)})

                if final.stop_reason == "refusal":
                    self.speak("Sorry, I can't help with that one.")
                    self.messages.append({"role": "assistant", "content": [b for b in echo_content(final.content) if getattr(b, "type", "") == "text"] or [{"type": "text", "text": "(declined)"}]})
                    break

                content_out = echo_content(final.content)
                tool_calls = [b for b in content_out if getattr(b, "type", "") == "tool_use"]
                if final.stop_reason == "max_tokens" and tool_calls:
                    logger.warning("Reply truncated in the middle of a tool call")
                    self.messages.append({"role": "assistant", "content": [b for b in content_out if getattr(b, "type", "") == "text"] or [{"type": "text", "text": "(cut off)"}]})
                    break
                if final.stop_reason == "pause_turn":
                    self.messages.append({"role": "assistant", "content": content_out})
                    continue
                if not tool_calls:
                    self.messages.append({"role": "assistant", "content": content_out})
                    break

                results = []
                for call in tool_calls:
                    if cancel.is_set():
                        # Every tool_use needs a tool_result, so the history stays valid.
                        results.append({"type": "tool_result", "tool_use_id": call.id, "is_error": True,
                                        "content": "Not run: the student interrupted you."})
                    else:
                        results.append(self.toolbox.run(call.name, call.input, call.id))
                self.messages.append({"role": "assistant", "content": content_out})
                self.messages.append({"role": "user", "content": results})
                if cancel.is_set():
                    result.cancelled = True
                    return result
            else:
                logger.warning("Stopped after %d tool rounds", MAX_TOOL_ROUNDS)
        return result

    def _fail(self, result: TurnResult, code: str, message: str) -> TurnResult:
        logger.warning("Turn failed: %s", code)
        # Undo everything this turn added, so the history stays valid for next time.
        del self.messages[self._turn_start:]
        self.speak(message)
        result.error = code
        result.spoken += message
        return result

    def _stream(self, client: anthropic.Anthropic, chunker: SentenceChunker, cancel: threading.Event,
                result: TurnResult) -> Any:
        req = self._request()
        with client.beta.messages.stream(**req) as stream:
            for event in stream:
                if cancel.is_set():
                    raise Cancelled
                etype = event.type
                if etype == "text":
                    self.emit("reply_delta", {"text": event.text})
                    for sentence in chunker.feed(event.text):
                        self.speak(sentence)
                        result.spoken += sentence + " "
                elif etype == "content_block_start":
                    kind = event.content_block.type
                    if kind == "thinking":
                        self.emit("thinking", {})
                    elif kind == "fallback":
                        logger.info("Claude handed this reply to a fallback model")
            final = stream.get_final_message()
        rest = chunker.flush()
        if rest:
            self.speak(rest)
            result.spoken += rest
        return final
