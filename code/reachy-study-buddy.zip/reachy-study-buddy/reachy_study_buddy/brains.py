# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Switches between the two brains: Claude (API key) and the free local model (Ollama)."""

from __future__ import annotations

import threading
from typing import Any, Callable

from .brain import Brain, TurnResult
from .local_brain import LocalBrain
from .store import Progress, Settings
from .tools import ToolBox


class BrainRouter:
    def __init__(self, settings: Settings, progress: Progress, toolbox: ToolBox, speak: Callable[[str], None],
                 emit: Callable[[str, dict[str, Any]], None]) -> None:
        self.settings = settings
        self.claude = Brain(settings, progress, toolbox, speak, emit)
        self.local = LocalBrain(settings, toolbox, speak, emit)
        self._last: Brain | LocalBrain | None = None

    @property
    def active(self) -> Brain | LocalBrain:
        return self.local if self.settings.get("brain") == "local" else self.claude

    @property
    def messages(self) -> list[dict[str, Any]]:
        return self.active.messages

    def run_turn(self, content: list[dict[str, Any]], cancel: threading.Event) -> TurnResult:
        brain = self.active
        if self._last is not None and brain is not self._last:
            self._last.reset()  # switching brains starts a fresh conversation
        self._last = brain
        return brain.run_turn(content, cancel)

    def reset(self) -> None:
        self.claude.reset()
        self.local.reset()

    def rollback_last_turn(self) -> None:
        self.active.rollback_last_turn()
