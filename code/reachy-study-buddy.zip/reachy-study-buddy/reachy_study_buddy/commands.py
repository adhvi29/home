# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Instant movement commands ("look up", "dance", "wag your antennas").

These are handled straight away without asking the AI, so the robot reacts instantly and
a small local model can't misread them.
"""

from __future__ import annotations

import re

_WAKE = r"(?:hey |hi |ok |okay )?(?:reachy|reachie|reechy|reachey|richie|ritchie|richy|ritchy|ricci|ricky)[,.!]?\s*"
_POLITE = r"(?:can you |could you |please |now |just |go |and )*"
_DIRECTIONS = {
    "up left": "up_left", "up right": "up_right", "down left": "down_left", "down right": "down_right",
    "up": "up", "upwards": "up", "the sky": "up", "sky": "up", "the ceiling": "up", "ceiling": "up",
    "down": "down", "downwards": "down", "the floor": "down", "floor": "down", "the desk": "down",
    "left": "left", "to the left": "left", "the left": "left", "your left": "left",
    "right": "right", "to the right": "right", "the right": "right", "your right": "right",
    "straight": "center", "straight ahead": "center", "ahead": "center", "forward": "center", "forwards": "center",
    "centre": "center", "center": "center", "the front": "center", "front": "center",
}
_EMOTIONS = {
    "happy": "happy", "sad": "sad", "angry": "angry", "mad": "angry", "excited": "excited", "surprised": "surprised",
    "shocked": "surprised", "curious": "curious", "confused": "confused", "proud": "proud", "shy": "shy",
    "sleepy": "sleepy", "tired": "sleepy", "in love": "love", "loving": "love",
}
_REPLIES = {"happy": "Yay!", "sad": "Aww.", "angry": "Grr!", "excited": "Ooh!", "surprised": "Whoa!", "curious": "Hmm?",
            "confused": "Huh?", "proud": "Ta-da!", "shy": "Oh, stop it.", "sleepy": "So sleepy.", "love": "Aww, thanks!"}


def parse(text: str) -> tuple[str, str, str] | None:
    """(kind, what, reply) if ``text`` is just a movement command, else None.
    kind is "point" (what = direction) or "gesture" (what = gesture name)."""
    t = text.lower().strip()
    t = re.sub(r"^" + _WAKE, "", t)
    t = re.sub(r"[.!?,]+$", "", t).strip()
    t = re.sub(r"^" + _POLITE, "", t).strip()
    t = re.sub(r"\s+please$", "", t)

    m = re.fullmatch(r"(?:look|turn|face|point)(?: your head| around to| round to)?(?: to| at| towards?)?\s+(.+)", t)
    if m:
        where = m.group(1).strip()
        if where in ("around", "round", "about"):
            return "gesture", "search", "Looking around!"
        if where in ("me", "at me", "here"):
            return "point", "center", "Hi!"
        if where in _DIRECTIONS:
            return "point", _DIRECTIONS[where], "Okay!"
        return None
    if re.fullmatch(r"(?:do a |do the |have a )?dance(?: for me)?|let'?s dance|show me (?:your|a) dance", t):
        return "gesture", "dance", "Let's go!"
    if re.fullmatch(r"(?:do a )?nod(?: your head)?|nod yes", t):
        return "gesture", "nod", ""
    if re.fullmatch(r"shake your head|shake no", t):
        return "gesture", "shake", ""
    if re.fullmatch(r"wag(?: your)?(?: antennas?| antennae| ears| tail)?|wiggle(?: your)? (?:antennas?|antennae|ears)", t):
        return "gesture", "excited", ""
    if re.fullmatch(r"(?:do a )?(?:bow|take a bow)", t):
        return "gesture", "bow", ""
    m = re.fullmatch(r"(?:be|look|act|get|show me)(?: you'?re| how you look when you'?re| how you feel when you'?re| a bit| really| very)? ("
                     + "|".join(sorted(map(re.escape, _EMOTIONS), key=len, reverse=True)) + r")", t)
    if m:
        name = _EMOTIONS[m.group(1)]
        return "gesture", name, _REPLIES[name]
    return None
