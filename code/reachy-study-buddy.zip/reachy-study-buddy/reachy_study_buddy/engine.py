# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Engine: ties hearing, the brain, the voice, the body and the web page together.

States
  standby       Reachy only reacts when it hears its name (or a tap / the Talk button)
  conversation  every utterance goes to Claude, until a quiet spell sends it back to standby
Reading mode sits on top: utterances are written into the open chapter instead of being
sent to Claude, unless the student says Reachy's name.
"""

from __future__ import annotations

import base64
import collections
import datetime as dt
import io
import logging
import queue
import random
import re
import threading
import time
from typing import Any, Callable

import numpy as np

from . import commands
from .brain import TurnResult
from .brains import BrainRouter
from .focus import FocusCoach, Timers
from .hearing import Listener, Transcriber
from .local_brain import ollama_status
from .materials import Materials
from .quiz import QuizBank
from .store import LOCAL_MODELS, MODELS, Progress, Settings, api_key_status
from .tools import ToolBox
from .voice import VOICES, PiperTTS, Speaker, chirp

logger = logging.getLogger(__name__)

WAKE = re.compile(r"\b(reachy|reachie|reechy|reachey|richie|ritchie|richy|ritchy|ricci|ricky)\b", re.I)
FILLER = re.compile(r"\b(hey|hi|hello|ok|okay|oi|um|uh|yo|so)\b", re.I)
HISTORY_IDLE_RESET_S = 20 * 60
MAX_HISTORY = 80


class Engine:
    def __init__(self, io_: Any, settings: Settings, progress: Progress, broadcast: Callable[[dict[str, Any]], None],
                 on_turn_off: Callable[[], None] | None = None, startup_note: str = "") -> None:
        self.io = io_
        self.settings = settings
        self.progress = progress
        self._broadcast = broadcast
        self.on_turn_off = on_turn_off
        self.startup_note = startup_note
        self.events: queue.Queue[tuple[str, Any]] = queue.Queue()

        self.quiz = QuizBank(progress)
        self.materials = Materials()
        self.focus = FocusCoach(progress, self._focus_event)
        self.timers = Timers(self._timer_event)
        self.toolbox = ToolBox(self)
        self.brain = BrainRouter(settings, progress, self.toolbox, speak=self._speak_reply, emit=self.emit)
        self.tts: PiperTTS | None = None
        self.speaker: Speaker | None = None
        self.transcriber = Transcriber(settings.get("stt_model"))
        self.listener: Listener | None = None
        self.stt_queue: queue.Queue[np.ndarray] = queue.Queue(maxsize=50)

        self.state = "starting"
        self.body_mode = ""
        self.turn_thread: threading.Thread | None = None
        self.turn_cancel: threading.Event | None = None
        self.turn_text = ""
        self.turn_spoke = False
        self.turn_source = ""
        self.restart_after_cancel = False
        self.pending: list[str] = []
        self.attachments: list[dict[str, Any]] = []
        self.materials_sent: set[str] = set()
        self.last_activity = time.monotonic()
        self.last_turn_end = 0.0
        self.standby_after_speech = False
        self.hearing_speech = False
        self.processing_speech = False  # utterance ended, speech recognition running
        self.speech_ended_at = 0.0
        self.turning_off = False
        self.restart_requested = False
        self.mic_level = 0.0
        self.transcript: collections.deque[dict[str, Any]] = collections.deque(maxlen=200)
        self.cards: collections.deque[dict[str, Any]] = collections.deque(maxlen=20)
        self.snapshot: bytes | None = None
        self.snapshot_ts = 0.0
        self.problems: dict[str, str] = {}
        self._claude_started_focus = False
        self._stop = threading.Event()

    # === plumbing ======================================================================
    def emit(self, kind: str, payload: dict[str, Any] | None = None) -> None:
        try:
            self._broadcast({"type": kind, **(payload or {})})
        except Exception as e:  # noqa: BLE001 - a UI hiccup must never break the robot
            logger.debug("broadcast failed: %s", e)

    def post(self, kind: str, data: Any = None) -> None:
        """Hand work to the engine thread (safe from any thread)."""
        self.events.put((kind, data))

    def _log(self, who: str, text: str, **extra: Any) -> None:
        item = {"who": who, "text": text, "ts": dt.datetime.now().strftime("%H:%M"), **extra}
        self.transcript.append(item)
        self.emit("transcript", {"item": item})

    # === start / stop ==================================================================
    def run(self, stop_event: threading.Event) -> None:
        self._stop = stop_event
        self.io.start()
        threading.Thread(target=self._load, name="loader", daemon=True).start()
        threading.Thread(target=self._stt_worker, name="stt", daemon=True).start()
        last_tick = 0.0
        while not stop_event.is_set():
            try:
                kind, data = self.events.get(timeout=0.1)
                self._handle(kind, data)
            except queue.Empty:
                pass
            except Exception:  # noqa: BLE001 - log and keep the robot running
                logger.exception("Engine error")
            try:
                if self.io.antenna_touched():
                    self._handle("touch", None)
                self._update_body()
                now = time.monotonic()
                if now - last_tick >= 1.0:
                    last_tick = now
                    self._tick()
            except Exception:  # noqa: BLE001
                logger.exception("Engine tick error")
        self.shutdown()

    @property
    def stopping(self) -> bool:
        return self._stop.is_set()

    def shutdown(self) -> None:
        self._stop.set()
        if self.turn_cancel:
            self.turn_cancel.set()
        if self.focus.phase != "idle":
            self.focus.stop(announce=False)
        if self.materials.recording:
            self.materials.finish()
        if self.listener:
            self.listener.stop()
        if self.speaker:
            self.speaker.interrupt()
            self.speaker.stop()
        try:
            self.io.stop()
        except Exception as e:  # noqa: BLE001
            logger.warning("Stopping hardware: %s", e)

    def _load(self) -> None:
        try:
            self.tts = PiperTTS(self.settings.get("voice"))
            self.speaker = Speaker(self.tts, self.io.play, self.io.flush, lambda: float(self.settings.get("speech_rate")),
                                   lambda: float(self.settings.get("volume")), lambda busy: self.emit("speaking", {"on": busy}))
            self.speaker.start()
        except Exception as e:  # noqa: BLE001
            logger.exception("Voice failed to load")
            self.problems["voice"] = f"Voice failed to load: {e}"
        self.emit("system", self.system_info())
        try:
            self.transcriber.load()
            self.problems.pop("hearing", None)
        except Exception as e:  # noqa: BLE001
            logger.exception("Speech recognition failed to load")
            self.problems["hearing"] = str(e)
        if self.transcriber.ready:
            self.listener = Listener(self.io.read_mic, self._on_utterance, self._on_speech_start, self._on_level,
                                     self._mic_blocked, lambda: int(self.settings.get("end_of_speech_ms")))
            self.listener.start()
        if self.settings.get("brain") == "local":
            t0 = time.time()
            if self.brain.local.warm_up():
                logger.info("Local brain warmed up in %.1fs", time.time() - t0)
        self.post("ready")

    # === hearing ======================================================================
    def _mic_blocked(self) -> bool:
        return bool(self.settings.get("mic_muted")) or (self.speaker is not None and self.speaker.busy)

    def _on_level(self, level: float) -> None:
        self.mic_level = level

    def _on_speech_start(self) -> None:
        self.hearing_speech = True
        self.emit("hearing", {"on": True})

    def _on_utterance(self, audio: np.ndarray) -> None:
        self.hearing_speech = False
        self.processing_speech = True  # look thoughtful straight away while the words are worked out
        self.speech_ended_at = time.monotonic()
        self.emit("hearing", {"on": False})
        try:
            self.stt_queue.put_nowait(audio)
        except queue.Full:
            self.processing_speech = False
            logger.warning("Speech recognition is falling behind; dropped an utterance")

    def _stt_worker(self) -> None:
        while not self._stop.is_set():
            try:
                audio = self.stt_queue.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                t0 = time.time()
                text = self.transcriber.transcribe(audio, hint=self._stt_hint())
                logger.info("Heard (%.1fs audio, %.2fs STT): %s", audio.size / 16000, time.time() - t0, text)
            except Exception:  # noqa: BLE001
                logger.exception("Transcription failed")
                text = ""
            if text:
                self.post("heard", text)
            else:
                self.processing_speech = False

    def _stt_hint(self) -> str:
        """Tell Whisper what we're studying, so subject words come out right."""
        rec = self.materials.recording_status()
        if rec:
            recent = " ".join(self.materials.text_so_far().split()[-40:])
            return f"{rec['subject']} {rec['title']}. {recent}"
        active = self.materials.index["items"].get(self.materials.index.get("active") or "")
        return f"{active['subject']} {active['title']}." if active else ""

    # === event handling ===============================================================
    def _handle(self, kind: str, data: Any) -> None:
        if self.turning_off:
            return
        if kind == "heard":
            self.processing_speech = False
            self._on_heard(data)
        elif kind == "turn_off":
            self._turn_off()
        elif kind == "restart":
            self._turn_off(restart=True)
        elif kind == "typed":
            self._interrupt_if_busy()
            if not self._quick_command(data, "typed"):
                self._start_turn(data, source="typed")
        elif kind == "talk":
            self._wake()
        elif kind == "stop":
            self._interrupt()
        elif kind == "touch":
            if (self.speaker and self.speaker.busy) or self._turn_running():
                self._interrupt()
            else:
                self._wake()
        elif kind == "turn_done":
            self._turn_done(*data)
        elif kind == "ready":
            self._ready()
        elif kind == "reload_voice":
            threading.Thread(target=self._reload_voice, daemon=True).start()
        elif kind == "reading":
            action, title, subject = data
            if action == "start":
                self.start_reading(title, subject)
                self.announce("Go ahead, I'm listening. Say my name if you need me, or tell me when you're done.")
            else:
                item = self.finish_reading(title, subject)
                if item is None:
                    self.announce("I didn't catch any reading, so there's nothing to save.")
                else:
                    self._start_turn("I've finished reading.", source="button")
        elif kind == "call":  # run a function on the engine thread
            data()

    def _ready(self) -> None:
        self.state = "standby" if self.settings.get("wake_word") else "conversation"
        name = self.settings.get("student_name").strip()
        hello = f"Hi {name}!" if name else "Hi!"
        brain = self.brain_status()
        if not self.transcriber.ready:
            self.announce(f"{hello} I can talk, but my hearing didn't start. Check the Study Buddy page on your laptop.")
        elif not brain["ready"]:
            self.announce(f"{hello} I'm Reachy, your study buddy. My brain isn't ready yet: {brain['problem']}")
        else:
            self.announce(f"{hello} I'm ready when you are. Just say my name.")
        if self.startup_note:
            self.announce(self.startup_note)
        self.io.gesture("happy")
        self.emit("system", self.system_info())

    def _on_heard(self, text: str) -> None:
        addressed = bool(WAKE.search(text))
        if self.materials.recording and not addressed:
            status = self.materials.add(text)
            self.emit("reading", {"status": self.materials.recording_status(), "words": status})
            if random.random() < 0.3:
                self.io.gesture("small_nod")
            return
        if self._turn_running():
            self.pending.append(text)
            if not self.turn_spoke and self.turn_cancel is not None:
                # Still thinking about the last thing they said: merge and start again.
                self.restart_after_cancel = True
                self.turn_cancel.set()
            return
        if self.state != "conversation" and self.settings.get("wake_word") and not addressed:
            self._log("heard", text)  # shown greyed out: not meant for Reachy
            return
        if addressed and not FILLER.sub("", WAKE.sub("", text)).strip(" ,.!?'\"-"):
            self._wake()
            return
        if self._quick_command(text, "voice"):
            return
        self._start_turn(text, source="voice")

    def _quick_command(self, text: str, source: str) -> bool:
        """'Look up', 'dance', 'wag your antennas': do it now, no AI needed."""
        cmd = commands.parse(text)
        if cmd is None:
            return False
        if not self.io.has_body:
            self._log("you", text, source=source)
            self.announce("I can't move right now because my motors have no power. Switch my power on, then press "
                          "Restart on the study page.")
            return True
        kind, what, reply = cmd
        self.state = "conversation"
        self.last_activity = time.monotonic()
        self._log("you", text, source=source)
        if kind == "point":
            self.io.point(what, 4.0)
        else:
            self.io.gesture(what)
        if reply:
            self.announce(reply)
        return True

    def _wake(self) -> None:
        self.state = "conversation"
        self.last_activity = time.monotonic()
        if self.speaker:
            self.speaker.sound(chirp("listen"))
        self.io.gesture("perk")
        self.emit("state", {"state": self.state})

    def _interrupt_if_busy(self) -> None:
        if self._turn_running() or (self.speaker and self.speaker.busy):
            self._interrupt()

    def _interrupt(self) -> None:
        self.pending.clear()
        self.restart_after_cancel = False
        if self.turn_cancel:
            self.turn_cancel.set()
        if self.speaker:
            self.speaker.interrupt()
        self.last_activity = time.monotonic()
        self.emit("interrupted", {})

    # === turns ========================================================================
    def _turn_running(self) -> bool:
        return self.turn_thread is not None and self.turn_thread.is_alive()

    def _start_turn(self, text: str, source: str) -> None:
        now = time.monotonic()
        self.state = "conversation"
        if self.brain.messages and (now - self.last_activity > HISTORY_IDLE_RESET_S or len(self.brain.messages) > MAX_HISTORY):
            self._reset_conversation()
        self.last_activity = now
        content = self._build_content(text, source)
        self._log("you", text, source=source)
        self.turn_text, self.turn_spoke, self.turn_source = text, False, source
        cancel = threading.Event()
        self.turn_cancel = cancel
        self.turn_thread = threading.Thread(target=self._turn_worker, args=(content, cancel), name="turn", daemon=True)
        self.turn_thread.start()
        self.emit("turn_start", {})

    def _turn_worker(self, content: list[dict[str, Any]], cancel: threading.Event) -> None:
        try:
            result = self.brain.run_turn(content, cancel)
        except Exception as e:  # noqa: BLE001
            logger.exception("Turn crashed")
            result = TurnResult(error=str(e))
            self._speak_reply("Sorry, something went wrong in my head. Try again?")
        self.post("turn_done", (result, cancel))

    def _speak_reply(self, sentence: str) -> None:
        if not self.turn_spoke and self.turn_source == "voice" and self.speech_ended_at:
            logger.info("Reply started %.1fs after you stopped talking", time.monotonic() - self.speech_ended_at)
        self.turn_spoke = True
        if self.speaker:
            self.speaker.say(sentence)

    def _turn_done(self, result: TurnResult, cancel: threading.Event) -> None:
        if cancel is not self.turn_cancel:
            return
        self.turn_thread = None
        self.last_activity = self.last_turn_end = time.monotonic()
        if result.spoken.strip():
            self._log("reachy", result.spoken.strip(), cancelled=result.cancelled)
        self.emit("reply_done", {"cancelled": result.cancelled, "error": result.error})
        if self.restart_after_cancel and result.cancelled:
            self.restart_after_cancel = False
            merged = " ".join([self.turn_text, *self.pending]).strip()
            self.pending.clear()
            # The merged turn repeats the first text, so forget the cancelled one everywhere.
            self.brain.rollback_last_turn()
            for item in reversed(self.transcript):
                if item["who"] == "you" and item["text"] == self.turn_text:
                    self.transcript.remove(item)
                    break
            self._start_turn(merged, source="voice")
            return
        if self.pending:
            merged = " ".join(self.pending)
            self.pending.clear()
            self._start_turn(merged, source="voice")

    def _build_content(self, text: str, source: str) -> list[dict[str, Any]]:
        blocks: list[dict[str, Any]] = [{"type": "text", "text": self._context_line()}]
        active = self.materials.active()
        if active and active["id"] not in self.materials_sent and active["text"].strip() and self._recent(active["created"]):
            blocks.append({
                "type": "document",
                "source": {"type": "text", "media_type": "text/plain", "data": active["text"]},
                "title": active["title"],
                "context": "Transcript of a chapter the student read aloud to you (speech recognition, so some words may be misheard).",
            })
            self.materials_sent.add(active["id"])
        if self.materials.recording:
            words = self.materials.text_so_far().split()
            tail = " ".join(words[-1500:])
            blocks.append({"type": "text", "text": f"[Reading mode is on: {len(words)} words read so far. The most recent part:]\n{tail}"})
        for att in self.attachments:
            blocks.append(att["block"])
        if self.attachments:
            blocks.append({"type": "text", "text": "[Attached by the student on the laptop page: " + ", ".join(a["name"] for a in self.attachments) + "]"})
            self.attachments = []
            self.emit("attachments", {"items": []})
        said = "typed" if source == "typed" else "said"
        blocks.append({"type": "text", "text": f"Student {said}: {text}"})
        return blocks

    @staticmethod
    def _recent(iso: str, hours: float = 24) -> bool:
        try:
            return dt.datetime.now() - dt.datetime.fromisoformat(iso) < dt.timedelta(hours=hours)
        except ValueError:
            return False

    def _context_line(self) -> str:
        now = dt.datetime.now()
        face = self.io.face_present()
        desk = {True: "yes", False: "no face in view", None: "unknown"}[face]
        n_mats = len(self.materials.list())
        mats = ""
        if n_mats:
            latest = self.materials.list()[0]["title"]
            mats = f" Saved chapters: {n_mats} (latest: {latest})."
        if self.io.has_body:
            body = "Reachy Mini robot"
        elif self.io.name.startswith("Reachy"):
            body = "Reachy Mini's camera, mic and speaker, but its motors are off, so you can't move or tilt your head"
        else:
            body = "laptop only (no robot body; the laptop webcam instead of your head camera)"
        return (f"[Context] {now:%A %d %B %Y, %I:%M %p}. Focus: {self.focus.describe()}. At desk: {desk}. "
                f"Running on: {body}.{mats}")

    def _reset_conversation(self) -> None:
        self.brain.reset()
        self.materials_sent.clear()

    # === ticking =======================================================================
    def _turn_off(self, restart: bool = False) -> None:
        """The power button: say bye, go to sleep, free the GPU and stop everything.
        With ``restart`` the launcher starts everything again (e.g. after switching the motors on)."""
        self.turning_off = True
        self.restart_requested = restart
        self._interrupt()
        self.emit("turning_off", {"restart": restart})
        self.io.gesture("sleepy")
        line = "Restarting. Back in a moment!" if restart else "Okay, turning off. Bye!"
        if self.speaker:
            self._log("reachy", line)
            self.speaker.say(line)
            self.speaker.wait_done(timeout=5)
        if self.settings.get("brain") == "local" and not restart:
            self.brain.local.unload()  # give the GPU memory back straight away
        logger.info("Turned off from the study page")
        if self.on_turn_off:
            self.on_turn_off()
        else:
            self._stop.set()

    def _update_body(self) -> None:
        if self.speaker and self.speaker.busy:
            mode = "speaking"
        elif self._turn_running() or self.processing_speech:
            mode = "thinking"
        elif self.hearing_speech:
            mode = "listening"
        elif self.materials.recording:
            mode = "reading"
        elif self.focus.phase == "focus" and not self.focus.paused:
            mode = "focus"
        elif self.focus.phase == "break":
            mode = "break"
        elif self.state == "conversation":
            mode = "idle"
        else:
            mode = "standby"
        if mode != self.body_mode:
            self.body_mode = mode
            self.io.set_mode(mode)
            self.emit("mode", {"mode": mode})

    def _tick(self) -> None:
        now = time.monotonic()
        self.io.set_presence_watch(self.focus.phase == "focus" and not self.focus.paused)
        self.focus.tick(self.io.face_present())
        self.timers.tick()
        idle = not self._turn_running() and not (self.speaker and self.speaker.busy) and not self.hearing_speech
        if idle and self.standby_after_speech:
            self.standby_after_speech = False
            self._reset_conversation()
            self._go_standby()
        timeout = float(self.settings.get("conversation_timeout_s"))
        if (idle and self.state == "conversation" and self.settings.get("wake_word") and not self.materials.recording
                and now - self.last_activity > timeout):
            self._go_standby()
        if idle and self.brain.messages and now - self.last_activity > HISTORY_IDLE_RESET_S:
            self._reset_conversation()
        self.emit("status", self.status())

    def _go_standby(self) -> None:
        if self.state != "standby":
            self.state = "standby"
            self.emit("state", {"state": self.state})

    # === announcements (no Claude call) ================================================
    def announce(self, text: str, gesture: str | None = None) -> None:
        self._log("reachy", text)
        if self.speaker:
            self.speaker.say(text)
        if gesture:
            self.io.gesture(gesture)

    def _focus_event(self, kind: str, p: dict[str, Any]) -> None:
        if kind == "focus_start":
            goal = f" on {p['goal']}" if p.get("goal") else ""
            if p["cycle"] == 1:
                if self._claude_started_focus:  # Claude is announcing it in its own words
                    self._claude_started_focus = False
                    self.io.gesture("nod")
                else:
                    self.announce(f"Focus time: {p['minutes']:g} minutes{goal}. I'll keep an eye on the clock.", "nod")
            else:
                self.announce(f"Break's over. Block {p['cycle']} of {p['cycles']}. Let's go!", "perk")
        elif kind == "break_start":
            longer = " That's four blocks, so this one is a longer break." if p.get("long") else ""
            self.announce(f"Nice work, block {p['cycle']} done!{longer} Take {p['minutes']:g} minutes: stand up, stretch and grab some water.", "celebrate")
            threading.Timer(2.6, lambda: self.io.gesture("stretch")).start()
        elif kind == "session_done":
            self.announce(f"That's the whole session done: {p['focused_min']:g} minutes of real focus. Brilliant work!", "dance")
        elif kind == "focus_stopped":
            self.announce("Okay, focus session stopped.")
        elif kind == "focus_paused":
            self.announce("Paused. Tell me when you're back.")
        elif kind == "focus_resumed":
            self.announce("And we're back.", "nod")
        elif kind == "left":
            self.io.gesture("search")
            self._log("system", "You left your desk during a focus block.")
        elif kind == "returned":
            if self.settings.get("welcome_back_voice") and p.get("away_s", 0) >= 60:
                self.announce("Welcome back!", "excited")
            else:
                self.io.gesture("excited")
        self.emit("focus", self.focus.status())
        self.push_stats()

    def _timer_event(self, kind: str, p: dict[str, Any]) -> None:
        if kind == "timer_done":
            if self.speaker:
                self.speaker.sound(chirp("alarm"))
            self.announce(f"Time's up for {p['label']}!", "surprised")
        self.emit(kind, p)

    # === things tools and the web page call ===========================================
    def look(self, where: str) -> tuple[bytes | None, str]:
        note = ""
        if self.io.has_body:
            self.io.hold(where)
            time.sleep(1.3)  # head travel + camera settle
        elif where == "desk":
            note = ("Your head can't tilt right now, so this is looking straight ahead. If the page isn't in view, "
                    "ask the student to hold it up in front of the camera.")
        try:
            jpeg = self.io.capture_jpeg()
        finally:
            self.io.hold(None)
        if jpeg is None:
            return None, "no frame from the camera"
        self.snapshot, self.snapshot_ts = jpeg, time.time()
        self.emit("snapshot", {"ts": self.snapshot_ts, "where": where})
        return jpeg, note

    def gesture(self, name: str) -> None:
        self.io.gesture(name)

    def turn_to(self, direction: str, seconds: float) -> bool:
        if not self.io.has_body:
            return False
        self.io.point(direction, seconds)
        return True

    def show_card(self, title: str, markdown: str, kind: str = "note") -> None:
        card = {"id": f"c{time.time_ns()}", "title": title, "markdown": markdown, "kind": kind, "ts": dt.datetime.now().strftime("%H:%M")}
        self.cards.append(card)
        self.emit("card", {"card": card})

    def show_question(self, q: dict[str, Any]) -> None:
        card = {"id": f"q{time.time_ns()}", "title": f"{q['subject'].replace('_', ' ').title()}: {q['topic']}",
                "html": q["html"], "marks": q["marks"], "kind": "question", "ts": dt.datetime.now().strftime("%H:%M")}
        self.cards.append(card)
        self.emit("card", {"card": card})

    def show_mark_scheme(self, q: dict[str, Any], entry: dict[str, Any]) -> None:
        lines = "\n".join(f"- {line}" for line in q["mark_scheme"])
        notes = f"\n\n*Examiner note:* {q['notes']}" if q.get("notes") else ""
        self.show_card(f"Mark scheme: you got {entry['got']:g}/{entry['out_of']:g}", lines + notes, kind="markscheme")

    def start_focus(self, focus_min: float, break_min: float | None, cycles: int | None, goal: str,
                    from_claude: bool = False) -> dict[str, Any]:
        s = self.settings.all()
        self._claude_started_focus = from_claude
        status = self.focus.start(focus_min or s["focus_minutes"], break_min or s["break_minutes"], cycles or s["cycles"],
                                  goal, s["long_break_minutes"], s["away_after_s"])
        self.push_focus()
        return status

    def start_reading(self, title: str, subject: str) -> dict[str, Any]:
        status = self.materials.start(title, subject)
        self.emit("reading", {"status": status, "words": 0})
        return status

    def finish_reading(self, title: str = "", subject: str = "") -> dict[str, Any] | None:
        item = self.materials.finish(title, subject)
        self.emit("reading", {"status": None, "words": 0})
        if item:
            self.materials_sent.discard(item["id"])
            self.push_materials()
        return item

    def request_standby(self) -> None:
        self.standby_after_speech = True

    def push_focus(self) -> None:
        self.emit("focus", self.focus.status())

    def push_stats(self) -> None:
        self.emit("stats", self.stats())

    def push_materials(self) -> None:
        self.emit("materials", {"items": self.materials.list()})

    def stats(self) -> dict[str, Any]:
        today = dt.date.today()
        week = [(today - dt.timedelta(days=i)).isoformat() for i in range(6, -1, -1)]
        return {
            "focus_today_min": round(self.focus.status()["focused_today_min"], 1),
            "focus_week": [{"day": d, "minutes": self.progress.focus_minutes_on(d)} for d in week],
            "streak_days": self.progress.streak_days(),
            "quiz": self.quiz.summary(),
            "notes": self.progress.recent_notes(10),
            "spent_today_usd": round(self.progress.spent_today(), 3),
            "budget_usd": self.settings.get("daily_budget_usd"),
        }

    def add_attachment(self, name: str, data: bytes, content_type: str) -> dict[str, Any]:
        from PIL import Image

        if len(self.attachments) >= 5:
            raise ValueError("You can attach up to 5 files at a time.")
        name = re.sub(r"[^\w .()-]", "_", name)[:80] or "file"
        lower = name.lower()
        if content_type == "application/pdf" or lower.endswith(".pdf"):
            if len(data) > 20 * 1024 * 1024:
                raise ValueError("PDFs must be under 20 MB.")
            block = {"type": "document", "title": name,
                     "source": {"type": "base64", "media_type": "application/pdf", "data": base64.b64encode(data).decode()}}
        elif content_type.startswith("image/") or lower.endswith((".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp")):
            img = Image.open(io.BytesIO(data)).convert("RGB")
            img.thumbnail((1568, 1568))
            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=88)
            block = {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": base64.b64encode(buf.getvalue()).decode()}}
        elif lower.endswith((".txt", ".md")):
            block = {"type": "document", "title": name,
                     "source": {"type": "text", "media_type": "text/plain", "data": data.decode("utf-8", errors="replace")[:400_000]}}
        else:
            raise ValueError("Upload a photo (JPG, PNG), a PDF or a text file.")
        self.attachments.append({"name": name, "block": block})
        items = [a["name"] for a in self.attachments]
        self.emit("attachments", {"items": items})
        return {"items": items}

    def clear_attachments(self) -> None:
        self.attachments = []
        self.emit("attachments", {"items": []})

    def _reload_voice(self) -> None:
        name = self.settings.get("voice")
        try:
            if self.tts and name != self.tts.voice_name:
                self.tts.load(name)
            self.problems.pop("voice", None)
        except Exception as e:  # noqa: BLE001
            self.problems["voice"] = f"Couldn't load voice {name}: {e}"
        self.emit("system", self.system_info())

    # === snapshots for the web page ==================================================
    def status(self) -> dict[str, Any]:
        return {
            "state": self.state,
            "mode": self.body_mode,
            "speaking": bool(self.speaker and self.speaker.busy),
            "thinking": self._turn_running(),
            "hearing": self.hearing_speech,
            "mic_level": round(self.mic_level, 2),
            "mic_muted": bool(self.settings.get("mic_muted")),
            "focus": self.focus.status(),
            "presence": self.io.face_present(),
            "timers": self.timers.list(),
            "reading": self.materials.recording_status(),
            "attachments": [a["name"] for a in self.attachments],
        }

    def brain_status(self) -> dict[str, Any]:
        s = self.settings.all()
        if s["brain"] == "local":
            st = ollama_status(s["local_model"])
            label = LOCAL_MODELS.get(s["local_model"], s["local_model"])
            if not st["running"]:
                problem = "the Ollama app isn't running. Open Ollama from the Start menu."
            elif not st["model_ready"]:
                problem = f"the model isn't downloaded. Run: ollama pull {s['local_model']}"
            else:
                problem = ""
            return {"kind": "local", "label": f"{label}, on this laptop", "ready": not problem, "problem": problem}
        key = api_key_status()
        label = MODELS.get(s["model"], (s["model"],))[0]
        problem = "" if key["configured"] else "add an Anthropic API key in Settings."
        return {"kind": "claude", "label": label, "ready": not problem, "problem": problem}

    def system_info(self) -> dict[str, Any]:
        return {
            "body": self.io.name,
            "has_body": self.io.has_body,
            "hearing": self.transcriber.describe(),
            "voice": self.tts.voice_name if self.tts else "loading",
            "voices": {k: v[0] for k, v in VOICES.items()},
            "models": {k: v[0] for k, v in MODELS.items()},
            "local_models": dict(LOCAL_MODELS),
            "brain": self.brain_status(),
            "api_key": api_key_status(),
            "problems": dict(self.problems),
            "bank": {k.replace("_", " "): len(v) for k, v in self.quiz.topics().items()},
        }

    def snapshot_state(self) -> dict[str, Any]:
        return {
            "status": self.status(),
            "system": self.system_info(),
            "settings": self.settings.all(),
            "stats": self.stats(),
            "transcript": list(self.transcript),
            "cards": list(self.cards),
            "materials": self.materials.list(),
            "snapshot_ts": self.snapshot_ts if self.snapshot else None,
        }
