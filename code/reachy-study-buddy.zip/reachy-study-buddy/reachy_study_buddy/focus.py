# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Focus coach (Pomodoro-style blocks and breaks) and simple countdown timers.

The coach is driven by ``tick()`` about once a second. Presence comes from face
detection: ``True`` (face seen), ``False`` (camera working, no face) or ``None``
(unknown, e.g. while the head is busy). Short gaps are ignored; only an absence
longer than ``away_after_s`` counts as being away from the desk.
"""

from __future__ import annotations

import datetime as dt
import itertools
import time
from typing import Any, Callable

from .store import Progress

Emit = Callable[[str, dict[str, Any]], None]


class FocusCoach:
    def __init__(self, progress: Progress, emit: Emit) -> None:
        self.progress = progress
        self.emit = emit
        self.phase = "idle"  # idle | focus | break
        self.paused = False
        self.goal = ""
        self.focus_min = 25
        self.break_min = 5
        self.long_break_min = 15
        self.cycles = 4
        self.cycle = 0
        self.phase_end = 0.0
        self.pause_left = 0.0
        self.long_break = False
        # presence during the current focus block
        self.away_after_s = 60
        self.absent_s = 0.0
        self.away = False
        self.away_total_s = 0.0
        self.block_started_wall = ""
        self.block_started = 0.0
        self.session_focused_min = 0.0
        self._last_tick = time.monotonic()

    # --- controls ----------------------------------------------------------------
    def start(self, focus_min: float, break_min: float, cycles: int, goal: str = "",
              long_break_min: float = 15, away_after_s: float = 60) -> dict[str, Any]:
        if self.phase != "idle":
            self.stop(announce=False)
        self.focus_min = max(1.0, min(float(focus_min), 120.0))
        self.break_min = max(1.0, min(float(break_min), 45.0))
        self.long_break_min = max(self.break_min, min(float(long_break_min), 60.0))
        self.cycles = max(1, min(int(cycles), 12))
        self.goal = (goal or "").strip()[:200]
        self.away_after_s = away_after_s
        self.cycle = 0
        self.session_focused_min = 0.0
        self._begin_focus()
        return self.status()

    def stop(self, announce: bool = True) -> dict[str, Any]:
        if self.phase == "focus":
            self._close_block(completed=False)
        summary = {"cycles_done": self.cycle - (1 if self.phase == "focus" else 0), "focused_min": round(self.session_focused_min, 1)}
        self.phase, self.paused = "idle", False
        if announce:
            self.emit("focus_stopped", summary)
        return summary

    def pause(self) -> dict[str, Any]:
        if self.phase != "idle" and not self.paused:
            self.paused = True
            self.pause_left = max(0.0, self.phase_end - time.monotonic())
            self.emit("focus_paused", self.status())
        return self.status()

    def resume(self) -> dict[str, Any]:
        if self.phase != "idle" and self.paused:
            self.paused = False
            self.phase_end = time.monotonic() + self.pause_left
            self.emit("focus_resumed", self.status())
        return self.status()

    def skip(self) -> dict[str, Any]:
        """End the current phase now (finish a block early, or cut a break short)."""
        if self.phase != "idle":
            self.paused = False
            self.phase_end = time.monotonic()
            self.tick(None)
        return self.status()

    # --- the clock -----------------------------------------------------------------
    def tick(self, face: bool | None) -> None:
        now = time.monotonic()
        dt_s = min(5.0, now - self._last_tick)
        self._last_tick = now
        if self.phase == "idle" or self.paused:
            return
        if self.phase == "focus":
            self._presence(face, dt_s)
        if now < self.phase_end:
            return
        if self.phase == "focus":
            self._close_block(completed=True)
            if self.cycle >= self.cycles:
                total = round(self.session_focused_min, 1)
                self.phase = "idle"
                self.emit("session_done", {"cycles": self.cycles, "focused_min": total, "goal": self.goal})
                return
            self.long_break = self.cycle % 4 == 0
            minutes = self.long_break_min if self.long_break else self.break_min
            self.phase = "break"
            self.phase_end = now + minutes * 60
            self.emit("break_start", {"cycle": self.cycle, "cycles": self.cycles, "minutes": minutes, "long": self.long_break})
        elif self.phase == "break":
            self._begin_focus()

    def _begin_focus(self) -> None:
        self.cycle += 1
        self.phase = "focus"
        self.paused = False
        self.phase_end = time.monotonic() + self.focus_min * 60
        self.block_started = time.monotonic()
        self.block_started_wall = dt.datetime.now().isoformat(timespec="seconds")
        self.absent_s = 0.0
        self.away = False
        self.away_total_s = 0.0
        self.emit("focus_start", {"cycle": self.cycle, "cycles": self.cycles, "minutes": self.focus_min, "goal": self.goal})

    def _presence(self, face: bool | None, dt_s: float) -> None:
        if face is True:
            if self.away:
                self.away_total_s += self.absent_s
                self.emit("returned", {"away_s": round(self.absent_s)})
            self.absent_s, self.away = 0.0, False
        elif face is False:
            self.absent_s += dt_s
            if not self.away and self.absent_s >= self.away_after_s:
                self.away = True
                self.emit("left", {"after_s": round(self.absent_s)})

    def _close_block(self, completed: bool) -> None:
        elapsed_min = (time.monotonic() - self.block_started) / 60
        away_s = self.away_total_s + (self.absent_s if self.away else 0.0)
        focused = max(0.0, elapsed_min - away_s / 60)
        self.session_focused_min += focused
        self.progress.add_focus_block({
            "start": self.block_started_wall,
            "end": dt.datetime.now().isoformat(timespec="seconds"),
            "planned_min": self.focus_min,
            "focused_min": round(focused, 1),
            "away_min": round(away_s / 60, 1),
            "goal": self.goal,
            "completed": completed,
        })

    # --- reporting ---------------------------------------------------------------
    def status(self) -> dict[str, Any]:
        left = self.pause_left if self.paused else max(0.0, self.phase_end - time.monotonic())
        return {
            "phase": self.phase,
            "paused": self.paused,
            "seconds_left": round(left) if self.phase != "idle" else 0,
            "cycle": self.cycle,
            "cycles": self.cycles,
            "focus_min": self.focus_min,
            "break_min": self.long_break_min if self.long_break else self.break_min,
            "goal": self.goal,
            "away": self.away,
            "focused_today_min": self.progress.focus_minutes_on(dt.date.today().isoformat())
            + (max(0.0, (time.monotonic() - self.block_started) / 60 - self.away_total_s / 60) if self.phase == "focus" else 0.0),
        }

    def describe(self) -> str:
        """One line for Claude's context."""
        s = self.status()
        if s["phase"] == "idle":
            return "no focus session running"
        mins = s["seconds_left"] // 60
        what = f"focus block {s['cycle']} of {s['cycles']}" if s["phase"] == "focus" else "break"
        goal = f", goal: {s['goal']}" if s["goal"] else ""
        paused = " (paused)" if s["paused"] else ""
        away = ", student is away from the desk" if s["away"] else ""
        return f"{what}{paused}, {mins} min left{goal}{away}"


class Timers:
    """Countdown timers, e.g. 'give me 6 minutes for this 6-mark question'."""

    def __init__(self, emit: Emit) -> None:
        self.emit = emit
        self._ids = itertools.count(1)
        self.items: dict[int, dict[str, Any]] = {}

    def add(self, minutes: float, label: str) -> dict[str, Any]:
        minutes = max(0.1, min(float(minutes), 180.0))
        tid = next(self._ids)
        self.items[tid] = {"id": tid, "label": (label or "timer").strip()[:80], "minutes": minutes,
                           "ends": time.monotonic() + minutes * 60}
        self.emit("timers", {"timers": self.list()})
        return self.items[tid]

    def cancel(self, tid: int | None = None) -> None:
        if tid is None:
            self.items.clear()
        else:
            self.items.pop(tid, None)
        self.emit("timers", {"timers": self.list()})

    def tick(self) -> None:
        now = time.monotonic()
        for tid, t in list(self.items.items()):
            if now >= t["ends"]:
                del self.items[tid]
                self.emit("timer_done", {"label": t["label"], "minutes": t["minutes"]})
                self.emit("timers", {"timers": self.list()})

    def list(self) -> list[dict[str, Any]]:
        now = time.monotonic()
        return [{"id": t["id"], "label": t["label"], "seconds_left": max(0, round(t["ends"] - now))} for t in self.items.values()]
