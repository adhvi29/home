# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Hearing: turns 16 kHz microphone audio into transcribed utterances.

mic chunks -> Silero VAD in 32 ms frames -> one array per utterance -> Whisper.
All of this runs on this computer. Audio is never uploaded anywhere.
"""

from __future__ import annotations

import collections
import glob
import logging
import os
import re
import site
import threading
import time
from pathlib import Path
from typing import Callable

import numpy as np

logger = logging.getLogger(__name__)

SAMPLE_RATE = 16000
FRAME = 512  # 32 ms: the frame size Silero VAD expects at 16 kHz
FRAME_MS = 32
CONTEXT = 64  # samples of the previous frame the model looks back at

# Primes Whisper to spell the robot's name and school vocabulary correctly.
WHISPER_PROMPT = "Reachy, can you help me with my IGCSE chemistry and physics worksheet?"

# Things Whisper is known to "hear" in near-silence.
HALLUCINATIONS = {
    "you", "thank you.", "thank you", "thanks.", "thanks for watching!", "thanks for watching.",
    "thank you for watching.", "thank you for watching!", "bye.", "bye!", "so", "okay.",
}


def enable_cuda_dlls() -> bool:
    """Make the NVIDIA DLLs from the ``[gpu]`` extra findable. True if any were found."""
    os.environ.setdefault("CUDA_CACHE_MAXSIZE", str(1 << 30))  # keep compiled GPU kernels between runs
    found = False
    bases = set(site.getsitepackages())
    try:
        bases.add(site.getusersitepackages())
    except AttributeError:
        pass
    for base in bases:
        for d in glob.glob(os.path.join(base, "nvidia", "*", "bin")):
            try:
                os.add_dll_directory(d)
            except (OSError, AttributeError):
                continue
            os.environ["PATH"] = d + os.pathsep + os.environ.get("PATH", "")
            found = True
    return found


class SileroVAD:
    """Streaming wrapper around the Silero VAD model that ships inside faster-whisper."""

    def __init__(self) -> None:
        import faster_whisper
        import onnxruntime as ort

        path = Path(faster_whisper.__file__).parent / "assets" / "silero_vad_v6.onnx"
        opts = ort.SessionOptions()
        opts.intra_op_num_threads = 1
        opts.inter_op_num_threads = 1
        opts.log_severity_level = 4
        self.session = ort.InferenceSession(str(path), sess_options=opts, providers=["CPUExecutionProvider"])
        self.reset()

    def reset(self) -> None:
        self.h = np.zeros((1, 1, 128), dtype=np.float32)
        self.c = np.zeros((1, 1, 128), dtype=np.float32)
        self.context = np.zeros(CONTEXT, dtype=np.float32)

    def __call__(self, frame: np.ndarray) -> float:
        """Speech probability (0 to 1) for one 512-sample frame."""
        x = np.concatenate([self.context, frame]).astype(np.float32).reshape(1, -1)
        prob, self.h, self.c = self.session.run(None, {"input": x, "h": self.h, "c": self.c})
        self.context = frame[-CONTEXT:].astype(np.float32)
        return float(np.asarray(prob).reshape(-1)[0])


class Transcriber:
    """faster-whisper, on the GPU when the CUDA libraries are installed, otherwise the CPU."""

    def __init__(self, choice: str = "auto") -> None:
        self.choice = choice
        self.model = None
        self.name = ""
        self.device = ""
        self.lock = threading.Lock()

    @property
    def ready(self) -> bool:
        return self.model is not None

    def describe(self) -> str:
        return f"{self.name} on {'GPU' if self.device == 'cuda' else 'CPU'}" if self.model else "loading"

    def load(self) -> None:
        from faster_whisper import WhisperModel

        attempts: list[tuple[str, str, str]] = []
        if enable_cuda_dlls():
            try:
                import ctranslate2

                if ctranslate2.get_cuda_device_count() > 0:
                    gpu_name = "small.en" if self.choice == "auto" else self.choice
                    attempts.append((gpu_name, "cuda", "float16"))
            except Exception as e:  # noqa: BLE001 - any failure just means "no GPU"
                logger.info("CUDA check failed: %s", e)
        cpu_name = "base.en" if self.choice in ("auto", "large-v3-turbo") else self.choice
        attempts.append((cpu_name, "cpu", "int8"))

        last_error: Exception | None = None
        for name, device, compute in attempts:
            try:
                t0 = time.time()
                kwargs = {"cpu_threads": 4} if device == "cpu" else {}
                model = WhisperModel(name, device=device, compute_type=compute, **kwargs)
                # First GPU run compiles kernels (slow once, then cached by the driver).
                warm = (np.random.default_rng(0).standard_normal(SAMPLE_RATE) * 0.01).astype(np.float32)
                list(model.transcribe(warm, language="en", beam_size=1)[0])
                self.model, self.name, self.device = model, name, device
                logger.info("Speech recognition ready: %s on %s (%.1fs)", name, device, time.time() - t0)
                return
            except Exception as e:  # noqa: BLE001 - fall through to the next option
                last_error = e
                logger.warning("Could not load Whisper %s on %s: %s", name, device, e)
        raise RuntimeError(f"Speech recognition failed to load: {last_error}")

    def transcribe(self, audio: np.ndarray, hint: str = "") -> str:
        """``hint``: words about what's being studied (chapter title, the last thing read aloud),
        which steer Whisper towards the right subject vocabulary."""
        if self.model is None:
            return ""
        prompt = f"{WHISPER_PROMPT} {hint}".strip()[-600:]
        with self.lock:
            segments, _info = self.model.transcribe(
                audio,
                language="en",
                beam_size=3 if self.device == "cuda" else 1,
                condition_on_previous_text=False,
                without_timestamps=True,
                initial_prompt=prompt,
                vad_filter=False,  # we already cut the audio with our own VAD
            )
            parts = []
            for seg in segments:
                if seg.no_speech_prob > 0.6 and seg.avg_logprob < -0.8:
                    continue
                parts.append(seg.text.strip())
        text = " ".join(parts).strip()
        if text.lower() in HALLUCINATIONS or not re.search(r"[A-Za-z0-9]", text):
            return ""
        # Whisper sometimes echoes the priming prompt back on noise.
        if text.strip().lower() in (WHISPER_PROMPT.lower(), prompt.lower()):
            return ""
        return text


class Listener(threading.Thread):
    """Reads mic audio, cuts it into utterances with VAD and hands each one to ``on_utterance``."""

    def __init__(
        self,
        read_chunk: Callable[[], np.ndarray | None],
        on_utterance: Callable[[np.ndarray], None],
        on_speech_start: Callable[[], None],
        on_level: Callable[[float], None],
        is_blocked: Callable[[], bool],
        end_of_speech_ms: Callable[[], int],
    ) -> None:
        super().__init__(name="listener", daemon=True)
        self.read_chunk = read_chunk
        self.on_utterance = on_utterance
        self.on_speech_start = on_speech_start
        self.on_level = on_level
        self.is_blocked = is_blocked
        self.end_of_speech_ms = end_of_speech_ms
        self.stop_event = threading.Event()
        self.vad = SileroVAD()

    def stop(self) -> None:
        self.stop_event.set()

    def run(self) -> None:
        pre_roll: collections.deque[np.ndarray] = collections.deque(maxlen=10)  # ~320 ms before speech starts
        buf = np.zeros(0, dtype=np.float32)
        speech: list[np.ndarray] = []
        in_speech = False
        hot = voiced = silent = 0
        was_blocked = False
        last_level = 0.0

        while not self.stop_event.is_set():
            try:
                chunk = self.read_chunk()
            except Exception as e:  # noqa: BLE001 - a flaky mic read must not kill the thread
                logger.warning("Mic read failed: %s", e)
                time.sleep(0.2)
                continue
            if chunk is None or chunk.size == 0:
                time.sleep(0.005)
                continue

            if self.is_blocked():
                # Muted, or Reachy is talking: drop audio so it never hears itself.
                if not was_blocked:
                    buf = np.zeros(0, dtype=np.float32)
                    speech, in_speech, hot, voiced, silent = [], False, 0, 0, 0
                    pre_roll.clear()
                    self.vad.reset()
                was_blocked = True
                continue
            if was_blocked:
                self.vad.reset()
                was_blocked = False

            buf = np.concatenate([buf, chunk.astype(np.float32, copy=False)])
            while buf.size >= FRAME:
                frame, buf = buf[:FRAME], buf[FRAME:]
                p = self.vad(frame)

                now = time.monotonic()
                if now - last_level > 0.1:
                    rms = float(np.sqrt(np.mean(frame * frame)) + 1e-9)
                    self.on_level(max(0.0, min(1.0, (20 * np.log10(rms) + 60) / 50)))
                    last_level = now

                if not in_speech:
                    pre_roll.append(frame)
                    hot = hot + 1 if p >= 0.5 else 0
                    if hot >= 3:  # ~100 ms of speech
                        in_speech = True
                        speech = list(pre_roll)
                        voiced, silent = hot, 0
                        self.on_speech_start()
                    continue

                speech.append(frame)
                if p >= 0.5:
                    voiced += 1
                    silent = 0
                elif p < 0.35:
                    silent += 1
                too_long = len(speech) * FRAME_MS >= 30_000
                if silent * FRAME_MS >= self.end_of_speech_ms() or too_long:
                    keep = len(speech) - max(0, silent - 8)  # trim the trailing silence, keep ~250 ms
                    audio = np.concatenate(speech[:keep])
                    in_speech, hot = False, 0
                    speech = []
                    pre_roll.clear()
                    if voiced >= 8:  # at least ~250 ms of real speech
                        self.on_utterance(audio)
