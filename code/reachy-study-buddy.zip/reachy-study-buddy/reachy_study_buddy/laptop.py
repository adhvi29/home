# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Run the study buddy without the robot: laptop mic, speakers and webcam.

    study-buddy-laptop            (after installing this package)
    python -m reachy_study_buddy.laptop --camera 1 --no-browser

Handy when Reachy isn't plugged in. Nothing here imports the Reachy Mini SDK.
"""

from __future__ import annotations

import argparse
import logging
import threading
import webbrowser

import uvicorn
from fastapi import FastAPI

from .engine import Engine
from .logs import setup_logging
from .robot_io import LaptopIO
from .store import Progress, Settings
from .web import Hub, install

logger = logging.getLogger("reachy_study_buddy")


def main() -> None:
    run()


def run(argv: list[str] | None = None) -> bool:
    """Run until turned off. Returns True if a restart was asked for."""
    parser = argparse.ArgumentParser(description="Reachy Study Buddy, laptop-only mode")
    parser.add_argument("--port", type=int, default=8042)
    parser.add_argument("--camera", type=int, default=None, help="camera index (default: Reachy's camera if plugged in, else 0)")
    parser.add_argument("--laptop-devices", action="store_true", help="use the laptop's mic/speaker/webcam even if Reachy is plugged in")
    parser.add_argument("--no-browser", action="store_true", help="don't open the page automatically")
    parser.add_argument("--no-audio", action="store_true", help="silent test mode: no microphone, no sound")
    parser.add_argument("--webcam-presence", action="store_true",
                        help="during focus blocks, use the webcam to notice when you leave your desk")
    parser.add_argument("--note", default="", help=argparse.SUPPRESS)  # something to say after hello
    args = parser.parse_args(argv)
    setup_logging()

    hub = Hub()
    ref: dict = {"engine": None}
    app = FastAPI(title="Reachy Study Buddy")
    install(app, ref, hub, serve_static=True)
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=args.port, log_level="warning"))
    web = threading.Thread(target=server.run, name="web", daemon=True)
    web.start()

    body = LaptopIO(args.camera, audio=not args.no_audio, webcam_presence=args.webcam_presence,
                    use_reachy_devices=not args.laptop_devices)
    stop = threading.Event()
    engine = Engine(body, Settings(), Progress(), hub.broadcast, on_turn_off=stop.set, startup_note=args.note)
    ref["engine"] = engine
    url = f"http://127.0.0.1:{args.port}"
    logger.info("Study Buddy page: %s  (Ctrl+C to quit)", url)
    if not args.no_browser:
        threading.Timer(1.5, lambda: webbrowser.open(url)).start()
    try:
        engine.run(stop)
    except KeyboardInterrupt:
        engine.shutdown()
    finally:
        server.should_exit = True
        web.join(timeout=5)  # free the port before any restart
    logger.info("Study Buddy is off.")
    return engine.restart_requested


if __name__ == "__main__":
    main()
