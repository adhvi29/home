# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Local brain: the same conversation and tools, run by a model on this laptop through Ollama.

Free, offline, and nothing leaves the computer. Ollama serves the model at
http://127.0.0.1:11434. Tool calls, images from the camera and uploaded worksheets
work the same way as with Claude, translated to Ollama's chat format.
"""

from __future__ import annotations

import base64
import io
import json
import logging
import threading
import urllib.error
import urllib.request
from typing import Any, Callable

from .brain import Cancelled, TurnResult
from .prompts import build_system_prompt
from .store import Settings
from .tools import TOOLS, ToolBox
from .voice import SentenceChunker

logger = logging.getLogger(__name__)

OLLAMA_URL = "http://127.0.0.1:11434"
MAX_TOOL_ROUNDS = 6
MAX_HISTORY_MESSAGES = 40
NUM_CTX = 24576

OLLAMA_TOOLS = [
    {"type": "function", "function": {"name": t["name"], "description": t["description"], "parameters": t["input_schema"]}}
    for t in TOOLS
]

LOCAL_EXTRA = """

Extra rules for you (you run on the student's laptop, so be brief and careful)
- Start every reply with a short spoken sentence (under ten words) before anything else, including tool calls, so \
the student hears you straight away.
- Spoken replies: under 40 words, plain sentences. Never use markdown, bullet points, dashes as lists or headings in \
what you say. Working and formulas go on screen with show_on_screen.
- One step at a time. When the student gets one part right, praise it and ask them to try the next part. Never \
give the answer to a part they haven't attempted yet, unless they ask you to.
- In a quiz, never hint at the answer when you ask the question. Wait for their answer first.
- Taking photos with your camera is fine: the student set you up to see their work.
- Use your tools by calling them, never by describing a call in text.
"""


def _get(path: str, timeout: float = 2.0) -> Any:
    with urllib.request.urlopen(f"{OLLAMA_URL}{path}", timeout=timeout) as resp:
        return json.loads(resp.read())


def ollama_status(model: str) -> dict[str, Any]:
    """Is Ollama running, and is the chosen model downloaded?"""
    try:
        tags = _get("/api/tags")
    except (urllib.error.URLError, OSError, ValueError):
        return {"running": False, "model_ready": False, "installed": []}
    installed = [m.get("name", "") for m in tags.get("models", [])]
    ready = any(name == model or name == f"{model}:latest" for name in installed)
    return {"running": True, "model_ready": ready, "installed": installed}


def pdf_to_text(b64: str, max_chars: int = 60_000) -> str:
    try:
        from pypdf import PdfReader

        reader = PdfReader(io.BytesIO(base64.b64decode(b64)))
        text = "\n".join((page.extract_text() or "") for page in reader.pages)
    except Exception as e:  # noqa: BLE001
        logger.warning("PDF text extraction failed: %s", e)
        return "(Couldn't read this PDF. Ask the student to upload a photo or screenshot of the page instead.)"
    text = text.strip()
    if len(text) < 40:
        return "(This PDF has no readable text, probably a scan. Ask the student to upload a photo or screenshot instead.)"
    return text[:max_chars]


def to_ollama_message(content: list[dict[str, Any]], role: str = "user") -> dict[str, Any]:
    """Anthropic-style content blocks -> one Ollama chat message."""
    texts: list[str] = []
    images: list[str] = []
    for block in content:
        kind = block.get("type")
        if kind == "text":
            texts.append(block["text"])
        elif kind == "image":
            images.append(block["source"]["data"])
        elif kind == "document":
            src = block["source"]
            title = block.get("title", "document")
            if src.get("type") == "text":
                texts.append(f"[Document: {title}. {block.get('context', '')}]\n{src['data']}")
            elif src.get("media_type") == "application/pdf":
                texts.append(f"[PDF: {title}]\n{pdf_to_text(src['data'])}")
    msg: dict[str, Any] = {"role": role, "content": "\n\n".join(texts)}
    if images:
        msg["images"] = images
    return msg


class LocalBrain:
    def __init__(self, settings: Settings, toolbox: ToolBox, speak: Callable[[str], None],
                 emit: Callable[[str, dict[str, Any]], None]) -> None:
        self.settings = settings
        self.toolbox = toolbox
        self.speak = speak
        self.emit = emit
        self.messages: list[dict[str, Any]] = []
        self.lock = threading.Lock()
        self._turn_start = 0

    def reset(self) -> None:
        with self.lock:
            self.messages = []
        self.toolbox.reset()

    def rollback_last_turn(self) -> None:
        with self.lock:
            del self.messages[self._turn_start:]

    def unload(self) -> None:
        """Free the GPU memory now instead of waiting for Ollama's keep-alive to run out."""
        body = {"model": self.settings.get("local_model"), "keep_alive": 0}
        req = urllib.request.Request(f"{OLLAMA_URL}/api/generate", data=json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                resp.read()
        except (urllib.error.URLError, OSError) as e:
            logger.info("Couldn't unload the local model: %s", e)

    def warm_up(self) -> bool:
        """Load the model onto the GPU and pre-read the system prompt, so the first real reply is quick.
        Includes a tiny image so the vision part is ready too."""
        model = self.settings.get("local_model")
        if not ollama_status(model)["model_ready"]:
            return False
        from PIL import Image

        buf = io.BytesIO()
        Image.new("RGB", (64, 64), "white").save(buf, format="JPEG")
        body = {
            "model": model,
            "messages": [self._system(), {"role": "user", "content": "Reply with OK.", "images": [base64.b64encode(buf.getvalue()).decode()]}],
            "tools": OLLAMA_TOOLS,
            "stream": False,
            "think": False,
            "options": {"num_ctx": NUM_CTX, "num_predict": 2},
            "keep_alive": "2h",
        }
        req = urllib.request.Request(f"{OLLAMA_URL}/api/chat", data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=300) as resp:
                resp.read()
            return True
        except (urllib.error.URLError, OSError) as e:
            logger.warning("Local brain warm-up failed: %s", e)
            return False

    def _system(self) -> dict[str, str]:
        s = self.settings.all()
        text = build_system_prompt(s["student_name"], s["subjects"], s["focus_minutes"], s["break_minutes"]) + LOCAL_EXTRA
        return {"role": "system", "content": text}

    def _trim(self) -> None:
        """Small models have small memories: keep the start (with any chapter) and the latest turns."""
        if len(self.messages) <= MAX_HISTORY_MESSAGES:
            return
        head = self.messages[:1]
        tail = self.messages[-(MAX_HISTORY_MESSAGES - 1):]
        while tail and tail[0]["role"] != "user":  # never start on a tool result or an assistant reply
            tail = tail[1:]
        self.messages = head + tail

    def run_turn(self, content: list[dict[str, Any]], cancel: threading.Event) -> TurnResult:
        result = TurnResult()
        model = self.settings.get("local_model")
        status = ollama_status(model)
        if not status["running"]:
            msg = "My brain app, Ollama, isn't running. Open Ollama from the Start menu, then ask me again."
            self.speak(msg)
            return TurnResult(spoken=msg, error="ollama_offline")
        if not status["model_ready"]:
            msg = f"My brain model isn't downloaded yet. In a terminal, run: ollama pull {model}."
            self.speak(msg)
            return TurnResult(spoken=msg, error="model_missing")

        with self.lock:
            self._turn_start = len(self.messages)
            self.messages.append(to_ollama_message(content))
            try:
                for _ in range(MAX_TOOL_ROUNDS):
                    reply, calls = self._stream(model, cancel, result)
                    assistant: dict[str, Any] = {"role": "assistant", "content": reply}
                    if calls:
                        assistant["tool_calls"] = calls
                    self.messages.append(assistant)
                    if not calls:
                        break
                    for call in calls:
                        fn = call.get("function", {})
                        name = fn.get("name", "")
                        args = fn.get("arguments") or {}
                        if isinstance(args, str):
                            try:
                                args = json.loads(args)
                            except ValueError:
                                args = {"_unparseable": args}
                        if cancel.is_set():
                            self.messages.append({"role": "tool", "tool_name": name, "content": "Not run: the student interrupted you."})
                            continue
                        res = self.toolbox.run(name, args, f"local_{len(self.messages)}")
                        text, images = _flatten_result(res)
                        self.messages.append({"role": "tool", "tool_name": name, "content": text})
                        if images:
                            self.messages.append({"role": "user", "content": "Here is the photo you just took with your camera.", "images": images})
                    if cancel.is_set():
                        result.cancelled = True
                        break
            except Cancelled:
                result.cancelled = True
            except (urllib.error.URLError, OSError, RuntimeError, ValueError) as e:
                logger.warning("Local brain failed: %s", e)
                del self.messages[self._turn_start:]
                msg = "My brain hiccupped. Check that Ollama is running, then try again."
                self.speak(msg)
                result.error, result.spoken = "local_error", msg
            self._trim()
        return result

    def _stream(self, model: str, cancel: threading.Event, result: TurnResult) -> tuple[str, list[dict[str, Any]]]:
        body = {
            "model": model,
            "messages": [self._system(), *self.messages],
            "tools": OLLAMA_TOOLS,
            "stream": True,
            "think": self.settings.get("effort") != "low",
            "options": {"num_ctx": NUM_CTX, "temperature": 0.6},
            "keep_alive": "2h",
        }
        req = urllib.request.Request(f"{OLLAMA_URL}/api/chat", data=json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json"})
        chunker = SentenceChunker()
        text = ""
        calls: list[dict[str, Any]] = []
        thinking_sent = False
        with urllib.request.urlopen(req, timeout=180) as resp:
            for line in resp:
                if cancel.is_set():
                    raise Cancelled
                if not line.strip():
                    continue
                chunk = json.loads(line)
                if chunk.get("error"):
                    raise RuntimeError(chunk["error"])
                msg = chunk.get("message") or {}
                if msg.get("thinking") and not thinking_sent:
                    self.emit("thinking", {})
                    thinking_sent = True
                delta = msg.get("content") or ""
                if delta:
                    text += delta
                    self.emit("reply_delta", {"text": delta})
                    for sentence in chunker.feed(delta):
                        self.speak(sentence)
                        result.spoken += sentence + " "
                calls.extend(msg.get("tool_calls") or [])
                if chunk.get("done"):
                    break
        rest = chunker.flush()
        if rest:
            self.speak(rest)
            result.spoken += rest
        return text, calls


def _flatten_result(res: dict[str, Any]) -> tuple[str, list[str]]:
    content = res.get("content")
    if isinstance(content, str):
        text = content
        images: list[str] = []
    else:
        text = "\n".join(b.get("text", "") for b in content if b.get("type") == "text")
        images = [b["source"]["data"] for b in content if b.get("type") == "image"]
    if res.get("is_error"):
        text = f"ERROR: {text}"
    return text, images
