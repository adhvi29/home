# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Logging to the console and to a small rotating file in the app-data folder."""

from __future__ import annotations

import logging
import logging.handlers

from .store import DATA_DIR

LOG_FILE = DATA_DIR / "logs" / "study_buddy.log"


def setup_logging(level: int = logging.INFO) -> None:
    root = logging.getLogger()
    if any(getattr(h, "_study_buddy", False) for h in root.handlers):
        return
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s", "%H:%M:%S")
    file_handler = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    console = logging.StreamHandler()
    for h in (file_handler, console):
        h.setFormatter(fmt)
        h._study_buddy = True  # type: ignore[attr-defined]
        root.addHandler(h)
    root.setLevel(level)
    for noisy in ("httpx", "httpx2", "httpcore", "uvicorn.access", "faster_whisper"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
