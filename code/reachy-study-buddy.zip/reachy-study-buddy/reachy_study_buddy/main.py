# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Reachy Study Buddy as a Reachy Mini app.

Normally started by ``study-buddy-robot`` (reachy_study_buddy/robot.py), which first runs
the Reachy Mini daemon with --no-media. The daemon can also start it as an app. Motors go
through the SDK; the camera, mic and speaker are used directly as USB devices, so
GStreamer is never needed. The study page is at http://127.0.0.1:8042.
"""

import threading

from .nogi import use_gi_stub

use_gi_stub()  # must come before the Reachy Mini SDK is imported

from reachy_mini import ReachyMini, ReachyMiniApp  # noqa: E402

from .logs import setup_logging  # noqa: E402
from .store import Progress, Settings  # noqa: E402
from .web import Hub, install  # noqa: E402


class ReachyStudyBuddy(ReachyMiniApp):
    # Only this laptop can open the page; nobody else on the Wi-Fi.
    custom_app_url: str | None = "http://127.0.0.1:8042"
    request_media_backend: str | None = "no_media"  # camera, mic and speaker are handled by Study Buddy

    def __init__(self, *args, **kwargs) -> None:  # noqa: ANN002, ANN003
        super().__init__(*args, **kwargs)
        setup_logging()
        self.hub = Hub()
        self.engine_ref: dict = {"engine": None}
        # Routes go on before the web server starts; the engine is plugged in once the robot is connected.
        if self.settings_app is not None:
            install(self.settings_app, self.engine_ref, self.hub, serve_static=False)

    def run(self, reachy_mini: ReachyMini, stop_event: threading.Event) -> None:
        from .engine import Engine
        from .robot_io import LaptopIO, ReachyIO

        body = ReachyIO(reachy_mini, LaptopIO(use_reachy_devices=True))
        engine = Engine(body, Settings(), Progress(), self.hub.broadcast, on_turn_off=stop_event.set)
        self.engine_ref["engine"] = engine
        engine.run(stop_event)


if __name__ == "__main__":
    app = ReachyStudyBuddy()
    try:
        app.wrapped_run()
    except KeyboardInterrupt:
        app.stop()
