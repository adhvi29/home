# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Study materials: chapters the student reads aloud to Reachy, kept as text.

Reading mode appends each transcribed utterance to an open material. When the
student finishes, the material is saved and becomes the "active" one, which new
conversations include automatically, so Reachy can quiz and explain from exactly
what was read.
"""

from __future__ import annotations

import datetime as dt
import json
import os
import re
import threading
import uuid
from pathlib import Path
from typing import Any

from .store import DATA_DIR

MAX_WORDS = 40_000  # about three long chapters; more than that is almost certainly a mistake


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")[:40] or "chapter"


class Materials:
    def __init__(self, folder: Path | None = None) -> None:
        self.folder = folder or DATA_DIR / "materials"
        self.folder.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.index_path = self.folder / "index.json"
        try:
            self.index: dict[str, Any] = json.loads(self.index_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.index = {"items": {}, "active": None}
        self.recording: dict[str, Any] | None = None  # material being read right now

    # --- persistence -----------------------------------------------------------------
    def _save_index(self) -> None:
        tmp = self.index_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.index, indent=1, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, self.index_path)

    def _text_path(self, mid: str) -> Path:
        return self.folder / f"{mid}.txt"

    # --- reading mode ----------------------------------------------------------------
    def start(self, title: str = "", subject: str = "") -> dict[str, Any]:
        with self.lock:
            if self.recording:
                self.finish()
            now = dt.datetime.now()
            title = title.strip()[:120] or f"Reading {now:%d %b %H:%M}"
            mid = f"{now:%Y%m%d-%H%M%S}-{_slug(title)}-{uuid.uuid4().hex[:4]}"
            self.recording = {"id": mid, "title": title, "subject": subject.strip()[:40], "started": now.isoformat(timespec="seconds"),
                              "parts": [], "words": 0}
            return self.recording_status()

    def add(self, text: str) -> int:
        """Append one transcribed utterance. Returns the word count so far."""
        with self.lock:
            if not self.recording or not text.strip():
                return self.recording["words"] if self.recording else 0
            if self.recording["words"] >= MAX_WORDS:
                return self.recording["words"]
            self.recording["parts"].append(text.strip())
            self.recording["words"] += len(text.split())
            # Save as we go, so nothing is lost if the app is closed mid-chapter.
            self._text_path(self.recording["id"]).write_text(self.text_so_far(), encoding="utf-8")
            return self.recording["words"]

    def text_so_far(self) -> str:
        with self.lock:
            return " ".join(self.recording["parts"]) if self.recording else ""

    def recording_status(self) -> dict[str, Any] | None:
        with self.lock:
            if not self.recording:
                return None
            r = self.recording
            return {"id": r["id"], "title": r["title"], "subject": r["subject"], "words": r["words"],
                    "last": r["parts"][-1] if r["parts"] else ""}

    def finish(self, title: str = "", subject: str = "") -> dict[str, Any] | None:
        """Stop reading mode and save. Returns the saved item, or None if nothing was read."""
        with self.lock:
            r, self.recording = self.recording, None
            if not r:
                return None
            if not r["parts"]:
                self._text_path(r["id"]).unlink(missing_ok=True)
                return None
            text = " ".join(r["parts"])
            self._text_path(r["id"]).write_text(text, encoding="utf-8")
            item = {"id": r["id"], "title": (title.strip() or r["title"])[:120], "subject": (subject.strip() or r["subject"])[:40],
                    "words": len(text.split()), "created": r["started"], "source": "read aloud"}
            self.index["items"][item["id"]] = item
            self.index["active"] = item["id"]
            self._save_index()
            return item

    # --- library ---------------------------------------------------------------------
    def list(self) -> list[dict[str, Any]]:
        with self.lock:
            items = sorted(self.index["items"].values(), key=lambda i: i["created"], reverse=True)
            return [dict(i, active=(i["id"] == self.index.get("active"))) for i in items]

    def get(self, mid: str) -> dict[str, Any] | None:
        with self.lock:
            item = self.index["items"].get(mid)
            if not item:
                return None
            try:
                text = self._text_path(mid).read_text(encoding="utf-8")
            except OSError:
                text = ""
            return dict(item, text=text)

    def find(self, query: str) -> dict[str, Any] | None:
        """Best match for a title the student says out loud ('the mole chapter')."""
        words = set(re.findall(r"[a-z0-9]+", query.lower())) - {"the", "chapter", "on", "about", "my", "a", "of"}
        best, best_score = None, 0
        for item in self.list():
            hay = set(re.findall(r"[a-z0-9]+", f"{item['title']} {item['subject']}".lower()))
            score = len(words & hay)
            if score > best_score:
                best, best_score = item, score
        return self.get(best["id"]) if best else None

    def active(self) -> dict[str, Any] | None:
        with self.lock:
            mid = self.index.get("active")
        return self.get(mid) if mid else None

    def set_active(self, mid: str | None) -> None:
        with self.lock:
            if mid is None or mid in self.index["items"]:
                self.index["active"] = mid
                self._save_index()

    def rename(self, mid: str, title: str, subject: str | None = None) -> None:
        with self.lock:
            item = self.index["items"].get(mid)
            if item:
                item["title"] = title.strip()[:120] or item["title"]
                if subject is not None:
                    item["subject"] = subject.strip()[:40]
                self._save_index()

    def update_text(self, mid: str, text: str) -> None:
        """The student fixed transcription mistakes on the laptop page."""
        with self.lock:
            item = self.index["items"].get(mid)
            if item:
                text = text.strip()[: MAX_WORDS * 12]
                self._text_path(mid).write_text(text, encoding="utf-8")
                item["words"] = len(text.split())
                self._save_index()

    def delete(self, mid: str) -> None:
        with self.lock:
            self.index["items"].pop(mid, None)
            if self.index.get("active") == mid:
                self.index["active"] = None
            self._text_path(mid).unlink(missing_ok=True)
            self._save_index()
