# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Motion: one 50 Hz loop owns every ``set_target`` call to Reachy Mini (head, antennas and base).

Layers, bottom to top:
  mode pose      idle, listening, thinking, speaking, reading, focus, break, standby
  looking at you the camera's face position steers the head; the base turns part of the way
  life           breathing, antenna sway, and glances around the room when nobody's there
  speech         the head bobs and the antennas flick with the loudness of Reachy's own voice
  gesture        nod, shake, celebrate, dance... using head, antennas and base
  hold           look at the desk / straight ahead for the camera (overrides everything)
Everything eases in and out and stays well inside the robot's limits.
"""

from __future__ import annotations

import collections
import logging
import math
import random
import threading
import time
from typing import Callable

import numpy as np

logger = logging.getLogger(__name__)

# Pose parameters: x, y, z in mm; roll, pitch, yaw in degrees (positive pitch looks down, positive yaw
# turns left; yaw is the head's direction in the room); antennas [right, left] in radians; body in degrees.
Pose = dict[str, float]
KEYS = ("x", "y", "z", "roll", "pitch", "yaw", "ar", "al", "body")
NEUTRAL_ANT = (-0.17, 0.17)  # a little off vertical, where the antenna motors don't buzz
SPEECH_RATE = 50  # envelope samples per second
AUDIO_RATE = 16000

#                    z   roll pitch  yaw     ar     al   track  body: how much the base turns to face you
MODES: dict[str, dict[str, float]] = {
    "idle":      dict(z=0, roll=0, pitch=0, yaw=0, ar=-0.17, al=0.17, track=1.0, body=0.6),
    "listening": dict(z=3, roll=7, pitch=-3, yaw=0, ar=0.20, al=-0.20, track=1.0, body=0.6),
    "thinking":  dict(z=2, roll=-8, pitch=-9, yaw=12, ar=0.10, al=0.35, track=0.4, body=0.5),
    "speaking":  dict(z=1, roll=0, pitch=0, yaw=0, ar=-0.10, al=0.10, track=1.0, body=0.6),
    "reading":   dict(z=0, roll=4, pitch=6, yaw=0, ar=0.05, al=-0.05, track=0.8, body=0.5),
    "focus":     dict(z=-3, roll=0, pitch=12, yaw=0, ar=-0.40, al=0.40, track=0.3, body=0.4),
    "break":     dict(z=2, roll=0, pitch=-2, yaw=0, ar=-0.17, al=0.17, track=1.0, body=0.6),
    "standby":   dict(z=-4, roll=0, pitch=8, yaw=0, ar=-0.55, al=0.55, track=0.6, body=0.4),
}
AIM_DEADBAND = 1.5  # degrees: once it's looking at you, small detector jitter doesn't move the head
FRAME_DELAY = 0.12  # seconds between where the head was and when we see the frame (motors + camera)
HOLDS: dict[str, Pose] = {
    "desk": dict(x=0, y=0, z=-6, roll=0, pitch=34, yaw=0, ar=-0.17, al=0.17, body=0),
    "ahead": dict(x=0, y=0, z=4, roll=0, pitch=-4, yaw=0, ar=-0.17, al=0.17, body=0),
}
POINTS: dict[str, tuple[float, float, float]] = {
    # direction: (head yaw, head pitch, base yaw) in degrees
    "left": (45, 0, 30), "right": (-45, 0, -30), "up": (0, -22, 0), "down": (0, 28, 0),
    "up_left": (35, -18, 20), "up_right": (-35, -18, -20), "down_left": (35, 22, 20), "down_right": (-35, 22, -20),
    "center": (0, 0, 0),
}
LIMITS = {"x": (-10, 10), "y": (-10, 10), "z": (-12, 15), "roll": (-25, 25), "pitch": (-25, 38), "yaw": (-100, 100),
          "ar": (-1.3, 1.3), "al": (-1.3, 1.3), "body": (-100, 100)}
MAX_HEAD_VS_BODY = 55.0  # the head may only twist this far from the base (hardware limit is 65)


def _env(t: float, dur: float) -> float:
    """Smooth 0 -> 1 -> 0 envelope so gestures start and end without a jolt."""
    if t <= 0 or t >= dur:
        return 0.0
    return math.sin(math.pi * t / dur) ** 0.6


def _gesture(name: str, t: float) -> tuple[Pose, float]:
    """Offsets for gesture ``name`` at time t, and the gesture's duration."""
    s = math.sin
    tau = 2 * math.pi
    g: Pose = {}
    if name == "nod":
        dur = 1.3
        g = {"pitch": 11 * s(tau * 2.2 * t) * _env(t, dur)}
    elif name == "small_nod":
        dur = 0.9
        g = {"pitch": 5 * s(tau * 1.1 * t) * _env(t, dur)}
    elif name == "shake":
        dur = 1.4
        e = _env(t, dur)
        g = {"yaw": 13 * s(tau * 2.0 * t) * e, "roll": 3 * s(tau * 2.0 * t) * e, "body": 4 * s(tau * 2.0 * t) * e}
    elif name == "celebrate":
        dur = 2.4
        e = _env(t, dur)
        g = {"z": 7 * abs(s(tau * 2.0 * t)) * e, "roll": 9 * s(tau * 1.5 * t) * e, "body": 14 * s(tau * 1.2 * t) * e,
             "ar": 0.9 * s(tau * 3.0 * t) * e, "al": -0.9 * s(tau * 3.0 * t) * e}
    elif name == "dance":
        dur = 4.0
        e = _env(t, dur)
        g = {"z": 6 * abs(s(tau * 1.8 * t)) * e, "roll": 10 * s(tau * 0.9 * t) * e, "yaw": 12 * s(tau * 0.9 * t + 1) * e,
             "body": 28 * s(tau * 0.45 * t) * e, "ar": 0.8 * s(tau * 1.8 * t) * e, "al": 0.8 * s(tau * 1.8 * t + math.pi) * e}
    elif name == "excited":  # antennas wag together like a dog's tail
        dur = 2.2
        e = _env(t, dur)
        wag = 0.55 * s(tau * 3.5 * t) * e
        g = {"z": 5 * abs(s(tau * 3.5 * t)) * e, "body": 6 * s(tau * 1.75 * t) * e, "roll": 4 * s(tau * 1.75 * t) * e,
             "ar": 0.35 * e + wag, "al": -0.35 * e + wag}
    elif name == "happy":  # a relaxed wag and a sway
        dur = 2.2
        e = _env(t, dur)
        wag = 0.4 * s(tau * 2.0 * t) * e
        g = {"roll": 7 * s(tau * 1.0 * t) * e, "z": 3 * e, "ar": 0.2 * e + wag, "al": -0.2 * e + wag}
    elif name == "angry":  # antennas shoot up stiff and tremble, head lowered
        dur = 2.0
        e = _env(t, dur)
        tremble = 0.07 * s(tau * 12 * t) * e
        g = {"pitch": 7 * e, "z": -3 * e, "yaw": 3 * s(tau * 6 * t) * e,
             "ar": 0.28 * e + tremble, "al": -0.28 * e - tremble}
    elif name == "confused":  # out-of-sync twitches and a head tilt
        dur = 2.0
        e = _env(t, dur)
        g = {"roll": -12 * e, "yaw": 6 * s(tau * 1.2 * t) * e,
             "ar": 0.4 * s(tau * 2.3 * t) * e, "al": -0.25 * e + 0.3 * s(tau * 3.1 * t + 1) * e}
    elif name == "proud":  # chin up, antennas high
        dur = 2.0
        e = _env(t, dur)
        g = {"pitch": -10 * e, "z": 6 * e, "ar": 0.3 * e, "al": -0.3 * e}
    elif name == "shy":  # fold down and look away
        dur = 2.4
        e = _env(t, dur)
        g = {"yaw": 25 * e, "pitch": 10 * e, "roll": 6 * e, "body": 10 * e, "ar": -0.8 * e, "al": 0.8 * e}
    elif name == "love":  # slow wave and a happy tilt
        dur = 2.6
        e = _env(t, dur)
        g = {"roll": 10 * s(tau * 0.6 * t) * e, "z": 3 * abs(s(tau * 1.2 * t)) * e,
             "ar": 0.35 * s(tau * 1.2 * t) * e, "al": -0.35 * s(tau * 1.2 * t + 0.9) * e}
    elif name == "sleepy":  # droop and a slow nod
        dur = 3.0
        e = _env(t, dur)
        g = {"pitch": 14 * e + 4 * s(tau * 0.5 * t) * e, "z": -5 * e, "ar": -0.9 * e, "al": 0.9 * e}
    elif name == "think":
        dur = 2.2
        e = _env(t, dur)
        g = {"roll": 10 * e, "pitch": -10 * e, "yaw": 15 * e, "body": 6 * e,
             "ar": 0.3 * s(tau * 0.8 * t) * e, "al": 0.3 * s(tau * 0.8 * t + 1.5) * e}
    elif name == "curious":  # one antenna up, one tilted, head tilt
        dur = 1.8
        e = _env(t, dur)
        g = {"roll": 16 * e, "z": 4 * e, "ar": 0.3 * e, "al": 0.45 * e}
    elif name == "surprised":  # both antennas snap up
        dur = 1.3
        e = min(1.0, t / 0.12) * _env(t, dur) ** 0.3 if t < dur else 0.0
        g = {"pitch": -9 * e, "z": 8 * e, "ar": 0.4 * e, "al": -0.4 * e}
    elif name == "sad":  # slow droop, head down, turning a little away
        dur = 2.8
        e = _env(t, dur)
        g = {"pitch": 16 * e, "z": -5 * e, "yaw": 8 * e, "body": 6 * e, "ar": -1.0 * e, "al": 1.0 * e}
    elif name == "wiggle":
        dur = 1.8
        e = _env(t, dur)
        g = {"yaw": 10 * s(tau * 1.6 * t) * e, "body": 10 * s(tau * 1.2 * t) * e,
             "ar": 0.5 * s(tau * 3.2 * t) * e, "al": 0.5 * s(tau * 3.2 * t + math.pi) * e}
    elif name == "bow":
        dur = 2.0
        g = {"pitch": 20 * _env(t, dur), "z": -4 * _env(t, dur)}
    elif name == "search":
        dur = 4.0
        e = _env(t, dur)
        g = {"yaw": 30 * s(tau * 0.5 * t) * e, "body": 35 * s(tau * 0.25 * t) * e, "pitch": -4 * e}
    elif name == "stretch":
        dur = 4.5
        e = _env(t, dur)
        g = {"roll": 14 * s(tau * 0.45 * t) * e, "pitch": -14 * e, "z": 10 * e, "body": 20 * s(tau * 0.3 * t) * e,
             "ar": 0.6 * e, "al": -0.6 * e}
    elif name == "perk":
        dur = 0.8
        e = _env(t, dur)
        g = {"z": 5 * e, "ar": 0.35 * e, "al": -0.35 * e}
    else:
        dur = 0.0
    return g, dur


def speech_envelope(audio: np.ndarray) -> np.ndarray:
    """Loudness of a clip, 50 values a second, scaled 0..~1."""
    hop = AUDIO_RATE // SPEECH_RATE
    n = audio.size // hop
    if n == 0:
        return np.zeros(0, dtype=np.float32)
    rms = np.sqrt(np.mean(audio[: n * hop].reshape(n, hop) ** 2, axis=1))
    ref = float(np.percentile(rms, 90)) or 1e-6
    env = np.clip(rms / ref, 0.0, 1.2)
    return np.convolve(env, np.ones(3) / 3, mode="same").astype(np.float32)


class MotionController(threading.Thread):
    RATE_HZ = 50

    def __init__(self, mini: object, create_head_pose: Callable[..., np.ndarray] | None = None) -> None:
        super().__init__(name="motion", daemon=True)
        if create_head_pose is None:
            from reachy_mini.utils import create_head_pose
        self._create_head_pose = create_head_pose
        self.mini = mini
        self.stop_event = threading.Event()
        self.lock = threading.Lock()
        self.mode = "idle"
        self.gesture_name: str | None = None
        self.gesture_start = 0.0
        self.gesture_dur = 0.0
        self.hold_name: str | None = None
        self.current: Pose = {k: 0.0 for k in KEYS}
        self.current["ar"], self.current["al"] = NEUTRAL_ANT
        self.commanded_ant = list(NEUTRAL_ANT)
        # looking at the student
        self._face: tuple[float, float, float] | None = None  # yaw, pitch offsets (deg), time seen
        self.aim_yaw = 0.0
        self.aim_pitch = 0.0
        self._aim_goal = (0.0, 0.0)
        self._history: collections.deque[tuple[float, float, float]] = collections.deque(maxlen=150)  # t, yaw, pitch
        self._point: tuple[float, float, float, float] | None = None  # yaw, pitch, body, until
        self._next_twitch = time.monotonic() + 5
        self._twitch_start = -10.0
        self._twitch_side = 0
        self._glance_goal = (0.0, 0.0)
        self._glance_until = 0.0
        self._next_glance = time.monotonic() + 6
        # talking
        self._speech: list[tuple[float, np.ndarray]] = []
        # antennas as buttons
        self._touch_hits = 0
        self._touch_quiet_until = 0.0
        self._touched = False
        self._errors = 0
        self._t0 = time.monotonic()

    # --- commands from other threads ------------------------------------------------
    def set_mode(self, mode: str) -> None:
        if mode in MODES:
            with self.lock:
                self.mode = mode

    def gesture(self, name: str) -> float:
        _, dur = _gesture(name, 0.0)
        if dur <= 0:
            return 0.0
        with self.lock:
            self.gesture_name, self.gesture_start, self.gesture_dur = name, time.monotonic(), dur
            if name not in ("nod", "small_nod", "shake", "bow", "search"):
                self._touch_quiet_until = time.monotonic() + dur + 0.6  # antenna-heavy: not a touch
        return dur

    def _twitch(self, now: float) -> tuple[float, float]:
        """Now and then one antenna flicks, like an animal's ear."""
        if now >= self._next_twitch:
            self._twitch_side = random.choice((0, 1))
            self._twitch_start = now
            self._next_twitch = now + random.uniform(6, 14)
            self._touch_quiet_until = max(self._touch_quiet_until, now + 0.8)
        dt = now - self._twitch_start
        if dt > 0.35:
            return 0.0, 0.0
        flick = 0.28 * math.sin(math.pi * dt / 0.35)
        return (flick, 0.0) if self._twitch_side == 0 else (0.0, -flick)

    def hold(self, name: str | None) -> None:
        """Point the head for the camera ('desk' / 'ahead'), or None to go back to normal."""
        with self.lock:
            self.hold_name = name if name in HOLDS else None

    def point(self, direction: str, seconds: float = 4.0) -> None:
        """Look somewhere on request ('look up', 'turn left') for a few seconds, then back to normal."""
        if direction in POINTS:
            with self.lock:
                self._point = (*POINTS[direction], time.monotonic() + max(1.0, min(seconds, 15.0)))

    def set_face_angles(self, yaw_offset: float, pitch_offset: float, captured_at: float) -> None:
        """The face is this many degrees away from where the camera pointed when the frame was captured.
        Called by the face follower ~15 times a second."""
        with self.lock:
            then = captured_at - FRAME_DELAY
            yaw_then, pitch_then = self.current["yaw"], self.current["pitch"]
            for t, yaw, pitch in reversed(self._history):  # where the head was pointing back then
                if t <= then:
                    yaw_then, pitch_then = yaw, pitch
                    break
            goal = (max(-90.0, min(90.0, yaw_then + yaw_offset)), max(-20.0, min(30.0, pitch_then + pitch_offset)))
            old = self._aim_goal
            if self._face is not None and abs(goal[0] - old[0]) < AIM_DEADBAND and abs(goal[1] - old[1]) < AIM_DEADBAND:
                goal = old  # close enough: hold still instead of chasing detector jitter
            else:
                goal = (old[0] + (goal[0] - old[0]) * 0.7, old[1] + (goal[1] - old[1]) * 0.7) if self._face else goal
            self._aim_goal = goal
            self._face = (yaw_offset, pitch_offset, time.monotonic())

    def speak(self, audio: np.ndarray, start: float) -> None:
        """Bob the head along with this clip of Reachy's voice, which starts playing at ``start``."""
        env = speech_envelope(audio)
        if env.size:
            with self.lock:
                now = time.monotonic()
                self._speech = [(s, e) for s, e in self._speech if s + e.size / SPEECH_RATE > now] + [(start, env)]

    def stop_speaking(self) -> None:
        with self.lock:
            self._speech = []

    def take_touch(self) -> bool:
        """True once after someone pushes an antenna."""
        with self.lock:
            touched, self._touched = self._touched, False
        return touched

    def face_recent(self, within: float = 1.5) -> bool:
        face = self._face
        return face is not None and time.monotonic() - face[2] < within

    def stop(self) -> None:
        self.stop_event.set()

    # --- the loop ------------------------------------------------------------------
    def run(self) -> None:
        period = 1.0 / self.RATE_HZ
        next_t = time.monotonic()
        last_touch_check = 0.0
        while not self.stop_event.is_set():
            now = time.monotonic()
            try:
                self._step(now, period)
                if now - last_touch_check > 0.1:
                    self._check_touch(now)
                    last_touch_check = now
                self._errors = 0
            except Exception as e:  # noqa: BLE001 - keep the loop alive, but don't spam the log
                self._errors += 1
                if self._errors in (1, 50) or self._errors % 500 == 0:
                    logger.warning("Motion loop error (%d): %s", self._errors, e)
                if self._errors > 5:
                    time.sleep(0.2)
            next_t += period
            time.sleep(max(0.0, next_t - time.monotonic()))
            if time.monotonic() - next_t > 0.5:
                next_t = time.monotonic()

    def _speech_level(self, now: float) -> float:
        level = 0.0
        for start, env in self._speech:
            i = int((now - start) * SPEECH_RATE)
            if 0 <= i < env.size:
                level = max(level, float(env[i]))
        return level

    def _step(self, now: float, period: float) -> None:
        with self.lock:
            mode, hold = self.mode, self.hold_name
            gname, gstart, gdur = self.gesture_name, self.gesture_start, self.gesture_dur
            if gname and now - gstart >= gdur:
                self.gesture_name = gname = None
            face = self._face
            aim_goal = self._aim_goal
            speech = self._speech_level(now)
            point = self._point if self._point and now < self._point[3] else None

        t = now - self._t0
        base = MODES[mode]
        seen = face is not None and now - face[2] < 2.5

        # Where to look: at the student, or glance around when nobody's there.
        if seen:
            goal_yaw, goal_pitch = aim_goal
        else:
            goal_yaw, goal_pitch = self._idle_glance(now, mode)
        k = 1 - math.exp(-period / (0.1 if seen else 0.8))
        self.aim_yaw += (goal_yaw - self.aim_yaw) * k
        self.aim_pitch += (goal_pitch - self.aim_pitch) * k

        if hold:
            target = dict(HOLDS[hold])
        else:
            w = base["track"]
            target = {
                "x": 0.0, "y": 0.0,
                "z": base["z"] + 3.5 * (0.4 if mode in ("focus", "standby") else 1.0) * math.sin(2 * math.pi * 0.12 * t),
                "roll": base["roll"],
                "pitch": base["pitch"] * (1 - w) + (self.aim_pitch + base["pitch"] * 0.3) * w,
                "yaw": base["yaw"] + self.aim_yaw * w,
                "ar": base["ar"], "al": base["al"],
                "body": self.aim_yaw * base["body"],
            }
            calm = 0.4 if mode in ("focus", "standby") else 1.0
            sway = 0.10 * calm * math.sin(2 * math.pi * 0.21 * t)
            target["ar"] += sway
            target["al"] -= sway
            if mode in ("idle", "break", "reading", "standby") and not gname:
                tr, tl = self._twitch(now)
                target["ar"] += tr
                target["al"] += tl
            if point:  # asked to look somewhere: that wins over looking at the student
                target["yaw"], target["pitch"], target["body"] = point[0], point[1], point[2]
            if mode == "thinking":
                target["ar"] += 0.25 * math.sin(2 * math.pi * 0.7 * t)
                target["al"] += 0.25 * math.sin(2 * math.pi * 0.7 * t + 1.6)
            if speech > 0.05:  # talking: bob with the voice
                target["pitch"] += 4.5 * (speech - 0.35)
                target["roll"] += 3.0 * speech * math.sin(2 * math.pi * 0.7 * t)
                target["yaw"] += 2.5 * speech * math.sin(2 * math.pi * 0.45 * t)
                target["z"] += 2.0 * speech
                target["ar"] += 0.12 * speech * math.sin(2 * math.pi * 1.3 * t)
                target["al"] -= 0.12 * speech * math.sin(2 * math.pi * 1.3 * t + 0.8)
            if gname:
                offs, _ = _gesture(gname, now - gstart)
                for key, v in offs.items():
                    target[key] += v

        # Keep the head within reach of the base.
        target["yaw"] = max(target["body"] - MAX_HEAD_VS_BODY, min(target["body"] + MAX_HEAD_VS_BODY, target["yaw"]))

        # Ease towards the target: quick enough to feel alive, smooth enough never to jerk.
        tau = 0.08 if gname else (0.12 if speech > 0.05 or seen else 0.3)
        alpha = 1 - math.exp(-period / tau)
        body_alpha = 1 - math.exp(-period / (0.15 if gname else 0.45))  # the base moves a little more slowly
        for key in KEYS:
            lo, hi = LIMITS[key]
            goal = min(max(target[key], lo), hi)
            self.current[key] += (goal - self.current[key]) * (body_alpha if key == "body" else alpha)
        self._history.append((now, self.current["yaw"], self.current["pitch"]))

        c = self.current
        head = self._create_head_pose(x=c["x"], y=c["y"], z=c["z"], roll=c["roll"], pitch=c["pitch"], yaw=c["yaw"],
                                      mm=True, degrees=True)
        antennas = np.array([c["ar"], c["al"]], dtype=np.float64)
        self.mini.set_target(head=head, antennas=antennas, body_yaw=math.radians(c["body"]))
        self.commanded_ant = [c["ar"], c["al"]]

    def _idle_glance(self, now: float, mode: str) -> tuple[float, float]:
        """Nobody in view: look around now and then, like something alive would."""
        if mode in ("listening", "speaking", "thinking"):
            return self.aim_yaw * 0.98, self.aim_pitch * 0.98
        if now >= self._next_glance:
            spread = 12 if mode in ("focus", "standby") else 30
            self._glance_goal = (random.uniform(-spread, spread), random.uniform(-6, 6))
            self._glance_until = now + random.uniform(1.5, 2.5)
            self._next_glance = now + random.uniform(7, 16) * (2 if mode == "standby" else 1)
        if now < self._glance_until:
            return self._glance_goal
        return 0.0, 0.0

    def _check_touch(self, now: float) -> None:
        """An antenna pushed well away from where we're holding it = a touch."""
        if now < self._touch_quiet_until:
            self._touch_hits = 0
            return
        present = self.mini.get_present_antenna_joint_positions()
        if present is None or len(present) != 2:
            return
        err = max(abs(present[0] - self.commanded_ant[0]), abs(present[1] - self.commanded_ant[1]))
        self._touch_hits = self._touch_hits + 1 if err > 0.5 else 0
        if self._touch_hits >= 3:
            with self.lock:
                self._touched = True
            self._touch_hits = 0
            self._touch_quiet_until = now + 2.0
