# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Run the Reachy Mini SDK without GStreamer.

On this laptop Windows Smart App Control interferes with GStreamer: at first its Python
bindings (``gi\\_gi.pyd``) were blocked outright, and later they imported but hung for
good the moment GStreamer started up. The Reachy Mini SDK imports ``gi`` at the top of
several media modules even when media is switched off.

This app never needs GStreamer: the daemon runs with ``--no-media`` and Study Buddy
handles the camera, mic and speaker itself as plain USB devices. So ``use_gi_stub()``
puts a do-nothing stand-in for ``gi`` in ``sys.modules`` before the SDK is imported.
Any stray GStreamer call becomes a harmless no-op instead of a hang. It does not get
around Smart App Control: the file it blocks is simply never loaded.
"""

from __future__ import annotations

import sys
import types
from unittest import mock

_REPOSITORY = ("Gst", "GstApp", "GLib", "GObject", "GstPbutils", "GstVideo", "GstAudio", "GstSdp", "GstWebRTC", "Gio")


def use_gi_stub() -> None:
    """Install the stand-in unless GStreamer's real bindings are already loaded."""
    if "gi" in sys.modules:
        return
    stub = types.ModuleType("gi")
    stub._study_buddy_stub = True  # type: ignore[attr-defined]
    stub.require_version = lambda *args, **kwargs: None  # type: ignore[attr-defined]
    repository = types.ModuleType("gi.repository")
    for name in _REPOSITORY:
        setattr(repository, name, mock.MagicMock(name=f"gi.repository.{name}"))
    stub.repository = repository  # type: ignore[attr-defined]
    sys.modules["gi"] = stub
    sys.modules["gi.repository"] = repository
