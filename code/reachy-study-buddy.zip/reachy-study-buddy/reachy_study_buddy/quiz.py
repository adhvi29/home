# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Quiz master: exam questions from your study guides, reviewed with spaced repetition.

Each question sits in a Leitner box. Full marks moves it up a box (seen again later),
a poor answer drops it back to box 0 (seen again soon).
"""

from __future__ import annotations

import datetime as dt
import json
import random
import re
from pathlib import Path
from typing import Any

from .store import Progress

BANK_PATH = Path(__file__).parent / "data" / "question_bank.json"
BOX_DAYS = [0, 1, 3, 7, 21]

SUBJECTS = {
    "physics": ["physics", "phys"],
    "chemistry": ["chemistry", "chem"],
    "biology": ["biology", "bio"],
    "computer_science": ["computer science", "computer_science", "cs", "computing", "comp sci", "ict"],
}
_STOP = {"the", "and", "of", "a", "an", "on", "in", "to", "for", "me", "quiz", "questions", "question", "topic", "chapter", "about", "some"}


def normalise_subject(name: str | None) -> str | None:
    if not name:
        return None
    n = name.strip().lower()
    for key, aliases in SUBJECTS.items():
        if n == key or n in aliases:
            return key
    return None


def _words(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in _STOP and len(w) > 1}


class QuizBank:
    def __init__(self, progress: Progress, path: Path = BANK_PATH) -> None:
        self.progress = progress
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            self.questions: dict[str, dict[str, Any]] = {q["id"]: q for q in data["questions"]}
        except (OSError, ValueError, KeyError):
            self.questions = {}

    # --- overview ----------------------------------------------------------------
    def topics(self) -> dict[str, list[str]]:
        out: dict[str, list[str]] = {}
        for q in self.questions.values():
            topics = out.setdefault(q["subject"], [])
            if q["topic"] not in topics:
                topics.append(q["topic"])
        return out

    def state(self, qid: str) -> dict[str, Any] | None:
        return self.progress.data["questions"].get(qid)

    # --- choosing a question ---------------------------------------------------
    def pick(self, subject: str | None = None, topic: str | None = None, prefer: str = "due",
             exclude: set[str] | None = None) -> tuple[dict[str, Any] | None, str]:
        """Best next question, or (None, explanation)."""
        exclude = exclude or set()
        subj = normalise_subject(subject)
        if subject and not subj and subject.lower() not in ("any", "all", "anything", "mixed"):
            available = ", ".join(s.replace("_", " ") for s in self.topics())
            return None, f"There is no question bank for {subject}. Banks exist for: {available}. You can write your own exam-style question instead."
        pool = [q for q in self.questions.values() if (not subj or q["subject"] == subj) and q["id"] not in exclude]
        if topic:
            want = _words(topic)
            scored = []
            for q in pool:
                topic_hits = len(want & _words(q["topic"]))
                text_hits = len(want & _words(q["text"]))
                if topic_hits or text_hits >= max(1, len(want) // 2 + (len(want) > 1)):
                    scored.append((topic_hits * 3 + text_hits, q))
            if not scored:
                names = "; ".join(t for t in self.topics().get(subj or "", [])) if subj else ""
                hint = f" Topics in {subj.replace('_', ' ')}: {names}." if names else ""
                return None, f"No bank questions match '{topic}'.{hint} You can write your own exam-style question on it instead."
            best = max(s for s, _ in scored)
            pool = [q for s, q in scored if s >= best - 1]
        if not pool:
            return None, "You've already been asked every matching question this session."

        today = dt.date.today().isoformat()
        accuracy = self.topic_accuracy()

        def rank(q: dict[str, Any]) -> float:
            st = self.state(q["id"])
            r = random.random() * 0.5
            if st is None:
                r += 2.0 if prefer == "new" else 1.0
            else:
                due = st.get("due", today) <= today
                r += (3.0 if due else 0.0) + (4 - st.get("box", 0)) * 0.3
            if prefer == "weak":
                r += (1.0 - accuracy.get((q["subject"], q["topic"]), 0.5)) * 3
            return r

        return max(pool, key=rank), ""

    # --- recording answers ---------------------------------------------------------
    def record(self, got: float, out_of: float, question_id: str | None = None, subject: str | None = None,
               topic: str | None = None, missed: list[str] | None = None) -> dict[str, Any]:
        out_of = max(1.0, float(out_of))
        got = min(max(0.0, float(got)), out_of)
        q = self.questions.get(question_id or "")
        subject = q["subject"] if q else (normalise_subject(subject) or (subject or "other").lower())
        topic = q["topic"] if q else (topic or "general")
        now = dt.datetime.now()
        entry = {"ts": now.isoformat(timespec="seconds"), "qid": question_id if q else None, "subject": subject,
                 "topic": topic, "got": got, "out_of": out_of, "missed": (missed or [])[:6]}
        with self.progress.lock:
            self.progress.data["quiz_log"].append(entry)
            self.progress.data["quiz_log"] = self.progress.data["quiz_log"][-5000:]
            if q:
                st = self.progress.data["questions"].setdefault(q["id"], {"box": 0, "seen": 0})
                ratio = got / out_of
                if ratio >= 0.8:
                    st["box"] = min(st.get("box", 0) + 1, len(BOX_DAYS) - 1)
                elif ratio < 0.5:
                    st["box"] = 0
                st["seen"] = st.get("seen", 0) + 1
                st["last"] = entry["ts"]
                st["last_score"] = f"{got:g}/{out_of:g}"
                st["due"] = (now.date() + dt.timedelta(days=BOX_DAYS[st["box"]])).isoformat()
            self.progress.save()
        return entry

    # --- stats -------------------------------------------------------------------
    def topic_accuracy(self, days: int = 60) -> dict[tuple[str, str], float]:
        since = (dt.datetime.now() - dt.timedelta(days=days)).isoformat()
        got: dict[tuple[str, str], list[float]] = {}
        with self.progress.lock:
            for e in self.progress.data["quiz_log"]:
                if e["ts"] >= since:
                    g = got.setdefault((e["subject"], e["topic"]), [0.0, 0.0])
                    g[0] += e["got"]
                    g[1] += e["out_of"]
        return {k: (v[0] / v[1] if v[1] else 0.0) for k, v in got.items()}

    def summary(self) -> dict[str, Any]:
        today = dt.date.today().isoformat()
        acc = self.topic_accuracy()
        with self.progress.lock:
            log = list(self.progress.data["quiz_log"])
            states = dict(self.progress.data["questions"])
        by_subject: dict[str, dict[str, float]] = {}
        for e in log:
            s = by_subject.setdefault(e["subject"], {"answered": 0, "got": 0.0, "out_of": 0.0})
            s["answered"] += 1
            s["got"] += e["got"]
            s["out_of"] += e["out_of"]
        attempts: dict[tuple[str, str], int] = {}
        for e in log:
            attempts[(e["subject"], e["topic"])] = attempts.get((e["subject"], e["topic"]), 0) + 1
        weakest = sorted((k for k in acc if attempts.get(k, 0) >= 2), key=lambda k: acc[k])[:5]
        return {
            "bank_size": len(self.questions),
            "answered_today": sum(1 for e in log if e["ts"].startswith(today)),
            "due_now": sum(1 for s in states.values() if s.get("due", today) <= today),
            "by_subject": {k: {"answered": v["answered"], "percent": round(100 * v["got"] / v["out_of"]) if v["out_of"] else 0}
                           for k, v in by_subject.items()},
            "weakest_topics": [{"subject": s, "topic": t, "percent": round(100 * acc[(s, t)])} for s, t in weakest],
        }
