# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Full robot mode: Pollen's Reachy Mini daemon drives the motors, Study Buddy does the rest.

    study-buddy-robot                 (or: python -m reachy_study_buddy.robot)

1. Starts the Reachy Mini daemon with ``--no-media`` (motors and kinematics only), using
   the GStreamer stand-in from ``nogi`` so it runs even though Smart App Control blocks
   GStreamer on this laptop. The daemon wakes the robot up.
2. Runs Study Buddy as a Reachy Mini app connected to that daemon. It uses Reachy's
   camera, mic and speaker directly as USB devices.
3. On "Turn off" (or Ctrl+C) the robot goes to sleep and everything stops.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import signal
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser

from .logs import setup_logging

logger = logging.getLogger("reachy_study_buddy.robot")
DAEMON = "http://127.0.0.1:8000"


def _daemon_status() -> dict | None:
    try:
        with urllib.request.urlopen(f"{DAEMON}/api/daemon/status", timeout=2) as r:
            return json.loads(r.read())
    except Exception:  # noqa: BLE001 - not up yet
        return None


def _kill_tree(pid: int) -> None:
    """Kill a process and everything it started. (The venv's python.exe is a launcher that runs the real
    interpreter as a child, so killing only the launcher would leave the daemon holding the motor port.)"""
    import psutil

    try:
        parent = psutil.Process(pid)
    except psutil.NoSuchProcess:
        return
    procs = parent.children(recursive=True) + [parent]
    for p in procs:
        try:
            p.kill()
        except psutil.NoSuchProcess:
            pass
    psutil.wait_procs(procs, timeout=5)


def _kill_stale_daemons() -> None:
    """A daemon left over from an earlier run keeps the robot's serial port open, and then a new one
    can't see any motors. Clear them out first."""
    import psutil

    me = os.getpid()
    for p in psutil.process_iter(["pid", "cmdline"]):
        cmd = " ".join(p.info.get("cmdline") or [])
        if p.info["pid"] != me and "reachy_study_buddy.robot" in cmd and "--daemon" in cmd:
            logger.info("Closing a leftover robot daemon (pid %s)", p.info["pid"])
            _kill_tree(p.info["pid"])


def _stop_daemon(daemon: subprocess.Popen | None, goto_sleep: bool) -> None:
    if daemon is None:
        return
    if goto_sleep:
        logger.info("Putting Reachy to sleep and stopping the daemon...")
        _post("/api/daemon/stop?goto_sleep=true")
        for _ in range(40):  # the stop runs as a background job: let the sleep move finish
            if (_daemon_status() or {}).get("state") in ("stopped", "not_initialized", "error", None):
                break
            time.sleep(0.25)
    try:
        daemon.send_signal(signal.CTRL_BREAK_EVENT if os.name == "nt" else signal.SIGINT)
        daemon.wait(timeout=5)
    except (subprocess.TimeoutExpired, OSError):
        pass
    _kill_tree(daemon.pid)  # make sure nothing is left holding the serial port


def _robot_plugged_in() -> bool:
    """Reachy Mini's motor board is a CH343 USB serial port (VID 1A86, PID 55D3). Checking first saves
    about 40 seconds of the daemon hunting for a robot that isn't there."""
    try:
        from serial.tools import list_ports

        return any((p.vid, p.pid) == (0x1A86, 0x55D3) for p in list_ports.comports())
    except Exception as e:  # noqa: BLE001 - if we can't tell, let the daemon try
        logger.info("Couldn't list serial ports: %s", e)
        return True


def _laptop_mode(note: str, no_browser: bool) -> bool:
    from . import laptop

    return laptop.run(["--note", note] + (["--no-browser"] if no_browser else []))


def _post(path: str) -> None:
    try:
        urllib.request.urlopen(urllib.request.Request(f"{DAEMON}{path}", method="POST"), timeout=20).read()
    except Exception as e:  # noqa: BLE001
        logger.warning("%s failed: %s", path, e)


def run_daemon(extra: list[str]) -> None:
    """Inside the daemon subprocess."""
    from .nogi import use_gi_stub

    use_gi_stub()
    from reachy_mini.daemon.app.main import main as daemon_main

    sys.argv = ["reachy-mini-daemon", "--no-media", *extra]
    daemon_main()


def main() -> None:
    if len(sys.argv) > 1 and sys.argv[1] == "--daemon":
        run_daemon(sys.argv[2:])
        return

    parser = argparse.ArgumentParser(description="Reachy Study Buddy with the robot moving")
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()
    setup_logging()
    no_browser = args.no_browser
    while _run_once(no_browser):
        logger.info("Restarting...")
        no_browser = True  # the page is already open; it reconnects by itself


def _run_once(no_browser: bool) -> bool:
    """Start the robot (or the no-motor fallback) and run until turned off. True = restart."""
    daemon: subprocess.Popen | None = None
    if _daemon_status() is None and not _robot_plugged_in():
        logger.info("Reachy isn't plugged in; starting without movement.")
        return _laptop_mode("Reachy isn't plugged into the laptop, so I can't move. Plug my USB cable and power in, "
                            "then press Restart on the study page.", no_browser)
    if _daemon_status() is None:
        _kill_stale_daemons()
        logger.info("Starting the Reachy Mini daemon (motors only, no GStreamer)...")
        flags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
        daemon = subprocess.Popen([sys.executable, "-u", "-m", "reachy_study_buddy.robot", "--daemon",
                                   "--no-preload-datasets", "--dataset-update-interval", "0"], creationflags=flags)
    t0 = time.time()
    while True:
        status = _daemon_status() or {}
        state = status.get("state")
        if state == "running":
            break
        died = daemon is not None and daemon.poll() is not None
        if state == "error" or died or time.time() - t0 > 90:
            reason = status.get("error") or ("the robot software stopped" if died else "the robot software didn't start")
            logger.warning("Can't move the robot (%s). Starting without movement.", reason)
            _stop_daemon(daemon, goto_sleep=False)
            note = ("My motors have no power, so I can't move right now. Switch my power on, then press Restart on "
                    "the study page." if "motor" in str(reason).lower()
                    else "I can't move right now, but I can still help you study.")
            return _laptop_mode(note, no_browser)
        time.sleep(0.5)
    logger.info("Robot ready in %.1fs", time.time() - t0)

    from .nogi import use_gi_stub

    use_gi_stub()
    from .main import ReachyStudyBuddy

    app = ReachyStudyBuddy()
    if not no_browser:
        threading.Timer(6.0, lambda: webbrowser.open("http://127.0.0.1:8042")).start()
    try:
        app.wrapped_run()
    except KeyboardInterrupt:
        app.stop()
    finally:
        _stop_daemon(daemon, goto_sleep=True)
        logger.info("Study Buddy is off.")
    engine = app.engine_ref.get("engine")
    return bool(engine is not None and engine.restart_requested)


if __name__ == "__main__":
    main()
