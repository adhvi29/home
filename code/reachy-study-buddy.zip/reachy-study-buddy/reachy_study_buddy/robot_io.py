# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""The two bodies the study buddy can live in.

``ReachyIO``  - Reachy Mini moving: head, antennas and base through the official SDK and
                daemon (run with --no-media), plus its camera, mic and speaker used
                directly as USB devices, and face following from its camera.
``LaptopIO``  - no motors: Reachy's camera, mic and speaker if it's plugged in (or the
                laptop's own). Also the media half of ``ReachyIO``.

Both give the engine the same small interface.
"""

from __future__ import annotations

import collections
import io
import logging
import threading
import time
from typing import Any

import numpy as np

logger = logging.getLogger(__name__)

RATE = 16000
MAX_IMAGE_EDGE = 1568  # Claude's vision works at up to ~1568 px on the long edge


def encode_jpeg(rgb: np.ndarray, max_edge: int = MAX_IMAGE_EDGE, quality: int = 85) -> bytes:
    from PIL import Image

    img = Image.fromarray(rgb)
    img.thumbnail((max_edge, max_edge))
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=quality)
    return buf.getvalue()


class ReachyIO:
    """Reachy Mini with its motors on. Media goes through a ``LaptopIO`` pointed at Reachy's
    own USB camera, mic and speaker, so GStreamer is never needed."""

    has_body = True
    name = "Reachy Mini"

    def __init__(self, mini: Any, media: LaptopIO) -> None:
        from .motion import MotionController
        from .vision import FaceFollower

        self.mini = mini
        self.media = media
        self.motion = MotionController(mini)
        self.faces = FaceFollower(media.latest_frame_with_time, self.motion.set_face_angles)
        self._play_end = 0.0

    def _glide(self, head_goal: np.ndarray, antennas_goal: list[float], seconds: float) -> None:
        """Smoothly move from wherever the robot is to a pose (only used before/after the motion loop)."""
        import math

        from reachy_mini.utils.interpolation import linear_pose_interpolation

        try:
            head0 = self.mini.get_current_head_pose()
            ant0 = np.array(self.mini.get_present_antenna_joint_positions(), dtype=np.float64)
        except Exception as e:  # noqa: BLE001
            logger.warning("Couldn't read the robot's pose: %s", e)
            return
        ant1 = np.array(antennas_goal, dtype=np.float64)
        t0 = time.monotonic()
        while (t := time.monotonic() - t0) <= seconds:
            a = 0.5 - 0.5 * math.cos(math.pi * min(1.0, t / seconds))
            self.mini.set_target(head=linear_pose_interpolation(head0, head_goal, a), antennas=ant0 + (ant1 - ant0) * a,
                                 body_yaw=0.0)
            time.sleep(0.02)

    def start(self) -> None:
        from reachy_mini.utils import create_head_pose

        from .motion import NEUTRAL_ANT

        self._glide(create_head_pose(), list(NEUTRAL_ANT), 1.5)  # never start the loop with a jump
        self.media.start()
        self.media.start_camera_stream()
        self.motion.start()
        self.faces.start()

    def stop(self) -> None:
        from reachy_mini.reachy_mini import SLEEP_ANTENNAS_JOINT_POSITIONS, SLEEP_HEAD_POSE

        self.faces.stop()
        self.motion.stop()
        self.motion.join(timeout=2)
        self._glide(SLEEP_HEAD_POSE, list(SLEEP_ANTENNAS_JOINT_POSITIONS), 2.0)  # head down, antennas folded
        self.media.stop()

    # audio: Reachy's own mic and speaker
    def read_mic(self) -> np.ndarray | None:
        return self.media.read_mic()

    def play(self, audio: np.ndarray) -> None:
        now = time.monotonic()
        start = max(now, self._play_end)
        self._play_end = start + audio.size / RATE
        self.motion.speak(audio, start)  # head bobs along with the words
        self.media.play(audio)

    def flush(self) -> None:
        self._play_end = 0.0
        self.motion.stop_speaking()
        self.media.flush()

    # vision
    def capture_jpeg(self) -> bytes | None:
        return self.media.capture_jpeg()

    def face_present(self) -> bool | None:
        return self.faces.present()

    def set_presence_watch(self, on: bool) -> None:
        pass  # face following runs all the time in robot mode

    # body
    def set_mode(self, mode: str) -> None:
        self.motion.set_mode(mode)

    def gesture(self, name: str) -> float:
        return self.motion.gesture(name)

    def hold(self, where: str | None) -> None:
        self.motion.hold(where)

    def point(self, direction: str, seconds: float) -> None:
        self.motion.point(direction, seconds)

    def antenna_touched(self) -> bool:
        return self.motion.take_touch()


def find_reachy_audio() -> tuple[int | None, int | None]:
    """Reachy Mini's mic and speaker as plain Windows sound devices (DirectSound keeps full names
    and resamples to 16 kHz for us). Returns (input index, output index)."""
    import sounddevice as sd

    try:  # re-read the device list: Reachy may have been plugged in after this program started
        sd._terminate()
        sd._initialize()
    except Exception as e:  # noqa: BLE001
        logger.debug("Could not refresh the sound device list: %s", e)
    apis = sd.query_hostapis()
    mic = spk = None
    for i, d in enumerate(sd.query_devices()):
        if "reachy mini" not in d["name"].lower() or "directsound" not in apis[d["hostapi"]]["name"].lower():
            continue
        if d["max_input_channels"] > 0 and mic is None:
            mic = i
        if d["max_output_channels"] > 0 and spk is None:
            spk = i
    return mic, spk


def find_camera(name_part: str) -> int | None:
    try:
        import cv2
        from cv2_enumerate_cameras import enumerate_cameras

        for cam in enumerate_cameras(cv2.CAP_DSHOW):
            if name_part.lower() in cam.name.lower():
                return cam.index
    except Exception as e:  # noqa: BLE001
        logger.info("Camera lookup failed: %s", e)
    return None


class LaptopIO:
    """No motors. Uses Reachy Mini's own mic, speaker and camera when it's plugged in
    (they are ordinary USB devices), otherwise the laptop's."""

    has_body = False
    name = "Laptop"

    def __init__(self, camera_index: int | None = None, audio: bool = True, webcam_presence: bool = False,
                 use_reachy_devices: bool = True) -> None:
        self.audio = audio  # False = silent test mode: no mic, speech is timed but not played
        self.webcam_presence = webcam_presence  # opt-in: watch the camera for a face during focus blocks
        self.mic_device: int | None = None
        self.speaker_device: int | None = None
        reachy_cam = find_camera("Reachy Mini") if use_reachy_devices else None
        if audio and use_reachy_devices:
            self.mic_device, self.speaker_device = find_reachy_audio()
        self.camera_index = camera_index if camera_index is not None else (reachy_cam if reachy_cam is not None else 0)
        on_reachy = self.mic_device is not None or (camera_index is None and reachy_cam is not None)
        self.name = "Reachy Mini (voice and camera, no movement)" if on_reachy else "Laptop"
        if on_reachy:
            logger.info("Using Reachy Mini's own mic/speaker (%s/%s) and camera %s", self.mic_device, self.speaker_device, self.camera_index)
        self._mic: collections.deque[np.ndarray] = collections.deque(maxlen=400)
        self._out = np.zeros(0, dtype=np.float32)
        self._out_lock = threading.Lock()
        self._in_stream = None
        self._out_stream = None
        self._cam = None
        self._cam_lock = threading.Lock()
        self._face: bool | None = None
        self._watch = False
        self._watch_thread: threading.Thread | None = None
        self._cascade = None
        self._stream = False  # continuous capture (robot mode: face following)
        self._latest: np.ndarray | None = None
        self._latest_t = 0.0

    def start(self) -> None:
        if not self.audio:
            return
        import sounddevice as sd

        def on_in(indata, frames, time_info, status):  # noqa: ANN001, ARG001
            self._mic.append(indata[:, 0].copy())  # channel 0: the mic array's processed output

        def on_out(outdata, frames, time_info, status):  # noqa: ANN001, ARG001
            with self._out_lock:
                n = min(frames, self._out.size)
                outdata[:n, 0] = self._out[:n]
                outdata[n:, 0] = 0
                self._out = self._out[n:]

        in_channels = 1
        if self.mic_device is not None:
            in_channels = min(2, int(sd.query_devices(self.mic_device)["max_input_channels"]))
        self._in_stream = sd.InputStream(device=self.mic_device, samplerate=RATE, channels=in_channels, dtype="float32",
                                         blocksize=512, callback=on_in)
        self._out_stream = sd.OutputStream(device=self.speaker_device, samplerate=RATE, channels=1, dtype="float32",
                                           blocksize=512, callback=on_out)
        self._in_stream.start()
        self._out_stream.start()

    def stop(self) -> None:
        self._stream = False
        self.set_presence_watch(False)
        for s in (self._in_stream, self._out_stream):
            if s is not None:
                s.stop()
                s.close()
        self._release_camera()

    def read_mic(self) -> np.ndarray | None:
        try:
            return self._mic.popleft()
        except IndexError:
            return None

    def play(self, audio: np.ndarray) -> None:
        if not self.audio:
            return
        with self._out_lock:
            self._out = np.concatenate([self._out, audio.astype(np.float32)])

    def flush(self) -> None:
        with self._out_lock:
            self._out = np.zeros(0, dtype=np.float32)

    # webcam
    def _open_camera(self):  # noqa: ANN202
        import cv2

        if self._cam is None or not self._cam.isOpened():
            self._cam = cv2.VideoCapture(self.camera_index, cv2.CAP_DSHOW)
            self._cam.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
            self._cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
        return self._cam

    def _release_camera(self) -> None:
        with self._cam_lock:
            if self._cam is not None:
                self._cam.release()
                self._cam = None

    def _grab_rgb(self) -> np.ndarray | None:
        with self._cam_lock:
            cam = self._open_camera()
            frame = None
            for _ in range(5):  # let exposure settle
                ok, f = cam.read()
                if ok:
                    frame = f
            if frame is None:
                return None
            return np.ascontiguousarray(frame[:, :, ::-1])

    def start_camera_stream(self) -> None:
        """Keep the camera running and the newest frame at hand (robot mode: face following)."""
        if self._stream:
            return
        self._stream = True
        threading.Thread(target=self._stream_loop, name="camera", daemon=True).start()

    def _stream_loop(self) -> None:
        while self._stream:
            with self._cam_lock:
                cam = self._open_camera()
                ok, frame = cam.read()
            if ok:
                self._latest, self._latest_t = frame, time.monotonic()
            else:
                time.sleep(0.5)  # camera busy or unplugged; try again
        self._release_camera()

    def latest_frame(self) -> np.ndarray | None:
        """Newest BGR frame from the stream, if it's fresh."""
        got = self.latest_frame_with_time()
        return None if got is None else got[0]

    def latest_frame_with_time(self) -> tuple[np.ndarray, float] | None:
        """Newest BGR frame and when it arrived (monotonic clock), if it's fresh."""
        frame, t = self._latest, self._latest_t
        if frame is None or time.monotonic() - t > 1.0:
            return None
        return frame, t

    def capture_jpeg(self) -> bytes | None:
        if self._stream:
            time.sleep(0.15)  # a frame taken after the head stopped moving
            frame = self.latest_frame()
            return None if frame is None else encode_jpeg(np.ascontiguousarray(frame[:, :, ::-1]))
        rgb = self._grab_rgb()
        if not self._watch:
            self._release_camera()  # camera light goes off again
        return None if rgb is None else encode_jpeg(rgb)

    def face_present(self) -> bool | None:
        return self._face if self._watch else None

    def set_presence_watch(self, on: bool) -> None:
        """Only watch for a face during focus blocks; the webcam is off the rest of the time."""
        on = on and self.webcam_presence
        if on == self._watch:
            return
        self._watch = on
        if on:
            self._watch_thread = threading.Thread(target=self._watch_loop, name="webcam-presence", daemon=True)
            self._watch_thread.start()
        else:
            self._face = None
            self._release_camera()

    def _watch_loop(self) -> None:
        import cv2

        if self._cascade is None:
            self._cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
        while self._watch:
            rgb = self._grab_rgb()
            if rgb is not None:
                gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
                small = cv2.resize(gray, (640, int(640 * gray.shape[0] / gray.shape[1])))
                faces = self._cascade.detectMultiScale(small, scaleFactor=1.15, minNeighbors=5, minSize=(50, 50))
                self._face = len(faces) > 0
            time.sleep(2.0)

    # no body
    def set_mode(self, mode: str) -> None:
        pass

    def gesture(self, name: str) -> float:
        return 0.0

    def hold(self, where: str | None) -> None:
        pass

    def point(self, direction: str, seconds: float) -> None:
        pass

    def antenna_touched(self) -> bool:
        return False
