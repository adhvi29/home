/*!
 * Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
 * Reachy Study Buddy - https://github.com/adhvi29
 * You may view and run this code for personal and educational use only.
 * You may not copy it into other projects, redistribute, sell, or present
 * it as your own work without written permission from the author.
 * Removing or changing this notice is not permitted. See LICENSE.txt.
 */
"use strict";
// Study Buddy page. Talks to the local app over /api (with the X-Study-Buddy header) and /ws.

const $ = (sel, el = document) => el.querySelector(sel);
const HEADERS = { "X-Study-Buddy": "1" };

const S = { settings: {}, system: {}, status: {}, stats: {}, materials: [] };
let liveBubble = null;

// ---------- theme (applied before anything else draws) ----------
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme || "light";
  try { localStorage.setItem("sb-theme", theme); } catch (e) { /* private mode */ }
}
try { applyTheme(localStorage.getItem("sb-theme") || "light"); } catch (e) { applyTheme("light"); }

// ---------- api ----------
async function api(path, method = "GET", body) {
  const opts = { method, headers: { ...HEADERS } };
  if (body instanceof FormData) opts.body = body;
  else if (body !== undefined) { opts.headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(body); }
  const res = await fetch(path, opts);
  let data = null;
  try { data = await res.json(); } catch (e) { /* empty body */ }
  if (!res.ok) throw new Error((data && data.detail) || res.statusText);
  return data;
}
function toast(text) { addLog({ who: "system", text, ts: "" }); }

// ---------- safe rendering ----------
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }

function renderMath(el) {
  if (window.renderMathInElement) {
    try {
      renderMathInElement(el, {
        delimiters: [
          { left: "$$", right: "$$", display: true }, { left: "\\[", right: "\\]", display: true },
          { left: "$", right: "$", display: false }, { left: "\\(", right: "\\)", display: false },
        ],
        throwOnError: false,
      });
    } catch (e) { /* leave raw TeX */ }
  }
}

// Markdown from Claude: math is lifted out first so the markdown parser can't mangle it,
// then everything is sanitised with DOMPurify before it touches the page.
function renderMarkdown(el, md) {
  if (!(window.marked && window.DOMPurify)) { el.textContent = md; return; }
  const maths = [];
  const lifted = md.replace(/\$\$[\s\S]+?\$\$|\\\[[\s\S]+?\\\]|\\\([\s\S]+?\\\)|\$(?!\s)[^$\n]+?\$/g, m => {
    maths.push(m);
    return `@@MATH${maths.length - 1}@@`;
  });
  let html = marked.parse(lifted, { breaks: true });
  html = html.replace(/@@MATH(\d+)@@/g, (_, i) => escapeHtml(maths[+i]));
  el.innerHTML = DOMPurify.sanitize(html, { USE_PROFILES: { html: true } });
  renderMath(el);
}

function renderHtml(el, html) {
  if (window.DOMPurify) el.innerHTML = DOMPurify.sanitize(html, { USE_PROFILES: { html: true, svg: true } });
  else el.textContent = new DOMParser().parseFromString(html, "text/html").body.textContent;
  renderMath(el);
}

// ---------- conversation ----------
const log = $("#log");
function addLog(item) {
  if (item.who === "reachy" && liveBubble) {
    liveBubble.classList.remove("live");
    $(".who", liveBubble).textContent = `Reachy${item.ts ? " · " + item.ts : ""}`;
    $(".txt", liveBubble).textContent = item.text;
    liveBubble = null;
    scrollLog();
    return;
  }
  const li = document.createElement("li");
  li.className = `msg ${item.who}`;
  const label = { you: item.source === "typed" ? "You typed" : "You", reachy: "Reachy", heard: "Heard (not for Reachy)", system: "" }[item.who];
  li.innerHTML = (label ? `<span class="who">${label}${item.ts ? " · " + item.ts : ""}</span>` : "") + `<span class="txt"></span>`;
  $(".txt", li).textContent = item.text;
  log.appendChild(li);
  while (log.children.length > 200) log.firstChild.remove();
  scrollLog();
}
function scrollLog() { log.scrollTop = log.scrollHeight; }
function startLive() {
  if (liveBubble) return;
  liveBubble = document.createElement("li");
  liveBubble.className = "msg reachy live";
  liveBubble.innerHTML = `<span class="who">Reachy</span><span class="txt"></span>`;
  log.appendChild(liveBubble);
  scrollLog();
}
function endLive() {
  if (liveBubble && !$(".txt", liveBubble).textContent.trim()) liveBubble.remove();
  else if (liveBubble) liveBubble.classList.remove("live");
  liveBubble = null;
}

$("#composer").addEventListener("submit", async ev => {
  ev.preventDefault();
  const input = $("#say");
  const text = input.value.trim();
  if (!text) return;
  input.value = "";
  try { await api("/api/say", "POST", { text }); } catch (e) { toast(e.message); }
});

$("#file").addEventListener("change", async ev => {
  for (const file of ev.target.files) {
    const fd = new FormData();
    fd.append("file", file);
    try { renderChips((await api("/api/upload", "POST", fd)).items); } catch (e) { toast(`${file.name}: ${e.message}`); }
  }
  ev.target.value = "";
});
function renderChips(items) {
  const box = $("#attach-chips");
  box.innerHTML = "";
  (items || []).forEach(name => {
    const chip = document.createElement("span");
    chip.className = "chip";
    chip.textContent = "📎 " + name;
    box.appendChild(chip);
  });
  if (items && items.length) {
    const clear = document.createElement("button");
    clear.type = "button";
    clear.className = "chip";
    clear.textContent = "Remove";
    clear.onclick = () => api("/api/upload", "DELETE").then(() => renderChips([]));
    box.appendChild(clear);
    const hint = document.createElement("span");
    hint.className = "hint";
    hint.textContent = "Goes with your next message. Ask about it out loud or type.";
    box.appendChild(hint);
  }
}

// ---------- board ----------
function addCard(card, prepend = true) {
  const box = $("#cards");
  const empty = $(".empty", box);
  if (empty) empty.remove();
  const el = document.createElement("article");
  el.className = `card ${card.kind || "note"}`;
  el.innerHTML = `<div class="card-head"><h3></h3><span class="t"></span></div><div class="body"></div>`;
  $("h3", el).textContent = card.title;
  $(".t", el).textContent = (card.marks ? `${card.marks} mark${card.marks === 1 ? "" : "s"} · ` : "") + (card.ts || "");
  if (card.html) renderHtml($(".body", el), card.html);
  else renderMarkdown($(".body", el), card.markdown || "");
  if (prepend) box.prepend(el); else box.appendChild(el);
  while (box.children.length > 20) box.lastChild.remove();
}
function showSnapshot(ts) {
  if (!ts) return;
  $("#snapshot").src = `/api/snapshot?ts=${ts}`;
  $("#snap-time").textContent = new Date(ts * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  $("#snapshot-wrap").hidden = false;
}

// ---------- status pill & top bar ----------
function renderStatus() {
  const st = S.status;
  const pill = $("#pill");
  let cls = "standby", text = "Say “Reachy” to wake me";
  if (st.mic_muted) { cls = "muted"; text = "Microphone muted"; }
  else if (st.speaking) { cls = "speaking"; text = "Speaking"; }
  else if (st.thinking) { cls = "thinking"; text = "Thinking…"; }
  else if (st.hearing) { cls = "listening"; text = "Listening…"; }
  else if (st.reading) { cls = "reading"; text = "Reading along with you"; }
  else if (st.state === "conversation") { cls = "idle"; text = "I'm listening"; }
  else if (st.state === "starting") { text = "Warming up…"; }
  pill.className = `pill ${cls}`;
  $("#pill-text").textContent = text;
  document.body.dataset.mode = st.mode || "";
  $("#stop").hidden = !(st.speaking || st.thinking);
  $("#mute").setAttribute("aria-pressed", String(!!st.mic_muted));
  $("#lvl").style.width = `${Math.round((st.mic_level || 0) * 100)}%`;
  $("#wake-hint").textContent = S.settings.wake_word === false ? "Always listening" : (st.state === "conversation" ? "Just talk" : "Say “Reachy” to start");
  if (st.focus) renderFocus(st.focus);
  if (st.timers) renderTimers(st.timers);
  renderReading(st.reading);
  if (st.attachments) renderChips(st.attachments);
}

$("#talk").onclick = () => api("/api/talk", "POST").catch(e => toast(e.message));
let turnedOff = false;
let restarting = false;
async function restartApp() {
  restarting = true;
  turnedOff = true;
  showOff("Restarting…", "Reachy is restarting. This page reconnects by itself.");
  try { await api("/api/restart", "POST"); } catch (e) { /* it may already be going */ }
}
$("#turn-off").onclick = async () => {
  if (!confirm("Turn Study Buddy off? Reachy will stop listening and go to sleep.")) return;
  showOff("Turning off…", "Reachy is saying bye and going to sleep.");
  turnedOff = true;
  try { await api("/api/turn-off", "POST"); } catch (e) { /* it may already be gone */ }
};
function showOff(title, text) {
  $("#off-title").textContent = title;
  $("#off-text").textContent = text;
  $("#off-screen").hidden = false;
}
$("#stop").onclick = () => api("/api/stop", "POST").catch(e => toast(e.message));
$("#mute").onclick = () => api("/api/mute", "POST", { muted: !S.status.mic_muted })
  .then(r => { S.status.mic_muted = r.muted; S.settings.mic_muted = r.muted; renderStatus(); })
  .catch(e => toast(e.message));

// ---------- focus ----------
const RING = 2 * Math.PI * 52;
function fmt(sec) { sec = Math.max(0, Math.round(sec)); return `${String(Math.floor(sec / 60)).padStart(2, "0")}:${String(sec % 60).padStart(2, "0")}`; }
function renderFocus(f) {
  const idle = f.phase === "idle";
  $("#focus-idle").hidden = !idle;
  $("#focus-live").hidden = idle;
  const panel = $(".panel.focus");
  panel.classList.toggle("on-break", f.phase === "break");
  const total = (f.phase === "break" ? f.break_min : f.focus_min) * 60 || 1;
  const left = idle ? (Number($("#f-min").value) || 25) * 60 : f.seconds_left;
  $("#clock").textContent = fmt(left);
  $("#ring").style.strokeDasharray = RING;
  $("#ring").style.strokeDashoffset = idle ? 0 : RING * (1 - left / total);
  $("#phase").textContent = idle ? "Ready" : f.paused ? "Paused" : f.phase === "break" ? "Break" : `Block ${f.cycle} of ${f.cycles}`;
  $("#focus-pause").textContent = f.paused ? "Resume" : "Pause";
  $("#goal-line").hidden = idle || !f.goal;
  $("#goal-line").textContent = f.goal ? `Goal: ${f.goal}` : "";
  const pres = $("#presence");
  const known = S.status.presence !== null && S.status.presence !== undefined;
  pres.hidden = f.phase !== "focus" || (!known && !f.away);
  pres.className = `presence ${f.away ? "away" : "here"}`;
  pres.textContent = f.away ? "Away from desk" : "At desk";
  $("#focus-today").textContent = Math.round(f.focused_today_min || 0);
}
$("#focus-start").onclick = () => api("/api/focus", "POST", {
  action: "start", focus_min: +$("#f-min").value, break_min: +$("#b-min").value, cycles: +$("#cycles").value, goal: $("#goal").value,
}).catch(e => toast(e.message));
$("#focus-pause").onclick = () => api("/api/focus", "POST", { action: S.status.focus && S.status.focus.paused ? "resume" : "pause" });
$("#focus-skip").onclick = () => api("/api/focus", "POST", { action: "skip" });
$("#focus-stop").onclick = () => { if (confirm("Stop this focus session?")) api("/api/focus", "POST", { action: "stop" }); };
["#f-min"].forEach(id => $(id).addEventListener("input", () => S.status.focus && renderFocus(S.status.focus)));

function renderTimers(list) {
  const ul = $("#timers");
  ul.innerHTML = "";
  list.forEach(t => {
    const li = document.createElement("li");
    li.innerHTML = `<span></span><span><b></b> <button title="Cancel">✕</button></span>`;
    li.firstChild.textContent = "⏱ " + t.label;
    $("b", li).textContent = fmt(t.seconds_left);
    $("button", li).onclick = () => api("/api/timer", "POST", { cancel: t.id });
    ul.appendChild(li);
  });
}

// ---------- reading ----------
function renderReading(r) {
  $("#read-idle").hidden = !!r;
  $("#read-live").hidden = !r;
  if (r) {
    $("#read-words").textContent = (r.words || 0).toLocaleString();
    $("#read-last").textContent = r.last ? `“…${r.last.slice(-160)}”` : "Start reading out loud whenever you're ready.";
  }
}
$("#read-start").onclick = () => api("/api/reading", "POST", { action: "start", title: $("#read-title").value }).catch(e => toast(e.message));
$("#read-done").onclick = () => api("/api/reading", "POST", { action: "finish" }).catch(e => toast(e.message));

function renderMaterials(items) {
  S.materials = items || [];
  const ul = $("#materials");
  ul.innerHTML = "";
  if (!S.materials.length) { ul.innerHTML = `<li class="empty">Nothing read yet.</li>`; return; }
  S.materials.forEach(m => {
    const li = document.createElement("li");
    li.innerHTML = `<button class="mat"><span class="mt"></span><span class="ms"></span></button>`;
    const btn = $("button", li);
    if (m.active) btn.classList.add("active");
    $(".mt", li).textContent = m.title;
    if (m.active) $(".mt", li).insertAdjacentHTML("beforeend", `<span class="badge">studying</span>`);
    $(".ms", li).textContent = `${m.words.toLocaleString()} words · ${m.created.slice(0, 10)}${m.subject ? " · " + m.subject : ""}`;
    btn.onclick = () => openChapter(m.id);
    ul.appendChild(li);
  });
}
let chapterId = null;
async function openChapter(id) {
  const m = await api(`/api/materials/${encodeURIComponent(id)}`);
  chapterId = id;
  $("#ch-title").textContent = m.title;
  $("#ch-name").value = m.title;
  $("#ch-text").value = m.text;
  $("#chapter").showModal();
}
$("#ch-save").onclick = async () => {
  await api(`/api/materials/${encodeURIComponent(chapterId)}`, "PUT", { title: $("#ch-name").value, text: $("#ch-text").value });
  $("#chapter").close();
};
$("#ch-use").onclick = async () => { await api(`/api/materials/${encodeURIComponent(chapterId)}`, "PUT", { active: true }); $("#chapter").close(); };
$("#ch-delete").onclick = async () => {
  if (!confirm("Delete this chapter for good?")) return;
  await api(`/api/materials/${encodeURIComponent(chapterId)}`, "DELETE");
  $("#chapter").close();
};

// ---------- progress ----------
const SUBJECT_NAMES = { physics: "Physics", chemistry: "Chemistry", biology: "Biology", computer_science: "Computer Science" };
function renderStats(st) {
  S.stats = st;
  $("#focus-today").textContent = Math.round(st.focus_today_min || 0);
  $("#answered-today").textContent = st.quiz ? st.quiz.answered_today : 0;
  $("#streak").textContent = st.streak_days ? `🔥 ${st.streak_days}-day streak` : "";
  renderSpend(st.spent_today_usd, st.budget_usd);

  const week = $("#week");
  week.innerHTML = "";
  const max = Math.max(60, ...st.focus_week.map(d => d.minutes));
  st.focus_week.forEach((d, i) => {
    const day = new Date(d.day + "T12:00:00").toLocaleDateString([], { weekday: "short" }).slice(0, 2);
    const bar = document.createElement("div");
    bar.className = "bar" + (i === 6 ? " today" : "");
    bar.title = `${d.minutes} min on ${d.day}`;
    bar.innerHTML = `<i class="fill" style="height:${Math.max(3, (d.minutes / max) * 100)}%"></i><span>${day}</span>`;
    week.appendChild(bar);
  });

  const subj = $("#subjects");
  const bySubject = (st.quiz && st.quiz.by_subject) || {};
  subj.innerHTML = Object.keys(bySubject).length ? "" : `<p class="hint">No quiz answers yet. Say “Reachy, quiz me”.</p>`;
  Object.entries(bySubject).forEach(([k, v]) => {
    const color = getComputedStyle(document.documentElement).getPropertyValue(`--subj-${k}`) ? `var(--subj-${k})` : "var(--subj-other)";
    const row = document.createElement("div");
    row.className = "subj";
    row.innerHTML = `<span></span><span>${v.percent}% · ${v.answered} question${v.answered === 1 ? "" : "s"}</span><div class="track"><i style="width:${v.percent}%;background:${color}"></i></div>`;
    row.firstChild.textContent = SUBJECT_NAMES[k] || k;
    subj.appendChild(row);
  });

  const weak = (st.quiz && st.quiz.weakest_topics) || [];
  $("#weak-wrap").hidden = !weak.length;
  $("#weak").innerHTML = "";
  weak.forEach(w => {
    const li = document.createElement("li");
    li.innerHTML = `<span></span> <b>${w.percent}%</b>`;
    li.firstChild.textContent = `${SUBJECT_NAMES[w.subject] || w.subject}: ${w.topic}`;
    $("#weak").appendChild(li);
  });

  const notes = st.notes || [];
  $("#notes-wrap").hidden = !notes.length;
  $("#notes").innerHTML = "";
  notes.slice().reverse().forEach(n => {
    const li = document.createElement("li");
    li.textContent = (n.subject ? `${n.subject}: ` : "") + n.text;
    $("#notes").appendChild(li);
  });
}
function renderSpend(spent, budget) {
  $("#spend").textContent = `$${(spent || 0).toFixed(2)}`;
  $("#spend-sub").textContent = `of $${Number(budget || 0).toFixed(2)} today`;
}

// ---------- system / banner ----------
function renderSystem(sys) {
  S.system = { ...S.system, ...sys };
  const s = S.system;
  const brain = s.brain || {};
  $("#body-line").textContent = `${s.body || "…"} · brain: ${brain.label || "…"} · hearing: ${s.hearing || "…"}`;
  const banner = $("#banner");
  const problems = Object.values(s.problems || {});
  if ((s.body || "").includes("no movement")) {
    banner.hidden = false;
    banner.innerHTML = `<span>Reachy's motors are off (no power), so it can't move. Switch its power on, then press Restart.</span> <button class="btn primary" id="banner-restart">Restart</button>`;
    $("#banner-restart").onclick = restartApp;
  } else if (brain.ready === false) {
    banner.hidden = false;
    banner.innerHTML = `<span></span> <button class="btn" id="banner-settings">Brain settings</button>`;
    banner.firstChild.textContent = `Reachy's brain isn't ready: ${brain.problem}`;
    $("#banner-settings").onclick = openSettings;
  } else if (problems.length) {
    banner.hidden = false;
    banner.textContent = problems.join(" · ");
  } else banner.hidden = true;

  const keyStatus = s.api_key || {};
  $("#key-status").textContent = keyStatus.configured
    ? `Key saved (from ${keyStatus.source}, ends in …${keyStatus.ends_with}).`
    : "No API key yet.";

  fillSelect($("#voice-select"), s.voices, S.settings.voice);
  fillSelect($("#model-select"), s.models, S.settings.model);
  fillSelect($("#local-model-select"), s.local_models, S.settings.local_model);
  $("#brain-status").textContent = brain.ready ? `Using ${brain.label}.` : (brain.problem ? `Not ready: ${brain.problem}` : "");
  showBrainOptions();
  const dl = $("#sysinfo");
  const bank = Object.entries(s.bank || {}).map(([k, v]) => `${k} ${v}`).join(", ");
  const rows = [["Body", s.body], ["Brain", brain.label], ["Hearing", s.hearing], ["Voice", s.voice],
    ["Question bank", bank || "none"], ["Problems", problems.join("; ") || "none"]];
  dl.innerHTML = "";
  rows.forEach(([k, v]) => {
    const dt = document.createElement("dt"); dt.textContent = k;
    const dd = document.createElement("dd"); dd.textContent = v || "";
    if (k === "Problems" && problems.length) dd.className = "bad";
    dl.append(dt, dd);
  });
}
function fillSelect(sel, options, value) {
  if (!options) return;
  const keys = Object.keys(options);
  if (sel.options.length !== keys.length) {
    sel.innerHTML = "";
    keys.forEach(k => sel.add(new Option(options[k], k)));
  }
  if (value) sel.value = value;
}

// ---------- settings ----------
const form = $("#settings-form");
function openSettings() { fillSettings(); $("#settings").showModal(); }
$("#open-settings").onclick = openSettings;
function fillSettings() {
  const s = S.settings;
  for (const el of form.elements) {
    if (!el.name || !(el.name in s)) continue;
    if (el.type === "checkbox") el.checked = !!s[el.name];
    else if (el.type === "radio") el.checked = s[el.name] === el.value;
    else el.value = s[el.name];
  }
  fillSelect($("#voice-select"), S.system.voices, s.voice);
  fillSelect($("#model-select"), S.system.models, s.model);
  fillSelect($("#local-model-select"), S.system.local_models, s.local_model);
  showBrainOptions();
}
function showBrainOptions() {
  const local = (S.settings.brain || "local") === "local";
  $("#local-opts").hidden = !local;
  $("#claude-opts").hidden = local;
}
let saveTimer = null;
const pending = {};
form.addEventListener("input", ev => {
  const el = ev.target;
  if (!el.name) return;
  let value = el.type === "checkbox" ? el.checked : el.type === "number" || el.type === "range" ? Number(el.value) : el.value;
  if (el.type === "radio" && !el.checked) return;
  if (el.name === "theme") applyTheme(value);
  if (el.name === "brain") { S.settings.brain = value; showBrainOptions(); }
  pending[el.name] = value;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    const body = { ...pending };
    Object.keys(pending).forEach(k => delete pending[k]);
    try { S.settings = await api("/api/settings", "PUT", body); renderStatus(); } catch (e) { toast(e.message); }
  }, 400);
});
$("#save-key").onclick = async () => {
  const key = $("#api-key").value.trim();
  if (!key) return;
  try {
    const status = await api("/api/apikey", "PUT", { key });
    $("#api-key").value = "";
    renderSystem({ api_key: status });
  } catch (e) { alert(e.message); }
};
$("#remove-key").onclick = async () => {
  if (!confirm("Remove the saved API key?")) return;
  renderSystem({ api_key: await api("/api/apikey", "PUT", { key: "" }) });
};
$("#test-voice").onclick = () => api("/api/voice/test", "POST");
$("#restart").onclick = () => { $("#settings").close(); restartApp(); };

// ---------- live connection ----------
function handle(msg) {
  switch (msg.type) {
    case "status": S.status = msg; renderStatus(); break;
    case "transcript": addLog(msg.item); break;
    case "turn_start": startLive(); break;
    case "reply_delta": startLive(); $(".txt", liveBubble).textContent += msg.text; scrollLog(); break;
    case "reply_done": endLive(); break;
    case "interrupted": endLive(); break;
    case "card": addCard(msg.card); break;
    case "snapshot": showSnapshot(msg.ts); break;
    case "focus": S.status.focus = msg; renderFocus(msg); break;
    case "timers": renderTimers(msg.timers); break;
    case "stats": renderStats(msg); break;
    case "materials": renderMaterials(msg.items); break;
    case "reading": renderReading(msg.status); break;
    case "attachments": renderChips(msg.items); break;
    case "usage": renderSpend(msg.today_usd, S.settings.daily_budget_usd); break;
    case "system": renderSystem(msg); break;
    case "speaking": S.status.speaking = msg.on; renderStatus(); break;
    case "hearing": S.status.hearing = msg.on; renderStatus(); break;
    case "state": S.status.state = msg.state; renderStatus(); break;
    case "mode": S.status.mode = msg.mode; document.body.dataset.mode = msg.mode; break;
    case "turning_off":
      turnedOff = true;
      restarting = !!msg.restart;
      if (restarting) showOff("Restarting…", "Reachy is restarting. This page reconnects by itself.");
      else showOff("Turning off…", "Reachy is saying bye and going to sleep.");
      break;
    case "tool":
      if (msg.name === "look") toast(msg.args.where === "desk" ? "Reachy is looking at your desk" : "Reachy is looking at what you're holding up");
      break;
    default: break;
  }
}

async function refresh() {
  try {
    const st = await api("/api/state");
    S.settings = st.settings;
    applyTheme(st.settings.theme);
    renderSystem(st.system);
    S.status = st.status;
    renderStatus();
    renderStats(st.stats);
    renderMaterials(st.materials);
    log.innerHTML = "";
    liveBubble = null;
    st.transcript.forEach(addLog);
    $("#cards").innerHTML = "";
    if (!st.cards.length) $("#cards").innerHTML = `<div class="empty">Ask Reachy to explain something, check your working or quiz you. Anything worth reading shows up here.</div>`;
    st.cards.forEach(c => addCard(c, true));
    showSnapshot(st.snapshot_ts);
    $("#f-min").value = st.settings.focus_minutes;
    $("#b-min").value = st.settings.break_minutes;
    $("#cycles").value = st.settings.cycles;
  } catch (e) {
    $("#pill-text").textContent = "Waiting for Reachy…";
    setTimeout(refresh, 1500);
  }
}

// Opened by double-clicking this file instead of through the app: hop over to the running app.
const APP_URL = "http://127.0.0.1:8042/";
async function openFromFile() {
  showOff("Opening Study Buddy…", "Looking for Study Buddy on this laptop.");
  try {
    await fetch(APP_URL + "api/state", { mode: "no-cors", cache: "no-store" });
    location.replace(APP_URL);
    return;
  } catch (e) {
    showOff("Study Buddy isn't running", "Double-click “Study Buddy” on your desktop (or Start Study Buddy.bat). This page will open it by itself once it's up.");
  }
  setTimeout(openFromFile, 2000);
}

function connect() {
  const ws = new WebSocket(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/ws`);
  ws.onopen = () => { if (turnedOff) { turnedOff = false; restarting = false; $("#off-screen").hidden = true; } refresh(); };
  ws.onmessage = ev => { try { handle(JSON.parse(ev.data)); } catch (e) { console.error(e); } };
  ws.onclose = () => {
    if (restarting) showOff("Restarting…", "Reachy is starting up again. This takes about half a minute.");
    else if (turnedOff) showOff("Study Buddy is off", "Reachy is asleep and not listening. Double-click “Start Study Buddy” to turn it back on.");
    else $("#pill-text").textContent = "Reconnecting…";
    setTimeout(connect, turnedOff && !restarting ? 5000 : 1500);
  };
}
if (location.protocol === "file:") openFromFile();
else connect();
