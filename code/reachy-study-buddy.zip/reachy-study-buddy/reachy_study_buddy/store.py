# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Settings, API key and study progress.

Everything lives in the user's app-data folder (``DATA_DIR``) as small JSON files.
The Anthropic API key is kept in Windows Credential Manager via ``keyring``, never
in a file, and is never sent to the web page.
"""

from __future__ import annotations

import copy
import datetime as dt
import json
import logging
import os
import threading
from pathlib import Path
from typing import Any

from platformdirs import user_data_dir

logger = logging.getLogger(__name__)

APP_NAME = "reachy_study_buddy"
_APP_DIR = Path(user_data_dir(APP_NAME, appauthor=False))
MODELS_DIR = _APP_DIR / "models"
# STUDY_BUDDY_DATA points settings, progress and chapters somewhere else (used for testing).
DATA_DIR = Path(os.environ.get("STUDY_BUDDY_DATA") or _APP_DIR)
KEYRING_SERVICE = APP_NAME
KEYRING_USER = "anthropic_api_key"

MODELS = {
    # id: (label, input $/MTok, output $/MTok)
    "claude-opus-5": ("Claude Opus 5 (smartest)", 5.00, 25.00),
    "claude-sonnet-5": ("Claude Sonnet 5 (faster, cheaper)", 2.00, 10.00),
    "claude-haiku-4-5": ("Claude Haiku 4.5 (fastest, cheapest)", 1.00, 5.00),
}

LOCAL_MODELS = {
    # Ollama model: label
    "qwen3.5:4b": "Qwen 3.5 4B (fast, 3.4 GB)",
    "qwen3.5:9b": "Qwen 3.5 9B (smarter, slower, 6.6 GB)",
}

DEFAULT_SETTINGS: dict[str, Any] = {
    "student_name": "",
    "subjects": "Physics, Chemistry, Biology and Maths",
    "brain": "local",  # "local" = free model on this laptop (Ollama); "claude" = Anthropic API key
    "local_model": "qwen3.5:4b",
    "model": "claude-opus-5",
    "effort": "low",
    "daily_budget_usd": 1.00,
    "wake_word": True,
    "conversation_timeout_s": 60,
    "voice": "en_GB-alba-medium",
    "speech_rate": 1.0,
    "volume": 1.0,
    "stt_model": "auto",
    "end_of_speech_ms": 650,
    "focus_minutes": 25,
    "break_minutes": 5,
    "long_break_minutes": 15,
    "cycles": 4,
    "away_after_s": 60,
    "welcome_back_voice": True,
    "theme": "light",
    "mic_muted": False,
}

# Limits applied to anything that comes in from the web page.
_NUMERIC_LIMITS = {
    "daily_budget_usd": (0.0, 20.0),
    "conversation_timeout_s": (10, 600),
    "speech_rate": (0.7, 1.4),
    "volume": (0.1, 1.5),
    "end_of_speech_ms": (400, 2500),
    "focus_minutes": (5, 90),
    "break_minutes": (1, 30),
    "long_break_minutes": (5, 45),
    "cycles": (1, 8),
    "away_after_s": (20, 600),
}
_CHOICES = {
    "brain": {"local", "claude"},
    "local_model": set(LOCAL_MODELS),
    "model": set(MODELS),
    "effort": {"low", "medium", "high"},
    "theme": {"light", "dark", "system"},
    "stt_model": {"auto", "base.en", "small.en", "large-v3-turbo"},
}
_TEXT_FIELDS = {"student_name": 40, "subjects": 200, "voice": 60}
_CHANGED_DEFAULTS = {"end_of_speech_ms": (900, 650)}  # key: (old default, new default)


def _atomic_write(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=1, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)


def _read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return copy.deepcopy(default)
    except (OSError, ValueError) as e:
        logger.warning("Could not read %s (%s); starting fresh", path, e)
        return copy.deepcopy(default)


def today() -> str:
    return dt.date.today().isoformat()


class Settings:
    """User-editable settings, validated on the way in."""

    def __init__(self, path: Path | None = None) -> None:
        self.path = path or DATA_DIR / "settings.json"
        self._lock = threading.Lock()
        stored = _read_json(self.path, {})
        for key, (old_default, new_default) in _CHANGED_DEFAULTS.items():
            if stored.get(key) == old_default:  # never touched by the student: move to the new default
                stored[key] = new_default
        self._data = {**DEFAULT_SETTINGS, **{k: v for k, v in stored.items() if k in DEFAULT_SETTINGS}}

    def get(self, key: str) -> Any:
        with self._lock:
            return self._data[key]

    def all(self) -> dict[str, Any]:
        with self._lock:
            return dict(self._data)

    def update(self, changes: dict[str, Any]) -> dict[str, Any]:
        """Apply the valid parts of ``changes`` and return the new settings."""
        clean: dict[str, Any] = {}
        for key, value in changes.items():
            if key not in DEFAULT_SETTINGS:
                continue
            default = DEFAULT_SETTINGS[key]
            try:
                if isinstance(default, bool):
                    clean[key] = bool(value)
                elif key in _NUMERIC_LIMITS:
                    lo, hi = _NUMERIC_LIMITS[key]
                    num = min(max(float(value), lo), hi)
                    clean[key] = int(num) if isinstance(default, int) else round(num, 2)
                elif key in _CHOICES:
                    if value in _CHOICES[key]:
                        clean[key] = value
                elif key in _TEXT_FIELDS:
                    clean[key] = str(value).strip()[: _TEXT_FIELDS[key]]
            except (TypeError, ValueError):
                continue
        with self._lock:
            self._data.update(clean)
            _atomic_write(self.path, self._data)
            return dict(self._data)


# --- API key -----------------------------------------------------------------

def get_api_key() -> str | None:
    """The environment variable wins, then Windows Credential Manager."""
    env = os.environ.get("ANTHROPIC_API_KEY")
    if env:
        return env.strip()
    try:
        import keyring

        return keyring.get_password(KEYRING_SERVICE, KEYRING_USER)
    except Exception as e:  # keyring backends raise many different types
        logger.warning("Could not read the API key from Credential Manager: %s", e)
        return None


def set_api_key(key: str | None) -> None:
    import keyring

    if key:
        keyring.set_password(KEYRING_SERVICE, KEYRING_USER, key.strip())
        return
    try:
        keyring.delete_password(KEYRING_SERVICE, KEYRING_USER)
    except keyring.errors.PasswordDeleteError:
        pass


def api_key_status() -> dict[str, Any]:
    """All the web page is allowed to know about the key."""
    key = get_api_key()
    if not key:
        return {"configured": False, "source": None, "ends_with": None}
    source = "environment variable" if os.environ.get("ANTHROPIC_API_KEY") else "Windows Credential Manager"
    return {"configured": True, "source": source, "ends_with": key[-4:]}


# --- Progress ----------------------------------------------------------------

EMPTY_PROGRESS: dict[str, Any] = {
    "questions": {},  # question id -> spaced repetition state
    "quiz_log": [],
    "focus_log": [],
    "notes": [],
    "usage": {},  # date -> {"usd": float, "input": int, "output": int}
}


class Progress:
    """Quiz results, focus sessions, notes and API spend."""

    def __init__(self, path: Path | None = None) -> None:
        self.path = path or DATA_DIR / "progress.json"
        self.lock = threading.RLock()
        stored = _read_json(self.path, EMPTY_PROGRESS)
        self.data: dict[str, Any] = {**copy.deepcopy(EMPTY_PROGRESS), **stored}

    def save(self) -> None:
        with self.lock:
            _atomic_write(self.path, self.data)

    # usage and budget
    def add_usage(self, usd: float, input_tokens: int, output_tokens: int) -> float:
        with self.lock:
            day = self.data["usage"].setdefault(today(), {"usd": 0.0, "input": 0, "output": 0})
            day["usd"] = round(day["usd"] + usd, 5)
            day["input"] += input_tokens
            day["output"] += output_tokens
            self.save()
            return day["usd"]

    def spent_today(self) -> float:
        with self.lock:
            return float(self.data["usage"].get(today(), {}).get("usd", 0.0))

    # notes
    def add_note(self, text: str, subject: str | None = None) -> dict[str, Any]:
        note = {"ts": dt.datetime.now().isoformat(timespec="seconds"), "text": text.strip()[:500], "subject": subject}
        with self.lock:
            self.data["notes"].append(note)
            self.data["notes"] = self.data["notes"][-200:]
            self.save()
        return note

    def recent_notes(self, n: int = 8) -> list[dict[str, Any]]:
        with self.lock:
            return list(self.data["notes"][-n:])

    # focus sessions
    def add_focus_block(self, record: dict[str, Any]) -> None:
        with self.lock:
            self.data["focus_log"].append(record)
            self.data["focus_log"] = self.data["focus_log"][-2000:]
            self.save()

    def focus_minutes_on(self, day: str) -> float:
        with self.lock:
            total = sum(r.get("focused_min", 0) for r in self.data["focus_log"] if r.get("start", "").startswith(day))
        return round(total, 1)

    def streak_days(self) -> int:
        """Consecutive days, ending today or yesterday, with focus time or a quiz answer."""
        with self.lock:
            days = {r.get("start", "")[:10] for r in self.data["focus_log"]}
            days |= {r.get("ts", "")[:10] for r in self.data["quiz_log"]}
        streak, d = 0, dt.date.today()
        if d.isoformat() not in days:
            d -= dt.timedelta(days=1)
        while d.isoformat() in days:
            streak += 1
            d -= dt.timedelta(days=1)
        return streak
