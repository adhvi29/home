# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""The tools Claude can use. Each one only touches the robot or this app's own data.

There is deliberately no tool for files, programs or the web.
"""

from __future__ import annotations

import base64
import json
import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .engine import Engine

logger = logging.getLogger(__name__)

GESTURES = ["nod", "shake", "celebrate", "dance", "think", "excited", "happy", "angry", "sad", "surprised", "curious",
            "confused", "proud", "shy", "love", "sleepy", "wiggle", "bow", "search"]
DIRECTIONS = ["left", "right", "up", "down", "up_left", "up_right", "down_left", "down_right", "center"]


def _tool(name: str, description: str, properties: dict[str, Any], required: list[str]) -> dict[str, Any]:
    return {
        "name": name,
        "description": description,
        # Streamed requests: let tool inputs stream as they are generated. We validate them ourselves below.
        "eager_input_streaming": True,
        "input_schema": {"type": "object", "properties": properties, "required": required, "additionalProperties": False},
    }


TOOLS: list[dict[str, Any]] = [
    _tool(
        "look",
        "Take a photo with your head camera and see it. Call this whenever the student shows you something or refers "
        "to 'this', 'here', 'my worksheet', 'my working', a textbook page or a diagram. 'desk' tilts your head down "
        "at paper lying on the desk in front of you; 'ahead' looks straight out at something held up to you.",
        {
            "where": {"type": "string", "enum": ["desk", "ahead"], "description": "Where to point the camera."},
            "reason": {"type": "string", "description": "Short note on what you are looking for."},
        },
        ["where"],
    ),
    _tool(
        "show_on_screen",
        "Show written content on the student's laptop (the Study Buddy page). Use it for anything easier to read than "
        "to hear: worked solutions, equations, step-by-step working, model answers, mark schemes, tables, definitions "
        "to copy down. Then just say a short summary out loud.",
        {
            "title": {"type": "string", "description": "Short heading, e.g. 'Question 3 worked solution'."},
            "markdown": {"type": "string", "description": "The content. Markdown, with LaTeX between $ signs for maths."},
        },
        ["title", "markdown"],
    ),
    _tool(
        "gesture",
        "Show a feeling with your head, antennas and base. Use naturally, not every turn: nod when the student is "
        "right, shake gently when wrong, excited (antennas wag like a tail) or celebrate for full marks, happy, sad "
        "(antennas droop), angry (antennas stiff, only as a joke), surprised, curious, confused, proud, shy, love, "
        "sleepy, think while working something out, dance when asked, search to look around.",
        {"name": {"type": "string", "enum": GESTURES}},
        ["name"],
    ),
    _tool(
        "turn_to",
        "Physically point your head (and turn your base) somewhere. Call this whenever the student asks you to "
        "look or turn in a direction ('look up', 'look left', 'turn right', 'look at the ceiling'). For 'look around' "
        "use gesture 'search'; to see something, use look instead.",
        {
            "direction": {"type": "string", "enum": DIRECTIONS},
            "seconds": {"type": "number", "minimum": 1, "maximum": 15, "description": "How long to hold it (default 4)."},
        },
        ["direction"],
    ),
    _tool(
        "get_quiz_question",
        "Fetch an exam-style question, with its mark scheme, from the student's own study guides. Call when they ask "
        "to be quizzed or tested. The question (not the mark scheme) is shown on their screen automatically. Read it "
        "out, wait for their answer, mark it against the scheme, then call record_quiz_result.",
        {
            "subject": {"type": "string", "description": "physics, chemistry, biology, computer_science, or any."},
            "topic": {"type": "string", "description": "Optional topic words, e.g. 'moles' or 'data transmission'."},
            "prefer": {"type": "string", "enum": ["due", "new", "weak"],
                       "description": "due: spaced-repetition reviews first (default); new: unseen questions; weak: weakest topics."},
        },
        [],
    ),
    _tool(
        "record_quiz_result",
        "Save the mark for a question you just marked, so weak topics come back sooner. Use the question_id from "
        "get_quiz_question, or give subject and topic for a question you wrote yourself.",
        {
            "marks_awarded": {"type": "number"},
            "marks_available": {"type": "number"},
            "question_id": {"type": "string"},
            "subject": {"type": "string"},
            "topic": {"type": "string"},
            "missed_points": {"type": "array", "items": {"type": "string"}, "description": "Mark scheme points they missed."},
        },
        ["marks_awarded", "marks_available"],
    ),
    _tool(
        "start_focus_session",
        "Start a timed focus session: focus blocks separated by breaks. The app handles the countdown, announces "
        "breaks and watches whether the student stays at the desk.",
        {
            "focus_minutes": {"type": "integer", "minimum": 5, "maximum": 90},
            "break_minutes": {"type": "integer", "minimum": 1, "maximum": 30},
            "cycles": {"type": "integer", "minimum": 1, "maximum": 8, "description": "How many focus blocks."},
            "goal": {"type": "string", "description": "What they want to get done, in their words."},
        },
        ["focus_minutes"],
    ),
    _tool(
        "focus_session_control",
        "Pause, resume, stop or skip the current focus session phase (skip ends a block or break early).",
        {"action": {"type": "string", "enum": ["pause", "resume", "stop", "skip"]}},
        ["action"],
    ),
    _tool(
        "set_timer",
        "Start a countdown, e.g. timed exam practice (about a minute per mark) or a reminder. You'll announce when it ends.",
        {"minutes": {"type": "number", "minimum": 0.5, "maximum": 180}, "label": {"type": "string"}},
        ["minutes", "label"],
    ),
    _tool(
        "save_note",
        "Save a short revision note for the student: a mistake they keep making, a formula to learn, a topic to revisit.",
        {"text": {"type": "string"}, "subject": {"type": "string"}},
        ["text"],
    ),
    _tool(
        "get_progress",
        "Get the student's study stats: focus minutes today, streak, quiz scores by subject, weakest topics, saved notes.",
        {},
        [],
    ),
    _tool(
        "start_reading",
        "Start reading mode. Call when the student wants to read a chapter, section or notes aloud to you. After a "
        "very short reply ('Go ahead, I'm listening'), you stay silent while the app writes down everything they read. "
        "They can still ask you things mid-way by saying your name.",
        {
            "title": {"type": "string", "description": "Chapter or section name, e.g. 'Chapter 9: The Mole'."},
            "subject": {"type": "string"},
        },
        [],
    ),
    _tool(
        "finish_reading",
        "End reading mode and save what was read as a chapter. Call when the student says they have finished reading. "
        "Returns the full text they read, so you can summarise it, explain it or quiz them on it.",
        {
            "title": {"type": "string", "description": "Better title, if you now know what the chapter was about."},
            "subject": {"type": "string"},
        },
        [],
    ),
    _tool(
        "open_material",
        "Load the full text of a chapter the student read to you earlier, found by title words (e.g. 'mole', "
        "'chapter 9'). Leave title empty to list everything saved.",
        {"title": {"type": "string"}},
        [],
    ),
    _tool(
        "end_conversation",
        "Go back to quiet standby. Call when the student says goodbye or is done, or asks you to be quiet. You will "
        "only respond again when they say your name.",
        {},
        [],
    ),
]

_SCHEMAS = {t["name"]: t["input_schema"] for t in TOOLS}
_JSON_TYPES = {"string": str, "number": (int, float), "integer": int, "array": list, "object": dict, "boolean": bool}


def validate(name: str, args: Any) -> str | None:
    """Check tool input against its schema. Returns an error message, or None if it's fine."""
    schema = _SCHEMAS.get(name)
    if schema is None:
        return f"Unknown tool {name}"
    if not isinstance(args, dict):
        return "Input must be an object"
    for key in schema["required"]:
        if key not in args:
            return f"Missing required field '{key}'"
    for key, value in args.items():
        spec = schema["properties"].get(key)
        if spec is None:
            return f"Unexpected field '{key}'"
        py = _JSON_TYPES[spec["type"]]
        if isinstance(value, bool) and spec["type"] in ("number", "integer"):
            return f"'{key}' must be a {spec['type']}"
        if not isinstance(value, py):
            return f"'{key}' must be a {spec['type']}"
        if "enum" in spec and value not in spec["enum"]:
            return f"'{key}' must be one of {spec['enum']}"
        if spec["type"] == "array" and not all(isinstance(v, str) for v in value):
            return f"'{key}' must be a list of strings"
    return None


class ToolBox:
    def __init__(self, engine: Engine) -> None:
        self.engine = engine
        self.asked_this_conversation: set[str] = set()

    def reset(self) -> None:
        self.asked_this_conversation.clear()

    def run(self, name: str, args: Any, tool_use_id: str) -> dict[str, Any]:
        """Run one tool call and return the matching tool_result block."""
        problem = validate(name, args)
        if problem:
            return self._error(tool_use_id, json.dumps({"INVALID_INPUT": problem, "received": args}, default=str))
        self.engine.emit("tool", {"name": name, "args": {k: v for k, v in args.items() if k != "markdown"}})
        try:
            content = getattr(self, f"_{name}")(**args)
        except Exception as e:  # noqa: BLE001 - report the failure to Claude instead of crashing the turn
            logger.exception("Tool %s failed", name)
            return self._error(tool_use_id, f"{name} failed: {e}")
        if isinstance(content, str):
            content = [{"type": "text", "text": content}]
        return {"type": "tool_result", "tool_use_id": tool_use_id, "content": content}

    @staticmethod
    def _error(tool_use_id: str, message: str) -> dict[str, Any]:
        return {"type": "tool_result", "tool_use_id": tool_use_id, "is_error": True, "content": message}

    # --- handlers ------------------------------------------------------------------
    def _look(self, where: str, reason: str = "") -> list[dict[str, Any]] | str:
        jpeg, note = self.engine.look(where)
        if jpeg is None:
            return f"Camera unavailable: {note}"
        return [
            {"type": "text", "text": f"Photo from your camera ({where}). {note}".strip()},
            {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": base64.b64encode(jpeg).decode()}},
        ]

    def _show_on_screen(self, title: str, markdown: str) -> str:
        self.engine.show_card(title[:120], markdown[:20000])
        return "Shown on the student's screen."

    def _gesture(self, name: str) -> str:
        self.engine.gesture(name)
        return "ok"

    def _turn_to(self, direction: str, seconds: float = 4.0) -> str:
        if not self.engine.turn_to(direction, seconds):
            return "Your motors are off right now, so you can't move. Tell the student."
        return f"Turned {direction.replace('_', ' ')} for {seconds:g} s, then you'll look back at the student."

    def _get_quiz_question(self, subject: str = "", topic: str = "", prefer: str = "due") -> str:
        q, why = self.engine.quiz.pick(subject or None, topic or None, prefer, exclude=self.asked_this_conversation)
        if q is None:
            return why
        self.asked_this_conversation.add(q["id"])
        self.engine.show_question(q)
        st = self.engine.quiz.state(q["id"])
        payload = {
            "question_id": q["id"],
            "subject": q["subject"],
            "topic": q["topic"],
            "total_marks": q["marks"],
            "type": "multiple choice" if q["kind"] == "mcq" else "written",
            "extended_tier_only": q.get("extended", False),
            "question": q["text"],
            "mark_scheme_do_not_reveal_until_answered": q["mark_scheme"],
            "examiner_notes": q.get("notes", ""),
            "shown_on_screen": True,
            "previous_attempts": ({"times": st.get("seen", 0), "last_score": st.get("last_score")} if st else None),
        }
        return json.dumps(payload, ensure_ascii=False)

    def _record_quiz_result(self, marks_awarded: float, marks_available: float, question_id: str = "",
                            subject: str = "", topic: str = "", missed_points: list[str] | None = None) -> str:
        entry = self.engine.quiz.record(marks_awarded, marks_available, question_id or None, subject or None,
                                        topic or None, missed_points)
        q = self.engine.quiz.questions.get(question_id or "")
        if q:
            self.engine.show_mark_scheme(q, entry)
        ratio = entry["got"] / entry["out_of"]
        self.engine.gesture("excited" if ratio >= 0.99 else "happy" if ratio >= 0.5 else "sad")  # feel it too
        self.engine.push_stats()
        return f"Saved: {entry['got']:g}/{entry['out_of']:g} for {entry['subject']} / {entry['topic']}."

    def _start_focus_session(self, focus_minutes: int, break_minutes: int | None = None, cycles: int | None = None,
                             goal: str = "") -> str:
        s = self.engine.start_focus(focus_minutes, break_minutes, cycles, goal, from_claude=True)
        return f"Focus session started: {s['cycles']} x {s['focus_min']:g} min, {s['break_min']:g} min breaks."

    def _focus_session_control(self, action: str) -> str:
        coach = self.engine.focus
        result = {"pause": coach.pause, "resume": coach.resume, "stop": coach.stop, "skip": coach.skip}[action]()
        self.engine.push_focus()
        return json.dumps(result, default=str)

    def _set_timer(self, minutes: float, label: str) -> str:
        t = self.engine.timers.add(minutes, label)
        return f"Timer '{t['label']}' set for {t['minutes']:g} min."

    def _save_note(self, text: str, subject: str = "") -> str:
        self.engine.progress.add_note(text, subject or None)
        self.engine.push_stats()
        return "Note saved."

    def _get_progress(self) -> str:
        return json.dumps(self.engine.stats(), ensure_ascii=False, default=str)

    def _start_reading(self, title: str = "", subject: str = "") -> str:
        status = self.engine.start_reading(title, subject)
        return (f"Reading mode will start as soon as you finish speaking (saving as '{status['title']}'). "
                "Keep your reply to a few words.")

    def _finish_reading(self, title: str = "", subject: str = "") -> str:
        item = self.engine.finish_reading(title, subject)
        if item is None:
            return "Reading mode is off and nothing was recorded."
        text = self.engine.materials.get(item["id"])["text"]
        self.engine.materials_sent.add(item["id"])  # it's in the conversation now; don't attach it again
        return json.dumps({"saved_as": item["title"], "subject": item["subject"], "words": item["words"],
                           "note": "This is a speech-recognition transcript, so expect some misheard words.",
                           "text": text}, ensure_ascii=False)

    def _open_material(self, title: str = "") -> str:
        mats = self.engine.materials
        if not title.strip():
            items = mats.list()
            if not items:
                return "No chapters saved yet."
            return json.dumps([{"title": i["title"], "subject": i["subject"], "words": i["words"], "date": i["created"][:10]}
                               for i in items[:30]], ensure_ascii=False)
        item = mats.find(title)
        if item is None:
            return "No saved chapter matches that. Call open_material with an empty title to list them."
        mats.set_active(item["id"])
        self.engine.materials_sent.add(item["id"])
        self.engine.push_materials()
        return json.dumps({"title": item["title"], "subject": item["subject"], "words": item["words"],
                           "date": item["created"][:10], "text": item["text"]}, ensure_ascii=False)

    def _end_conversation(self) -> str:
        self.engine.request_standby()
        return "Going to standby after this reply. Say a short goodbye."
