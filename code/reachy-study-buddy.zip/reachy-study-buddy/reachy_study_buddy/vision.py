# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Face following: finds the student's face in Reachy's camera about 15 times a second.

Uses Pollen's YuNet face detector from the Reachy Mini SDK (ONNX, no GStreamer), then
turns the face's pixel position into real angles with the camera's calibrated lens model
(Pollen's intrinsics and distortion for the Lite camera). The motion loop pairs each
angle with where the head was pointing when that frame was taken, so it doesn't overshoot.
"""

from __future__ import annotations

import logging
import math
import threading
import time
from typing import Callable

import numpy as np

logger = logging.getLogger(__name__)


def lens_model(width: int, height: int) -> tuple[np.ndarray, np.ndarray] | None:
    """Camera matrix and distortion for Reachy Mini Lite's camera at this frame size."""
    try:
        from reachy_mini.media.camera_constants import CameraResolution, ReachyMiniLiteCamSpecs
        from reachy_mini.media.camera_utils import scale_intrinsics
    except Exception as e:  # noqa: BLE001
        logger.info("No camera calibration available: %s", e)
        return None
    full = CameraResolution.R3840x2592at30fps.value
    for res in CameraResolution:
        w, h, _fps, crop = res.value
        if (w, h) == (width, height):
            K = scale_intrinsics(ReachyMiniLiteCamSpecs.K, (full[0], full[1]), (w, h), crop)
            return K, np.asarray(ReachyMiniLiteCamSpecs.D, dtype=np.float64)
    return None


class FaceFollower(threading.Thread):
    RATE_HZ = 15

    def __init__(self, get_frame: Callable[[], tuple[np.ndarray, float] | None],
                 on_face: Callable[[float, float, float], None]) -> None:
        """``on_face(yaw_offset_deg, pitch_offset_deg, captured_at)``: how far to turn to face the
        student, relative to where the head pointed when the frame was captured."""
        super().__init__(name="face-follower", daemon=True)
        self.get_frame = get_frame
        self.on_face = on_face
        self.stop_event = threading.Event()
        self.last_update = 0.0
        self.last_seen = 0.0
        self.ok = True
        self._lens: tuple[int, int, tuple[np.ndarray, np.ndarray] | None] | None = None

    def stop(self) -> None:
        self.stop_event.set()

    def present(self) -> bool | None:
        """True/False once the camera is working, None when we can't tell."""
        now = time.monotonic()
        if not self.ok or now - self.last_update > 3.0:
            return None
        return now - self.last_seen < 1.5

    def _angles(self, u: float, v: float, width: int, height: int) -> tuple[float, float]:
        """Pixel -> (yaw, pitch) offset in degrees. Positive yaw = turn left, positive pitch = look down."""
        import cv2

        if self._lens is None or self._lens[:2] != (width, height):
            self._lens = (width, height, lens_model(width, height))
        model = self._lens[2]
        if model is not None:
            K, D = model
            xn, yn = cv2.undistortPoints(np.array([[[u, v]]], dtype=np.float64), K, D).reshape(2)
        else:  # rough fallback: ~81 x 52 degree view
            xn = (u - width / 2) / (width / 2) * math.tan(math.radians(40.7))
            yn = (v - height / 2) / (height / 2) * math.tan(math.radians(25.8))
        return -math.degrees(math.atan(xn)), math.degrees(math.atan(yn))

    def run(self) -> None:
        import cv2

        try:
            from reachy_mini.vision.face_detector import FaceDetector

            detector = FaceDetector()
        except Exception as e:  # noqa: BLE001 - no detector means no face following, not a crash
            logger.warning("Face detector unavailable: %s", e)
            self.ok = False
            return
        period = 1.0 / self.RATE_HZ
        last_frame_t = 0.0
        while not self.stop_event.is_set():
            t0 = time.monotonic()
            got = self.get_frame()
            if got is not None and got[1] != last_frame_t:
                frame, captured_at = got
                last_frame_t = captured_at
                h, w = frame.shape[:2]
                scale = 640 / w
                small = cv2.resize(frame, (640, int(round(h * scale))))
                try:
                    faces = detector.detect(small)
                except Exception as e:  # noqa: BLE001
                    logger.debug("Face detection failed: %s", e)
                    faces = []
                self.last_update = time.monotonic()
                if faces:
                    # The biggest face is the student sitting in front of Reachy.
                    fx, fy, fw, fh = max(faces, key=lambda f: f.bbox[2] * f.bbox[3]).bbox
                    u, v = (fx + fw / 2) / scale, (fy + fh * 0.45) / scale  # aim near the eyes
                    yaw, pitch = self._angles(u, v, w, h)
                    self.last_seen = self.last_update
                    self.on_face(yaw, pitch, captured_at)
            time.sleep(max(0.0, period - (time.monotonic() - t0)))
