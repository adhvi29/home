# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Voice: Piper text-to-speech, played one sentence at a time.

Claude's reply streams in token by token. ``SentenceChunker`` cuts it into sentences,
``Speaker`` synthesises each sentence on this computer and pushes 16 kHz audio to the
robot's speaker (or the laptop's), so Reachy starts talking before the reply is done.
"""

from __future__ import annotations

import logging
import queue
import re
import threading
import time
import urllib.request
from pathlib import Path
from typing import Callable

import numpy as np

from .store import MODELS_DIR

logger = logging.getLogger(__name__)

OUT_RATE = 16000  # Reachy Mini's speaker runs at 16 kHz

VOICES = {
    # name: (label, path in the rhasspy/piper-voices repo)
    "en_GB-alba-medium": ("British English, female (Alba)", "en/en_GB/alba/medium"),
    "en_GB-jenny_dioco-medium": ("British English, female (Jenny)", "en/en_GB/jenny_dioco/medium"),
    "en_GB-northern_english_male-medium": ("British English, male", "en/en_GB/northern_english_male/medium"),
    "en_US-lessac-medium": ("American English, female (Lessac)", "en/en_US/lessac/medium"),
    "en_US-amy-medium": ("American English, female (Amy)", "en/en_US/amy/medium"),
    "en_US-ryan-medium": ("American English, male (Ryan)", "en/en_US/ryan/medium"),
}
_VOICE_URL = "https://huggingface.co/rhasspy/piper-voices/resolve/main/{path}/{name}.{ext}"


def ensure_voice(name: str) -> Path:
    """Path to the voice model, downloading it from Hugging Face the first time."""
    if name not in VOICES:
        raise ValueError(f"Unknown voice {name}")
    folder = MODELS_DIR / "piper"
    folder.mkdir(parents=True, exist_ok=True)
    model = folder / f"{name}.onnx"
    for ext in ("onnx", "onnx.json"):
        target = folder / f"{name}.{ext}"
        if target.exists() and target.stat().st_size > 0:
            continue
        url = _VOICE_URL.format(path=VOICES[name][1], name=name, ext=ext)
        logger.info("Downloading voice %s", url)
        tmp = target.with_suffix(target.suffix + ".part")
        with urllib.request.urlopen(url, timeout=60) as resp, open(tmp, "wb") as f:
            while chunk := resp.read(1 << 16):
                f.write(chunk)
        tmp.replace(target)
    return model


# --- Resampling --------------------------------------------------------------

def _lowpass(cutoff_hz: float, rate: int, taps: int = 63) -> np.ndarray:
    n = np.arange(taps) - (taps - 1) / 2
    h = np.sinc(2 * cutoff_hz / rate * n) * np.hamming(taps)
    return (h / h.sum()).astype(np.float32)


def resample(x: np.ndarray, rate_in: int, rate_out: int = OUT_RATE) -> np.ndarray:
    """Band-limit, then interpolate. Plenty for speech."""
    if rate_in == rate_out or x.size == 0:
        return x.astype(np.float32)
    if rate_out < rate_in:
        x = np.convolve(x, _lowpass(0.45 * rate_out, rate_in), mode="same")
    n_out = int(round(x.size * rate_out / rate_in))
    t = np.arange(n_out) * (rate_in / rate_out)
    return np.interp(t, np.arange(x.size), x).astype(np.float32)


# --- Making text sound right out loud -----------------------------------------

_SUP = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺", "0123456789-+")
_SUB = str.maketrans("₀₁₂₃₄₅₆₇₈₉", "0123456789")
_SQ, _CU = r"(?:²|\^2)", r"(?:³|\^3)"

# Units a science student hears all the time, said the way a teacher says them.
_UNITS = [
    (rf"\bm\s*/\s*s{_SQ}|\bm\s*s⁻²", "metres per second squared"),
    (r"\bm\s*/\s*s\b|\bm\s*s⁻¹", "metres per second"),
    (r"\bkm\s*/\s*h\b", "kilometres per hour"),
    (rf"\bg\s*/\s*cm{_CU}", "grams per cubic centimetre"),
    (rf"\bkg\s*/\s*m{_CU}", "kilograms per cubic metre"),
    (rf"\bmol\s*/\s*dm{_CU}", "moles per cubic decimetre"),
    (rf"\bg\s*/\s*dm{_CU}", "grams per cubic decimetre"),
    (r"\bg\s*/\s*mol\b", "grams per mole"),
    (rf"\bN\s*/\s*m{_SQ}", "newtons per square metre"),
    (rf"(\d)\s*cm{_CU}", r"\1 cubic centimetres"),
    (rf"(\d)\s*dm{_CU}", r"\1 cubic decimetres"),
    (rf"(\d)\s*m{_CU}", r"\1 cubic metres"),
    (rf"(\d)\s*cm{_SQ}", r"\1 square centimetres"),
    (rf"(\d)\s*m{_SQ}", r"\1 square metres"),
]
_REPLACEMENTS = [
    (r"\be\.g\.", "for example"),
    (r"\bi\.e\.", "that is"),
    (r"\betc\.", "and so on"),
    (r"\bvs\.?", "versus"),
    (r"°C\b", " degrees Celsius"),
    (r"°", " degrees"),
    (r"%", " percent"),
    (r"→|->|⟶", " gives "),
    (r"⇌", " is in equilibrium with "),
    (r"½", " a half"),
    (r"¼", " a quarter"),
    (r"(\d)\s*[×x]\s*10\^?\(?([-+]?\d+)\)?", r"\1 times ten to the power \2"),  # 6.02 × 10^23
    (r"(\w)\^\(?([-+]?\d+)\)?", r"\1 to the power \2"),
    (r"×", " times "),
    (r"÷", " divided by "),
    (r"±", " plus or minus "),
    (r"≈", " approximately "),
    (r"≠", " is not equal to "),
    (r"≤", " is less than or equal to "),
    (r"≥", " is greater than or equal to "),
    (r"√", " square root of "),
    (r"π", " pi "),
    (r"Δ", " change in "),
    (r"µ|μ", " micro"),
    (r"Ω", " ohms"),
    (r"&", " and "),
    (r"([\d)])\s+-\s+([\d(])", r"\1 minus \2"),
    (r"([\d)])\s*/\s*([\d(])", r"\1 divided by \2"),
    (r"\s=\s", " equals "),
    (r"(^|\n)\s*[-•]\s+", r"\1"),  # list bullets
    (r"\s[-, , ]\s", ", "),  # dashes used as pauses
]
_EMOJI = re.compile("[\U0001F000-\U0001FAFF☀-➿️]")


def _powers(t: str) -> str:
    """10²³ -> 10 to the power 23, x² -> x squared, mol⁻¹ -> mol to the power -1."""
    def multi(m: re.Match[str]) -> str:
        return f"{m.group(1)} to the power {m.group(2).translate(_SUP)}"

    t = re.sub(r"(\w)([⁻⁺]?[⁰¹²³⁴⁵⁶⁷⁸⁹]{2,}|[⁻⁺][⁰¹²³⁴⁵⁶⁷⁸⁹]+)", multi, t)
    t = re.sub(r"(\w)²|(\w)\^2\b", lambda m: f"{m.group(1) or m.group(2)} squared", t)
    t = re.sub(r"(\w)³|(\w)\^3\b", lambda m: f"{m.group(1) or m.group(2)} cubed", t)
    return t.translate(_SUP)


def to_speech(text: str) -> str:
    """Strip markdown and swap symbols for words a speaker can say."""
    t = re.sub(r"```.*?```", " ", text, flags=re.S)  # never read code blocks aloud
    t = re.sub(r"<sub>(.*?)</sub>", r" \1", t)  # A<sub>r</sub> -> A r
    t = re.sub(r"<[^>\n]{1,40}>", " ", t)  # any other stray HTML tag
    t = re.sub(r"https?://\S+", " a link ", t)
    t = re.sub(r"\$\$?([^$]+)\$\$?", r"\1", t)  # LaTeX delimiters
    t = re.sub(r"[*_#`>|~]+", " ", t)
    t = _EMOJI.sub(" ", t)
    t = t.translate(_SUB)  # H₂O -> H2O, which the voice reads as "H two O"
    for pattern, spoken in _UNITS:
        t = re.sub(pattern, spoken, t)
    t = re.sub(r"(\d)\s*[×x]\s*10([⁻⁺]?[⁰¹²³⁴⁵⁶⁷⁸⁹]+)", lambda m: f"{m.group(1)} times ten to the power {m.group(2).translate(_SUP)}", t)
    t = _powers(t)
    for pattern, spoken in _REPLACEMENTS:
        t = re.sub(pattern, spoken, t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


class SentenceChunker:
    """Collects streamed text and releases whole sentences."""

    _ABBREV = ("e.g.", "i.e.", "etc.", "vs.", "mr.", "mrs.", "ms.", "dr.", "no.", "fig.", "approx.")

    def __init__(self, min_chars: int = 12) -> None:
        self.buf = ""
        self.min_chars = min_chars
        self.first = True  # the first chunk may be cut at a comma, so Reachy starts talking sooner

    def feed(self, delta: str) -> list[str]:
        self.buf += delta
        out: list[str] = []
        while True:
            cut = self._find_cut()
            if cut is None:
                break
            sentence, self.buf = self.buf[:cut].strip(), self.buf[cut:]
            if sentence:
                out.append(sentence)
                self.first = False
        return out

    def flush(self) -> str:
        rest, self.buf = self.buf.strip(), ""
        return rest

    def _find_cut(self) -> int | None:
        for m in re.finditer(r"[.!?…]+[\"')\]]*(\s+)|\n+", self.buf):
            end = m.end()
            head = self.buf[: m.start() + 1].strip()
            if len(head) < self.min_chars:
                continue
            if head.lower().endswith(self._ABBREV):
                continue
            if re.search(r"\d\.$", head) and re.match(r"\d", self.buf[m.end():m.end() + 1] or ""):
                continue  # a decimal point, not a full stop
            return end
        # First words of a reply: a clause is enough to start speaking.
        if self.first and len(self.buf) >= 28:
            m = re.search(r"[,;:]\s", self.buf[20:])
            if m:
                return 20 + m.end()
        # Very long run-on sentence: break at a comma so speech can start.
        if len(self.buf) > 220:
            comma = self.buf.rfind(", ", 0, 200)
            if comma > 60:
                return comma + 2
        return None


# --- TTS engine ---------------------------------------------------------------

class PiperTTS:
    def __init__(self, voice: str) -> None:
        self.lock = threading.Lock()
        self.voice_name = ""
        self.voice = None
        self.load(voice)

    def load(self, voice: str) -> None:
        import onnxruntime as ort
        from piper import PiperVoice

        path = ensure_voice(voice)
        v = PiperVoice.load(str(path))
        # One thread is fastest on this kind of laptop CPU (measured: 0.12x real time).
        opts = ort.SessionOptions()
        opts.intra_op_num_threads = 1
        opts.inter_op_num_threads = 1
        v.session = ort.InferenceSession(str(path), sess_options=opts, providers=["CPUExecutionProvider"])
        with self.lock:
            self.voice, self.voice_name = v, voice
        logger.info("Voice ready: %s", voice)

    def synth(self, text: str, rate: float = 1.0, volume: float = 1.0) -> np.ndarray:
        from piper.config import SynthesisConfig

        text = to_speech(text)
        if not text:
            return np.zeros(0, dtype=np.float32)
        with self.lock:
            voice = self.voice
            cfg = SynthesisConfig(length_scale=1.0 / max(0.5, rate))
            chunks = list(voice.synthesize(text, syn_config=cfg))
            sr = voice.config.sample_rate
        if not chunks:
            return np.zeros(0, dtype=np.float32)
        audio = np.concatenate([c.audio_float_array for c in chunks]).astype(np.float32)
        audio = resample(audio, sr, OUT_RATE)
        return np.clip(audio * volume * 0.9, -1.0, 1.0)


def chirp(kind: str = "listen") -> np.ndarray:
    """Tiny synthesised sound effects, so no sound files are needed."""
    notes = {"listen": [(880, 0.07), (1320, 0.09)], "done": [(1320, 0.07), (880, 0.09)], "alarm": [(988, 0.12), (0, 0.06)] * 3}[kind]
    out = []
    for freq, dur in notes:
        t = np.arange(int(OUT_RATE * dur)) / OUT_RATE
        env = np.minimum(1, np.minimum(t, dur - t) / 0.01)
        out.append(0.25 * np.sin(2 * np.pi * freq * t) * env if freq else np.zeros_like(t))
    return np.concatenate(out).astype(np.float32)


class Speaker(threading.Thread):
    """Speaks queued sentences in order and knows when Reachy is still talking."""

    TAIL_S = 0.35  # keep the mic closed a little after the last word (room echo)

    def __init__(
        self,
        tts: PiperTTS,
        play: Callable[[np.ndarray], None],
        flush: Callable[[], None],
        get_rate: Callable[[], float],
        get_volume: Callable[[], float],
        on_state: Callable[[bool], None],
    ) -> None:
        super().__init__(name="speaker", daemon=True)
        self.tts = tts
        self.play = play
        self.flush = flush
        self.get_rate = get_rate
        self.get_volume = get_volume
        self.on_state = on_state
        self.q: queue.Queue[tuple[int, str | np.ndarray]] = queue.Queue()
        self.generation = 0
        self.speaking_until = 0.0
        self.working = False
        self.stop_event = threading.Event()
        self._was_busy = False
        self._lock = threading.Lock()

    # public API
    def say(self, text: str) -> None:
        if text.strip():
            self.q.put((self.generation, text))

    def sound(self, audio: np.ndarray) -> None:
        self.q.put((self.generation, audio))

    def interrupt(self) -> None:
        with self._lock:
            self.generation += 1
            while True:
                try:
                    self.q.get_nowait()
                except queue.Empty:
                    break
            self.speaking_until = 0.0
        try:
            self.flush()
        except Exception as e:  # noqa: BLE001
            logger.warning("Could not flush audio: %s", e)

    @property
    def busy(self) -> bool:
        return self.working or not self.q.empty() or time.monotonic() < self.speaking_until + self.TAIL_S

    def wait_done(self, timeout: float = 60.0, cancel: threading.Event | None = None) -> None:
        end = time.monotonic() + timeout
        while self.busy and time.monotonic() < end:
            if cancel is not None and cancel.is_set():
                return
            time.sleep(0.05)

    def stop(self) -> None:
        self.stop_event.set()

    def run(self) -> None:
        while not self.stop_event.is_set():
            self._report_state()
            try:
                gen, item = self.q.get(timeout=0.1)
            except queue.Empty:
                continue
            if gen != self.generation:
                continue
            self.working = True
            try:
                audio = item if isinstance(item, np.ndarray) else self.tts.synth(item, self.get_rate(), self.get_volume())
                with self._lock:
                    if gen != self.generation or audio.size == 0:
                        continue
                    now = time.monotonic()
                    start = max(now, self.speaking_until)
                    self.speaking_until = start + audio.size / OUT_RATE
                self.play(audio)
            except Exception as e:  # noqa: BLE001 - one bad sentence must not kill the voice
                logger.warning("Speech failed: %s", e)
            finally:
                self.working = False

    def _report_state(self) -> None:
        busy = self.busy
        if busy != self._was_busy:
            self._was_busy = busy
            try:
                self.on_state(busy)
            except Exception:  # noqa: BLE001
                pass
