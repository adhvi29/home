# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""The Study Buddy web page's API.

Safety rules, because this runs on your laptop:
- the server listens on 127.0.0.1 only, so nobody else on the Wi-Fi can reach it;
- requests must be addressed to localhost (blocks DNS-rebinding tricks);
- every request that changes something must carry the X-Study-Buddy header, which a
  random website in another tab cannot add without the browser asking us first
  (and we never say yes), so other sites can't drive Reachy or read your chats;
- the WebSocket only accepts connections from this page's own origin;
- the API key can be written but never read back.
"""

from __future__ import annotations

import asyncio
import json
import logging
import threading
from pathlib import Path
from typing import TYPE_CHECKING, Any

from fastapi import FastAPI, File, HTTPException, Request, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from .store import api_key_status, set_api_key

if TYPE_CHECKING:
    from .engine import Engine

logger = logging.getLogger(__name__)

STATIC_DIR = Path(__file__).parent / "static"
ALLOWED_HOSTS = {"127.0.0.1", "localhost"}


class Hub:
    """Fans engine events out to every open page. Safe to call from any thread."""

    def __init__(self) -> None:
        self.clients: set[tuple[asyncio.AbstractEventLoop, asyncio.Queue[str]]] = set()
        self.lock = threading.Lock()

    def broadcast(self, msg: dict[str, Any]) -> None:
        text = json.dumps(msg, default=str)
        with self.lock:
            clients = list(self.clients)
        for loop, q in clients:
            try:
                loop.call_soon_threadsafe(_put_latest, q, text)
            except RuntimeError:  # loop closed
                with self.lock:
                    self.clients.discard((loop, q))


def _put_latest(q: asyncio.Queue[str], text: str) -> None:
    if q.full():  # a slow page drops old status updates rather than stalling the robot
        try:
            q.get_nowait()
        except asyncio.QueueEmpty:
            pass
    q.put_nowait(text)


def _host_ok(host_header: str | None) -> bool:
    host = (host_header or "").rsplit(":", 1)[0].strip("[]").lower()
    return host in ALLOWED_HOSTS


def install(app: FastAPI, engine_ref: dict[str, Engine | None], hub: Hub, serve_static: bool) -> None:
    """Add the Study Buddy routes to ``app``. ``engine_ref['engine']`` is filled in once the robot is up."""

    def eng() -> Engine:
        e = engine_ref.get("engine")
        if e is None:
            raise HTTPException(503, "Reachy is still starting up")
        return e

    @app.middleware("http")
    async def guard(request: Request, call_next):  # noqa: ANN001, ANN202
        if not _host_ok(request.headers.get("host")):
            return JSONResponse({"detail": "Forbidden host"}, status_code=403)
        if request.url.path.startswith("/api/") and request.method not in ("GET", "HEAD", "OPTIONS"):
            if request.headers.get("x-study-buddy") != "1":
                return JSONResponse({"detail": "Missing X-Study-Buddy header"}, status_code=403)
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        return response

    if serve_static:
        app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

        @app.get("/")
        async def index() -> FileResponse:
            return FileResponse(STATIC_DIR / "index.html")

    # The page links its files relatively ("main.js"), so they're also served from the root.
    @app.get("/main.js")
    async def main_js() -> FileResponse:
        return FileResponse(STATIC_DIR / "main.js", media_type="text/javascript")

    @app.get("/style.css")
    async def style_css() -> FileResponse:
        return FileResponse(STATIC_DIR / "style.css", media_type="text/css")

    @app.get("/api/state")
    async def state() -> dict[str, Any]:
        return eng().snapshot_state()

    @app.get("/api/snapshot")
    async def snapshot() -> Response:
        e = eng()
        if not e.snapshot:
            raise HTTPException(404, "No photo yet")
        return Response(e.snapshot, media_type="image/jpeg")

    @app.post("/api/say")
    async def say(body: dict[str, Any]) -> dict[str, bool]:
        text = str(body.get("text", "")).strip()[:4000]
        if text:
            eng().post("typed", text)
        return {"ok": True}

    @app.post("/api/talk")
    async def talk() -> dict[str, bool]:
        eng().post("talk")
        return {"ok": True}

    @app.post("/api/stop")
    async def stop() -> dict[str, bool]:
        eng().post("stop")
        return {"ok": True}

    @app.post("/api/turn-off")
    async def turn_off() -> dict[str, bool]:
        eng().post("turn_off")
        return {"ok": True}

    @app.post("/api/restart")
    async def restart() -> dict[str, bool]:
        eng().post("restart")
        return {"ok": True}

    @app.post("/api/mute")
    async def mute(body: dict[str, Any]) -> dict[str, Any]:
        s = eng().settings.update({"mic_muted": bool(body.get("muted"))})
        return {"muted": s["mic_muted"]}

    @app.post("/api/focus")
    async def focus(body: dict[str, Any]) -> dict[str, Any]:
        e = eng()
        action = body.get("action")
        done = threading.Event()
        result: dict[str, Any] = {}

        def run() -> None:
            try:
                if action == "start":
                    result.update(e.start_focus(float(body.get("focus_min") or 0), float(body.get("break_min") or 0),
                                                int(body.get("cycles") or 0), str(body.get("goal", ""))[:200]))
                elif action in ("pause", "resume", "stop", "skip"):
                    getattr(e.focus, action)()
                    result.update(e.focus.status())
                e.push_focus()
            finally:
                done.set()

        e.post("call", run)
        await asyncio.to_thread(done.wait, 5)
        return result

    @app.post("/api/timer")
    async def timer(body: dict[str, Any]) -> dict[str, Any]:
        e = eng()
        if body.get("cancel") is not None:
            e.post("call", lambda: e.timers.cancel(int(body["cancel"])))
        else:
            minutes = float(body.get("minutes") or 0)
            if minutes <= 0:
                raise HTTPException(400, "minutes must be positive")
            e.post("call", lambda: e.timers.add(minutes, str(body.get("label", "Timer"))[:80]))
        return {"ok": True}

    @app.post("/api/reading")
    async def reading(body: dict[str, Any]) -> dict[str, bool]:
        action = "start" if body.get("action") == "start" else "finish"
        eng().post("reading", (action, str(body.get("title", ""))[:120], str(body.get("subject", ""))[:40]))
        return {"ok": True}

    @app.get("/api/materials/{mid}")
    async def material(mid: str) -> dict[str, Any]:
        item = eng().materials.get(mid)
        if item is None:
            raise HTTPException(404, "Not found")
        return item

    @app.put("/api/materials/{mid}")
    async def material_update(mid: str, body: dict[str, Any]) -> dict[str, Any]:
        e = eng()
        if "title" in body or "subject" in body:
            e.materials.rename(mid, str(body.get("title", "")), body.get("subject"))
        if "text" in body:
            e.materials.update_text(mid, str(body["text"]))
            e.materials_sent.discard(mid)  # send the corrected version next time
        if body.get("active"):
            e.materials.set_active(mid)
            e.materials_sent.discard(mid)
        e.push_materials()
        return {"ok": True}

    @app.delete("/api/materials/{mid}")
    async def material_delete(mid: str) -> dict[str, bool]:
        e = eng()
        e.materials.delete(mid)
        e.push_materials()
        return {"ok": True}

    @app.post("/api/upload")
    async def upload(file: UploadFile = File(...)) -> dict[str, Any]:
        data = await file.read(25 * 1024 * 1024 + 1)
        if len(data) > 25 * 1024 * 1024:
            raise HTTPException(413, "File too large (25 MB max)")
        try:
            return eng().add_attachment(file.filename or "file", data, file.content_type or "")
        except ValueError as err:
            raise HTTPException(400, str(err)) from err

    @app.delete("/api/upload")
    async def clear_uploads() -> dict[str, bool]:
        eng().clear_attachments()
        return {"ok": True}

    @app.get("/api/settings")
    async def get_settings() -> dict[str, Any]:
        return eng().settings.all()

    @app.put("/api/settings")
    async def put_settings(body: dict[str, Any]) -> dict[str, Any]:
        e = eng()
        before = e.settings.all()
        after = e.settings.update(body)
        if after["voice"] != before["voice"]:
            e.post("reload_voice")
        e.emit("system", e.system_info())
        return after

    @app.put("/api/apikey")
    async def put_key(body: dict[str, Any]) -> dict[str, Any]:
        key = str(body.get("key", "")).strip()
        if key and not key.startswith("sk-ant-"):
            raise HTTPException(400, "That doesn't look like an Anthropic API key (they start with sk-ant-).")
        try:
            set_api_key(key or None)
        except Exception as err:  # noqa: BLE001
            raise HTTPException(500, f"Couldn't save the key: {err}") from err
        e = engine_ref.get("engine")
        if e:
            e.emit("system", e.system_info())
        return api_key_status()

    @app.post("/api/voice/test")
    async def voice_test() -> dict[str, bool]:
        e = eng()
        name = e.settings.get("student_name").strip()
        e.post("call", lambda: e.announce(f"Hi{' ' + name if name else ''}! This is how I sound. Shall we get studying?", "wiggle"))
        return {"ok": True}

    @app.websocket("/ws")
    async def ws(socket: WebSocket) -> None:
        origin = socket.headers.get("origin")
        if not _host_ok(socket.headers.get("host")) or (origin is not None and not _origin_ok(origin)):
            await socket.close(code=1008)
            return
        await socket.accept()
        loop = asyncio.get_running_loop()
        q: asyncio.Queue[str] = asyncio.Queue(maxsize=500)
        entry = (loop, q)
        with hub.lock:
            hub.clients.add(entry)
        try:
            while True:
                try:
                    text = await asyncio.wait_for(q.get(), timeout=1.0)
                except asyncio.TimeoutError:
                    e = engine_ref.get("engine")
                    if e is not None and e.stopping:
                        break  # turning off: close, or the web server would wait for this page forever
                    continue
                await socket.send_text(text)
        except (WebSocketDisconnect, RuntimeError):
            pass
        finally:
            with hub.lock:
                hub.clients.discard(entry)
            try:
                await socket.close()
            except RuntimeError:
                pass


def _origin_ok(origin: str) -> bool:
    from urllib.parse import urlparse

    try:
        parsed = urlparse(origin)
    except ValueError:
        return False
    return parsed.scheme in ("http", "https") and (parsed.hostname or "").lower() in ALLOWED_HOSTS
