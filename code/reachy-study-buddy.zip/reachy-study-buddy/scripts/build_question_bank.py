# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Build reachy_study_buddy/data/question_bank.json from your study-guide web pages.

Reads the exam-style questions (with mark schemes) out of:
  igcse-physics-guide/index.html        div.exq
  igcse-cs-guide/index.html             div.exq
  igcse-biology-guide/*.html            div.q with div.ms
  chemistry-hub/ch*.html                div.quiz[data-quiz] (multiple choice)

Run it again whenever you add questions to those guides:
  python scripts/build_question_bank.py            (looks in the folder above this app)
  python scripts/build_question_bank.py D:\\somewhere\\Projects
"""

from __future__ import annotations

import datetime as dt
import json
import re
import sys
from pathlib import Path

from bs4 import BeautifulSoup, NavigableString, Tag

APP_DIR = Path(__file__).resolve().parents[1]
OUT = APP_DIR / "reachy_study_buddy" / "data" / "question_bank.json"


def clean(text: str) -> str:
    text = re.sub(r"\s+", " ", text.replace("\u00a0", " ")).strip()
    return re.sub(r"\s+([.,;:!?)])", r"\1", text)  # get_text(" ") leaves "diet ." after inline tags


def safe_html(el: Tag) -> str:
    """Question HTML for the web page: drop scripts, event handlers and the mark scheme."""
    el = BeautifulSoup(str(el), "html.parser")
    for bad in el.find_all(["script", "style", "iframe", "details"]):
        bad.decompose()
    for ms in el.select(".ms"):
        ms.decompose()
    for tag in el.find_all(True):
        for attr in list(tag.attrs):
            if attr.lower().startswith("on") or (attr in ("href", "src") and str(tag[attr]).strip().lower().startswith("javascript")):
                del tag[attr]
    return str(el)


def has_figure(el: Tag) -> bool:
    return bool(el.find(["svg", "img", "figure", "canvas", "table"]))


def heading_before(el: Tag, names=("h2",)) -> str:
    h = el.find_previous(list(names))
    return clean(h.get_text(" ")) if h else ""


def parts_text(body: Tag) -> tuple[str, bool]:
    """Intro paragraphs + (a)/(b) parts with their marks, as plain text."""
    lines: list[str] = []
    extended = False
    for child in body.children:
        if isinstance(child, NavigableString):
            if clean(str(child)):
                lines.append(clean(str(child)))
            continue
        if "tot" in (child.get("class") or []):
            continue
        if child.name == "ol":
            for i, li in enumerate(child.find_all("li", recursive=False)):
                li = BeautifulSoup(str(li), "html.parser").li
                marks = ""
                for mk in li.select(".mk"):
                    marks = clean(mk.get_text())
                    mk.decompose()
                for s in li.select(".S"):
                    extended = True
                    s.decompose()
                lines.append(f"({chr(97 + i)}) {clean(li.get_text(' '))} {marks}".strip())
        else:
            for s in child.select(".S") if isinstance(child, Tag) else []:
                extended = True
                s.decompose()
            text = clean(child.get_text(" "))
            if text:
                lines.append(text)
    text = "\n".join(lines)
    text = re.sub(r"^\d+\s+", "", text)  # CS guide numbers its questions
    return text, extended


def total_marks(el: Tag, text: str) -> int:
    tot = el.select_one(".tot")
    if tot:
        m = re.search(r"(\d+)", tot.get_text())
        if m:
            return int(m.group(1))
    return sum(int(x) for x in re.findall(r"\[(\d+)\]", text)) or 1


def mark_scheme_lines(ms: Tag) -> tuple[list[str], str]:
    ms = BeautifulSoup(str(ms), "html.parser")
    for s in ms.select("summary"):
        s.decompose()
    notes = []
    for n in ms.select(".note"):
        notes.append(clean(n.get_text(" ")))
        n.decompose()
    lines = []
    for li in ms.find_all("li"):
        p = li.select_one(".p")
        pts = ""
        if p:
            pts = clean(p.get_text())
            p.decompose()
        lines.append(f"[{pts} mark{'s' if pts not in ('1', '') else ''}] {clean(li.get_text(' '))}" if pts else clean(li.get_text(" ")))
    if not lines:
        whole = re.sub(r"^Mark scheme:?\s*", "", clean(ms.get_text(" ")), flags=re.I)
        if whole:
            lines = [whole]
    return lines, " ".join(notes)


def exq_questions(path: Path, subject: str, prefix: str) -> list[dict]:
    soup = BeautifulSoup(path.read_text(encoding="utf-8"), "html.parser")
    source = clean(soup.title.get_text()) if soup.title else path.stem
    out, counters = [], {}
    for q in soup.select("div.exq"):
        body = q.select_one(".exq-b")
        ms = q.select_one(".ms")
        if not body or not ms:
            continue
        topic = heading_before(q)
        chap = counters.setdefault(topic, len(counters) + 1)
        n = sum(1 for x in out if x["topic"] == topic) + 1
        text, extended = parts_text(body)
        scheme, notes = mark_scheme_lines(ms)
        out.append({
            "id": f"{prefix}-{chap:02d}-{n:02d}",
            "subject": subject,
            "topic": topic,
            "source": source,
            "kind": "written",
            "marks": total_marks(body, text),
            "extended": extended,
            "text": text,
            "html": safe_html(body),
            "mark_scheme": scheme,
            "notes": notes,
            "has_figure": has_figure(body),
        })
    return out


def biology_questions(folder: Path) -> list[dict]:
    out = []
    for path in sorted(folder.glob("*.html")):
        soup = BeautifulSoup(path.read_text(encoding="utf-8"), "html.parser")
        source = clean(soup.title.get_text()) if soup.title else path.stem
        for q in soup.select("div.q"):
            ms = q.select_one(".ms")
            if not ms:
                continue
            qq = BeautifulSoup(str(q), "html.parser").div
            marks = 1
            mk = qq.select_one(".mk")
            if mk:
                m = re.search(r"\d+", mk.get_text())
                marks = int(m.group()) if m else 1
                mk.decompose()
            qq.select_one(".ms").decompose()
            text = re.sub(r"^\d+\.\s*", "", clean(qq.get_text(" ")))
            topic = heading_before(q)
            scheme, notes = mark_scheme_lines(ms)
            out.append({
                "id": f"bio-{path.stem[:12]}-{len(out) + 1:02d}",
                "subject": "biology",
                "topic": topic,
                "source": source,
                "kind": "written",
                "marks": marks,
                "extended": False,
                "text": f"{text} [{marks}]",
                "html": safe_html(qq),
                "mark_scheme": scheme,
                "notes": notes,
                "has_figure": has_figure(qq),
            })
    return out


def chemistry_mcqs(folder: Path) -> list[dict]:
    out = []
    for path in sorted(folder.glob("ch*.html")):
        soup = BeautifulSoup(path.read_text(encoding="utf-8"), "html.parser")
        topic = clean(soup.title.get_text()).split("")[-1].strip() if soup.title else path.stem
        for quiz in soup.select("div.quiz[data-quiz]"):
            for i, item in enumerate(json.loads(quiz["data-quiz"]), 1):
                txt = lambda h: clean(BeautifulSoup(h, "html.parser").get_text(" "))  # noqa: E731
                opts = [txt(o) for o in item["opts"]]
                letters = "ABCD"
                text = txt(item["q"]) + "\n" + "\n".join(f"{letters[j]}: {o}" for j, o in enumerate(opts))
                out.append({
                    "id": f"chem-{path.stem}-{i:02d}",
                    "subject": "chemistry",
                    "topic": topic,
                    "source": f"Chemistry Hub, {clean(soup.title.get_text()) if soup.title else path.stem}",
                    "kind": "mcq",
                    "marks": 1,
                    "extended": False,
                    "text": text,
                    "html": "<p>" + item["q"] + "</p><ol type='A'>" + "".join(f"<li>{o}</li>" for o in item["opts"]) + "</ol>",
                    "options": opts,
                    "answer": letters[item["a"]],
                    "mark_scheme": [f"Answer {letters[item['a']]}: {opts[item['a']]}", txt(item.get("why", ""))],
                    "notes": "",
                    "has_figure": False,
                })
    return out


def main() -> None:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else APP_DIR.parent
    bank: list[dict] = []
    sources = [
        (root / "igcse-physics-guide" / "index.html", lambda p: exq_questions(p, "physics", "phy")),
        (root / "igcse-cs-guide" / "index.html", lambda p: exq_questions(p, "computer_science", "cs")),
        (root / "igcse-biology-guide", biology_questions),
        (root / "chemistry-hub", chemistry_mcqs),
    ]
    for path, reader in sources:
        if not path.exists():
            print(f"skip (not found): {path}")
            continue
        found = reader(path)
        print(f"{len(found):4d} questions from {path}")
        bank.extend(found)
    ids = [q["id"] for q in bank]
    assert len(ids) == len(set(ids)), "duplicate question ids"
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps({"built": dt.date.today().isoformat(), "questions": bank}, indent=1, ensure_ascii=False), encoding="utf-8")
    print(f"wrote {len(bank)} questions to {OUT}")


if __name__ == "__main__":
    main()
