# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""The Claude conversation loop, run against a fake Messages API on localhost.

This checks what we actually send (model, fallbacks, caching, tools) and how the
streamed reply is spoken and stored, without an API key or the internet.
"""

from __future__ import annotations

import io
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import anthropic
import pytest
from PIL import Image

from reachy_study_buddy import brain as brain_mod
from reachy_study_buddy.brain import Brain, echo_content
from reachy_study_buddy.store import Progress, Settings
from reachy_study_buddy.tools import ToolBox


def sse(events: list[dict]) -> bytes:
    return b"".join(f"event: {e['type']}\ndata: {json.dumps(e)}\n\n".encode() for e in events)


def message(blocks: list[dict], stop_reason: str, model: str = "claude-opus-5") -> bytes:
    """A streamed assistant message made of text / tool_use / thinking blocks."""
    ev: list[dict] = [{"type": "message_start", "message": {
        "id": "msg_x", "type": "message", "role": "assistant", "model": model, "content": [],
        "stop_reason": None, "stop_sequence": None,
        "usage": {"input_tokens": 1000, "output_tokens": 1, "cache_creation_input_tokens": 0, "cache_read_input_tokens": 3000}}}]
    for i, b in enumerate(blocks):
        if b["type"] == "text":
            ev.append({"type": "content_block_start", "index": i, "content_block": {"type": "text", "text": ""}})
            for word in b["text"].split(" "):
                ev.append({"type": "content_block_delta", "index": i, "delta": {"type": "text_delta", "text": word + " "}})
        elif b["type"] == "thinking":
            ev.append({"type": "content_block_start", "index": i, "content_block": {"type": "thinking", "thinking": "", "signature": ""}})
            ev.append({"type": "content_block_delta", "index": i, "delta": {"type": "signature_delta", "signature": "sig123"}})
        elif b["type"] == "tool_use":
            ev.append({"type": "content_block_start", "index": i, "content_block": {"type": "tool_use", "id": b["id"], "name": b["name"], "input": {}}})
            ev.append({"type": "content_block_delta", "index": i, "delta": {"type": "input_json_delta", "partial_json": json.dumps(b["input"])}})
        ev.append({"type": "content_block_stop", "index": i})
    ev.append({"type": "message_delta", "delta": {"stop_reason": stop_reason, "stop_sequence": None}, "usage": {"output_tokens": 200}})
    ev.append({"type": "message_stop"})
    return sse(ev)


class FakeAnthropic:
    def __init__(self, replies: list[bytes]):
        self.replies = list(replies)
        self.requests: list[dict] = []
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):  # noqa: N802
                body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                outer.requests.append({"path": self.path, "headers": dict(self.headers), "body": body})
                payload = outer.replies.pop(0)
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

            def log_message(self, *args):
                pass

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.url = f"http://127.0.0.1:{self.server.server_address[1]}"

    def close(self):
        self.server.shutdown()


class FakeEngine:
    def __init__(self, progress):
        from reachy_study_buddy.focus import FocusCoach, Timers
        from reachy_study_buddy.quiz import QuizBank

        self.progress = progress
        self.quiz = QuizBank(progress)
        self.focus = FocusCoach(progress, lambda *a: None)
        self.timers = Timers(lambda *a: None)
        self.cards, self.looked, self.materials_sent = [], [], set()

    def emit(self, *a):
        pass

    def look(self, where):
        self.looked.append(where)
        buf = io.BytesIO()
        Image.new("RGB", (64, 48), "white").save(buf, format="JPEG")
        return buf.getvalue(), ""

    def show_card(self, title, md, kind="note"):
        self.cards.append((title, md))

    def gesture(self, name):
        self.cards.append(("gesture", name))

    def show_question(self, q):
        self.cards.append(("question", q["id"]))

    def show_mark_scheme(self, q, entry):
        pass

    def push_stats(self):
        pass


@pytest.fixture
def setup(tmp_path, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test-key")
    settings = Settings(tmp_path / "s.json")
    settings.update({"student_name": "Alex"})
    progress = Progress(tmp_path / "p.json")
    engine = FakeEngine(progress)
    spoken: list[str] = []
    brain = Brain(settings, progress, ToolBox(engine), speak=spoken.append, emit=lambda *a: None)
    return brain, engine, spoken, progress


def use_server(brain, fake, monkeypatch):
    real = anthropic.Anthropic
    monkeypatch.setattr(brain_mod.anthropic, "Anthropic", lambda **kw: real(**{**kw, "base_url": fake.url}))


def test_look_then_answer(setup, monkeypatch):
    brain, engine, spoken, progress = setup
    fake = FakeAnthropic([
        message([{"type": "thinking"}, {"type": "text", "text": "Let me take a look."},
                 {"type": "tool_use", "id": "toolu_1", "name": "look", "input": {"where": "desk"}}], "tool_use"),
        message([{"type": "text", "text": "Question three wants the resultant velocity. What do you get if you use Pythagoras?"}], "end_turn"),
    ])
    use_server(brain, fake, monkeypatch)
    try:
        result = brain.run_turn([{"type": "text", "text": "Student said: can you check question 3?"}], threading.Event())
    finally:
        fake.close()

    assert result.error is None and not result.cancelled
    assert engine.looked == ["desk"]
    assert spoken == ["Let me take a look.", "Question three wants the resultant velocity.",
                      "What do you get if you use Pythagoras?"]

    first = fake.requests[0]
    body = first["body"]
    assert first["path"].startswith("/v1/messages")
    assert body["model"] == "claude-opus-5"
    assert body["fallbacks"] == "default"
    assert "server-side-fallback-2026-07-01" in first["headers"].get("anthropic-beta", "")
    assert body["thinking"] == {"type": "adaptive"} and body["output_config"] == {"effort": "low"}
    assert body["cache_control"] == {"type": "ephemeral"}
    assert body["system"][0]["cache_control"] == {"type": "ephemeral"}
    assert "Alex" in body["system"][0]["text"]
    assert all(t["eager_input_streaming"] for t in body["tools"])
    assert body["stream"] is True

    second = fake.requests[1]["body"]["messages"]
    assert [m["role"] for m in second] == ["user", "assistant", "user"]
    assert second[1]["content"][0]["type"] == "thinking"  # thinking is echoed back unchanged
    tool_result = second[2]["content"][0]
    assert tool_result["type"] == "tool_result" and tool_result["tool_use_id"] == "toolu_1"
    assert tool_result["content"][1]["type"] == "image"

    assert [m["role"] for m in brain.messages] == ["user", "assistant", "user", "assistant"]
    assert progress.spent_today() > 0


def test_invalid_tool_input_goes_back_as_error(setup, monkeypatch):
    brain, engine, spoken, _ = setup
    fake = FakeAnthropic([
        message([{"type": "tool_use", "id": "toolu_9", "name": "gesture", "input": {"name": "backflip"}}], "tool_use"),
        message([{"type": "text", "text": "Okay, a nod instead."}], "end_turn"),
    ])
    use_server(brain, fake, monkeypatch)
    try:
        brain.run_turn([{"type": "text", "text": "Student said: do a backflip"}], threading.Event())
    finally:
        fake.close()
    result_block = fake.requests[1]["body"]["messages"][2]["content"][0]
    assert result_block["is_error"] is True and "INVALID_INPUT" in result_block["content"]


def test_budget_and_missing_key(setup, monkeypatch):
    brain, engine, spoken, progress = setup
    brain.settings.update({"daily_budget_usd": 0.5})
    progress.add_usage(0.6, 1, 1)
    r = brain.run_turn([{"type": "text", "text": "hi"}], threading.Event())
    assert r.error == "budget" and "spending limit" in spoken[-1]
    monkeypatch.delenv("ANTHROPIC_API_KEY")
    monkeypatch.setattr(brain_mod, "get_api_key", lambda: None)
    r = brain.run_turn([{"type": "text", "text": "hi"}], threading.Event())
    assert r.error == "no_api_key" and brain.messages == []


def test_non_opus_models_skip_opus_only_options(setup, monkeypatch):
    brain, engine, spoken, _ = setup
    brain.settings.update({"model": "claude-haiku-4-5"})
    fake = FakeAnthropic([message([{"type": "text", "text": "Hello there, ready to study?"}], "end_turn", model="claude-haiku-4-5")])
    use_server(brain, fake, monkeypatch)
    try:
        brain.run_turn([{"type": "text", "text": "Student said: hi"}], threading.Event())
    finally:
        fake.close()
    body = fake.requests[0]["body"]
    assert "fallbacks" not in body and "thinking" not in body and "output_config" not in body


def test_echo_content_after_fallback():
    class B:
        def __init__(self, type_, **kw):
            self.type = type_
            self.__dict__.update(kw)

    content = [B("thinking"), B("text", text="partial"), B("tool_use", id="t1"), B("fallback"),
               B("text", text="rest"), B("tool_use", id="t2")]
    kept = echo_content(content)
    assert [b.type for b in kept] == ["text", "text", "tool_use"]
    assert kept[-1].id == "t2"
