# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Tests for the parts that don't need a robot, a microphone or the internet."""

from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import pytest

from reachy_study_buddy import focus as focus_mod
from reachy_study_buddy.focus import FocusCoach, Timers
from reachy_study_buddy.materials import Materials
from reachy_study_buddy.quiz import QuizBank
from reachy_study_buddy.store import Progress, Settings
from reachy_study_buddy.tools import TOOLS, validate
from reachy_study_buddy.voice import SentenceChunker, resample, to_speech


@pytest.fixture
def progress(tmp_path):
    return Progress(tmp_path / "progress.json")


# --- voice -------------------------------------------------------------------------

def test_chunker_releases_whole_sentences_only():
    c = SentenceChunker()
    out = []
    for piece in ["Electrolysis needs ", "free ions. So the ", "compound must be molten", " or dissolved! What do you think?"]:
        out += c.feed(piece)
    assert out == ["Electrolysis needs free ions.", "So the compound must be molten or dissolved!"]
    assert c.flush() == "What do you think?"


def test_chunker_keeps_decimals_and_abbreviations():
    c = SentenceChunker()
    out = c.feed("The answer is 3.14 metres, e.g. about three metres. Next part. ")
    assert out == ["The answer is 3.14 metres, e.g. about three metres."]
    assert c.flush() == "Next part."  # very short sentences wait to join the next one


def test_to_speech_reads_symbols_as_words():
    said = to_speech("**Speed** = 6.0 m/s², that's 50% faster → nice 😀 see https://x.y")
    assert "*" not in said and "😀" not in said and "http" not in said
    assert "metres per second squared" in said and "percent" in said and "gives" in said


@pytest.mark.parametrize("written, spoken", [
    ("6.022 × 10²³ particles", "6.022 times ten to the power 23 particles"),
    ("a = 3.0 m/s²", "a equals 3.0 metres per second squared"),
    ("24 m/s in 8.0 s", "24 metres per second in 8.0 s"),
    ("density 2.7 g/cm³", "density 2.7 grams per cubic centimetre"),
    ("x² + y³", "x squared + y cubed"),
    ("rate = 0.5 mol/dm³", "rate equals 0.5 moles per cubic decimetre"),
    ("H₂O and CO₂", "H2O and CO2"),
    ("(24 - 0) / 8.0", "(24 minus 0) divided by 8.0"),
    ("- Initial velocity = 0\n- Final velocity = 24", "Initial velocity equals 0 Final velocity equals 24"),
    ("s = ½at²", "s equals a halfat squared"),
    ("an A<sub>r</sub> of 35.5", "an A r of 35.5"),
])
def test_to_speech_science(written, spoken):
    assert to_speech(written) == spoken


def test_resample_length_and_range():
    x = np.sin(np.linspace(0, 200, 22050)).astype(np.float32)
    y = resample(x, 22050, 16000)
    assert abs(y.size - 16000) <= 1
    assert np.abs(y).max() <= 1.01


# --- tools -------------------------------------------------------------------------

def test_every_tool_streams_eagerly_and_validates():
    for t in TOOLS:
        assert t["eager_input_streaming"] is True
        assert t["input_schema"]["additionalProperties"] is False
    assert validate("look", {"where": "desk"}) is None
    assert "one of" in validate("look", {"where": "ceiling"})
    assert "Missing" in validate("show_on_screen", {"title": "x"})
    assert "Unexpected" in validate("gesture", {"name": "nod", "extra": 1})
    assert "number" in validate("record_quiz_result", {"marks_awarded": True, "marks_available": 2})
    assert validate("nope", {}) == "Unknown tool nope"


# --- quiz --------------------------------------------------------------------------

@pytest.mark.skipif(not (Path(__file__).parents[1] / "reachy_study_buddy" / "data" / "question_bank.json").exists(),
                    reason="question bank is not included in this download")
def test_quiz_picks_by_subject_and_topic(progress):
    bank = QuizBank(progress)
    assert len(bank.questions) >= 100
    q, why = bank.pick("chemistry", "mole")
    assert q is not None and q["subject"] == "chemistry" and "Mole" in q["topic"], why
    q, why = bank.pick("cs", "boolean logic")
    assert q is not None and q["subject"] == "computer_science" and q["topic"] == "Boolean logic"
    q, why = bank.pick("history")
    assert q is None and "no question bank" in why.lower()
    q, why = bank.pick("physics", "quantum chromodynamics")
    assert q is None and "Topics in physics" in why


@pytest.mark.skipif(not (Path(__file__).parents[1] / "reachy_study_buddy" / "data" / "question_bank.json").exists(),
                    reason="question bank is not included in this download")
def test_quiz_spaced_repetition(progress):
    bank = QuizBank(progress)
    q, _ = bank.pick("biology")
    bank.record(3, 3, question_id=q["id"])
    assert bank.state(q["id"])["box"] == 1
    bank.record(0, 3, question_id=q["id"])
    assert bank.state(q["id"])["box"] == 0
    bank.record(1, 2, subject="maths", topic="quadratics")  # a question Claude wrote itself
    s = bank.summary()
    assert s["answered_today"] == 3
    assert s["by_subject"]["maths"]["percent"] == 50


# --- focus -------------------------------------------------------------------------

class Clock:
    def __init__(self):
        self.t = 1000.0

    def __call__(self):
        return self.t


def test_focus_cycle_and_presence(progress, monkeypatch):
    clock = Clock()
    monkeypatch.setattr(focus_mod.time, "monotonic", clock)
    events = []
    coach = FocusCoach(progress, lambda k, p: events.append((k, p)))
    coach.start(focus_min=10, break_min=2, cycles=2, goal="ch 9", away_after_s=60)
    assert events[-1][0] == "focus_start"
    for _ in range(90):  # 90 s with no face -> away
        clock.t += 1
        coach.tick(False)
    assert ("left" in [e[0] for e in events]) and coach.status()["away"]
    clock.t += 1
    coach.tick(True)
    assert events[-1][0] == "returned"
    clock.t = 1000 + 10 * 60 + 0.5  # the block ends on time
    coach.tick(True)
    assert events[-1][0] == "break_start"
    block = progress.data["focus_log"][-1]
    assert 7.5 < block["focused_min"] < 9.0 and block["away_min"] > 1.0
    clock.t += 2 * 60 + 1
    coach.tick(None)
    assert events[-1] == ("focus_start", {"cycle": 2, "cycles": 2, "minutes": 10.0, "goal": "ch 9"})
    clock.t += 10 * 60 + 1
    coach.tick(True)
    assert events[-1][0] == "session_done" and coach.phase == "idle"


def test_timers_fire(monkeypatch):
    clock = Clock()
    monkeypatch.setattr(focus_mod.time, "monotonic", clock)
    fired = []
    timers = Timers(lambda k, p: fired.append(k))
    timers.add(0.5, "question 3")
    clock.t += 31
    timers.tick()
    assert "timer_done" in fired and timers.list() == []


# --- materials ------------------------------------------------------------------------

def test_reading_mode_saves_a_chapter(tmp_path):
    mats = Materials(tmp_path / "materials")
    mats.start("Ch 9 The Mole", "chemistry")
    mats.add("One mole of any substance contains six point zero two times ten to the twenty three particles.")
    mats.add("Molar mass is the mass of one mole, in grams per mole.")
    assert mats.recording_status()["words"] > 20
    item = mats.finish()
    assert item["title"] == "Ch 9 The Mole" and mats.active()["id"] == item["id"]
    again = Materials(tmp_path / "materials")  # survives a restart
    assert again.find("the mole chapter")["text"].startswith("One mole")
    mats.start("empty")
    assert mats.finish() is None


# --- settings ------------------------------------------------------------------------

def test_settings_are_validated(tmp_path):
    s = Settings(tmp_path / "settings.json")
    after = s.update({"daily_budget_usd": 999, "model": "gpt-4", "focus_minutes": "30", "student_name": "  Alex ", "bogus": 1})
    assert after["daily_budget_usd"] == 20.0
    assert after["model"] == "claude-opus-5"
    assert after["focus_minutes"] == 30
    assert after["student_name"] == "Alex"
    assert "bogus" not in after
    assert Settings(tmp_path / "settings.json").get("focus_minutes") == 30
