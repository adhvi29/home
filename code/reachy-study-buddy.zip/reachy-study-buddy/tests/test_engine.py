# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""How the engine routes what Reachy hears: standby, its name, conversation and reading mode."""

from __future__ import annotations

import pytest

from reachy_study_buddy.engine import WAKE, Engine
from reachy_study_buddy.materials import Materials
from reachy_study_buddy.store import Progress, Settings


class StubIO:
    has_body = False
    name = "Laptop"

    def __init__(self):
        self.gestures = []

    def face_present(self):
        return None

    def gesture(self, name):
        self.gestures.append(name)
        return 0.0

    def hold(self, where):
        pass

    def set_mode(self, mode):
        pass

    def antenna_touched(self):
        return False

    def set_presence_watch(self, on):
        pass


@pytest.fixture
def eng(tmp_path):
    e = Engine(StubIO(), Settings(tmp_path / "s.json"), Progress(tmp_path / "p.json"), lambda msg: None)
    e.materials = Materials(tmp_path / "materials")
    e.state = "standby"
    started: list[tuple[str, str]] = []
    e._start_turn = lambda text, source: started.append((text, source))
    return e, started


@pytest.mark.parametrize("said, expected", [
    ("look up", ("point", "up")),
    ("Reachy, look to the left!", ("point", "left")),
    ("can you turn right please", ("point", "right")),
    ("look at the ceiling", ("point", "up")),
    ("look around", ("gesture", "search")),
    ("Reachy dance", ("gesture", "dance")),
    ("wag your antennas", ("gesture", "excited")),
    ("show me how you look when you're angry", ("gesture", "angry")),
    ("be sad", ("gesture", "sad")),
])
def test_quick_movement_commands(said, expected):
    from reachy_study_buddy.commands import parse

    kind, what, _reply = parse(said)
    assert (kind, what) == expected


@pytest.mark.parametrize("said", ["look up the formula for density", "turn the page", "I'm sad about my test",
                                  "what is a dance of electrons", "look at my worksheet"])
def test_normal_questions_are_not_commands(said):
    from reachy_study_buddy.commands import parse

    assert parse(said) is None


def test_wake_word_matching():
    for yes in ["Reachy, quiz me", "hey richie", "Ritchie can you help", "OK reachy."]:
        assert WAKE.search(yes), yes
    for no in ["the reaction reaches equilibrium", "reach for the top", "a rich source of iron"]:
        assert not WAKE.search(no), no


def test_standby_ignores_speech_not_for_reachy(eng):
    e, started = eng
    e._on_heard("I'll finish this worksheet later")
    assert started == [] and e.transcript[-1]["who"] == "heard"


def test_name_alone_wakes_it_up(eng):
    e, started = eng
    e._on_heard("Hey Reachy!")
    assert started == [] and e.state == "conversation" and "perk" in e.io.gestures


def test_name_with_a_request_starts_a_turn(eng):
    e, started = eng
    e._on_heard("Reachy, quiz me on moles")
    assert started == [("Reachy, quiz me on moles", "voice")]


def test_conversation_needs_no_name(eng):
    e, started = eng
    e.state = "conversation"
    e._on_heard("what's a mole")
    assert started == [("what's a mole", "voice")]


def test_reading_mode_writes_down_the_chapter(eng):
    e, started = eng
    e.start_reading("Ch 9 The Mole", "chemistry")
    e._on_heard("One mole of any substance contains the Avogadro number of particles.")
    e._on_heard("The molar mass is the mass of one mole in grams.")
    assert started == []
    assert e.materials.recording_status()["words"] > 15
    e._on_heard("Reachy, what does molar mass mean?")
    assert started == [("Reachy, what does molar mass mean?", "voice")]
    content = e._build_content("Reachy, what does molar mass mean?", "voice")
    reading_block = [b for b in content if b["type"] == "text" and b["text"].startswith("[Reading mode is on")]
    assert reading_block and "molar mass is the mass" in reading_block[0]["text"]


def test_finished_chapter_is_attached_once(eng):
    e, started = eng
    e.start_reading("Ch 9 The Mole", "chemistry")
    e._on_heard("One mole of any substance contains the Avogadro number of particles.")
    item = e.finish_reading()
    first = e._build_content("I've finished reading.", "button")
    docs = [b for b in first if b["type"] == "document"]
    assert len(docs) == 1 and docs[0]["title"] == item["title"]
    second = e._build_content("quiz me on it", "voice")
    assert not [b for b in second if b["type"] == "document"]  # already in the conversation
    assert "Saved chapters: 1" in second[0]["text"]
