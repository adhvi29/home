# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""Voice in, text out: Piper speaks a sentence, the listener cuts it out with VAD and
Whisper transcribes it. Needs the downloaded models, so it is skipped without them."""

from __future__ import annotations

import threading
import time

import numpy as np
import pytest

from reachy_study_buddy.hearing import FRAME, Listener, SileroVAD, Transcriber
from reachy_study_buddy.store import MODELS_DIR

pytestmark = pytest.mark.skipif(not (MODELS_DIR / "piper" / "en_GB-alba-medium.onnx").exists(), reason="voice model not downloaded")


@pytest.fixture(scope="module")
def speech():
    from reachy_study_buddy.voice import PiperTTS

    tts = PiperTTS("en_GB-alba-medium")
    return tts.synth("Reachy, can you quiz me on the mole chapter?")


def test_streaming_vad_matches_batch(speech):
    from faster_whisper.vad import SileroVADModel
    import faster_whisper
    from pathlib import Path

    audio = np.concatenate([np.zeros(8000, np.float32), speech, np.zeros(8000, np.float32)])
    audio = audio[: audio.size - audio.size % FRAME]
    batch = SileroVADModel(str(Path(faster_whisper.__file__).parent / "assets" / "silero_vad_v6.onnx"))(audio).reshape(-1)
    vad = SileroVAD()
    stream = np.array([vad(audio[i:i + FRAME]) for i in range(0, audio.size, FRAME)])
    assert np.allclose(batch, stream, atol=1e-3)
    assert stream.max() > 0.9 and stream[:10].max() < 0.3  # silence, then clear speech


def test_listener_and_whisper(speech):
    stt = Transcriber("auto")
    stt.load()
    rng = np.random.default_rng(1)
    stream = np.concatenate([rng.normal(0, 0.002, 16000).astype(np.float32), speech,
                             rng.normal(0, 0.002, 32000).astype(np.float32)])
    chunks = [stream[i:i + 320] for i in range(0, stream.size, 320)]  # 20 ms chunks like the robot's
    got: list[np.ndarray] = []
    done = threading.Event()

    def read():
        return chunks.pop(0) if chunks else None

    def on_utt(a):
        got.append(a)
        done.set()

    listener = Listener(read, on_utt, lambda: None, lambda lvl: None, lambda: False, lambda: 700)
    listener.start()
    done.wait(10)
    listener.stop()
    assert len(got) == 1
    assert 2.0 < got[0].size / 16000 < speech.size / 16000 + 1.0
    t0 = time.time()
    plain = stt.transcribe(got[0])
    print(f"\n{stt.describe()}: '{plain}' in {time.time() - t0:.2f}s")
    assert "reachy" in plain.lower() and "chapter" in plain.lower()
    # Knowing what's being studied fixes subject words ("more" -> "mole").
    hinted = stt.transcribe(got[0], hint="chemistry Chapter 9: The Mole.")
    print(f"with a hint: '{hinted}'")
    assert "mole" in hinted.lower()
