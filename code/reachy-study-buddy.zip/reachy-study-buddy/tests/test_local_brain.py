# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""The local (Ollama) brain against a fake Ollama server: streaming, tool calls, photos."""

from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import pytest

from reachy_study_buddy import local_brain as lb
from reachy_study_buddy.local_brain import LocalBrain, to_ollama_message
from reachy_study_buddy.store import Settings
from reachy_study_buddy.tools import ToolBox

from test_brain import FakeEngine  # noqa: E402  (same fake robot)


def ndjson(chunks: list[dict]) -> bytes:
    return b"".join(json.dumps(c).encode() + b"\n" for c in chunks)


class FakeOllama:
    def __init__(self, replies: list[list[dict]], models=("qwen3.5:4b",)):
        self.replies, self.requests, outer = list(replies), [], self

        class H(BaseHTTPRequestHandler):
            def do_GET(self):  # noqa: N802
                body = json.dumps({"models": [{"name": m} for m in models]}).encode()
                self.send_response(200)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_POST(self):  # noqa: N802
                outer.requests.append(json.loads(self.rfile.read(int(self.headers["Content-Length"]))))
                body = ndjson(outer.replies.pop(0))
                self.send_response(200)
                self.send_header("Content-Type", "application/x-ndjson")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *a):
                pass

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.url = f"http://127.0.0.1:{self.server.server_address[1]}"


def words(text: str) -> list[dict]:
    return [{"message": {"role": "assistant", "content": w + " "}, "done": False} for w in text.split(" ")]


@pytest.fixture
def local(tmp_path, monkeypatch):
    from reachy_study_buddy.store import Progress

    settings = Settings(tmp_path / "s.json")
    settings.update({"brain": "local", "student_name": "Alex"})
    engine = FakeEngine(Progress(tmp_path / "p.json"))
    spoken: list[str] = []
    return LocalBrain(settings, ToolBox(engine), spoken.append, lambda *a: None), engine, spoken, monkeypatch


def test_local_turn_with_look(local):
    brain, engine, spoken, monkeypatch = local
    fake = FakeOllama([
        words("Let me have a look.") + [{"message": {"role": "assistant", "content": "", "tool_calls": [
            {"function": {"name": "look", "arguments": {"where": "desk"}}}]}, "done": False}, {"done": True, "message": {}}],
        words("It's asking for the resultant velocity. Try Pythagoras.") + [{"done": True, "message": {}}],
    ])
    monkeypatch.setattr(lb, "OLLAMA_URL", fake.url)
    r = brain.run_turn([{"type": "text", "text": "[Context] ..."}, {"type": "text", "text": "Student said: check question 3"}], threading.Event())
    fake.server.shutdown()
    assert r.error is None
    assert engine.looked == ["desk"]
    assert spoken[0] == "Let me have a look." and spoken[-1] == "Try Pythagoras."
    first = fake.requests[0]
    assert first["model"] == "qwen3.5:4b" and first["stream"] is True and first["think"] is False
    assert first["messages"][0]["role"] == "system" and "Alex" in first["messages"][0]["content"]
    assert {t["function"]["name"] for t in first["tools"]} >= {"look", "show_on_screen", "start_reading"}
    second = fake.requests[1]["messages"]
    assert [m["role"] for m in second[1:]] == ["user", "assistant", "tool", "user"]
    assert second[-1]["images"]  # the photo rides along in a user message


def test_local_not_ready(local):
    brain, engine, spoken, monkeypatch = local
    monkeypatch.setattr(lb, "OLLAMA_URL", "http://127.0.0.1:9")  # nothing listening
    r = brain.run_turn([{"type": "text", "text": "hi"}], threading.Event())
    assert r.error == "ollama_offline" and "Ollama" in spoken[-1]
    fake = FakeOllama([], models=("something-else",))
    monkeypatch.setattr(lb, "OLLAMA_URL", fake.url)
    r = brain.run_turn([{"type": "text", "text": "hi"}], threading.Event())
    fake.server.shutdown()
    assert r.error == "model_missing" and "ollama pull qwen3.5:4b" in spoken[-1]


def test_content_conversion():
    msg = to_ollama_message([
        {"type": "text", "text": "[Context] Friday."},
        {"type": "document", "title": "Ch 9", "context": "transcript", "source": {"type": "text", "media_type": "text/plain", "data": "Moles..."}},
        {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": "AAAA"}},
        {"type": "text", "text": "Student said: hi"},
    ])
    assert msg["role"] == "user" and msg["images"] == ["AAAA"]
    assert "Moles..." in msg["content"] and msg["content"].endswith("Student said: hi")
