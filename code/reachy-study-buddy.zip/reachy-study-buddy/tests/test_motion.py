# Copyright (c) 2026 Adhvik Mahesh. All rights reserved.
# Reachy Study Buddy - https://github.com/adhvi29
# You may view and run this code for personal and educational use only.
# You may not copy it into other projects, redistribute, sell, or present
# it as your own work without written permission from the author.
# Removing or changing this notice is not permitted. See LICENSE.txt.

"""The motion loop against a fake robot: looking at the student, the base, speech bob, limits."""

from __future__ import annotations

import math

import numpy as np

from reachy_study_buddy.motion import LIMITS, MAX_HEAD_VS_BODY, MotionController, speech_envelope


def head_pose(x=0, y=0, z=0, roll=0, pitch=0, yaw=0, mm=True, degrees=True):
    return {"z": z, "roll": roll, "pitch": pitch, "yaw": yaw}


class FakeMini:
    def __init__(self):
        self.targets = []

    def set_target(self, head, antennas, body_yaw):
        self.targets.append((head, list(antennas), math.degrees(body_yaw)))

    def get_present_antenna_joint_positions(self):
        return [-0.17, 0.17]


def run(motion: MotionController, seconds: float, t0: float | None = None) -> float:
    """Step the loop on a simulated clock that starts now (gestures are stamped with the real clock)."""
    import time as _t

    t = _t.monotonic() if t0 is None else t0
    for _ in range(int(seconds * 50)):
        t += 0.02
        motion._step(t, 0.02)
    return t


def test_turns_head_and_base_towards_a_face():
    mini = FakeMini()
    m = MotionController(mini, create_head_pose=head_pose)
    m.set_mode("listening")
    import time as _t

    # The student sits 30 degrees to the right. Each frame reports the offset from where the head pointed.
    true_yaw = -30.0
    for _ in range(40):
        now = _t.monotonic()
        m.set_face_angles(true_yaw - m.current["yaw"], 0.0, now + 0.12)
        run(m, 0.07, t0=now)
    head, _ant, body = mini.targets[-1]
    assert abs(head["yaw"] - true_yaw) < 4  # looking right at the student
    assert body < -10  # the base turned too
    assert abs(head["yaw"] - body) <= MAX_HEAD_VS_BODY + 1e-6
    # Tiny detector jitter doesn't move the head once it's on target.
    before = m._aim_goal
    m.set_face_angles(0.8, -0.6, _t.monotonic() + 0.12)
    assert m._aim_goal == before


def test_everything_stays_inside_limits():
    mini = FakeMini()
    m = MotionController(mini, create_head_pose=head_pose)
    for g in ["dance", "celebrate", "search", "stretch", "shake", "sad", "surprised"]:
        m.gesture(g)
        t = run(m, 0.0)
        m.gesture_start = t  # start the gesture on the simulated clock
        run(m, 4.5, t0=t)
    for head, ant, body in mini.targets:
        assert LIMITS["pitch"][0] - 1e-6 <= head["pitch"] <= LIMITS["pitch"][1] + 1e-6
        assert LIMITS["roll"][0] - 1e-6 <= head["roll"] <= LIMITS["roll"][1] + 1e-6
        assert abs(head["yaw"] - body) <= MAX_HEAD_VS_BODY + 1e-6
        assert all(-1.31 <= a <= 1.31 for a in ant)
    bodies = [b for _, _, b in mini.targets]
    assert max(bodies) - min(bodies) > 20  # the dance and search really turn the base


def test_speech_bob_follows_the_voice():
    loud = (np.sin(np.arange(16000) / 5) * 0.5).astype(np.float32)
    env = speech_envelope(np.concatenate([loud, np.zeros(16000, np.float32)]))
    assert env.size == 100 and env[:40].mean() > 0.8 and env[60:].max() < 0.1
    mini = FakeMini()
    m = MotionController(mini, create_head_pose=head_pose)
    m.set_mode("speaking")
    import time as _t

    now = _t.monotonic()
    m.speak(np.concatenate([loud, loud]), start=now)
    run(m, 1.0, t0=now)
    pitches = [h["pitch"] for h, _, _ in mini.targets]
    assert max(pitches) - min(pitches) > 0.8  # the head moves while talking
